#!/bin/sh

Mlog -x $MTIMEOUT monetdb-xquery-config --conds
