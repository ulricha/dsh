/**
 * @file
 *
 * Transforms the logical algebra tree into a tree that represents
 * SQL statements.
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * $Id$
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"

/** assert() */
#include <assert.h>
/** fprintf() */
#include <stdio.h>
/** strcpy, strlen, ... */
#include <string.h>

#include "oops.h"             /* PFoops() */
#include "mem.h"
#include "array.h"
#include "string_utils.h"

#include "lalg2sqlalg.h"

/* Easily access subtree-parts */
#include "child_mnemonic.h"

#include "sqlalg.h"
#include "algebra.h"
#include "alg_dag.h"
#include "ordering.h"
#include "properties.h"

#include "sqlalg_mnemonic.h"
#include "sqlalg_opt.h"

/* Mnemonic for SQL algebra annotation */
#define OP(n)       ((n)->sa_ann->op)
#define PRJ_LIST(n) ((n)->sa_ann->prj_list)
#define SEL_LIST(n) ((n)->sa_ann->sel_list)


#define IS_NUM_GEN(op)   ((op)->kind == la_rownum || \
                          (op)->kind == la_rowrank || \
                          (op)->kind == la_rank)

#define ANTISEMIJOIN_FLAG(op)    L((op))->kind == la_difference && \
                                 PFprop_key (L((op))->prop, (op)->sem.eqjoin.col1) && \
                                 R((op))->kind == la_project && \
                                 PFprop_key (R((op))->prop, (op)->sem.eqjoin.col2)

/* Auxiliary function that searches for a certain col
   in a expression list and returns an expression
   representing the found column. If no column was
   found, NULL will be returned */
static PFsa_expr_t *
find_expr (PFsa_exprlist_t *expr_list, PFalg_col_t col)
{
    unsigned int i;
    PFsa_expr_t *curr_expr = NULL;

    for (i = 0; i < elsize(expr_list); i++) {
        curr_expr = elat(expr_list, i);
        if ((curr_expr->col) == col)
            return curr_expr;
    }
    return NULL;
}

/* Auxiliary function that constructs an expression list containing
   column references of the columns in a schema */
static PFsa_exprlist_t *
exprlist_from_schema (PFalg_schema_t schema)
{
    unsigned int i;
    PFsa_exprlist_t *ret = el(schema.count);

    for (i = 0; i < schema.count; i++) {
        eladd(ret) = PFsqlalg_expr_column (schema.items[i].name, 
                                           schema.items[i].type);
    }
    return ret;
}

/* Auxiliary function to get a copy of the complete expression tree
   of expression @a n */
static PFsa_expr_t *
deep_copy_expr (PFsa_expr_t *n)
{
    PFsa_expr_t *ret = PFmalloc (sizeof(PFsa_expr_t));
    memcpy (ret, n, sizeof(PFsa_expr_t));
    unsigned int i;

    for (i = 0; i < PFSA_EXPR_MAXCHILD && n->child[i]; i++) {
        ret->child[i] = deep_copy_expr (n->child[i]);
    }

    return ret;
}

/* Bind a SQL algebra operator to a la operator during translation. That is:
   Put a selection and projection operator on top of the current
   operator to 'materialize' changes in schema and predicates */
static void
bindop (PFla_op_t *n)
{
    PFsa_expr_t *expr;
    unsigned int   i;        
    bool           identical_cols = true;

    /* check if there are any selection predicates, if not,
       do not build selection operator! */
    if(elsize(SEL_LIST(n))) {
        OP(n) = PFsqlalg_op_select (OP(n), SEL_LIST(n));
    }

    /* check if the projection list only contains projection items
       with equal names */
    for (i = 0; i < elsize (PRJ_LIST(n)); i++) {
        expr = elat(PRJ_LIST(n), i);
        identical_cols &= expr->kind == sa_expr_column &&
                          expr->sem.col.old == expr->col;
    }
            
    /* only generate a projection if some changes to the
       input schema are present */
    if (!identical_cols ||
        elsize (PRJ_LIST(n)) != OP(n)->schema.count) {
        OP(n) = PFsqlalg_op_project (OP(n), false, PRJ_LIST(n));
    }

    PRJ_LIST(n) = exprlist_from_schema (n->schema);
    SEL_LIST(n) = el(1);

    return;
}

/* ----- Translate the logical algebra into SQL algebra ----- */

/* Worker that performes translation from la to SQL algebra. Note that
   not every operator is translated 1-to-1 but so called selection
   and projection lists are carried along, which represent changes
   in schema (e.g. attaching of a row) or selection predicates.

   The function is bottom-up: We descend to leaf nodes, compute
   operators and lists and write them to an annotation field (sa_ann)
   in the original la operator */
static void
alg2sqlalg_worker(PFla_op_t *n)
{
    unsigned int i;

    /* traverse child operators recursively */
    for (i = 0; i < PFLA_OP_MAXCHILD && n->child[i]; i++) {
        if (!n->child[i]->bit_dag)
            alg2sqlalg_worker(n->child[i]);
    }

    /* build annotation */
    n->sa_ann = PFmalloc(sizeof(PFsa_ann_t));

    /* mark node vistited */
    n->bit_dag = true;

    switch (n->kind) {

       case la_serialize_seq:
       case la_serialize_rel:
        {
            /* TODO Check for constant columns because of SQL errors...
               if (!PFprop_const (n->prop, pos_col))
               TODO Check if scenarioL: col AS pos, ..., col AS item works */

            PFla_op_t               *child_la_op = NULL;
            PFalg_col_t              curr_col;
            PFsa_expr_t             *curr_expr   = NULL;
            PFsa_expr_t             *expr_copy   = NULL;
            PFsa_exprlist_t         *orderlist   = NULL;
            PFalg_collist_t         *collist     = NULL;
            PFalg_col_t              pos_col     = n->kind == la_serialize_seq ?
                                                   n->sem.ser_seq.pos :
                                                   n->sem.ser_rel.pos;

            /* build order list containing pos columns */
            orderlist = el(1);
 
            /* Bind node with LA DAG: If the pos column is a number
               generating operator, do not build it and put its
               semantical content directly in the orderlist */
            if (IS_NUM_GEN (R(n)) &&
                R(n)->sem.sort.res == pos_col){

                bindop(RL(n));
                child_la_op = RL(n);

                /* Put the number generating operators sort columns in orderlist*/
                for (i = 0; i < PFord_count (R(n)->sem.sort.sortby); i++) {
                    curr_col = PFord_order_col_at (R(n)->sem.sort.sortby, i);
                    curr_expr = find_expr (PRJ_LIST(child_la_op),
                                           curr_col);

                    /* Copy the current expression, take sortorder into account */
                    expr_copy = deep_copy_expr (curr_expr);
                    expr_copy->sortorder = PFord_order_dir_at (R(n)->sem.sort.sortby, i);

                    eladd(orderlist) = expr_copy;
                }
            } else {
                bindop(R(n));
                child_la_op = R(n);
                eladd(orderlist) = find_expr (PRJ_LIST(child_la_op),
                                              pos_col);
            }

            if (n->kind == la_serialize_seq) {
                /* build list containing the item column */
                collist = PFalg_collist(1);
                PFalg_collist_add(collist) = n->sem.ser_seq.item;
            }
            
            OP(n) = PFsqlalg_op_serialize_rel (OP (child_la_op),
                                               OP (L(n)),
                                               n->kind == la_serialize_seq ?
                                                   col_NULL :
                                                   n->sem.ser_rel.iter,
                                               orderlist,
                                               n->kind == la_serialize_seq ?
                                                   collist :
                                                   n->sem.ser_rel.items);

            /* not necessary to set neither project nor select list */
        }
            break;

        case la_side_effects:

            /* build operator and lists */
            OP(n) = PFsqlalg_op_nil_node ();
            PRJ_LIST(n) = NULL;
            SEL_LIST(n) = NULL;

            break;

        case la_lit_tbl:
            /* Build literal table operator with the information
               of the original la operator. */

            /* build operator and lists */
            OP(n) = PFsqlalg_op_literal_table (n->schema, n->sem.lit_tbl.count,
                                               n->sem.lit_tbl.tuples);
            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            SEL_LIST(n) = el(1);

            break;

        case la_empty_tbl:
            /* Build empty table operator with the schema
             of the original la operator. */

            /* build operator and lists */
            OP(n) = PFsqlalg_op_literal_table (n->schema, 0,
                                               NULL);
            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            SEL_LIST(n) = el(1);

            break;

        case la_ref_tbl:
        {
            /* Build table reference operator with the information
               of the original la operator. Therefor construct a list
               of atom expressions representing the original column
               names */

            char*               table_name;
            char*               org_name;
            PFsa_exprlist_t    *col_names_list = NULL;
            PFsa_expr_t        *atom           = NULL;

            table_name = PFstrdup (n->sem.ref_tbl.name);

            /* fill projection list with original names of columns */
            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            col_names_list = el(PFarray_last (n->sem.ref_tbl.tcols));

            for (i = 0; i < PFarray_last (n->sem.ref_tbl.tcols); i++){
                org_name = *(char**) PFarray_at (n->sem.ref_tbl.tcols, i);

                atom = PFsqlalg_expr_atom (n->schema.items[i].name,
                                           PFalg_lit_str(org_name));

                eladd(col_names_list) = atom;
            }

            /* build operator and lists */
            OP(n) = PFsqlalg_op_table (table_name,
                                       n->schema,
                                       PRJ_LIST(n),
                                       col_names_list);

            SEL_LIST(n) = el(1);
        }
            break;

        case la_attach:
            /* Append atom expression representing attached value
             to projection list. Operator and selection list stay
             unchanged. */

            OP(n) = OP (L(n));
            PRJ_LIST(n) = elcopy (PRJ_LIST (L(n)));

            eladd(PRJ_LIST(n)) = PFsqlalg_expr_atom (n->sem.attach.res,
                                                     n->sem.attach.value);
            SEL_LIST(n) = SEL_LIST (L(n));

            break;

        case la_cross:

            bindop(L(n));
            bindop(R(n));

            /* build operator and lists */
            OP(n) = PFsqlalg_op_cross (OP(L(n)), OP(R(n)));

            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            SEL_LIST(n) = el(1);
      
            break;

        case la_eqjoin:
        case la_semijoin:
        {
            /* Translate eqjoin/semijoin operator. Bind both children
             and build join operator with selection predicates. */

            PFsa_exprlist_t    *exprlist     = el(1);
            PFsa_expr_t        *expr         = NULL;
            PFsa_expr_t        *left_col     = NULL;
            PFsa_expr_t        *right_col    = NULL;

            bindop(L(n));
            bindop(R(n));

            left_col = find_expr (PRJ_LIST (L(n)),
                                  n->sem.eqjoin.col1);
            right_col = find_expr (PRJ_LIST (R(n)),
                                   n->sem.eqjoin.col2);

            /* build expression for equality condition */
            expr = PFsqlalg_expr_comp (left_col,
                                       right_col,
                                       sa_comp_equal,
                                       PFcol_new(col_item));
            eladd(exprlist) = expr;

            switch (n->kind) {
                case la_eqjoin:
                    OP(n) = PFsqlalg_op_join (OP(L(n)),
                                              OP(R(n)),
                                              exprlist);

                    break;
                case la_semijoin:
                    OP(n) = PFsqlalg_op_semijoin (OP(L(n)),
                                                  OP(R(n)),
                                                  exprlist);
                    break;
                default:
                    break;
            }

            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            SEL_LIST(n) = el(1);

            /* Set antisemijoin flag for optimization if appropriate */
            if (ANTISEMIJOIN_FLAG(n))
                OP(n)->sem.join.antisemijoin_flag = true;
        }
            break;

        case la_thetajoin:
        {
            /* Translate thetajoin operator. Bind both children
             and build join operator with selection predicates. */

            PFsa_exprlist_t        *exprlist  = NULL;
            PFsa_comp_kind_t        comp_kind = sa_comp_equal;
            PFalg_sel_t             curr_pred;
            PFsa_expr_t            *left_col  = NULL;
            PFsa_expr_t            *right_col = NULL;
            PFsa_expr_t            *pred_expr;

            bindop(L(n));
            bindop(R(n));

            /* build list with join predicates */
            exprlist = el(n->sem.thetajoin.count);
            for (i = 0; i < n->sem.thetajoin.count; i++) {

                curr_pred = n->sem.thetajoin.pred[i];

                left_col = find_expr (PRJ_LIST (L(n)),
                                      curr_pred.left);

                right_col = find_expr (PRJ_LIST (R(n)),
                                       curr_pred.right);

                /* determine adequate comparison kind */
                switch (curr_pred.comp) {
                    case alg_comp_eq:
                        comp_kind = sa_comp_equal;
                        break;
                    case alg_comp_gt:
                        comp_kind = sa_comp_gt;
                        break;
                    case alg_comp_ge:
                        comp_kind = sa_comp_gte;
                        break;
                    case alg_comp_lt:
                        comp_kind = sa_comp_lt;
                        break;
                    case alg_comp_le:
                        comp_kind = sa_comp_lte;
                        break;
                    case alg_comp_ne:
                        comp_kind = sa_comp_notequal;
                        break;
                }

                /* build expression 'left_col comp right_col' */
                pred_expr = PFsqlalg_expr_comp (left_col, 
                                                right_col,
                                                comp_kind,
                                                PFcol_new(col_item));
                eladd(exprlist) = pred_expr;
            }

            OP(n) = PFsqlalg_op_join (OP(L(n)),
                                      OP(R(n)),
                                      exprlist);

            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            SEL_LIST(n) = el(1);
        }
            break;

        case la_project:
        {
            /* Translate project operator. Note that actually NO
             SQL algebra project operator is built, filling the projection
             list with the columns of the la operator projection
             list suffices. Operator and selection list stay
             unchanged. */

            PFsa_expr_t        *expr;
            PFsa_expr_t        *expr_cpy;

            OP(n) = OP (L(n));
            PRJ_LIST(n) = el(n->sem.proj.count);

            /* add only those expressions to projection
             list which appear in proj list */
            for (i = 0; i < n->sem.proj.count; i++) {
                expr = find_expr (PRJ_LIST (L(n)),
                                  n->sem.proj.items[i].old);

                /* copy expression. copy expression deep if the PRJ_LIST
                   of L(n) is potentially accessed twice or more to prevent
                   edges between different operators in DOT output */
                if (L(n)->refctr > 1) {
                    expr_cpy = PFmalloc (sizeof(PFsa_expr_t));
                    memcpy (expr_cpy, expr, sizeof(PFsa_expr_t));
                }
                else
                    expr_cpy = deep_copy_expr (expr);

                /* consider possible renaming */
                expr_cpy->col = n->sem.proj.items[i].new;

                eladd(PRJ_LIST(n)) = expr_cpy;
            }

            SEL_LIST(n) = SEL_LIST (L(n));
        }
            break;

        case la_select:
        {
            /* Translate select operator. Note that actually NO
             SQL algebra select operator is built, adding the selection
             column to the selection list suffices. Operator and
             projection list stay unchanged. */

            PFsa_expr_t        *expr;
            PFsa_expr_t        *expr_cpy;

            OP(n) = OP (L(n));
            PRJ_LIST(n) = PRJ_LIST (L(n));

            SEL_LIST(n) = elcopy(SEL_LIST (L(n)));

            /* find "selected" col */
            expr = find_expr (PRJ_LIST(n),
                              n->sem.select.col);

            /* deep copy */
            expr_cpy = deep_copy_expr (expr);

            if (expr->kind == sa_expr_column ||
                expr->type == aat_int)
                eladd(SEL_LIST(n)) = PFsqlalg_expr_comp (expr_cpy,
                                                         PFsqlalg_expr_atom (
                                                             PFcol_new (col_item),
                                                             PFalg_lit_int (1)),
                                                         sa_comp_equal,
                                                         PFcol_new (col_item));
            else
                /* add comparison expression to selection list */
                eladd(SEL_LIST(n)) = expr_cpy;
        }
            break;

        case la_pos_select:
        {
            PFsa_expr_t            *num_gen_expr = NULL;
            PFsa_expr_t            *comp_expr    = NULL;
            PFsa_expr_t            *expr         = NULL;
            PFsa_exprlist_t        *sortlist     = NULL;
            PFsa_exprlist_t        *partlist     = NULL;
            PFsa_expr_t            *expr_cpy     = NULL;
            PFalg_col_t             curr_col;
            bool                    curr_sortorder;

            /* copy the sort columns from semantic field into sortlist */
            sortlist = el(PFord_count (n->sem.sort.sortby));
            partlist = el(1);

            if (n->sem.sort.part) {
                /* find partitioning column and append it to partitioning
                 list */
                expr = find_expr(PRJ_LIST (L(n)),
                                 n->sem.sort.part);

                eladd(partlist) = expr;
            }

            for (i = 0; i < PFord_count (n->sem.sort.sortby); i++) {
                curr_col = PFord_order_col_at (n->sem.sort.sortby, i);
                curr_sortorder = PFord_order_dir_at(n->sem.sort.sortby, i);

                /* Do not order by constant values */                
                if (PFprop_const (n->prop, curr_col))
                    continue;

                expr = find_expr(PRJ_LIST (L(n)),
                                 curr_col);

                /* copy expression */
                expr_cpy = PFmalloc (sizeof(PFsa_expr_t));
                memcpy (expr_cpy, expr, sizeof(PFsa_expr_t));

                /* consider possible different sortorder */
                expr_cpy->sortorder = curr_sortorder;

                eladd(sortlist) = expr_cpy;
            }

            /* Build number generating expression */
            num_gen_expr  = PFsqlalg_expr_num_gen (sa_num_gen_rownum,
                                                   sortlist,
                                                   partlist,
                                                   PFcol_new(col_item));

            /* Since SQL does not allow number generating functions in the
               WHERE clause, add the num_gen_expr to the projection list
               of this operator so that we can refer to it as a column. */
            OP(n) = OP(L(n));
            PRJ_LIST(n) = elcopy(PRJ_LIST(L(n)));
            SEL_LIST(n) = SEL_LIST(L(n));

            eladd(PRJ_LIST(n)) = num_gen_expr;
            /* Since the schema of n does not contain the number generating
               epxression that was just created, replace the schema with one
               that does contain it: the schema from PRJ_LIST(n) */
            n->schema = schema_from_exprlist (PRJ_LIST(n));
            bindop(n);
            
            /* Build comparison with reference to the just added column
               that represents the numbering expression */
            comp_expr  = PFsqlalg_expr_comp(find_expr (
                                                PRJ_LIST(n),
                                                num_gen_expr->col),
                                            PFsqlalg_expr_atom (
                                                PFcol_new (col_item),
                                                PFalg_lit_nat (
                                                    n->sem.pos_sel.pos)),
                                            sa_comp_equal,
                                            PFcol_new (col_item));

            /* Finally, add the comparison expression to the selection
               list like in an ordinary select */
            eladd(SEL_LIST(n)) = comp_expr;
        }
            break;

        case la_disjunion:

            bindop(L(n));
            bindop(R(n));

            /* build operator and lists */
            OP(n) = PFsqlalg_op_union (OP (L(n)), OP (R(n)));

            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            SEL_LIST(n) = el(1);

            break;

        case la_intersect:
        {
            /* The intersection of two tables is equivalent to
             an semijoin over all attributes of the tables. In
             our case, the tables have same schema */

            PFsa_exprlist_t        *exprlist;
            PFsa_expr_t            *expr_l;
            PFsa_expr_t            *expr_r;

            bindop(L(n));
            bindop(R(n));

            exprlist = el(n->schema.count);

            for (i = 0; i < n->schema.count; i++) {

                expr_l = find_expr (PRJ_LIST(L(n)),
                                    n->schema.items[i].name);
                expr_r = find_expr (PRJ_LIST(R(n)),
                                    n->schema.items[i].name);

                eladd(exprlist) = PFsqlalg_expr_comp (expr_l,
                                                      expr_r,
                                                      sa_comp_equal,
                                                      PFcol_new(col_item));
            }

            OP(n) = PFsqlalg_op_semijoin (OP(L(n)),
                                          OP(R(n)),
                                          exprlist);

            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            SEL_LIST(n) = el(1);
        }
            break;

        case la_difference:

            bindop(L(n));
            bindop(R(n));

            /* build operator and lists */
            OP(n) = PFsqlalg_op_except (OP (L(n)), OP (R(n)));
            
            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            SEL_LIST(n) = el(1);

            break;

        case la_distinct:
        {
            /* To preserve sematics of plan safely, bind at occurence
             of distinct operator */
            PFsa_op_t *sel = NULL;

            if(elsize(SEL_LIST(L(n)))) {
                sel = PFsqlalg_op_select (OP(L(n)), SEL_LIST(L(n)));
            }

            OP(n) = PFsqlalg_op_project (sel ? sel : OP(L(n)), true, PRJ_LIST(L(n)));
            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            SEL_LIST(n) = el(1);
        }
            break;

        case la_fun_1to1:
        {
            /* Append expression representing the function
             to projection list. Operator and selection list stay
             unchanged. */

            PFsa_exprlist_t            *exprlist;
            PFsa_expr_t                *expr;
            PFsa_expr_func_name         func_name;
            PFalg_col_t                 curr_col;

            OP(n) = OP (L(n));
            PRJ_LIST(n) = elcopy (PRJ_LIST (L(n)));

            /* determine function kind */
            switch (n->sem.fun_1to1.kind) {
                case alg_fun_num_add:
                    func_name = sa_func_add;
                    break;
                case alg_fun_num_subtract:
                    func_name = sa_func_sub;
                    break;
                case alg_fun_num_multiply:
                    func_name = sa_func_mult;
                    break;
                case alg_fun_num_divide:
                    func_name = sa_func_div;
                    break;
                case alg_fun_num_modulo:
                    func_name = sa_func_mod;
                    break;
                case alg_fun_fn_like:
                    func_name = sa_func_like;
                    break;
                case alg_fun_fn_year_from_date:
                    func_name = sa_func_year_from_date;
                    break;
                case alg_fun_fn_month_from_date:
                    func_name = sa_func_month_from_date;
                    break;
                case alg_fun_fn_day_from_date:
                    func_name = sa_func_day_from_date;
                    break;
                case alg_fun_fn_substring:
                    func_name = sa_func_substring;
                    break;
                case alg_fun_fn_substring_len:
                    func_name = sa_func_substring_len;
                    break;
                default:
                    PFoops (OOPS_FATAL, "unknown function kind (%i) found",
                                        n->sem.fun_1to1.kind);
                    break;
            }

            /* build list with input columns for function */
            exprlist = el(PFalg_collist_size(n->sem.fun_1to1.refs));

            for (i = 0; i < PFalg_collist_size(n->sem.fun_1to1.refs); i++) {
                curr_col = PFalg_collist_at (n->sem.fun_1to1.refs, i);

                expr = find_expr (PRJ_LIST(n),
                                  curr_col);
                eladd(exprlist) = expr;
            }

            eladd(PRJ_LIST(n)) = PFsqlalg_expr_func (func_name,
                                                     exprlist,
                                                     n->sem.fun_1to1.res);
            SEL_LIST(n) = SEL_LIST (L(n));
        }
            break;

        case la_num_eq:
        case la_num_gt:
        {
            /* Append comparison expression representing gt/eq
             to projection list. Operator and selection list
             stay unchanged. */
            PFsa_comp_kind_t           comp_kind = sa_comp_equal;
            PFsa_expr_t                *col1_expr;
            PFsa_expr_t                *col2_expr;

            OP(n) = OP (L(n));
            PRJ_LIST(n) = elcopy (PRJ_LIST (L(n)));

            /* If column is constant, use its value instead a
               a reference to it */
            if (PFprop_const (n->prop, n->sem.binary.col1))
                col1_expr = PFsqlalg_expr_atom (
                                PFcol_new (col_item),
                                PFprop_const_val (
                                    n->prop,
                                    n->sem.binary.col1));
            else
                /* find left operand col1 in projection list */
                col1_expr = find_expr (PRJ_LIST(n),
                                       n->sem.binary.col1);

            /* If column is constant, use its value instead a
               a reference to it */
            if (PFprop_const (n->prop, n->sem.binary.col2))
                col2_expr = PFsqlalg_expr_atom (
                                PFcol_new (col_item),
                                PFprop_const_val (
                                    n->prop,
                                    n->sem.binary.col2));
            else                
                /* find left operand col2 in projection list */
                col2_expr = find_expr (PRJ_LIST(n),
                                       n->sem.binary.col2);

            /* determine comparison kind */
            switch (n->kind) {
                case la_num_eq:
                    comp_kind = sa_comp_equal;
                    break;
                case la_num_gt:
                    comp_kind = sa_comp_gt;
                    break;
                default:
                    break;
            }

            /* add comparison expression to projection list */
            eladd(PRJ_LIST(n)) = PFsqlalg_expr_comp (col1_expr,
                                                     col2_expr,
                                                     comp_kind,
                                                     n->sem.binary.res);
            SEL_LIST(n) = SEL_LIST (L(n));
        }
            break;

        case la_bool_and:
        case la_bool_or:
        {
            /* Append function expression representing and/or
             to projection list. Operator and selection list
             stay unchanged. */

            PFsa_exprlist_t        *exprlist;
            PFsa_expr_t            *expr;
            PFsa_expr_func_name     func_name = sa_func_or;

            OP(n) = OP (L(n));
            PRJ_LIST(n) = elcopy (PRJ_LIST (L(n)));

            /* build list with input columns for function */
            exprlist = el(2);

            /* append col1 to input list for function */
            expr = find_expr (PRJ_LIST(n),
                              n->sem.binary.col1);
            if (expr->kind == sa_expr_column ||
                expr->type == aat_int)
                expr = PFsqlalg_expr_comp (expr,
                                           PFsqlalg_expr_atom (
                                               PFcol_new (col_item),
                                               PFalg_lit_int (1)),
                                           sa_comp_equal,
                                           PFcol_new (col_item));
            eladd(exprlist) = expr;

            /* append col2 to input list for function */
            expr = find_expr (PRJ_LIST(n),
                              n->sem.binary.col2);
            if (expr->kind == sa_expr_column ||
                expr->type == aat_int)
                expr = PFsqlalg_expr_comp (expr,
                                           PFsqlalg_expr_atom (
                                               PFcol_new (col_item),
                                               PFalg_lit_int (1)),
                                           sa_comp_equal,
                                           PFcol_new (col_item));
            eladd(exprlist) = expr;

            switch (n->kind) {
                case la_bool_or:
                    func_name = sa_func_or;
                    break;
                case la_bool_and:
                    func_name = sa_func_and;
                    break;
                default:
                    break;
            }

            eladd(PRJ_LIST(n)) = PFsqlalg_expr_func (func_name,
                                                     exprlist,
                                                     n->sem.binary.res);
            SEL_LIST(n) = SEL_LIST (L(n));
        }
            break;

        case la_bool_not:
        {
            /* Append function expression representing 'not'
             to projection list. Operator and selection list
             stay unchanged. */

            PFsa_exprlist_t        *exprlist;
            PFsa_expr_t            *expr;

            OP(n) = OP (L(n));
            PRJ_LIST(n) = elcopy (PRJ_LIST (L(n)));

            /* build list with input columns for function */
            exprlist = el(1);

            /* append col1 to input list for function */
            expr = find_expr (PRJ_LIST(n),
                              n->sem.unary.col);
            if (expr->kind == sa_expr_column)
                expr = PFsqlalg_expr_comp (expr,
                                           PFsqlalg_expr_atom (
                                               PFcol_new (col_item),
                                               PFalg_lit_int (1)),
                                           sa_comp_equal,
                                           PFcol_new (col_item));
            eladd(exprlist) = expr;

            eladd(PRJ_LIST(n)) = PFsqlalg_expr_func (sa_func_not,
                                                     exprlist,
                                                     n->sem.unary.res);
            SEL_LIST(n) = SEL_LIST (L(n));
        }
            break;

        case la_aggr:
        {
            /* Append aggregate columns and partitioning column (if exists)
               to projection list */

            unsigned int            i;
            PFalg_col_t             curr_col;
            PFla_op_t              *child_la_op   = NULL;
            PFsa_expr_t            *expr          = NULL;
            PFsa_expr_t            *expr_cpy      = NULL;
            PFsa_exprlist_t        *exprlist      = NULL;
            PFsa_exprlist_t        *grpbylist;
            PFalg_aggr_t            aggr;
            PFsa_aggr_kind_t        aggr_kind;

            exprlist = el(n->sem.aggr.count);
            grpbylist = el(1);

            if (n->sem.aggr.part == col_NULL) {
               /* There is no partitioning column */
               bindop(L(n));
               child_la_op = L(n);
            } else {
                /* Check if the partitioning column is a number generating
                   operator that lies directly under the aggregation
                   operator. Check further if this number generating 
                   operator is not used anymore above the aggregation
                   operator */
                if (IS_NUM_GEN (L(n)) &&
                    L(n)->sem.sort.res == n->sem.aggr.part &&
                    !PFprop_icol(n->prop, n->sem.aggr.part)) { 

                    /* Avoid binding of number generating operator, bind instead its
                       predecessor */
                    bindop(LL(n));
                    child_la_op = LL(n);
                    
                    /* We ignore the column L(n)->sem.sort.res, i.e. we do
                       not put a dummy in exprlist and grpbylist because of
                       !PFprop_icol(n->prop, L(n)->sem.sort.res) */

                    /* Put the number generating operators sort columns
                       in exprlist and grpbylist */
                    for (i = 0; i < PFord_count (L(n)->sem.sort.sortby); i++) {
                        curr_col = PFord_order_col_at (L(n)->sem.sort.sortby, i);
                        expr = find_expr (PRJ_LIST (LL(n)), curr_col);
                        eladd(exprlist) = expr;
                        eladd(grpbylist) = expr;
                    }

                } else {
                    bindop(L(n));
                    child_la_op = L(n);
                    
                    /* Put partitioning column in exprlist and grpbylist */
                    expr = find_expr (PRJ_LIST (L(n)), n->sem.aggr.part);
                    eladd(exprlist) = expr;
                    eladd(grpbylist) = expr;
                }
            }

            /* for every aggregation in list, append a column to PRJ_LIST(n) */
            for (i = 0; i < n->sem.aggr.count; i++) {
                aggr = n->sem.aggr.aggr[i];

                expr = find_expr (PRJ_LIST (child_la_op),
                                  aggr.col);

                /* determine aggregation kind */
                switch (aggr.kind) {
                    case alg_aggr_count:
                        aggr_kind = sa_aggr_count;
                        break;
                    case alg_aggr_min:
                        aggr_kind = sa_aggr_min;
                        break;
                    case alg_aggr_max:
                        aggr_kind = sa_aggr_max;
                        break;
                    case alg_aggr_avg:
                        aggr_kind = sa_aggr_avg;
                        break;
                    case alg_aggr_sum:
                        aggr_kind = sa_aggr_sum;
                        break;
                    case alg_aggr_dist:
                        /* Check if aggr.col is already in exprlist (note that
                           if it is, its also in the grpbylist) */
                        expr = find_expr (exprlist, aggr.col);
                        if (expr) {
                            /* Rename the expression representing aggr.col
                               (grpbylist contains the same expression
                               so it will know about the renaming) */
                            expr->col = aggr.res;
                        } else {
                            /* aggr.col not found, add and rename it to both
                               exprlist and grpbylist */
                            expr = find_expr (PRJ_LIST(child_la_op), aggr.col);
                            if (expr->kind != sa_expr_atom) {
                                expr_cpy = deep_copy_expr (expr);
                                expr_cpy->col = aggr.res;
                                eladd(exprlist) = expr_cpy;
                                eladd(grpbylist) = expr_cpy;
                            }
                        }
                        /* continue: No operator is built in this iteration */
                        continue;
                        break;
                    default:
                        PFoops (OOPS_FATAL, "translation of la aggregation kind %i"
                                " not supported so far", aggr.kind);
                        break;
                }

                eladd(exprlist) = PFsqlalg_expr_aggr (expr,
                                                      aggr_kind,
                                                      aggr.res);
            }

            OP(n) = PFsqlalg_op_groupby (OP (child_la_op), grpbylist, exprlist);

            PRJ_LIST(n) = exprlist_from_schema (n->schema);
            SEL_LIST(n) = SEL_LIST (child_la_op);
        }
            break;

        case la_rownum:
        {
            PFsa_expr_t            *expr;
            PFsa_exprlist_t        *sortlist;
            PFsa_exprlist_t        *partlist;
            PFsa_expr_t            *expr_cpy;
            PFalg_col_t             curr_col;
            bool                    curr_sortorder;

            OP(n) = OP (L(n));
            PRJ_LIST(n) = elcopy(PRJ_LIST (L(n)));
            SEL_LIST(n) = SEL_LIST (L(n));

            /* copy the sort columns from semantic field into sortlist */
            sortlist = el(PFord_count (n->sem.sort.sortby));
            partlist = el(1);

            if (n->sem.sort.part != col_NULL) {
                /* find partitioning column and append it to partitioning
                 list */
                expr = find_expr(PRJ_LIST (L(n)),
                                 n->sem.sort.part);

                eladd(partlist) = expr;
            }

            for (i = 0; i < PFord_count (n->sem.sort.sortby); i++) {
                curr_col = PFord_order_col_at (n->sem.sort.sortby, i);
                curr_sortorder = PFord_order_dir_at(n->sem.sort.sortby, i);
                
                if (PFprop_const (n->prop, curr_col))
                    continue;

                expr = find_expr(PRJ_LIST (L(n)),
                                 curr_col);

                expr_cpy = PFmalloc(sizeof(PFsa_expr_t));
                memcpy(expr_cpy, expr, sizeof(PFsa_expr_t));

                /* consider possible different sortorder */
                expr_cpy->sortorder = curr_sortorder;

                eladd(sortlist) = expr_cpy;
            }

            expr = PFsqlalg_expr_num_gen (sa_num_gen_rownum,
                                          sortlist,
                                          partlist,
                                          n->sem.sort.res);

            eladd(PRJ_LIST(n)) = expr;

            bindop(n);
        }
            break;

        case la_rowrank:
        case la_rank:
        {
            PFsa_exprlist_t        *sortlist;
            PFsa_expr_t            *expr;
            PFsa_expr_t            *expr_cpy;
            PFalg_col_t             curr_col;
            bool                    curr_sortorder;
            PFsa_num_gen_kind_t     kind = sa_num_gen_rowrank;

            OP(n) = OP (L(n));
            PRJ_LIST(n) = elcopy(PRJ_LIST (L(n)));

            /* copy the sort columns from semantic field into sortlist */
            sortlist = el(PFord_count (n->sem.sort.sortby));

            for (i = 0; i < PFord_count (n->sem.sort.sortby); i++) {
                curr_col = PFord_order_col_at (n->sem.sort.sortby, i);
                curr_sortorder = PFord_order_dir_at(n->sem.sort.sortby, i);
                
                if (PFprop_const (n->prop, curr_col))
                    continue;

                expr = find_expr (PRJ_LIST(n),
                                  curr_col);

                expr_cpy = PFmalloc(sizeof(PFsa_expr_t));
                memcpy(expr_cpy, expr, sizeof(PFsa_expr_t));

                /* consider possible different sortorder */
                expr_cpy->sortorder = curr_sortorder;

                eladd(sortlist) = expr_cpy;
            }

            switch (n->kind) {
                case la_rowrank:
                    kind = sa_num_gen_rowrank;
                    break;
                case la_rank:
                    kind = sa_num_gen_rank;
                    break;
                default:
                    break;
            }

            /* rank, rowrank do not have a partition list: hand over empty list */
            expr = PFsqlalg_expr_num_gen (kind,
                                          sortlist,
                                          el(1),
                                          n->sem.sort.res);

            eladd(PRJ_LIST(n)) = expr;

            SEL_LIST(n) = SEL_LIST (L(n));

            bindop(n);
        }
            break;

        case la_rowid:
        {
            PFsa_expr_t            *expr;

            OP(n) = OP (L(n));
            PRJ_LIST(n) = elcopy(PRJ_LIST (L(n)));

            expr = PFsqlalg_expr_num_gen (sa_num_gen_rowid,
                                          el(1),
                                          el(1),
                                          n->sem.rowid.res);

            eladd(PRJ_LIST(n)) = expr;

            SEL_LIST(n) = SEL_LIST (L(n));

            bindop(n);
        }
            break;

        case la_cast:
        {
            /* Append convert expression representing the conversion
             to projection list. Operator and selection list stay
             unchanged. */

            PFsa_expr_t            *org_col;
            PFsa_expr_t            *new_col;

            OP(n) = OP (L(n));
            PRJ_LIST(n) = elcopy(PRJ_LIST (L(n)));

            org_col = find_expr(PRJ_LIST(n),
                                n->sem.type.col);

            if (!monomorphic(n->sem.type.ty))
                PFoops (OOPS_FATAL, "Cannot convert to a polymorphic type since"
                        " polymorphic columns are not allowed in SQL algebra" );

            new_col = PFsqlalg_expr_convert (org_col,
                                             n->sem.type.ty,
                                             n->sem.type.res);

            eladd(PRJ_LIST(n)) = new_col;

            SEL_LIST(n) = SEL_LIST (L(n));
        }
            break;

        case la_empty_frag:

            /* build operator and lists */
            OP(n) = PFsqlalg_op_nil_node();
            PRJ_LIST(n) = NULL;
            SEL_LIST(n) = NULL;

            break;

        case la_nil:

            /* build operator and lists */
            OP(n) = PFsqlalg_op_nil_node();
            PRJ_LIST(n) = NULL;
            SEL_LIST(n) = NULL;

            break;

        default:
            PFoops (OOPS_FATAL, "translation of la operator kind %i not"
                                " not implemented yet", n->kind);
            break;
    }

    /* Note: Binding every operator that is referenced more than once
       yields a DOT output without edges between the expressions
       of different operators but is not strictly necessary for SQL
       code generation */
    if (n->refctr > 1)
        bindop (n);
}

/* Translate the logical algebra into SQL algebra */
PFsa_op_t *
PFlalg2sqlalg (PFla_op_t * n)
{
    /* start worker to fill sa_ann fields in n */
    PFla_dag_reset(n);
    alg2sqlalg_worker(n);
    PFla_dag_reset(n);

    /* Run optimizations on plan */
    OP(n) = PFsqlalg_opt (OP(n));
    
    return OP(n);
}

/* vim:set shiftwidth=4 expandtab filetype=c: */

