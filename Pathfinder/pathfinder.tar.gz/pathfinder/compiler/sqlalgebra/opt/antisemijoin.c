
/**
 * @file
 *
 * This file checks, if there is a pattern below a join operator that can
 * be replaced with the antisemijoin operator. The pattern is the following:
 *
 *                    |
 *                 eqjoin
 *                 /     \
 *                /       \
 *               /         \
 *           except         |
 *           /   \          |
 *          /     \         |
 *         |      project   |
 *         |       |        |
 *       project   |        |
 *      (ex_chld)  |        |
 *         |       |        /
 *         .     thetajoin /
 *         .       |     \/
 *         .       |     /\
 *         |       |    /  \
 *       project   |   /    \
 * (ex_root_nrst)  |  /      \
 *         |      project    operator
 *         |  (left_child)  (right_child)
 *          \     /           |
 *           \   /            |
 *           project          |
 *        (except_root)       |
 *             |              |
 *             |              |
 * 
 * This pattern will be replaced by the antisemijoin if some conditions
 * are satisfied.... TODO!
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * $Id$
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"
#include <assert.h>
#include <stdio.h>

#include "sqlalg.h"
#include "properties.h"
#include "mem.h"          /* PFmalloc() */

#include "sqlalg_mnemonic.h"
#include "child_mnemonic.h"
#include "sqlalg_dag.h"

/* For deep_copy_expr() function */
#include "lalg2sqlalg.h"

/* Auxiliary function to copy an expression list with all
   its expressions deeply */
static PFsa_exprlist_t *
deep_copy_exprlist (PFsa_exprlist_t *list)
{
    unsigned int i;
    PFsa_expr_t *curr_expr;
    PFsa_exprlist_t *list_copy = el (elsize (list));

    for (i = 0; i < elsize (list); i++) {
        curr_expr = elat(list, i);
        eladd(list_copy) = deep_copy_expr (curr_expr);
    }

    return list_copy;
}

/* TODO Comment! Better variable names especially for lcol, rcol */
static void
build_antisemijoin (PFsa_op_t *eqjoin)
{
    unsigned int i;
    PFsa_expr_t *curr_expr;
    PFsa_op_t *curr_op            = NULL;
    PFsa_op_t *except_child       = NULL;
    PFsa_op_t *except_root_parent = NULL;
    PFsa_op_t *except_root        = NULL;
    PFsa_op_t *right_child        = NULL;
    PFsa_op_t *left_child         = NULL;
    PFsa_op_t *thetajoin          = NULL;

    PFalg_col_t lcol;
    PFalg_col_t rcol;

    PFsa_exprlist_t *new_prj_list = NULL;
    PFsa_op_t *antisemijoin       = NULL;
    PFsa_op_t *new_prj            = NULL;

    /* When this point is reached, the following is true:
       - eqjoin->kind == sa_op_join
       - eqjoin results from the translation of a LA eqjoin with one
         single equality comparison
       - both expressions in the equality comparison have key
         property */

    /* Extract the two column names of comparison */
    curr_expr = elat (eqjoin->sem.join.expr_list, 0);
    lcol = L(curr_expr)->kind == sa_expr_column ?
           L(curr_expr)->sem.col.old :
           L(curr_expr)->col;
    rcol = R(curr_expr)->kind == sa_expr_column ?
           R(curr_expr)->sem.col.old :
           R(curr_expr)->col;

    /* Left of the eqjoin we have an except operator with exactly
       one column which is lcol */
    if (L(eqjoin)->kind != sa_op_except)
        return;
    if (L(eqjoin)->schema.count != 1 ||
        L(eqjoin)->schema.items[0].name != lcol)
        return;

    /* except_child is left child  of except operator
       (except_child is therefore a proj operator) */
    except_child = LL(eqjoin);

    /* Start with except_child looking for the except root. (Starting with
       except_child is done because we also need the parent operator of the
       except_root which can already be the except_child)  */
    for (curr_op = except_child; curr_op &&
                                 curr_op->kind == sa_op_project &&
                                 L(curr_op); curr_op = L(curr_op)) {

        /* Look for origin of lcol */
        curr_expr = find_expr (curr_op->sem.proj.expr_list, lcol);

        if (!curr_expr)
            return;
        /* Remember possible renaming of lcol */
        if (curr_expr->kind == sa_expr_column)
               lcol = curr_expr->sem.col.old;

        if (L(curr_op)->refctr == 2) {
            except_root_parent = curr_op;
            except_root = L(curr_op);
            break;
        }
        
    }

    if (!except_root || !except_root_parent)
        return;

    /* Because the schema of except only consists of
       lcol and we are descending from except! */
    rcol = L(eqjoin)->schema.items[0].name;

    /* Start at right child of except */
    for (curr_op = LR(eqjoin); curr_op; curr_op = L(curr_op)) {
        /* The except_root is found again */
        if (curr_op == except_root)
            break;

        if (curr_op->kind == sa_op_project) {
            /* Look for origin of rcol */
            curr_expr = find_expr (curr_op->sem.proj.expr_list, rcol);
            
            if (!curr_expr)
                return;
            /* Remember possible renaming of rcol */
            if (curr_expr->kind == sa_expr_column)
                   rcol = curr_expr->sem.col.old;
        } else if (curr_op->kind == sa_op_join) {
            /* Found join, right_child and left_child */
            thetajoin = curr_op;
            right_child = R(curr_op);
            left_child = L(curr_op);
        } else
            /* If there is somehing else that project or join operators
               return */
            return;
    }

    /* At this point, lcol has to be equal to rcol */
    if (lcol != rcol)
        return;

    if (!thetajoin || !right_child || !left_child)
        return;

    /* Reset the rcol to the value of the eqjoin */
    curr_expr = elat (eqjoin->sem.join.expr_list, 0);
    rcol = R(curr_expr)->kind == sa_expr_column ?
           R(curr_expr)->sem.col.old :
           R(curr_expr)->col;

    /* Follow from eqjoin to except_root and remember possible renamings of rcol */
    for (curr_op = R(eqjoin); curr_op; curr_op = L(curr_op)) {
        /* The except_root is found again */
        if (curr_op == except_root)
            break;
        
        if (curr_op->kind == sa_op_project) {
            /* Look for origin of rcol, this time starting from eqjoin */
            curr_expr = find_expr (curr_op->sem.proj.expr_list, rcol);
            if (!curr_expr)
                return;
            /* Remember possible renaming of rcol */
            if (curr_expr->kind == sa_expr_column)
                   rcol = curr_expr->sem.col.old;
        }
    }

    /* Again, lcol has to be equal to rcol */
    if (lcol != rcol)
        return;

    /* Look for DISTINCT to throw away because of the DISTINCT 
       semantics of NOT IN, NOT EXISTS regarding the right side */
    /* TODO Possible optimization: descend deeper in right child
       and remove duplicates taking into account semantics of the
       ops that occur in right child. */
    for (curr_op = right_child; curr_op; curr_op = L(curr_op)) {
        /* Break at the first occurrence of a non-project operator */
        if (curr_op->kind != sa_op_project)
            break;
        else
            if (curr_op->distinct) {
                curr_op->distinct = false;
                break;
            }
    }

    /* Right child of eqjoin is the left_child of thetajoin */
    if (R(eqjoin) == left_child) {

        /* Prepare project operator new_prj to restore schema above
           the operators that constitute the antisemijoin pattern
           and that will be replaced by the antisemijoin operator */

        /* First check if all columns that are referenced in except_root_parent
           are found in schema of left_child */
        for (i = 0; i < elsize (except_root_parent->sem.proj.expr_list); i++) {
            curr_expr = elat (except_root_parent->sem.proj.expr_list, i);
            if (!PFsa_expr_cols_in_schema (curr_expr, left_child->schema))
                return;
        }

        /* Use only column expressions from left_child for new_prj
           because the exprs in this left_child will be built so
           column references suffice */
        new_prj_list = exprlist_from_schema (left_child->schema);
        /* Deep copy the expression list from the except_child because
           it can contain renamings and more stuff that we should not
           throw away. (All column references in expressions of
           except_root_parent are in schema of left_child, so all column
           references in expressions from except_child are also in schema
           of left_child.) */
        elconcat (new_prj_list, deep_copy_exprlist (except_child->sem.proj.expr_list));

        /* Build antisemijoin operator */
        antisemijoin = PFsqlalg_op_antisemijoin (left_child,
                                                 right_child,
                                                 elcopy (
                                                     thetajoin->sem.join.expr_list));

        new_prj = PFsqlalg_op_project (antisemijoin, false, new_prj_list);

        /* Replace */
        *eqjoin = *new_prj;
    }
}

void
PFsqlalgopt_antisemijoin (PFsa_op_t *root)
{
    PFsa_op_t *eqjoin;

    PFsqlalg_dag_reset (root);
    PFsqlalg_infer_refctr (root);

    /* Look for joins to run optimization on. For semantics of this
       while loop see sqlalgebra/sqlalg_dag.c */    
    while ((eqjoin = PFsqlalg_find_op (sa_op_join, root)))
        /* Check that eqjoin->sem.join.expr_list contains only one key=key predicate.
           This information has been stored in a flag while translating LA->SA.*/
        if (eqjoin->sem.join.antisemijoin_pattern)
            build_antisemijoin (eqjoin);

    return;
}

/* vim:set shiftwidth=4 expandtab filetype=c: */ 

