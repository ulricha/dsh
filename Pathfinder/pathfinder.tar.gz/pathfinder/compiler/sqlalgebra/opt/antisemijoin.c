
/**
 * @file
 *
 * This file checks, if there is a pattern below a join operator that can
 * be replaced with the antisemijoin operator. The pattern is the following:
 *
 *                    |
 *                 eqjoin
 *                 /     \
 *                /       \
 *               /         \
 *           except         |
 *           /   \          |
 *          /     \         |
 *         |      project   |
 *         |       |        |
 *       project   |        |
 *      (ex_chld)  |        |
 *         |       |        /
 *         |     thetajoin /
 *         |       |     \/
 *         |       |     /\
 *         |      project  \
 *         |  (left_child)  \
 *          \     /          \
 *           \   /           op
 *           project     (right_child)
 *        (except_root)       |
 *             |              |
 *             |              |
 * 
 * This pattern will be replaced by the antisemijoin if some conditions
 * are satisfied.... TODO!
 *
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * $Id$
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"
#include <assert.h>
#include <stdio.h>

#include "sqlalg.h"
#include "properties.h"
#include "mem.h"          /* PFmalloc() */

#include "sqlalg_mnemonic.h"
#include "child_mnemonic.h"

/* TODO Comment!*/
static void
build_antisemijoin (PFsa_op_t *op)
{
    PFsa_op_t *curr_op = NULL;
    PFsa_op_t *supposable_except_child = NULL;
    PFsa_op_t *supposable_except_root = NULL;
    PFsa_op_t *supposable_right_child = NULL;
    PFsa_op_t *supposable_left_child = NULL;
    PFsa_op_t *supposable_thetajoin = NULL;

    PFsa_exprlist_t *new_prj_list = NULL;
    PFsa_op_t *antisemijoin = NULL;
    PFsa_op_t *new_prj = NULL;

    if (op->kind != sa_op_join)
        return;

    if (L(op)->kind != sa_op_except)
        return;

    /* Check that op->sem.join.expr_list contains only key=key predicates */
    if (!op->sem.join.antisemijoin_flag)
        return;

    /* Start at left child of except */
    curr_op = LL(op);
    while (1) {
        if (curr_op->refctr == 2) {
            supposable_except_root = curr_op;
            break;
        }
        
        if (curr_op->kind != sa_op_project)
            return;
        else
            /* Save first occurring project as except_child */
            if (!supposable_except_child)
                supposable_except_child = curr_op;

        curr_op = L(curr_op);
    }

    if (!supposable_except_root || !supposable_except_child)
        return;

    /* Start at right child of except */
    curr_op = LR(op);
    while (1) {
        /* The except_root is found again */
        if (curr_op == supposable_except_root)
            break;

        /* Joins right child is right_child */
        if (curr_op->kind == sa_op_join) {
            supposable_thetajoin = curr_op;
            supposable_right_child = R(curr_op);
        }

        /* left_child is the project right before the join */
        if (!supposable_left_child &&
            curr_op->kind == sa_op_project &&
            curr_op->refctr == 2)
            supposable_left_child = curr_op;

        curr_op = L(curr_op);
    }

    if (!supposable_right_child || !supposable_left_child || !supposable_thetajoin)
        return;

    /* Look for DISTINCT to throw away because of the DISTINCT 
       semantics of NOT IN, NOT EXISTS regarding the right side */
    curr_op = supposable_right_child;
    while (1) {
        if (curr_op->kind != sa_op_project)
            break;
        else
            if (curr_op->distinct) {
                curr_op->distinct = false;
                break;
            }

        curr_op = L(curr_op);
    }

    if (R(op) == supposable_left_child) {
        /* Build antisemijoin operator */
        new_prj_list = elcopy (supposable_left_child->sem.proj.expr_list);
        elconcat(new_prj_list, elcopy (supposable_except_child->sem.proj.expr_list));

        antisemijoin = PFsqlalg_op_antisemijoin (supposable_left_child, supposable_right_child,
                                                 elcopy (supposable_thetajoin->sem.join.expr_list));

        new_prj = PFsqlalg_op_project (antisemijoin, false, new_prj_list);

        /* Replace */
        *op = *new_prj;
    }
}

void
PFsqlalgopt_antisemijoin (PFsa_op_t *op)
{
    build_antisemijoin (op);

    (void) op;
}

/* vim:set shiftwidth=4 expandtab filetype=c: */ 

