
/**
 * @file
 *
 * This optimization merges two adjacent project operators in SQL algebra.
 * FIXME MOre info to come here.
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * $Id$
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"
#include <assert.h>
#include <stdio.h>

#include "sqlalg.h"
#include "sqlalg_dag.h"
#include "properties.h"
#include "mem.h"          /* PFmalloc() */

#include "sqlalg_mnemonic.h"
#include "child_mnemonic.h"

/* For find_expr() and deep_copy_expr() functions */
#include "lalg2sqlalg.h"

/* Function that indicates if an expression tree contains
   a rowid expression */
static bool
contains_rowid (PFsa_expr_t *expr)
{
    unsigned int i;

    if (expr->kind == sa_expr_num_gen &&
        expr->sem.num_gen.kind == sa_num_gen_rowid)
        return true;

    for (i = 0; i < PFSA_EXPR_MAXCHILD && expr->child[i]; i++)
        /* propagate encountered rowid expression */
        if (contains_rowid (expr->child[i]))
                return true;

    /* no rowid expression found */
    return false;
}

/* Auxiliary function that replaces all column expressions in @a expr 
   with corresponding expressions (regarding the column name) in
   @a list*/
static void
replace_col_refs_in_expr (PFsa_expr_t *expr, PFsa_exprlist_t *list)
{
    unsigned int i;
    PFsa_expr_t *found_expr;
    PFsa_expr_t *fnd_expr_cpy;

    /* Bottom-up traversal */
    for (i = 0; i < PFSA_EXPR_MAXCHILD && expr->child[i]; i++) {
        if (!expr->child[i]->bit_dag)
            replace_col_refs_in_expr (expr->child[i], list);
    }

    expr->bit_dag = true;

    if (expr->kind == sa_expr_column) {
        /* Look for corresponding expression */
        found_expr = find_expr (list, expr->sem.col.old);
        
        /* Deep copy corresponding expression */
        fnd_expr_cpy = deep_copy_expr (found_expr);
        
        /* Consider renaming */
        fnd_expr_cpy->col = expr->col;
        
        /* Replace expression */
        *expr = *fnd_expr_cpy;
    }
}

/* Traverse the operator tree bottom-up and merge adjacent
   project operators */
static void
merge_projections_worker (PFsa_op_t *n)
{
    unsigned int i, j;
    PFsa_expr_t *curr_expr;

    /* Bottom-up traversal */
    for (i = 0; i < PFSA_OP_MAXCHILD && n->child[i]; i++)
        if (!n->child[i]->bit_dag)
            merge_projections_worker (n->child[i]);

    /* Mark operator visited */
    n->bit_dag = true;

    /* Treat only projections */
    if (n->kind == sa_op_project) {

        /* Check if left child of current project op is also
           a project op that does not have the distinct flag set */
        if (L(n)->kind == sa_op_project &&
            L(n)->distinct == false) {

            /* Do not merge if left child contains number
               generating expressions that are potentially accessed
               more than one time (because left child is referenced
               more than one time)
               TODO This merge-avoiding is only necessary for
               rowid exprs that are actually referenced more than once! */
            if (L(n)->refctr > 1) {
                for (j = 0; j < elsize (L(n)->sem.proj.expr_list); j++) {
                    curr_expr = elat(L(n)->sem.proj.expr_list, j);
                    if (contains_rowid (curr_expr))
                        return;
                }
            }

            /* Replace all column references in the current project op
               with column references from the left child (a project op) */
            for (j = 0; j < elsize(n->sem.proj.expr_list); j++) {
                curr_expr = elat(n->sem.proj.expr_list, j);

                replace_col_refs_in_expr (curr_expr, L(n)->sem.proj.expr_list);
            }

            /* Bypass the old left child */
            L(n) = LL(n);
        }
    }
}

/* Try to merge adjacent projection operators */
void
PFsqlalgopt_merge_projections (PFsa_op_t *root)
{
    PFsqlalg_dag_reset (root);
    PFsqlalg_infer_refctr (root);
    merge_projections_worker (root);
    PFsqlalg_dag_reset (root);

    return;
}

/* vim:set shiftwidth=4 expandtab filetype=c: */ 

