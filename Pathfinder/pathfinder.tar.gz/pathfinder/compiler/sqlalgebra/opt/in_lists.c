/* Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.pathfinder-xquery.org/license
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2011 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *//**
 *
 * @file
 *
 * Build IN lists of the expression lists of the operators select, join and
 * semijoin. Therefore, every expression is checked for expression constellations
 * which can be translated into IN lists. Then, the information is collected
 * in an data list and from this data list the IN lists are built.
 *
 * An example:
 * 
 * Operators expression list:
 *      OR
 *     /  \
 *  A=5    OR
 *        /  \
 *     A=7    OR
 *           /  \
 *        B=9    OR
 *              /  \
 *            C=1  C=2
 *
 * Intermediate disjunction list:
 * [[A=5], [A=7], [B=9], [C=1], [C=2]]
 *
 * Data list:
 * [{A, [5, 7]}, {B, [9]}, {C, [1, 2]}]
 *
 * IN expressions list:
 * [{A IN (5, 7)}, {B=9}, {C IN (1, 2)}]
 *
 * Build OR expressions on top of IN expressions list:
 *                OR  <-- This expression replaces the original OR expression!
 *               /  \
 *             OR    \
 *            / \     \
 *           /   \     \
 * A IN (5, 7)  B=9   C IN (1, 2)
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"
#include <assert.h>
#include <stdio.h>

#include "sqlalg.h"
#include "properties.h"
#include "mem.h"          /* PFmalloc() */

#include "sqlalg_mnemonic.h"
#include "child_mnemonic.h"
#include "sqlalg_dag.h"

#define IS_OR_EXPR(e)             ((e)->kind == sa_expr_func && \
                                   (e)->sem.func.name == sa_func_or)
#define IS_EQ_EXPR(e)             ((e)->kind == sa_expr_comp && \
                                   (e)->sem.comp.kind == sa_comp_equal)
#define COMPARES_COL_WITH_ATOM(e) IS_EQ_EXPR((e)) && \
                                  ((L((e))->kind == sa_expr_column &&  \
                                    R((e))->kind == sa_expr_atom) ||   \
                                   (L((e))->kind == sa_expr_atom &&    \
                                    R((e))->kind == sa_expr_column))

/* Structure to collect data of IN lists. For an IN list
   expression in the WHERE clause of a SQL query 'id IN
   (1, 2, 3)', field col_expr would contain the SQL algebra
   expression for column 'id' and field values would be
   a list with SQL algebra atom expressions for values 1, 2, 3*/
struct in_list_data
{
    PFsa_expr_t        *col_expr;
    PFsa_exprlist_t    *values;
};
typedef struct in_list_data in_list_data;

/* Traverse the tree below an SQL algebra OR expression and
   check if it does contain only other SQL algebra expressions
   of kind OR, equal, column, atom. If an equal expression is
   encountered, check if is a comparison of a column and an atom. */
static bool
has_inlist_potential (PFsa_expr_t *expr)
{
    unsigned int i;

    if (expr->kind == sa_expr_column ||
        expr->kind == sa_expr_atom)
        return true;

    if (!IS_EQ_EXPR(expr) && !IS_OR_EXPR(expr))
        return false;

    if (IS_EQ_EXPR(expr) && !COMPARES_COL_WITH_ATOM(expr))
        return false;

    for (i = 0; i < PFSA_EXPR_MAXCHILD && expr->child[i]; i++) {
        if (!has_inlist_potential (expr->child[i]))
            return false;
    }
    return true;
}

/* Fill all the SQL algebra equal expressions of an OR expression tree
   in a list of disjunctions. */
static void
fill_disjunction_list (PFsa_expr_t *expr, PFsa_exprlist_t *disj_list)
{
    unsigned int i;
    
    if (IS_EQ_EXPR(expr)){
        eladd(disj_list) = expr;
        return;
    }

    for (i = 0; i < PFSA_EXPR_MAXCHILD && expr->child[i]; i++) {
        fill_disjunction_list (expr->child[i], disj_list);
    }
}

/* Normalize the SQL algebra equal expressions in the disjunction list,
   i.e. the column is always the left child of the current OR expression
   and the atomic value is always the right child of the current OR
   expression. */
static void
normalize_disjunction_list (PFsa_exprlist_t *disj_list)
{
    unsigned int i;
    PFsa_expr_t *curr_expr = NULL;
    PFsa_expr_t *swap      = NULL;

    for (i = 0; i < elsize(disj_list); i++) {
        curr_expr = elat(disj_list, i);

        if (L(curr_expr)->kind == sa_expr_column)
            continue;
        else if (L(curr_expr)->kind == sa_expr_atom) {
            swap = L(curr_expr);
            L(curr_expr) = R(curr_expr);
            R(curr_expr) = swap;
        }
    }
}

/* Put the SQL algebra equal expressions of @a disj_list in list
   @a data_list (which contains in_list_data items). If there is
   already an entry for column L(expr)->col_expr in @a data_list,
   add the atom R(expr) to the list of values. Otherwise, add a
   new entry to @a data_list */
static void
collect_inlist_data (PFsa_exprlist_t *disj_list, PFarray_t *data_list)
{
    unsigned int   i, j;
    PFsa_expr_t   *expr = NULL;
    in_list_data   datalist_item;

    for (j = 0; j < elsize(disj_list); j++) {
        expr = elat(disj_list, j);

        /* Check if there is an item in data_list that already holds an
           list for L(expr)->col_expr. If found, add value (which resides in
           R(expr)) to that list. Note that L(expr) is a SQL algebra
           column expression and R(expr) is a SQL algebra atom expression */
        for (i = 0; i < PFarray_last (data_list); i++) {
                datalist_item = 
                        *(in_list_data *) PFarray_at ((PFarray_t *) data_list, i);

                if (L(expr)->col == datalist_item.col_expr->col) {
                    eladd(datalist_item.values) = R(expr);
                    break;
                }
        }

        /* If no such item was found, add a new one to data_list */
        if (i >= PFarray_last (data_list)) {
                datalist_item = (in_list_data) {
                                    .col_expr = L(expr),
                                    .values   = el(1)
                                };
                eladd (datalist_item.values) = R(expr);

                *(in_list_data *) PFarray_add(data_list) = datalist_item;
        }
    }
}

/* Iterate over @a data_list and return a list of
   SQL algebra in/equal expressions */
static PFsa_exprlist_t *
build_in_exprs_list (PFarray_t *data_list)
{
    unsigned int     i;
    in_list_data     datalist_item;
    PFsa_exprlist_t *list = el(1);

    for (i = 0; i < PFarray_last (data_list); i++) {
        datalist_item = 
            *(in_list_data *) PFarray_at ((PFarray_t *) data_list, i);

        /* If the list for the current datalist_item contains one
           value only, we don't build an IN list, but a simple
           comparison */
        if (elsize(datalist_item.values) == 1)
            eladd(list) = PFsqlalg_expr_comp (
                              datalist_item.col_expr,
                              elat(datalist_item.values, 0),
                              sa_comp_equal,
                              PFcol_new(col_item));
        /* Build IN list */
        else
            eladd(list) = PFsqlalg_expr_in (
                              datalist_item.col_expr->col,
                              datalist_item.values,
                              PFcol_new(col_item));
    }
    return list;
}

/* Transform the disjunction list containing SQL algebra
   in/equal expressions into a single SQL algebra OR expression
   tree. Assign that OR tree the original name @a col_name of
   the column which is about to be replaced with it. */
static PFsa_expr_t *
in_exprs_list2or_expr (PFsa_exprlist_t *in_exprs_list, PFalg_col_t col_name)
{
    unsigned int    i;
    PFsa_expr_t     *curr_expr = NULL;
    PFsa_expr_t     *or_expr   = NULL;
    PFsa_exprlist_t *arg_list  = el(1);

    if (elsize(in_exprs_list) == 1) {
        /* In this case, build_in_exprs_list() has merged all equal
           expressions into one IN list */
        or_expr = elat(in_exprs_list, 0);

        or_expr->col = col_name;
        return or_expr;
    }

    /* If we reach this point, in_exprs_list has at least two elements
       since we always fill it with an OR expression which has two
       children */
    eladd(arg_list) = elat(in_exprs_list, 0);
    eladd(arg_list) = elat(in_exprs_list, 1);

    or_expr = PFsqlalg_expr_func (
                  sa_func_or,
                  arg_list,
                  PFcol_new (col_item));

    for (i = 2; i < elsize(in_exprs_list); i++) {
        curr_expr = elat(in_exprs_list, i);

        arg_list = el(1);
        eladd(arg_list) = or_expr;
        eladd(arg_list) = curr_expr;
        
        or_expr = PFsqlalg_expr_func (
                      sa_func_or,
                      arg_list,
                      PFcol_new (col_item));
    }

    or_expr->col = col_name;
    return or_expr;
}

/* Find SQL algebra OR expressions in the expression tree and
   try to build in lists out of them */
static bool
build_inlist (PFsa_expr_t *expr)
{
    unsigned int     i;
    PFsa_exprlist_t *disj_list     = NULL;
    PFarray_t       *data_list     = NULL;
    PFsa_exprlist_t *in_exprs_list = NULL;

    if (IS_OR_EXPR(expr) && has_inlist_potential (expr)){
        /* Init the lists */
        disj_list = el(1);
        data_list = PFarray (sizeof (in_list_data), 1);

        fill_disjunction_list (expr, disj_list);

        normalize_disjunction_list (disj_list);

        collect_inlist_data (disj_list, data_list);

        /* Check if some of the entries of disj_list were merged
           in the data_list by function collect_inlist_data,
           which means that we can produce at least one IN list */
        if (PFarray_last (data_list) < elsize(disj_list)) {
            
            in_exprs_list = build_in_exprs_list (data_list);

            /* Replace the OR expression with an OR expression
               that potentially contains IN lists */
            *expr = *in_exprs_list2or_expr (in_exprs_list, expr->col);
            return true;
        } 
        else
            return false;
    }

    for (i = 0; i < PFSA_EXPR_MAXCHILD && expr->child[i]; i++) {
        if (!build_inlist (expr->child[i]))
            return false;
    }
    return false;
}

/* Try to build IN lists of the expressions of operator @a op */
void
PFsqlalgopt_in_lists_in_op (PFsa_op_t *op)
{
    unsigned int     i;
    PFsa_expr_t     *curr_expr  = NULL;
    PFsa_exprlist_t *expr_list  = NULL;

    assert (op->kind == sa_op_project ||
            op->kind == sa_op_select ||
            op->kind == sa_op_join ||
            op->kind == sa_op_semijoin);

    /* Check which operator we have */
    switch (op->kind) {
        case sa_op_project:
            expr_list = op->sem.proj.expr_list;
            break;
        case sa_op_select:
            expr_list = op->sem.select.expr_list;
            break;
        case sa_op_join:
        case sa_op_semijoin:
            expr_list = op->sem.join.expr_list;
            break;
        default:
            break;
    }

    for (i = 0; i < elsize(expr_list); i++) {
        curr_expr = elat(expr_list, i);

        /* Check if we can build IN lists out of the expressions in curr_expr:
           If so, build IN lists, otherwise, return false */
        build_inlist (curr_expr);
    }

}

/* Try to build IN lists of the expressions of operator @a op */
void
PFsqlalgopt_in_lists (PFsa_op_t *root)
{
    PFsa_op_t *op;

    /* Build IN lists: Look for select, join and semijoin operators in
       @a root and build IN lists for their expressions, if possible */
    PFsqlalg_dag_reset (root);
    while ((op = PFsqlalg_find_op (sa_op_project, root)))
        PFsqlalgopt_in_lists_in_op (op);

    while ((op = PFsqlalg_find_op (sa_op_select, root)))
        PFsqlalgopt_in_lists_in_op (op);

    while ((op = PFsqlalg_find_op (sa_op_join, root)))
        PFsqlalgopt_in_lists_in_op (op);

    while ((op = PFsqlalg_find_op (sa_op_semijoin, root)))
        PFsqlalgopt_in_lists_in_op (op);

    return;
}

/* vim:set shiftwidth=4 expandtab filetype=c: */ 
