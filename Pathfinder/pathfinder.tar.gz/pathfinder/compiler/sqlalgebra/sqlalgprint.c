/* Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.pathfinder-xquery.org/license
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2011 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *//**
 *
 * @file
 *
 * Debugging: dump SQL algebra plan in AT&T dot format.
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"

#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "sqlalgprint.h"

#include "alg_dag.h"
#include "mem.h"
#include "oops.h"
#include "pfstrings.h"

#include "sqlalg_mnemonic.h"
#include "sqlalg_dag.h"

/** Node names to print out for all the SQL algebra operator nodes. */
static char *dot_op_id[]  = {
      [sa_op_serialize_rel]    = "REL SERIALIZE"
    , [sa_op_project]          = "PROJECT"
    , [sa_op_select]           = "SELECT"
    , [sa_op_literal_table]    = "LIT TABLE"
    , [sa_op_table]            = "TABLE"
    , [sa_op_union]            = "UNION"
    , [sa_op_except]           = "EXCEPT"
    , [sa_op_groupby]          = "GROUPBY"
    , [sa_op_join]             = "JOIN"
    , [sa_op_semijoin]         = "SEMI JOIN"
    , [sa_op_antisemijoin]     = "ANTI SEMI JOIN"
    , [sa_op_cross]            = "CROSS"
    , [sa_op_nil_node]         = "NIL"
};

/** Colors to print out for all the SQL algebra operator nodes. */
static char *dot_op_color[] = {
      [sa_op_serialize_rel]    = "#C0C0C0"
    , [sa_op_project]          = "#63B8FF"
    , [sa_op_select]           = "#4169E1"
    , [sa_op_literal_table]    = "#EEAD0E"
    , [sa_op_table]            = "#EEAD0E"
    , [sa_op_union]            = "#CD661D"
    , [sa_op_except]           = "#CD661D"
    , [sa_op_groupby]          = "#4169E1"
    , [sa_op_join]             = "#66CD00"
    , [sa_op_semijoin]         = "#66CD00"
    , [sa_op_antisemijoin]     = "#FF3300"
    , [sa_op_cross]            = "#CD661D"
    , [sa_op_nil_node]         = "#FFFFFF"
};

/** Node names to print out for all the SQL algebra expression nodes. */
static char *dot_expr_id[]  = {
      [sa_expr_func]             = "func"
    , [sa_expr_num_gen]          = "num_gen"
    , [sa_expr_comp]             = "comp"
    , [sa_expr_aggr]             = "aggr"
    , [sa_expr_convert]          = "convert"
    , [sa_expr_in]               = "in"
    , [sa_expr_column]           = "col"
    , [sa_expr_atom]             = "atom"
};

/** Names to print out for all the SQL algebra expression aggregation nodes. */
static char *dot_expr_aggr_id[]  = {
      [sa_aggr_count]          = "count"
    , [sa_aggr_sum]            = "sum"
    , [sa_aggr_avg]            = "avg"
    , [sa_aggr_max]            = "max"
    , [sa_aggr_min]            = "min"
};

/* Names to print out for all comparison types */
static char *dot_expr_comp_id[] = {
      [sa_comp_equal]          = "equal"
    , [sa_comp_notequal]       = "not_eq"
    , [sa_comp_lt]             = "lt"
    , [sa_comp_lte]            = "lte"
    , [sa_comp_gt]             = "gt"
    , [sa_comp_gte]            = "gte"
};

/** Names to print out for all the SQL algebra expression function nodes. */
static char *dot_expr_func_id[]  = {
      [sa_func_add]              = "add"
    , [sa_func_sub]              = "sub"
    , [sa_func_mult]             = "mult"
    , [sa_func_div]              = "div"
    , [sa_func_mod]              = "mod"
    , [sa_func_and]              = "and"
    , [sa_func_or]               = "or"
    , [sa_func_not]              = "not"
    , [sa_func_like]             = "like"
    , [sa_func_year_from_date]   = "year from date"
    , [sa_func_month_from_date]  = "month from date"
    , [sa_func_day_from_date]    = "day from date"
    , [sa_func_substring]        = "substring"
    , [sa_func_substring_len]    = "substring len"
};

/** Names to print out for all number generating function types */
static char *dot_expr_num_gen_id[]  = {
      [sa_num_gen_rank]        = "rank"
    , [sa_num_gen_rowrank]     = "rowrank"
    , [sa_num_gen_rownum]      = "rownum"
    , [sa_num_gen_rowid]       = "rowid"
};

/** Colors to print out for all the SQL algebra expression nodes. */
static char *dot_expr_color[] = {
      [sa_expr_func]             = "#B8B8B8"
    , [sa_expr_num_gen]          = "#A6A6A6"
    , [sa_expr_comp]             = "#B8B8B8"
    , [sa_expr_aggr]             = "#4169E1"
    , [sa_expr_convert]          = "#B8B8B8"
    , [sa_expr_in]               = "#B8B8B8"
    , [sa_expr_column]           = "#E5E5E5"
    , [sa_expr_atom]             = "#E5E5E5"
};

/* helper function that returns string with value of atom */
static char *
sqlalg_atom_str(PFalg_atom_t atom)
{
    unsigned int maxlength = 50;
    char *ret = PFmalloc(maxlength * sizeof(char));

    if (atom.is_null)
        sprintf(ret, "NULL");
    else
        switch (atom.type) {
            case aat_nat:
                sprintf(ret, "%u", atom.val.nat_);
                break;
            case aat_int:
                sprintf(ret, LLFMT, atom.val.int_);
                break;
            case aat_str:
                if (strlen(atom.val.str) >= 20) {
                    /* TODO! Check if this does always behave right? */
                    sprintf(ret, "%s", atom.val.str);
                    ret[16] = '.';
                    ret[17] = '.';
                    ret[18] = '.';
                    ret[19] = '\0';
                } else sprintf(ret, "%s", atom.val.str);
                break;
            case aat_dec:
                sprintf(ret, "%s", atom.val.dec_);
                break;
            case aat_dbl:
                sprintf(ret, "%s", atom.val.dbl);
                break;
            case aat_bln:
                sprintf(ret, "%s", atom.val.bln ? "true" : "false");
                break;
            case aat_qname:
                sprintf(ret, "%s", PFqname_str (atom.val.qname));
                break;
            default:
                break;
        }

    /* make sure that string terminates after maxlength */
    ret[maxlength - 1] = '\0';

    return ret;
}

/* --------------- Print operators and expressions --------------- */

/**
 * Print SQL algebra expression in AT&T dot notation.
 * @param dot Array into which we print
 * @param n The current node to print (function is recursive)
 */
static void
sqlalg_dot_expr (PFarray_t *dot, PFsa_expr_t *n)
{
    unsigned int c;
    assert(n->node_id);

    /* mark node visited */
    n->bit_dag = true;

    /* open up label */
    PFarray_printf (dot, "expr_%i [label=\"%s\\n", n->node_id, dot_expr_id[n->kind]);

    /* create additional semantic information */
    switch (n->kind)
    {
        case sa_expr_convert:
            PFarray_printf(dot, "to: %s\\n", PFalg_simple_type_str(n->type));
            PFarray_printf(dot, "%s", PFcol_str(n->col));
            break;

        case sa_expr_func:
        {
            PFarray_printf(dot, "%s\\n", dot_expr_func_id[n->sem.func.name]);
            PFarray_printf(dot, "%s", PFcol_str(n->col));
        }
            break;

        case sa_expr_num_gen:
        {
            PFsa_expr_t *expr;

            PFarray_printf(dot, "%s\\n", dot_expr_num_gen_id[n->sem.num_gen.kind]);

            /* print partitioning columns */
            if (n->sem.num_gen.kind == sa_num_gen_rownum &&
                elsize(n->sem.num_gen.part_cols) > 0)
            {
                PFarray_printf(dot, "part cols: <");
                for (c = 0; c < elsize(n->sem.num_gen.part_cols) - 1; c++) {
                    expr = elat(n->sem.num_gen.part_cols, c);
                    PFarray_printf(dot, "%s, ", PFcol_str(expr->col));
                }
                expr = elat(n->sem.num_gen.part_cols,
                            elsize(n->sem.num_gen.part_cols) - 1);
                PFarray_printf(dot, "%s>\\n", PFcol_str(expr->col));
            }

            if (elsize(n->sem.num_gen.sort_cols) > 0) {
                PFarray_printf(dot, "sort cols: <");
                for (c = 0; c < elsize(n->sem.num_gen.sort_cols) - 1; c++) {
                    expr = elat(n->sem.num_gen.sort_cols, c);
                    PFarray_printf(dot, "%s%s, ", PFcol_str(expr->col),
                                                   expr->sortorder != DIR_ASC ? " (desc)" : "");
                }
                expr = elat(n->sem.num_gen.sort_cols,
                            elsize(n->sem.num_gen.sort_cols) - 1);
                PFarray_printf(dot, "%s%s>\\n", PFcol_str(expr->col),
                                                 expr->sortorder != DIR_ASC ? " (desc)" : "");
            }

            PFarray_printf(dot, "%s", PFcol_str(n->col));
        }
            break;

        case sa_expr_comp:
            PFarray_printf(dot, "%s\\n", dot_expr_comp_id[n->sem.comp.kind]);
            PFarray_printf(dot, "%s", PFcol_str(n->col));
            break;

        case sa_expr_aggr:
            if (n->sem.aggr.kind == sa_aggr_count &&
                !n->child[0])
                PFarray_printf(dot, "count(*)\\n");
            else
                PFarray_printf(dot, "%s\\n", dot_expr_aggr_id[n->sem.aggr.kind]);

            PFarray_printf(dot, "%s", PFcol_str(n->col));
            break;

        case sa_expr_in:
        {
            PFsa_expr_t *expr;

            PFarray_printf(dot, "%s IN\\n", PFcol_str(n->sem.in.col));

            if (elsize(n->sem.in.in_list) > 0) {
                PFarray_printf(dot, "(");
                for (c = 0; c < elsize(n->sem.in.in_list) - 1; c++) {
                    expr = elat(n->sem.in.in_list, c);
                    PFarray_printf(dot, "%s, ", sqlalg_atom_str (expr->sem.atom.atom));
                }
                expr = elat(n->sem.in.in_list,
                            elsize(n->sem.in.in_list) - 1);
                PFarray_printf(dot, "%s)\\n", sqlalg_atom_str (expr->sem.atom.atom));
            }

            PFarray_printf(dot, "%s", PFcol_str(n->col));
        }
            break;

        case sa_expr_atom:
            /* print atom value and type */
            PFarray_printf(dot, "val: %s (%s)\\n", sqlalg_atom_str(n->sem.atom.atom),
                           PFalg_simple_type_str(n->type));

            PFarray_printf(dot, "%s", PFcol_str(n->col));
            break;

        case sa_expr_column:
            PFarray_printf(dot, "%s", PFcol_str(n->col));
            if ((n->col) != (n->sem.col.old))
                PFarray_printf (dot, " : %s", PFcol_str(n->sem.col.old));
            if ((n->sortorder) != DIR_ASC)
                PFarray_printf (dot, " (desc) \\n");
            break;


        default:
            break;
    }

    /* close up label */
    PFarray_printf (dot, "\", fillcolor=\"%s\" ];\n", dot_expr_color[n->kind]);

    for (c = 0; c < PFSA_EXPR_MAXCHILD && n->child[c]; c++) {
        PFarray_printf (dot,
                        "expr_%i -> expr_%i;\n",
                        n->node_id, n->child[c]->node_id);
    }

    for (c = 0; c < PFSA_EXPR_MAXCHILD && n->child[c]; c++) {
        if (!n->child[c]->bit_dag)
            sqlalg_dot_expr (dot, n->child[c]);
    }
}

/**
 * Print SQL algebra operator in AT&T dot notation.
 * @param dot Array into which we print
 * @param n The current node to print (function is recursive)
 */
static void
sqlalg_dot_op (PFarray_t *dot, PFarray_t *dot_expr, PFsa_op_t *n)
{
    unsigned int c, i, j;
    assert(n->node_id);

    /* mark node visited */
    n->bit_dag = true;

    /* open up label */
    PFarray_printf (dot,
                    "node_%i [label=\"{ <op%i> %s\\n",
                    n->node_id,
                    n->node_id,
                    dot_op_id[n->kind]);

    if (n->kind == sa_op_project &&
        n->distinct == true) PFarray_printf(dot, "DISTINCT\\n");

    /* NIL node: close label and return */
    if (n->kind == sa_op_nil_node){
        PFarray_printf (dot, "}\", fillcolor=\"%s\" ];\n", dot_op_color[n->kind]);
        return;
    }

    /* print schema for all operators */
    if (n->schema.count > 0) {
        PFarray_printf(dot, "Schema: ( ");
        for (i = 0; i < n->schema.count - 1; i++)
            PFarray_printf (dot, "%s:%s \\| ",
                            PFcol_str(n->schema.items[i].name),
                            PFalg_simple_type_str(n->schema.items[i].type));
        PFarray_printf (dot, "%s:%s )\\n",
                        PFcol_str(n->schema.items[i].name),
                        PFalg_simple_type_str(n->schema.items[i].type));
    }

    /* create additional semantic information for operator */
    switch (n->kind)
    {

        /* print table for literal table then return */
        case sa_op_literal_table:

            PFarray_printf(dot, "| { cols ");
            for (i = 0; i < n->schema.count; i++)
                PFarray_printf (dot, "| %s:%s",
                                PFcol_str(n->schema.items[i].name),
                                PFalg_simple_type_str(n->schema.items[i].type));
            PFarray_printf(dot, "}");
            break;

        case sa_op_serialize_rel:
        {
            PFalg_col_t  curr_col;
            PFsa_expr_t *curr_expr = NULL;

            /* print iter, pos and items */
            PFarray_printf(dot, "| { iter:\\n%s",
                           PFcol_str(n->sem.ser_rel.iter));

            PFarray_printf(dot, "| { pos:");
            for (i = 0; i < elsize(n->sem.ser_rel.order_list); i++) {
                curr_expr = elat(n->sem.ser_rel.order_list, i);
                PFarray_printf(dot, "| %s%s", PFcol_str(curr_expr->col),
                                                 curr_expr->sortorder != DIR_ASC ?
                                                     " (desc)" :
                                                     "");
            }
            PFarray_printf(dot, "}");

            PFarray_printf(dot, "| { items:");
            for (i = 0; i < PFalg_collist_size(n->sem.ser_rel.items); i++) {
                curr_col = PFalg_collist_at(n->sem.ser_rel.items, i);
                PFarray_printf(dot, "| %s", PFcol_str(curr_col));
            }
            PFarray_printf(dot, "}}");
        }
            break;


        case sa_op_project:

            PFarray_printf(dot, "| { exprs:");
            for (i = 0; i < elsize(n->sem.proj.expr_list); i++) {
                PFsa_expr_t *curr_expr = elat(n->sem.proj.expr_list,i);
                PFarray_printf (dot,
                                "| <expr%i> %s",
                                curr_expr->node_id,
                                PFcol_str(curr_expr->col));

                /* print edge from record entry to expression */
                PFarray_printf (dot_expr,
                                "node_%i:expr%i -> expr_%i;\n",
                                n->node_id,
                                curr_expr->node_id,
                                curr_expr->node_id);

                /* traverse associated expression trees */
                sqlalg_dot_expr(dot_expr, curr_expr);
            }
            PFarray_printf(dot, "}");
            break;

        case sa_op_select:

            PFarray_printf(dot, "| { exprs:");
            for (i = 0; i < elsize(n->sem.select.expr_list); i++) {
                PFsa_expr_t *curr_expr = elat(n->sem.select.expr_list,i);
                PFarray_printf (dot,
                                "| <expr%i> %s",
                                curr_expr->node_id,
                                PFcol_str(curr_expr->col));

                /* print edge from record entry to expression */
                PFarray_printf (dot_expr,
                                "node_%i:expr%i -> expr_%i;\n",
                                n->node_id,
                                curr_expr->node_id,
                                curr_expr->node_id);

                /* traverse associated expression trees */
                sqlalg_dot_expr(dot_expr, curr_expr);
            }
            PFarray_printf(dot, "}");
            break;

        case sa_op_groupby:

            PFarray_printf(dot, "| { prj:");
            for (i = 0; i < elsize(n->sem.groupby.prj_list); i++) {
                PFsa_expr_t *curr_expr = elat(n->sem.groupby.prj_list,i);
                PFarray_printf (dot,
                                "| <prj%i> %s",
                                curr_expr->node_id,
                                PFcol_str(curr_expr->col));

                /* print edge from record entry to expression */
                PFarray_printf (dot_expr,
                                "node_%i:prj%i -> expr_%i;\n",
                                n->node_id,
                                curr_expr->node_id,
                                curr_expr->node_id);

                /* traverse associated expression trees */
                sqlalg_dot_expr(dot_expr, curr_expr);
            }
            PFarray_printf(dot, "}");
            PFarray_printf(dot, "| { grp:");
            for (i = 0; i < elsize(n->sem.groupby.grp_list); i++) {
                PFsa_expr_t *curr_expr = elat(n->sem.groupby.grp_list,i);
                PFarray_printf (dot,
                                "| <grp%i> %s",
                                curr_expr->node_id,
                                PFcol_str(curr_expr->col));

                /* print edge from record entry to expression */
                PFarray_printf (dot_expr,
                                "node_%i:grp%i -> expr_%i;\n",
                                n->node_id,
                                curr_expr->node_id,
                                curr_expr->node_id);

                /* traverse associated expression trees */
                sqlalg_dot_expr(dot_expr, curr_expr);
            }
            PFarray_printf(dot, "}");
            break;

        case sa_op_table:
        {
            PFarray_printf(dot, "| { table name: | %s}", n->sem.table.name);
            /* print original names of table */
            PFarray_printf(dot, "| { cols: ");
            for (i = 0; i < elsize(n->sem.table.expr_list); i++) {
                PFsa_expr_t *curr_name = elat(n->sem.table.col_names, i);

                PFarray_printf(dot, "| %s: %s (%s) ", PFcol_str(n->schema.items[i].name),
                               sqlalg_atom_str(curr_name->sem.atom.atom),
                               PFalg_simple_type_str(n->schema.items[i].type));
            }
            PFarray_printf(dot, "}");
        }
            break;


        case sa_op_join:
        case sa_op_semijoin:
        case sa_op_antisemijoin:

            PFarray_printf(dot, "| { exprs:");
            for (i = 0; i < elsize(n->sem.join.expr_list); i++) {
                PFsa_expr_t *curr_expr = elat(n->sem.join.expr_list,i);
                PFarray_printf (dot,
                                "| <expr%i> %s",
                                curr_expr->node_id,
                                PFcol_str(curr_expr->col));

                /* print edge from record entry to expression */
                PFarray_printf (dot_expr,
                                "node_%i:expr%i -> expr_%i;\n",
                                n->node_id,
                                curr_expr->node_id,
                                curr_expr->node_id);

                /* traverse associated expression trees */
                sqlalg_dot_expr(dot_expr, curr_expr);
            }
            PFarray_printf(dot, "}");
            break;

        default:
            break;
    }

    /* close up label */
    PFarray_printf (dot, "}\", fillcolor=\"%s\" ];\n", dot_op_color[n->kind]);

    /* print extra node for literal table */
    if (n->kind == sa_op_literal_table) {
        PFarray_printf(dot, "subgraph clusterOp%i {\n"
                       "color=\"%s\";\n",
                       n->node_id,
                       dot_op_color[n->kind]);
        /* print table node */
        PFarray_printf (dot,
                        "node_%i_table [label=",
                        n->node_id);

        /* print table. if table is empty just print 'EMPTY TABLE'*/
        if (n->sem.literal_table.tuples_count > 0){
            PFarray_printf(dot, "<<table border=\"0\" cellborder=\"0\">");
            PFarray_printf(dot, "<tr>");
            for (i = 0; i < n->schema.count; i++)
                PFarray_printf (dot, "<td>%s:%s</td>",
                                PFcol_str(n->schema.items[i].name),
                                PFalg_simple_type_str(n->schema.items[i].type));
            PFarray_printf(dot, "</tr>");
            for (i = 0; i < n->sem.literal_table.tuples_count; i++) {
                PFalg_tuple_t curr_tuple = n->sem.literal_table.tuples[i];
                PFarray_printf(dot, "<tr>");
                for (j = 0; j < curr_tuple.count; j++) {
                    PFalg_atom_t curr_atom = curr_tuple.atoms[j];
                    PFarray_printf (dot,
                                    "<td>%s</td>",
                                    sqlalg_atom_str(curr_atom));
                }
                PFarray_printf(dot, "</tr>");
            }
            PFarray_printf(dot, "</table>>, ");
        } else {
            PFarray_printf(dot, "\"EMPTY TABLE\", ");
        }
        PFarray_printf (dot, "fillcolor=\"#FFFFFF\" ];\n");
        PFarray_printf (dot, "node_%i -> node_%i_table [style=invis];\n", n->node_id,
                        n->node_id);
        PFarray_printf(dot, "}\n");
    }


    /* remember if current operator resides inside a cluster (for drawing arrows) */
    bool cluster = false;

    /* flush expression buffer (if filled) and reset it afterwards */
    if (PFarray_last(dot_expr)) {
        PFarray_printf (dot,
                        "subgraph clusterOp%i {\n"
                        "color=\"%s\";\n"
                        "style=bold;\n"
                        "node [shape=ellipse];\n"
                        "edge [style=solid];\n"
                        "%s"
                        "}\n",
                        n->node_id,
                        dot_op_color[n->kind],
                        (char *) dot_expr->base);
        cluster = true;
        PFarray_last(dot_expr) = 0;
    }

    for (c = 0; c < PFSA_OP_MAXCHILD && n->child[c]; c++) {
        PFarray_printf (dot,
                        "node_%i -> node_%i",
                        n->node_id,
                        n->child[c]->node_id);
        /* arrow points to cluster? */
        if (cluster) PFarray_printf(dot, "[ltail=clusterOp%i]", n->node_id);
        PFarray_printf(dot, ";\n");
    }

    for (c = 0; c < PFSA_OP_MAXCHILD && n->child[c]; c++) {
        if (!n->child[c]->bit_dag)
            sqlalg_dot_op (dot, dot_expr, n->child[c]);
    }
}

/* --------------- Start dot output generation --------------- */

/**
 * Dump SQL algebra tree initialization in AT&T dot format
 */
static void
sqlalg_dot_init (FILE *f)
{
    fprintf (f, "digraph XQueryAlgebra {\n"
                "compound=true;\n"
                "ordering=out;\n"
                "node [shape=record];\n"
                "node [height=0.1];\n"
                "node [width=0.2];\n"
                "node [style=filled];\n"
                "node [color=\"#050505\"];\n"
                "node [fontsize=10];\n"
                "edge [fontsize=9];\n"
                "edge [dir=back];\n"
                "edge [style=bold];\n");
}

/**
 * Worker for PFsqlalg_dot and PFsqlalg_dot_bundle
 */
static void
sqlalg_dot_internal (FILE *f, PFsa_op_t *root)
{
    /* initialize array to hold dot output */
    PFarray_t *dot = PFarray (sizeof (char), 32000);
    PFarray_t *dot_helper = PFarray (sizeof (char), 3200);

    /* inside debugging we need to reset the dag bits first */
    PFsqlalg_dag_reset (root);
    PFsqlalg_create_node_id (root);
    PFsqlalg_infer_refctr (root);
    sqlalg_dot_op (dot, dot_helper, root); // worker anstossen
    PFsqlalg_dag_reset (root);
    PFsqlalg_reset_node_id (root);

    /* put content of array into file */
    fprintf (f, "%s}\n", (char *) dot->base);
}

/**
 * Dump SQL algebra in AT&T dot format
 * (pipe the output through `dot -Tps' to produce a Postscript file).
 *
 * @param f file to dump into
 * @param root root of SQL algebra plan
 */
void
PFsqlalg_dot (FILE *f, PFsa_op_t *root)
{
    assert (root);

    sqlalg_dot_init (f);
    sqlalg_dot_internal (f, root);
}

/* vim:set shiftwidth=4 expandtab: */
