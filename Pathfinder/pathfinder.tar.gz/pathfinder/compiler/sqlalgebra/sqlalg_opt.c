/**
 * @file
 *
 * Optimization of the SQL algebra: This file triggers the optimizations
 * which are defined in include/sqlalg_opt.h and implemented in sqlalg/opt.
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * $Id$
 */

#include "pf_config.h"
#include "pathfinder.h"
#include "sqlalg.h"
#include "sqlalg_dag.h"
#include "sqlalg_mnemonic.h"
#include "sqlalg_opt.h"
#include "mem.h"
#include "oops.h"

#include <stdio.h>
#include <assert.h>
#include <string.h>

/* Easily access subtree-parts */
#include "child_mnemonic.h"

/* Build IN lists: Look for select, join and semijoin operators in
   @a root and build IN lists for their expressions, if possible */
static PFsa_op_t *
build_in_lists (PFsa_op_t *root)
{
    PFsa_op_t *op;

    PFsqlalg_dag_reset (root);
    while ((op = PFsqlalg_find_op (sa_op_project, root)))
        PFsqlalgopt_in_lists (op);

    while ((op = PFsqlalg_find_op (sa_op_select, root)))
        PFsqlalgopt_in_lists (op);

    while ((op = PFsqlalg_find_op (sa_op_join, root)))
        PFsqlalgopt_in_lists (op);

    while ((op = PFsqlalg_find_op (sa_op_semijoin, root)))
        PFsqlalgopt_in_lists (op);

    return root;
}

/* Check for pattern (which is described in sqlalgebra/opt/antisemijoin.c)
   in @a root and replace it with the antisemijoin operator. */
static PFsa_op_t *
build_antisemijoin (PFsa_op_t *root)
{
    PFsa_op_t *op;

    PFsqlalg_dag_reset (root);
    PFsqlalg_infer_refctr (root);
    
    while ((op = PFsqlalg_find_op (sa_op_join, root)))
        PFsqlalgopt_antisemijoin (op);

    return root;
}

/* Function to start the optimizations */
static PFsa_op_t*
perform_optimizations (PFsa_op_t *root)
{
    /* Build IN lists */
    root = build_in_lists (root);

    /* Check for 'antisemijoin' pattern */
    root = build_antisemijoin (root);

    /* More optimizations to come here */

    return root;
}

/* Perform optimizations on @a root */
PFsa_op_t *
PFsqlalg_opt (PFsa_op_t *root)
{
    return perform_optimizations (root);
}

/* vim:set shiftwidth=4 expandtab filetype=c: */ 
