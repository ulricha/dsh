/**
 * @file
 *
 * Functions related to SQL algebra plan construction.
 *
 * This file mainly contains the constructor functions to create an
 * internal representation of the intermediate SQL algebra.
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * $Id$
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"

/** handling of variable argument lists */
#include <stdarg.h>
/** strcpy, strlen, ... */
#include <string.h>
#include <stdio.h>
/** assert() */
#include <assert.h>

#include "oops.h"
#include "mem.h"
#include "array.h"

#include "sqlalg.h"

#include "sqlalg_mnemonic.h"

#define INIT_ANTISEMIJOIN_FLAG(op) \
                       (op)->sem.join.antisemijoin_flag = false;

/* --------------- Expression nodes --------------- */

/**
 * Create an expression (leaf) node.
 */
static PFsa_expr_t *
sqlalg_expr_leaf (PFsa_expr_kind_t kind)
{
    PFsa_expr_t *ret = PFmalloc (sizeof (PFsa_expr_t));

    for (unsigned int i = 0; i < PFSA_EXPR_MAXCHILD; i++)
        ret->child[i] = NULL;

    ret->kind      = kind;
    ret->col       = col_NULL;
    ret->type      = 0;
    ret->refctr    = 0;
    ret->bit_reset = false;
    ret->bit_dag   = false;
    ret->node_id   = 0;
    ret->sortorder = DIR_ASC;     /* default sortorder ascending */

    return ret;
}

/**
 * Create an expression node with one child.
 * Similar to #sqlalg_expr_leaf(), but additionally wires one child.
 */
static PFsa_expr_t *
sqlalg_expr_wire1 (PFsa_expr_kind_t kind, const PFsa_expr_t *n)
{
    PFsa_expr_t *ret = sqlalg_expr_leaf (kind);

    assert (n);

    ret->child[0] = (PFsa_expr_t *) n;

    return ret;
}

/**
 * Create an expression node with two children.
 * Similar to #sqlalg_expr_wire1(), but additionally wires another child.
 */
static PFsa_expr_t *
sqlalg_expr_wire2 (PFsa_expr_kind_t kind,
                   const PFsa_expr_t *n1, const PFsa_expr_t *n2)
{
    PFsa_expr_t *ret = sqlalg_expr_wire1 (kind, n1);

    assert (n2);

    ret->child[1] = (PFsa_expr_t *) n2;

    return ret;
}

/**
 * Create an expression node with two children.
 * Similar to #sqlalg_expr_wire2(), but additionally wires another child.
 */
static PFsa_expr_t *
sqlalg_expr_wire3 (PFsa_expr_kind_t kind,
                   const PFsa_expr_t *n1, const PFsa_expr_t *n2, const PFsa_expr_t *n3)
{
    PFsa_expr_t *ret = sqlalg_expr_wire2 (kind, n1, n2);

    assert (n3);

    ret->child[2] = (PFsa_expr_t *) n3;

    return ret;
}

/* --------------- Operator nodes --------------- */

/**
 * Create a logical algebra operator (leaf) node.
 *
 * Allocates memory for an algebra operator leaf node
 * and initializes all its fields. The node will have the
 * kind @a kind.
 */
static PFsa_op_t *
sqlalg_op_leaf (PFsa_op_kind_t kind)
{
    PFsa_op_t *ret = PFmalloc (sizeof (PFsa_op_t));

    for (unsigned int i = 0; i < PFSA_OP_MAXCHILD; i++)
        ret->child[i] = NULL;

    ret->kind      = kind;
    ret->distinct  = false;
    ret->refctr    = 0;
    ret->bit_reset = false;
    ret->bit_dag   = false;
    ret->node_id   = 0;

    ret->sql_ann   = NULL;

    return ret;
}

/**
 * Create an algebra operator node with one child.
 * Similar to #la_op_leaf(), but additionally wires one child.
 */
static PFsa_op_t *
sqlalg_op_wire1 (PFsa_op_kind_t kind, const PFsa_op_t *n)
{
    PFsa_op_t *ret = sqlalg_op_leaf (kind);

    assert (n);

    ret->child[0] = (PFsa_op_t *) n;

    return ret;
}


/**
 * Create an algebra operator node with two children.
 * Similar to #la_op_wire1(), but additionally wires another child.
 */
static PFsa_op_t *
sqlalg_op_wire2 (PFsa_op_kind_t kind, const PFsa_op_t *n1, const PFsa_op_t *n2)
{
    PFsa_op_t *ret = sqlalg_op_wire1 (kind, n1);

    assert (n2);

    ret->child[1] = (PFsa_op_t *) n2;

    return ret;
}

/* -------------------- Auxiliary functions --------------------*/

#ifndef NDEBUG
/* Auxiliary function to determine if all
 columns that are referenced in expr are
 columns of schema
 */
static bool
expr_cols_in_schema (PFsa_expr_t *expr, PFalg_schema_t schema)
{
    unsigned int i;

    if (expr->kind == sa_expr_column) {
        /* Loop to check if original expression name is in schema */
        for (i = 0; i < schema.count; i++) {
            if (expr->sem.col.old == schema.items[i].name)
                return true;
        }
        /* column name not in schema */
        return false;
    }
    else {
        /* traverse the children expressions */
        for (i = 0; i < PFSA_EXPR_MAXCHILD && expr->child[i]; i++){

            /* propagate missing match */
            if (!expr_cols_in_schema(expr->child[i], schema))
                return false;
        }
        /* no problem detected */
        return true;
    }
}

#endif

static PFalg_schema_t
concat_schemas (PFalg_schema_t schema1, PFalg_schema_t schema2)
{
    unsigned int i, j;
    PFalg_schema_t *schema = PFmalloc (sizeof (PFalg_schema_t));

    schema->count = schema1.count + schema2.count;
    schema->items = PFmalloc (schema->count * sizeof (*(schema->items)));

    /* copy schema */
    for (i = 0; i < schema1.count; i++) {
        schema->items[i] = schema1.items[i];
    }
    for (j = 0; j < schema2.count; j++) {
        schema->items[i + j] = schema2.items[j];
    }

    return *schema;
}

/* Auxiliary function to check if @a expr contains number generating
   functions (non-static because needed in lalg2sqlalg.c) */
bool
contains_num_gen (PFsa_expr_t *expr)
{
    unsigned int i;

    if (expr->kind == sa_expr_num_gen)
        return true;

    for (i = 0; i < PFSA_EXPR_MAXCHILD && expr->child[i]; i++)
        /* propagate encountered number generating expression */
        if (contains_num_gen (expr->child[i]))
                return true;

    /* no number generating expression found */
    return false;
}

/* Auxiliary function to get schema from a list of expressions
   (non-static because needed in lalg2sqlalg.c) */
PFalg_schema_t
schema_from_exprlist(PFsa_exprlist_t *expr_list)
{
    unsigned int    i;
    PFalg_schema_t *ret       = PFmalloc (sizeof(PFalg_schema_t));
    PFsa_expr_t    *curr_expr = NULL;

    ret->count = elsize(expr_list);
    ret->items = PFmalloc(ret->count * sizeof(*(ret->items)));

    /* The new schema consists of columns in expr_list  */
    for (i = 0; i < elsize(expr_list); i++) {
        curr_expr = elat(expr_list, i);
        ret->items[i].name = curr_expr->col;
        ret->items[i].type = curr_expr->type;
    }

    return *ret;
}

/* Auxiliary function to get schema from an operator node */
static PFalg_schema_t
schema_from_operator(PFsa_op_t *op)
{
    PFalg_schema_t *ret = PFmalloc (sizeof(PFalg_schema_t));
    unsigned int i;

    /* allocate memory for result schema which is the same as the schema of op */
    ret->count = op->schema.count;
    ret->items = PFmalloc(ret->count * sizeof(*(ret->items)));

    /* copy schema */
    for (i = 0; i < op->schema.count; i++) {
        ret->items[i] = op->schema.items[i];
    }

    return *ret;
}

/* --------------- Constructors for expressions --------------- */

/* Constructor for function expression */
PFsa_expr_t *
PFsqlalg_expr_func (PFsa_expr_func_name name, PFsa_exprlist_t *child_list,
                    PFalg_col_t res_col)
{
    PFsa_expr_t *ret = NULL;
    PFsa_expr_t *n1 = NULL;
    PFsa_expr_t *n2 = NULL;
    PFsa_expr_t *n3 = NULL;

    /* Common cases */
    if (elsize(child_list) == 0)
    {
        ret = sqlalg_expr_leaf (sa_expr_func);
    }
    else if (elsize(child_list) == 1)
    {
        n1  = elat(child_list, 0);
        ret = sqlalg_expr_wire1 (sa_expr_func, n1);
    }
    else if (elsize(child_list) == 2)
    {
        n1  = elat(child_list, 0);
        n2  = elat(child_list, 1);
        ret = sqlalg_expr_wire2 (sa_expr_func, n1, n2);
    }
    else if (elsize(child_list) == 3)
    {
        n1  = elat(child_list, 0);
        n2  = elat(child_list, 1);
        n3  = elat(child_list, 2);
        ret = sqlalg_expr_wire3 (sa_expr_func, n1, n2, n3);
    }
    else if (elsize(child_list) > PFSA_EXPR_MAXCHILD)
    {
        /* show an error message */
        PFoops (OOPS_FATAL,
                "SQL algebra expression function: expression cannot have more "
                "than %i children", PFSA_EXPR_MAXCHILD);
    }

    ret->sem.func.name = name;
    ret->col = res_col;

    switch (name) {
        case sa_func_and:
        case sa_func_or:
        case sa_func_not:
        case sa_func_like:
            ret->type = aat_bln;
            break;

        case sa_func_div:
            ret->type = aat_dbl;
            break;

        case sa_func_mod:
        case sa_func_year_from_date:
        case sa_func_month_from_date:
        case sa_func_day_from_date:
            ret->type = aat_int;
            break;

        case sa_func_substring:
        case sa_func_substring_len:
            ret->type = aat_str;
            break;

        default:
            ret->type = n1 ? n1->type :       /* Assuming that child type will be okay */
                             aat_uA;
            break;
    }

    return ret;
}

/* Constructor for number generating function expression */
PFsa_expr_t *
PFsqlalg_expr_num_gen (PFsa_num_gen_kind_t kind, PFsa_exprlist_t *sort_list,
                       PFsa_exprlist_t *part_list, PFalg_col_t res_col)
{
#ifndef NDEBUG
    unsigned int i;
    PFsa_expr_t *curr_expr;
#endif
    PFsa_expr_t *ret = sqlalg_expr_leaf (sa_expr_num_gen);

    ret->sem.num_gen.kind = kind;
    ret->sem.num_gen.sort_cols = sort_list;
    ret->sem.num_gen.part_cols = part_list;

    ret->col = res_col;
    ret->type = aat_nat;

#ifndef NDEBUG
    /* Do not permit nesting of number generating expressions */
    for (i = 0; i < elsize(sort_list); i++) {
        curr_expr = elat(sort_list, i);
        if (contains_num_gen (curr_expr))
            PFoops (OOPS_FATAL,
                    "SQL algebra: number generating expression must not"
                    " contain other number generating expressions");
    }
    for (i = 0; i < elsize(part_list); i++) {
        curr_expr = elat(part_list, i);
        if (contains_num_gen (curr_expr))
            PFoops (OOPS_FATAL,
                    "SQL algebra: number generating expression must not"
                    " contain other number generating expressions");
    }
#endif

    return ret;
}

/* Constructor for comparison expression */
PFsa_expr_t *
PFsqlalg_expr_comp (PFsa_expr_t *n1, PFsa_expr_t *n2, PFsa_comp_kind_t kind,
                 PFalg_col_t res_col)
{
    PFsa_expr_t *ret = sqlalg_expr_wire2 (sa_expr_comp, n1, n2);

    ret->sem.comp.kind = kind;

    ret->col = res_col;
    ret->type = aat_bln;

    return ret;
}

/* Constructor for aggr expression */
PFsa_expr_t *
PFsqlalg_expr_aggr (PFsa_expr_t *n, PFsa_aggr_kind_t aggr_kind,
                    PFalg_col_t res_col)
{
    PFsa_expr_t *ret = !n
                        ? sqlalg_expr_leaf (sa_expr_aggr)
                        : sqlalg_expr_wire1 (sa_expr_aggr, n);

    ret->sem.aggr.kind = aggr_kind;
    ret->col = res_col;

    switch (aggr_kind) {
        case sa_aggr_count:
            ret->type = aat_nat;
            break;
        case sa_aggr_sum:
            ret->type = aat_nat;
            break;
        default:
            ret->type = n ? n->type : aat_int;
            break;
    }


#ifndef NDEBUG
    if (!n && aggr_kind != sa_aggr_count)
        PFoops (OOPS_FATAL,
                "aggr: input expression expected.");
#endif

    return ret;
}

/* Constructor for convert expression */
PFsa_expr_t *
PFsqlalg_expr_convert (PFsa_expr_t *n, PFalg_simple_type_t type,
                       PFalg_col_t res_col)
{
    PFsa_expr_t *ret = sqlalg_expr_wire1 (sa_expr_convert, n);

    ret->col = res_col;
    ret->type = type;

    return ret;
}

/* Constructor for in list expression */
PFsa_expr_t *
PFsqlalg_expr_in (PFalg_col_t col, PFsa_exprlist_t *in_list,
                  PFalg_col_t res_col)
{
#ifndef NDEBUG
    unsigned int i;
    PFsa_expr_t *curr_expr = NULL;
#endif
    PFsa_expr_t *ret = sqlalg_expr_leaf (sa_expr_in);

    ret->sem.in.col = col;
    ret->sem.in.in_list = in_list;

    ret->col = res_col;
    ret->type = aat_bln;

#ifndef NDEBUG
    for (i = 0; i < elsize(in_list); i++) {
        curr_expr = elat(in_list, i);
        if (curr_expr->kind != sa_expr_atom)
            PFoops (OOPS_FATAL,
                    "SQL algebra in list operator can only contain atomic values");
    }
#endif

    return ret;
}

/* Constructor for column expression */
PFsa_expr_t *
PFsqlalg_expr_column (PFalg_col_t col, PFalg_simple_type_t type)
{
    PFsa_expr_t *ret = sqlalg_expr_leaf (sa_expr_column);

    ret->sem.col.old = col;
    ret->col = col;
    ret->type = type;

    return ret;
}

/* Constructor for atom expression */
PFsa_expr_t *
PFsqlalg_expr_atom (PFalg_col_t res_col, PFalg_atom_t atom)
{
    PFsa_expr_t *ret = sqlalg_expr_leaf (sa_expr_atom);

    ret->sem.atom.atom = atom;
    ret->col = res_col;
    ret->type = atom.type;

    return ret;
}


/* --------------- Constructors for operators --------------- */

/* Constructor for nil node operator */
PFsa_op_t *
PFsqlalg_op_nil_node (void)
{
    PFsa_op_t *ret = sqlalg_op_leaf(sa_op_nil_node);
    return ret;
}

/* Constructor for serialize operator */
PFsa_op_t *
PFsqlalg_op_serialize_rel (PFsa_op_t *DAG, PFsa_op_t *side_effects,
                           PFalg_col_t iter,
                           PFsa_exprlist_t *order_list,
                           PFalg_collist_t *items)
{
    PFsa_op_t *ret = sqlalg_op_wire2 (sa_op_serialize_rel, side_effects, DAG);

    ret->schema = schema_from_operator(DAG);

    ret->sem.ser_rel.iter  = iter;
    ret->sem.ser_rel.order_list = order_list;
    ret->sem.ser_rel.items = items;

    return ret;
}

/* Constructor for project operator */
PFsa_op_t *
PFsqlalg_op_project (PFsa_op_t *n, bool distinct_flag,
                     PFsa_exprlist_t *expr_list)
{
    PFsa_op_t *ret = sqlalg_op_wire1 (sa_op_project, n);
#ifndef NDEBUG
    unsigned int i;
    PFsa_expr_t *curr_expr;
#endif

    /* Get schema from colum names in expr_list */
    ret->schema = schema_from_exprlist (expr_list);

    ret->distinct = distinct_flag;
    ret->sem.proj.expr_list = expr_list;

#ifndef NDEBUG
    /* Check if expr_list only contains expressions with columns from n->schema */
    for (i = 0; i < elsize(expr_list); i++) {
        curr_expr = elat(expr_list, i);

        if (!expr_cols_in_schema (curr_expr, n->schema)) {
            PFoops (OOPS_FATAL,
                    "SQL algebra project: expression for column %s references unknown column",
                    PFcol_str (curr_expr->col));
        }
    }
#endif

    return ret;
}

/* Constructor for select operator */
PFsa_op_t *
PFsqlalg_op_select (PFsa_op_t *n, PFsa_exprlist_t *expr_list)
{
    PFsa_op_t *ret = sqlalg_op_wire1 (sa_op_select, n);
#ifndef NDEBUG
    unsigned int i;
    PFsa_expr_t *curr_expr;
#endif

    ret->schema = schema_from_operator(n);

    ret->sem.select.expr_list = expr_list;

#ifndef NDEBUG
    for (i = 0; i < elsize(expr_list); i++) {
        curr_expr = elat(expr_list, i);

        /* check which type of expressions reside in expr_list */
        if (curr_expr->type != aat_bln) {
            PFoops (OOPS_FATAL,
                    "SQL algebra select: only expressions with type boolean"
                    " can be in conjunction list");
        }

        /* Check if expr_list only contains expressions with columns from n->schema */
        if (!expr_cols_in_schema (curr_expr, n->schema)) {
            PFoops (OOPS_FATAL,
                    "SQL algebra select: expression for column %s references unknown column",
                    PFcol_str (curr_expr->col));
        }

        /* Check if expr_list contains number generating expressions */
        if (contains_num_gen (curr_expr))
            PFoops (OOPS_FATAL,
                    "SQL algebra select: expression contains number generating expressions");
    }
#endif

    return ret;
}

/* Constructor for literal table operator */
PFsa_op_t *
PFsqlalg_op_literal_table (PFalg_schema_t names,
                           unsigned int tuples_count, PFalg_tuple_t *tuples)
{
    PFsa_op_t *ret = sqlalg_op_leaf (sa_op_literal_table);
    unsigned int i;

    /* copy the passed schema */
    ret->schema.count = names.count;
    ret->schema.items = PFmalloc (ret->schema.count * sizeof(*(ret->schema.items)));

    for (i = 0; i < names.count; i++) {
        ret->schema.items[i] = names.items[i];
    }

    ret->sem.literal_table.tuples_count = tuples_count;
    ret->sem.literal_table.tuples = tuples;

#ifndef NDEBUG
    /* check if all tuples have same schema as the given schema "names" */
    for (i = 0; i < tuples_count; i++) {
        /* same number of columns? */
        if (names.count != tuples[i].count) {
            PFoops (OOPS_FATAL,
                    "SQL algebra literal table: tuplelist contains too wide/too small tuple");
        }
    }

    for (i = 0; i < names.count; i++) {
        if (!monomorphic(names.items[i].type))
                PFoops(OOPS_FATAL,
                    "SQL algebra literal table: found polymorphic column"
                    " (%s)", PFcol_str(names.items[i].name));
    }
#endif

    return ret;
}

/* Constructor for table operator */
PFsa_op_t *
PFsqlalg_op_table (char* name, PFalg_schema_t schema,
                   PFsa_exprlist_t *expr_list, PFsa_exprlist_t *col_names)
{
    assert(name);

    PFsa_op_t *ret = sqlalg_op_leaf (sa_op_table);

    ret->schema = schema;

    ret->sem.table.name = name;
    ret->sem.table.expr_list = expr_list;
    ret->sem.table.col_names = col_names;

    return ret;
}

/* Constructor for union operator. Note that this operator expects
   its input operators to have the exact same schema. */
PFsa_op_t *
PFsqlalg_op_union (PFsa_op_t *n1, PFsa_op_t *n2)
{
    PFsa_op_t *ret = sqlalg_op_wire2 (sa_op_union, n1, n2);
#ifndef NDEBUG
    unsigned int i;
#endif

    ret->schema = schema_from_operator(n1);

#ifndef NDEBUG
    /* union requires schemata of same size */
    if (n1->schema.count != n2->schema.count) {
        PFoops (OOPS_FATAL,
                "SQL algebra union: input operators have  different"
                " number of columns (%i and %i)",
                n1->schema.count, n2->schema.count);
    }

    /* union requires schemata of same names and types */
    for (i = 0; i < n1->schema.count; i++) {
        if (n1->schema.items[i].name != n2->schema.items[i].name)
                PFoops (OOPS_FATAL,
                        "SQL algebra union: unaligned name found at column"
                        " position %i: left child: %s, right child: %s",
                        i, PFcol_str(n1->schema.items[i].name),
                        PFcol_str(n2->schema.items[i].name));

        if  (n1->schema.items[i].type != n2->schema.items[i].type)
            PFoops (OOPS_FATAL,
                    "SQL algebra union: polymorphic columns found: %s (%s) and %s (%s)",
                    PFcol_str (n1->schema.items[i].name),
                    PFalg_simple_type_str (n1->schema.items[i].type),
                    PFcol_str (n2->schema.items[i].name),
                    PFalg_simple_type_str (n2->schema.items[i].type));
    }
#endif
    return ret;
}

/* Constructor for except operator. Note that this operator expects
    its input operators to have the exact same schema.  */
PFsa_op_t *
PFsqlalg_op_except (PFsa_op_t *n1, PFsa_op_t *n2)
{
    PFsa_op_t *ret = sqlalg_op_wire2 (sa_op_except, n1, n2);
#ifndef NDEBUG
    unsigned int i;
#endif

    ret->schema = schema_from_operator(n1);

#ifndef NDEBUG
    /* union requires schemata of same size */
    if (n1->schema.count != n2->schema.count) {
        PFoops (OOPS_FATAL,
                "SQL algebra except: input operators have  different"
                " number of columns (%i and %i)",
                n1->schema.count, n2->schema.count);
    }

    /* union requires schemata of same names and types */
    for (i = 0; i < n1->schema.count; i++) {
        if (n1->schema.items[i].name != n2->schema.items[i].name)
                PFoops (OOPS_FATAL,
                        "SQL algebra except: unaligned name found at column"
                        " position %i: left child: %s, right child: %s",
                        i, PFcol_str(n1->schema.items[i].name),
                        PFcol_str(n2->schema.items[i].name));

        if  (n1->schema.items[i].type != n2->schema.items[i].type)
            PFoops (OOPS_FATAL,
                    "SQL algebra except: polymorphic columns found: %s (%s) and %s (%s)",
                    PFcol_str (n1->schema.items[i].name),
                    PFalg_simple_type_str (n1->schema.items[i].type),
                    PFcol_str (n2->schema.items[i].name),
                    PFalg_simple_type_str (n2->schema.items[i].type));
    }
#endif

    return ret;
}

/* Constructor for groupby operator */
PFsa_op_t *
PFsqlalg_op_groupby (PFsa_op_t *n,
                     PFsa_exprlist_t *grp_list, PFsa_exprlist_t *prj_list)
{
#ifndef NDEBUG
    unsigned int i, j, k;
    PFsa_expr_t *curr_prj  = NULL;
    PFsa_expr_t *curr_grp  = NULL;
    PFsa_expr_t *curr_sort = NULL;
    PFsa_expr_t *curr_part = NULL;
#endif
    PFsa_op_t *ret = sqlalg_op_wire1 (sa_op_groupby, n);

    /* Get schema from colum names in prj_list */
    ret->schema = schema_from_exprlist (prj_list);

    ret->sem.groupby.grp_list = grp_list;
    ret->sem.groupby.prj_list = prj_list;

#ifndef NDEBUG
    /* Check if prj_list only contains expressions with columns from n->schema */
    for (i = 0; i < elsize(prj_list); i++) {
        curr_prj = elat(prj_list, i);

        if (!expr_cols_in_schema (curr_prj, n->schema)) {
            PFoops (OOPS_FATAL,
                    "SQL algebra group by: expression for column %s references unknown column",
                    PFcol_str (curr_prj->col));
        }
    }

    /* Check if grp_list does not contain number generating expressions */
    for (i = 0; i < elsize(grp_list); i++) {
        curr_grp = elat(grp_list, i);
        if (contains_num_gen (curr_grp))
            PFoops (OOPS_FATAL,
                    "SQL algebra group by: group by list must not contain"
                    " number generating expressions");
    }

    /* check if every non-aggregate column in prj_list is also in grp_list */
    for (i = 0; i < elsize(prj_list); i++) {
        curr_prj = elat(prj_list, i);

        if (curr_prj->kind == sa_expr_aggr) {
            /* Aggregate functions do not need a correspondent in grp_list */
            continue;
        }

        /* If a number generating expression is in prj_list, we have to check
           if the columns in its part and sort list also appear in grp_list */
        if (curr_prj->kind == sa_expr_num_gen) {
            /* Check if columns in part list of number generating expression 
               appear in grp_list */
            for (j = 0; j < elsize(curr_prj->sem.num_gen.part_cols); j++) {
                curr_part = elat(curr_prj->sem.num_gen.part_cols, j);

                /* Look for correspondent of curr_part in grp_list */
                for (k = 0; k < elsize(grp_list); k++) {
                    curr_grp = elat(grp_list, k);
                    if (curr_part->col == curr_grp->col)
                        break;
                }
                if (k >= elsize(grp_list))
                    PFoops (OOPS_FATAL,
                        "SQL algebra group by: partitioning column %s of number"
                        " generating function must also appear in group by list",
                        PFcol_str(curr_part->col));
            }

            /* Check if columns in sort list of number generating expression 
               appear in grp_list */
            for (j = 0; j < elsize(curr_prj->sem.num_gen.sort_cols); j++) {
                curr_sort = elat(curr_prj->sem.num_gen.sort_cols, j);

                /* Look for correspondent of curr_sort in grp_list */
                for (k = 0; k < elsize(grp_list); k++) {
                    curr_grp = elat(grp_list, k);
                    if (curr_sort->col == curr_grp->col)
                        break;
                }
                if (k >= elsize(grp_list))
                    PFoops (OOPS_FATAL,
                        "SQL algebra group by: sort column %s of number generating "
                        " function must also appear in group by list",
                        PFcol_str(curr_sort->col));
            }
            /* No problem found */
            continue;
        }

        /* Look for correspondent of curr_prj in grp_list */
        for (j = 0; j < elsize(grp_list); j++) {
            curr_grp = elat(grp_list, j);
            if (curr_prj->col == curr_grp->col) {
                break;
            }
        }

        if (j >= elsize(grp_list))
            PFoops (OOPS_FATAL,
                    "SQL algebra group by: column %s must also appear in group by list",
                    PFcol_str(curr_prj->col));

    }
#endif

    return ret;
}

/* Constructor for join operator */
PFsa_op_t *
PFsqlalg_op_join (PFsa_op_t *n1, PFsa_op_t *n2, PFsa_exprlist_t *expr_list)
{
#ifndef NDEBUG
    PFsa_expr_t *curr_expr;
#endif
    PFsa_op_t *ret = sqlalg_op_wire2 (sa_op_join, n1, n2);
    unsigned int i;

    ret->schema = concat_schemas (n1->schema, n2->schema);

    ret->sem.join.expr_list = expr_list;
    
    INIT_ANTISEMIJOIN_FLAG(ret);

#ifndef NDEBUG
    for (i = 0; i < elsize(expr_list); i++) {
        curr_expr = elat(expr_list, i);

        /* check which type of expressions reside in expr_list */
        if (curr_expr->type != aat_bln)
            PFoops (OOPS_FATAL,
                    "SQL algebra join: only booleans can be in conjunction list");

       /* Check if expr_list only contains expressions with columns from ret->schema.
          Use of ret->schema because expr_list can contain columns from both children
          and ret->schema represents all these columns */
        if (!expr_cols_in_schema (curr_expr, ret->schema))
            PFoops (OOPS_FATAL,
                    "SQL algebra join: expression for column %s references unknown column",
                    PFcol_str (curr_expr->col));

        /* Check if expr_list contains number generating expressions */
        if (contains_num_gen (curr_expr))
            PFoops (OOPS_FATAL,
                    "SQL algebra join: expression contains number generating expressions");
    }
#endif

    return ret;
}

/* Constructor for semijoin operator */
PFsa_op_t *
PFsqlalg_op_semijoin (PFsa_op_t *n1, PFsa_op_t *n2, PFsa_exprlist_t *expr_list)
{
#ifndef NDEBUG
    unsigned int i;
    PFsa_expr_t *curr_expr;
    PFalg_schema_t schema;
#endif
    PFsa_op_t *ret = sqlalg_op_wire2 (sa_op_semijoin, n1, n2);
    
    ret->schema = schema_from_operator(n1);

    ret->sem.join.expr_list = expr_list;

    INIT_ANTISEMIJOIN_FLAG(ret);

#ifndef NDEBUG
    schema = concat_schemas (n1->schema, n2->schema);

    for (i = 0; i < elsize(expr_list); i++) {
        curr_expr = elat(expr_list, i);

        /* check which type of expressions reside in expr_list */
        if (curr_expr->type != aat_bln)
            PFoops (OOPS_FATAL,
                    "SQL algebra semijoin: only booleans can be in conjunction list");

        /* Check if expr_list only contains expressions with columns from n1->schema
           or n2->schema. */
        if (!expr_cols_in_schema (curr_expr, schema))
            PFoops (OOPS_FATAL,
                    "SQL algebra semijoin: expression for column %s references unknown column",
                    PFcol_str (curr_expr->col));

        /* Check if expr_list contains number generating expressions */
        if (contains_num_gen (curr_expr))
            PFoops (OOPS_FATAL,
                    "SQL algebra semijoin: expression contains number generating expressions");
    }
#endif

    return ret;
}

/* Constructor for antisemijoin operator */
PFsa_op_t *
PFsqlalg_op_antisemijoin (PFsa_op_t *n1, PFsa_op_t *n2, PFsa_exprlist_t *expr_list)
{
#ifndef NDEBUG
    unsigned int i;
    PFsa_expr_t *curr_expr;
    PFalg_schema_t schema;
#endif
    PFsa_op_t *ret = sqlalg_op_wire2 (sa_op_antisemijoin, n1, n2);
    
    ret->schema = schema_from_operator(n1);

    ret->sem.join.expr_list = expr_list;

    /* Note: Although this is the antisemijoin constructor, set this flag
       false as it will be correctly filled while translating LA to SA */
    INIT_ANTISEMIJOIN_FLAG(ret);

#ifndef NDEBUG
    schema = concat_schemas (n1->schema, n2->schema);

    for (i = 0; i < elsize(expr_list); i++) {
        curr_expr = elat(expr_list, i);

        /* check which type of expressions reside in expr_list */
        if (curr_expr->type != aat_bln)
            PFoops (OOPS_FATAL,
                    "SQL algebra semijoin: only booleans can be in conjunction list");

        /* Check if expr_list only contains expressions with columns from n1->schema
           or n2->schema. */
        if (!expr_cols_in_schema (curr_expr, schema))
            PFoops (OOPS_FATAL,
                    "SQL algebra semijoin: expression for column %s references unknown column",
                    PFcol_str (curr_expr->col));

        /* Check if expr_list contains number generating expressions */
        if (contains_num_gen (curr_expr))
            PFoops (OOPS_FATAL,
                    "SQL algebra semijoin: expression contains number generating expressions");
    }
#endif

    return ret;
}

/* Constructor for cross operator */
PFsa_op_t *
PFsqlalg_op_cross (PFsa_op_t *n1, PFsa_op_t *n2)
{
    PFsa_op_t *ret = sqlalg_op_wire2 (sa_op_cross, n1, n2);

    ret->schema = concat_schemas (n1->schema, n2->schema);

    return ret;
}

/* vim:set shiftwidth=4 expandtab: */
