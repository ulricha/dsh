/* Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.pathfinder-xquery.org/license
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2011 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *//**
 *
 * @file
 *
 * Functions related to the traversal of SQL algebra DAGs
 */

#include "pf_config.h"
#include "pathfinder.h"
#include <stdio.h>
#include <assert.h>

#include "sqlalg_dag.h"
#include "sqlalg_mnemonic.h"

/* --------------- DAG traversal functions --------------- */

/* flags to ensure a real DAG traversal */
#define STOP 0
#define DUMMY 1

/* Functions to perform the work */

/* helper function that prepares the
 DAG bit reset for expression nodes */
static unsigned int
prepare_reset_expr(PFsa_expr_t *n, unsigned int dummy)
{
    assert (n);

    if (n->bit_reset)
        return STOP;
    else
        n->bit_reset = true;

    return dummy;
}

/* helper function that prepares the
 DAG bit reset for expression nodes */
static unsigned int
prepare_reset_op(PFsa_op_t *n, unsigned int dummy)
{
    assert (n);

    if (n->bit_reset)
        return STOP;
    else
        n->bit_reset = true;

    return dummy;
}

/* helper function to reset the DAG bit in expressions */
static unsigned int
reset_expr (PFsa_expr_t *n, unsigned int dummy)
{
    assert (n);

    if (!n->bit_reset)
        return STOP;

    n->bit_reset = false;
    n->bit_dag = false;
    return dummy;
}

/* helper function to reset the DAG bit in operators */
static unsigned int
reset_op (PFsa_op_t *n, unsigned int dummy)
{
    assert (n);

    if (!n->bit_reset)
        return STOP;

    n->bit_reset = false;
    n->bit_dag = false;
    return dummy;
}

/* helper function that sets the
 node id for expression nodes */
static unsigned int
create_node_id_expr (PFsa_expr_t *n, unsigned int node_id)
{
    if (n->bit_dag)
        return STOP;
    else
        n->bit_dag = true;

    /* set node id */
    n->node_id = node_id++;

    return node_id;
}

/* helper function that sets the
 node id for operators nodes */
static unsigned int
create_node_id_op (PFsa_op_t *n, unsigned int node_id)
{
    if (n->bit_dag)
        return STOP;
    else
        n->bit_dag = true;

    /* set node id */
    n->node_id = node_id++;

    return node_id;
}

/* helper function that resets the
 node id for expression nodes */
static unsigned int
reset_node_id_expr(PFsa_expr_t *n, unsigned int dummy)
{
    assert (n);

    if (n->bit_dag)
        return STOP;
    else
        n->bit_dag = true;

    /* reset node id */
    n->node_id = 0;

    return dummy;
}

/* helper function that resets the
 node id for operator nodes */
static unsigned int
reset_node_id_op(PFsa_op_t *n, unsigned int dummy)
{
    assert (n);

    if (n->bit_dag)
        return STOP;
    else
        n->bit_dag = true;
    /* reset node id */

    n->node_id = 0;

    return dummy;
}

/* helper function that infers the
 reference counter for expression nodes */
static unsigned int
infer_refctr_expr(PFsa_expr_t *n, unsigned int dummy)
{
    assert (n);

    /* count number of incoming edges */
    n->refctr++;

    /* only descend once */
    if (n->bit_dag)
        return STOP;
    else
        n->bit_dag = true;

    n->refctr = 1;

    return dummy;
}

/* helper function that infers the
 reference counter for operator nodes */
static unsigned int
infer_refctr_op(PFsa_op_t *n, unsigned int dummy)
{
    assert (n);

    /* count number of incoming edges */
    n->refctr++;

    /* only descend once */
    if (n->bit_dag)
        return STOP;
    else
        n->bit_dag = true;

    n->refctr = 1;

    return dummy;
}

/* Functions to traverse the DAG */

/* Stub declaration */
static unsigned int
traverse_expr (PFsa_expr_t *n, unsigned int node_id,
               unsigned int (*f) (PFsa_expr_t *, unsigned int));

/* Traverse all expressions (and all of their children)
 in a list applying function f to them */
static unsigned int
traverse_expr_list (PFsa_exprlist_t *list, unsigned int node_id,
                    unsigned int (*f) (PFsa_expr_t *, unsigned int))
{
    unsigned int i;
    PFsa_expr_t *curr_expr;

    for (i = 0; i < elsize(list); i++) {
        curr_expr = elat(list, i);
        node_id = traverse_expr(curr_expr, node_id, f);
    }

    return node_id;
}

/* Traverse an expression (and all of its children)
 applying function f to it */
static unsigned int
traverse_expr (PFsa_expr_t *n, unsigned int node_id,
               unsigned int (*f) (PFsa_expr_t *, unsigned int))
{
    unsigned int i, flag;

    /* do something with f */
    flag = f(n, node_id);

    if (flag == STOP)
        return node_id;
    else
        node_id = flag;

    /* In some expressions, exression lists have to be traversed as well */
    switch (n->kind) {
        case sa_expr_num_gen:
            node_id = traverse_expr_list(n->sem.num_gen.sort_cols, node_id, f);
            node_id = traverse_expr_list(n->sem.num_gen.part_cols, node_id, f);
            break;
        case sa_expr_in:
            node_id = traverse_expr_list(n->sem.in.in_list, node_id, f);
            break;
        default:
            break;
    }

    for (i = 0; i < PFSA_EXPR_MAXCHILD && n->child[i]; i++)
        node_id = traverse_expr (n->child[i], node_id, f);

    return node_id;
}

/* Traverse an operator (and all of its children)
 applying function f to its operators and function g
 to its expressions */
static unsigned int
traverse_op (PFsa_op_t *n, unsigned int node_id,
             unsigned int (*f) (PFsa_op_t *, unsigned int),
             unsigned int (*g) (PFsa_expr_t *, unsigned int))
{
    unsigned int i, flag;
    assert (node_id != STOP);

    /* do something with f */
    flag = f(n, node_id);

    if (flag == STOP)
        return node_id;
    else
        node_id = flag;

    /* In some operators, exressions have to be traversed as well,
     applying function g */
    switch (n->kind) {
        case sa_op_serialize_rel:
            node_id = traverse_expr_list(n->sem.ser_rel.order_list, node_id, g);
            break;
        case sa_op_project:
            node_id = traverse_expr_list(n->sem.proj.expr_list, node_id, g);
            break;
        case sa_op_select:
            node_id = traverse_expr_list(n->sem.select.expr_list, node_id, g);
            break;
        case sa_op_table:
            node_id = traverse_expr_list(n->sem.table.expr_list, node_id, g);
            node_id = traverse_expr_list(n->sem.table.col_names, node_id, g);
            break;
        case sa_op_groupby:
            node_id = traverse_expr_list(n->sem.groupby.grp_list, node_id, g);
            node_id = traverse_expr_list(n->sem.groupby.prj_list, node_id, g);
            break;
        case sa_op_join:
        case sa_op_semijoin:
        case sa_op_antisemijoin:
            node_id = traverse_expr_list(n->sem.join.expr_list, node_id, g);
            break;
        default:
            break;
    }

    for (i = 0; i < PFSA_OP_MAXCHILD && n->child[i]; i++)
        node_id = traverse_op (n->child[i], node_id, f, g);

    return node_id;
}

/* Functions to start DAG traversal */

/* Reset SQL algebra DAG to allow another traversal */
void
PFsqlalg_dag_reset(PFsa_op_t *n)
{
    traverse_op (n, DUMMY, prepare_reset_op, prepare_reset_expr);
    traverse_op (n, DUMMY, reset_op, reset_expr);
    return;
}

/* Create node ids for all operators and
 expressions in a SQL algebra DAG */
void
PFsqlalg_create_node_id (PFsa_op_t *n)
{
    traverse_op (n, 1, create_node_id_op, create_node_id_expr);
    PFsqlalg_dag_reset (n);
    return;
}

/* Reset node ids of all operators and
 expressions in a SQL algebra DAG */
void
PFsqlalg_reset_node_id (PFsa_op_t *n)
{
    traverse_op (n, DUMMY, reset_node_id_op, reset_node_id_expr);
    PFsqlalg_dag_reset (n);
    return;
}

/* Infer reference counters in SQL algebra DAG */
void
PFsqlalg_infer_refctr (PFsa_op_t *n)
{
    traverse_op (n, DUMMY, infer_refctr_op, infer_refctr_expr);
    PFsqlalg_dag_reset (n);
    return;
}

/* Traverse the operator tree below operator @a n and
   check if it contains an operator of kind @a kind.
   If so, return found operator. If no operator was
   found return NULL. This function uses the n->bit_dag
   bit to indicate that the current operator has been
   already returned in a previous (top-down) traversal */
static PFsa_op_t *
findop (PFsa_op_kind_t kind, PFsa_op_t *n)
{
    unsigned int  i;
    PFsa_op_t    *op = NULL;

    if (!n->bit_dag && n->kind == kind) {
        n->bit_dag = true;
        return n;
    }

    for (i = 0; i < PFSA_OP_MAXCHILD && n->child[i]; i++) {
        op = findop(kind, n->child[i]);
        if (op)
            return op;
    }

    return NULL;
}

/* Find operator of kind @a kind in plan @a root. This function is
   itended to be called in the condition of a while loop: As long
   as there are more operators of kind @a kind in plan @a root, these
   operators are returned. If no more operators remain, NULL is returned:
   while ((op = PFsqlalg_find_op (kind, root))) {
        do something with op
   }
   Attention: If you quit the while loop earlier, you have to make
   sure that PFsqlalg_dag_reset(root) is called. */
PFsa_op_t *
PFsqlalg_find_op (PFsa_op_kind_t kind, PFsa_op_t *root)
{
    PFsa_op_t *op = NULL;
    
    op = findop(kind, root);
    
    if (op)
        return op;

    else {
        /* Nothing found */
        PFsqlalg_dag_reset (root);
        return NULL;
    }
    return NULL;
}

/* vim:set shiftwidth=4 expandtab: */
