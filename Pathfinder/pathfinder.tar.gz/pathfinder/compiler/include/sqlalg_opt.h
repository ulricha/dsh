/* Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.pathfinder-xquery.org/license
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2011 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *//**
 *
 * @file
 *
 * Definitions regarding the optimization of the SQL algebra.
 */

#ifndef SQLALG_OPT_H
#define SQLALG_OPT_H

#include "sqlalg.h"

/* Try to build IN lists of the expressions of operator @a op */
void PFsqlalgopt_in_lists (PFsa_op_t *root);

/* Try to find the 'antisemijoin' pattern around operator @a op */
void PFsqlalgopt_antisemijoin (PFsa_op_t *root);

/* Try to merge adjacent projection operators */
void PFsqlalgopt_merge_projections (PFsa_op_t *root);

/* Perform optimizations on @a root */
PFsa_op_t* PFsqlalg_opt (PFsa_op_t *root);

#endif /* SQLALG_OPT */

/* vim:set shiftwidth=4 expandtab filetype=c: */ 
