/* Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.pathfinder-xquery.org/license
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2011 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *//**
 *
 * @file
 *
 * Mnemonic abbreviations for translation of SQL algebra to SQL.
 */

#ifndef SQLALG_2_SQL_MNEMONIC_H
#define SQLALG_2_SQL_MNEMONIC_H

/* ---- Mnemonics for SQL algebra to SQL translation ---- */

/* Mnemonic for sql annotation */
#define BOUND(n)     ((n)->sql_ann->bound)
#define COLLIST(n)   ((n)->sql_ann->colmap)
#define FROMLIST(n)  ((n)->sql_ann->frommap)
#define WHERELIST(n) ((n)->sql_ann->wheremap)

#define collist_item_t  PFsqlalg2sql_collist_item_t
#define fromlist_item_t PFsqlalg2sql_fromlist_item_t

/* Functions for COLLIST */
#define column_l(size)           PFarray (sizeof (collist_item_t), (size))
#define column_l_copy(cl)        PFarray_copy((cl))
#define column_l_at(cl,i)        *(collist_item_t *) PFarray_at((cl), (i))
#define column_l_add(cl)         *(collist_item_t *) PFarray_add((cl))
#define column_l_size(cl)        PFarray_last((cl))
#define column_l_append(cl1,cl2) PFarray_concat ((cl1), (cl2))

/* Functions for FROMLIST */
#define from_l(size)             PFarray (sizeof (fromlist_item_t), (size))
#define from_l_copy(fl)          PFarray_copy((fl))
#define from_l_at(fl,i)          *(fromlist_item_t *) PFarray_at((fl), (i))
#define from_l_add(fl)           *(fromlist_item_t *) PFarray_add((fl))
#define from_l_size(fl)          PFarray_last((fl))
#define from_l_append(fl1,fl2)   PFarray_concat ((fl1), (fl2))

/* Functions for WHERELIST */
#define where_l(size)            PFarray (sizeof (PFsql_t *), (size))
#define where_l_copy(wl)         PFarray_copy((wl))
#define where_l_at(wl,i)         *(PFsql_t **) PFarray_at((wl), (i))
#define where_l_add(wl)          *(PFsql_t **) PFarray_add((wl))
#define where_l_size(wl)         PFarray_last((wl))
#define where_l_append(wl1,wl2)  PFarray_concat ((wl1), (wl2))

/* Helper functions */
#define new_sql_collist_item(c,t,e) \
        PFsqlalg2sql_new_sql_collist_item ((c), (t), (e))
#define new_sql_fromlist_item(t,a)  \
        PFsqlalg2sql_new_sql_fromlist_item ((t), (a))
#define new_table_name()            \
        PFsqlalg2sql_new_table_name ()
#define new_alias()                 \
        PFsqlalg2sql_new_alias ()
#define new_sql_col(c,t)            \
        PFsqlalg2sql_new_sql_col ((c),(t))
#define reset_names_aliases_varnos()\
        PFsqlalg2sql_reset_names_aliases_varnos ()
#define copy_lists_from_to(f,t)     \
        PFsqlalg2sql_copy_lists_from_to ((f),(t))
#define new_sql_literal(a)          \
        PFsqlalg2sql_new_sql_literal ((a))
#define transform_frommap(p)        \
        PFsqlalg2sql_transform_frommap ((p))
#define transform_wheremap(p)       \
        PFsqlalg2sql_transform_wheremap ((p))
#define transform_expression(n,c)   \
        PFsqlalg2sql_transform_expression ((n),(c))
#define col_env_lookup(l,c)         \
        PFsqlalg2sql_col_env_lookup ((l),(c))
#define substitute_aliases(p)       \
        PFsqlalg2sql_substitute_aliases ((p))

#endif /* SQLALG_2_SQL_MNEMONIC_H */

/* vim:set shiftwidth=4 expandtab: */
