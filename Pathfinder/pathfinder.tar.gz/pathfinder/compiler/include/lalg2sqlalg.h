/* Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.pathfinder-xquery.org/license
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2011 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *//**
 *
 * @file
 */
#ifndef LALG_2_SQLALG_H
#define LALG_2_SQLALG_H

#include "logical.h"
#include "sqlalg.h"

/* Auxiliary function that searches for a certain col
   in a expression list and returns an expression
   representing the found column. If no column was
   found, NULL will be returned (needed in
   sqlalgebra/opt/merge_projections.c) */
PFsa_expr_t* find_expr (PFsa_exprlist_t *expr_list, PFalg_col_t col);

/* Auxiliary function to get a copy of the complete expression tree
   of expression @a n (needed in sqlalgebra/opt/merge_projections.c)*/
PFsa_expr_t* deep_copy_expr (PFsa_expr_t *n);

/* Auxiliary function that constructs an expression list containing
   column references of the columns in a schema (needed in
   sqlalgebra/opt/antisemijoin.c) */
PFsa_exprlist_t* exprlist_from_schema (PFalg_schema_t schema);

/* Translate the logical algebra into SQL algebra */
PFsa_op_t* PFlalg2sqlalg(PFla_op_t *p);

#endif /* LALG_2_SQLALG */
