/* -*- c-basic-offset:4; c-indentation-style:"k&r"; indent-tabs-mode:nil -*- */

/**
 * @file
 *
 * Definitions for helper functions for translation of SQL algebra to SQL.
 *
 * @if COPYRIGHT
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * @endif COPYRIGHT
 *
 * $Id$
 */

#ifndef SQLALG_2_SQL_HELPER_H
#define SQLALG_2_SQL_HELPER_H

#include "algebra.h"
#include "sqlalg.h"
#include "sql.h"

/**
 * Annotations to SQL algebra tree nodes. Used during
 * SQL code generation. (typedef resides in sqlalg.h.)
 */
struct PFsqlalg2sql_ann_t {
    unsigned        bound:1;       /**< indicates if the operator has been bound */

    PFarray_t       *colmap;       /**< Mapping table that maps (logical)
                                        column/type  pairs to their
                                        SQL expression or in case of
                                        a binding to their column names.
                                        (select list) */
    PFarray_t       *frommap;      /**< table--alias mappings */
    PFarray_t       *wheremap;     /**< contains references to the boolean
                                        in colmap */

    bool             bind;         /**< a boolean indicating if a numbering
                                        operator needs to be bound */
};

/* ---- Definition of the COL, FROM and WHERELISTs ---- */

/* COLLIST */
#define PFsqlalg2sql_collist_t   PFarray_t
/* FROMLIST */
#define PFsqlalg2sql_fromlist_t  PFarray_t
/* WHERELIST */
#define PFsqlalg2sql_wherelist_t PFarray_t

/* check if sql_statement is a literal */
#define IS_LITERAL(s) (s->kind == sql_lit_int \
                     || s->kind == sql_lit_lng \
                     || s->kind == sql_lit_dec \
                     || s->kind == sql_lit_str)

/* ---- Definitions and functions regarding the column,
        from and where lists collected during translation  ---- */

/* Items of COLLIST */
struct PFsqlalg2sql_collist_item_t
{
    PFalg_simple_type_t type;
    PFalg_col_t         col;
    PFsql_t            *expression;
};
typedef struct PFsqlalg2sql_collist_item_t PFsqlalg2sql_collist_item_t;

/* Items of FROMLIST */
struct PFsqlalg2sql_fromlist_item_t
{
    PFsql_t *table;
    PFsql_t *alias;
};
typedef struct PFsqlalg2sql_fromlist_item_t PFsqlalg2sql_fromlist_item_t;

/* Items of WHERELIST are of type PFsql_t */

/* Helper function that constructs a sql_collist_item */
PFsqlalg2sql_collist_item_t PFsqlalg2sql_new_sql_collist_item (
                                PFalg_col_t col,
                                PFalg_simple_type_t type,
                                PFsql_t *expr);

/* Helper function that constructs a sql_fromlist_item */
PFsqlalg2sql_fromlist_item_t PFsqlalg2sql_new_sql_fromlist_item (PFsql_t *tbl,
                                                                 PFsql_t *al);

/* Returns a new table name. */
PFsql_tident_t PFsqlalg2sql_new_table_name (void);

/* Returns a new alias. */
PFsql_aident_t PFsqlalg2sql_new_alias (void);

/* Returns a new column name
   (also storing its logical algebra name and its type). */
PFsql_col_t * PFsqlalg2sql_new_sql_col (PFalg_col_t col, PFalg_simple_type_t ty);

/* Helper function to reset name and alias variables so that the
   names and aliases in each query start from scratch */
void PFsqlalg2sql_reset_names_aliases_varnos ();

/* Helper function that copies the col, from and where
   lists from one SQL algebra operater to another */
void PFsqlalg2sql_copy_lists_from_to (PFsa_op_t *from, PFsa_op_t *to);

/* Construct a SQL literal from a given algebra atom. */
PFsql_t * PFsqlalg2sql_new_sql_literal (PFalg_atom_t atom);

/* Transform the fromlist of a SQL algebra operator into a list of
   SQL alias binds needed for construction of SQL operators. */
PFsql_t * PFsqlalg2sql_transform_frommap (PFsa_op_t *p);

/* Transform a wherelist of a SQL algebra operator into a list of
   SQL predicates needed for construction of SQL operators. */
PFsql_t * PFsqlalg2sql_transform_wheremap (PFsa_op_t *n);

/* Transform a SQL expression @a n into another SQL expression that
   can be put in a selectlist to represent col: If n already represents
   the desired col return it. Otherwise put n in a column assign
   operator ('n AS col'). In case col is a bool we have to build a case
   statement. */
PFsql_t * PFsqlalg2sql_transform_expression (PFsql_t *n, PFsql_t *col);

/* Helper function that searches in a list @a col_list for an item
   with column col */
PFsqlalg2sql_collist_item_t PFsqlalg2sql_col_env_lookup (
                                PFsqlalg2sql_collist_t *col_list,
                                PFalg_col_t col);

/* Substitue all table aliases in the col, from and where list
   of SQL algebra operator @a n by new ones. */
void PFsqlalg2sql_substitute_aliases (PFsa_op_t *n);

#endif /* SQLALG_2_SQL_HELPER_H */

/* vim:set shiftwidth=4 expandtab: */
