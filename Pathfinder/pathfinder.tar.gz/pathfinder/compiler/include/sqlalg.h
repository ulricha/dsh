/* Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.pathfinder-xquery.org/license
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2011 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *//**
 *
 * @file
 *
 * SQL algebra structure and constructor definitions.
 *
 * This algebra does so far not support polymorphic columns, since it is
 * mainly used as an intermediate algebra to generate SQL code from source
 * languages that are unlikely to produce polymorphic columns.
 *
 * For the set operators union and except we expect the input relations
 * to have aligned names, i.e., columns occur in the same order in both
 * schemas of the input.
 *
 * Number generating expressions (DENSE_RANK and ROW_NUMBER in SQL) cannot
 * be nested since this is not supported by all DBMSs. They cannot appear
 * in selection or group by lists. If they appear in a projection list of
 * a group by operator, the entries from their partition and sorting lists 
 * must also appear in the group by list.
 * 
 */

#ifndef SQLALG_H
#define SQLALG_H

#include "array.h"
#include "algebra.h"

/* ----------- SQL algebra expression lists ------------ */

/* A list of expressions (actually: column names) */
#define PFsa_exprlist_t                   PFarray_t
/* Constructor for a expression list */
#define PFsqlalg_exprlist(size)           PFarray (sizeof (PFsa_expr_t *), (size))
#define PFsqlalg_exprlist_copy(el)        PFarray_copy ((el))
/* Positional access to a expression list */
#define PFsqlalg_exprlist_at(el,i)        *(PFsa_expr_t **) PFarray_at ((el), (i))
#define PFsqlalg_exprlist_top(el)         *(PFsa_expr_t **) PFarray_top ((el))
/* Append to a expression list */
#define PFsqlalg_exprlist_add(el)         *(PFsa_expr_t **) PFarray_add ((el))
#define PFsqlalg_exprlist_concat(el1,el2) PFarray_concat ((el1), (el2))
/* Size of a expression list */
#define PFsqlalg_exprlist_size(el)        PFarray_last ((el))

/* --------------- SQL algebra expressions --------------- */

/* SQL algebra expression kinds */
enum PFsa_expr_kind_t {
      sa_expr_func        = 1
    , sa_expr_num_gen     = 2
    , sa_expr_comp        = 3
    , sa_expr_aggr        = 4
    , sa_expr_convert     = 5
    , sa_expr_in          = 6
    , sa_expr_column      = 7
    , sa_expr_atom        = 8
};
typedef enum PFsa_expr_kind_t PFsa_expr_kind_t;

/* SQL algebra number generating function kinds
 (for la operators rank, rowrank and rownum) */
enum PFsa_num_gen_kind_t {
      sa_num_gen_rank     = 1
    , sa_num_gen_rowrank  = 2
    , sa_num_gen_rownum   = 3
    , sa_num_gen_rowid    = 4
};
typedef enum PFsa_num_gen_kind_t PFsa_num_gen_kind_t;

/* SQL algebra comparison function kinds */
enum PFsa_comp_kind_t {
      sa_comp_equal       = 1
    , sa_comp_notequal    = 2
    , sa_comp_lt          = 3
    , sa_comp_lte         = 4
    , sa_comp_gt          = 5
    , sa_comp_gte         = 6
};
typedef enum PFsa_comp_kind_t PFsa_comp_kind_t;

/* SQL algebra aggregation function kinds */
enum PFsa_aggr_kind_t {
      sa_aggr_count       = 1
    , sa_aggr_sum         = 2
    , sa_aggr_avg         = 3
    , sa_aggr_max         = 4
    , sa_aggr_min         = 5
};
typedef enum PFsa_aggr_kind_t PFsa_aggr_kind_t;

/* SQL algebra function kinds */
enum PFsa_expr_func_name {
      sa_func_add             = 1
    , sa_func_sub             = 2
    , sa_func_mult            = 3
    , sa_func_div             = 4
    , sa_func_mod             = 5
    , sa_func_and             = 6
    , sa_func_or              = 7
    , sa_func_not             = 8
    , sa_func_like            = 9
    , sa_func_year_from_date  = 10
    , sa_func_month_from_date = 11
    , sa_func_day_from_date   = 12
    , sa_func_substring       = 13
    , sa_func_substring_len   = 14
};
typedef enum PFsa_expr_func_name PFsa_expr_func_name;


/* semantic content in expressions */
union PFsa_expr_sem_t {
    /* semantic content for expression kind sa_expr_func */
    struct {
        PFsa_expr_func_name     name;
    } func;

    /* semantic content for expression kind sa_expr_num_gen */
    struct {
        /* number generating functions: rownum, rowrank and rank */
        PFsa_num_gen_kind_t     kind;
        PFsa_exprlist_t        *sort_cols;      /* sort columns for rownum,
                                                   rowrank and rank op */
        PFsa_exprlist_t        *part_cols;      /* partitioning columns
                                                   for rownum op */
    } num_gen;

    /* semantic content for expression kind sa_expr_comp */
    struct {
        PFsa_comp_kind_t        kind;
    } comp;

    /* semantic content for expression kind sa_expr_aggr */
    struct {
        PFsa_aggr_kind_t        kind;
    } aggr;

    /* semantic content for expression kind sa_expr_in */
    struct {
        PFalg_col_t             col;
        PFsa_exprlist_t        *in_list;        /* in list with sa_expr_atoms */
    } in;

    /* semantic content for expression kind sa_expr_column */
    struct {
        PFalg_col_t             old;
    } col;

    /* semantic content for expression kind sa_expr_atom */
    struct {
        PFalg_atom_t            atom;
    } atom;

};
typedef union PFsa_expr_sem_t PFsa_expr_sem_t;

/* maximum number of children of a #PFsa_expr_t node */
#define PFSA_EXPR_MAXCHILD 3

/* SQL expression node */
struct PFsa_expr_t {

    PFsa_expr_kind_t     kind;         /* expression kind */
    PFsa_expr_sem_t      sem;          /* expression semantics */
    struct PFsa_expr_t  *child[PFSA_EXPR_MAXCHILD]; /* child list */

    PFalg_col_t          col;
    PFalg_simple_type_t  type;

    unsigned int         refctr;

    unsigned             bit_reset:1;  /* used to reset the dag bit
                                          in a DAG traversal */
    unsigned             bit_dag:1;    /* enables DAG traversal */
    int                  node_id;      /* specifies the id of this operator
                                          node; required exclusively to
                                          create dot output. */
    bool                 sortorder;    /* sortorder:
                                          false = ascending
                                          (DIR_ASC in algebra.h),
                                          true = descending
                                          (DIR_DESC in algebra.h) */
};
typedef struct PFsa_expr_t PFsa_expr_t;

/* --------------- SQL algebra operators --------------- */

/* SQL algebra operator kinds */
enum PFsa_op_kind_t{
      sa_op_serialize_rel      = 1
    , sa_op_project            = 2
    , sa_op_select             = 3
    , sa_op_literal_table      = 4
    , sa_op_table              = 5
    , sa_op_union              = 6
    , sa_op_except             = 7
    , sa_op_groupby            = 8
    , sa_op_join               = 9
    , sa_op_semijoin           = 10
    , sa_op_antisemijoin       = 11
    , sa_op_cross              = 12
    , sa_op_nil_node           = 13
};
typedef enum PFsa_op_kind_t PFsa_op_kind_t;

/* semantic content in algebra operators */
union PFsa_op_sem_t {

    /* semantic content for serialization operator */
    struct {
        PFalg_col_t         iter;         /* name of column iter */
        PFsa_exprlist_t    *order_list;   /* list of order columns */
        PFalg_collist_t    *items;        /* list of item columns */
    } ser_rel;

    /* semantic content for projection operator */
    struct {
        PFsa_exprlist_t    *expr_list;
    } proj;

    /* semantic content for select operator */
    struct {
        PFsa_exprlist_t    *expr_list;    /* list of conjunctions */
    } select;

    /* semantic content for literal table operator */
    struct {
        unsigned int        tuples_count; /* count of tuples in tuple list */
        PFalg_tuple_t      *tuples;       /* tuple list */
    } literal_table;

    /* semantic content for table operator */
    struct {
        char*               name;
        PFsa_exprlist_t    *expr_list;
        PFsa_exprlist_t    *col_names;    /* list of expressions containing
                                             original column names */
    } table;

    /* semantic content for groupby operator */
    struct {
        PFsa_exprlist_t    *grp_list;     /* grouping criteria list */

        PFsa_exprlist_t    *prj_list;     /* projection list */
    } groupby;

    /* semantic content for join and semijoin operator */
    struct {
        PFsa_exprlist_t    *expr_list;        /* list of conjunctions */
        bool               antisemijoin_pattern; /* flag for antisemijoin optimization */
    } join;
};
typedef union PFsa_op_sem_t PFsa_op_sem_t;


/* maximum number of children of a #PFsa_op_t node */
#define PFSA_OP_MAXCHILD 2

typedef struct PFsqlalg2sql_ann_t PFsqlalg2sql_ann_t;

/* SQL algebra operator node */
struct PFsa_op_t {

    PFsa_op_kind_t      kind;             /* operator kind */
    PFsa_op_sem_t       sem;              /* operator semantics */
    PFalg_schema_t      schema;           /* result schema */
    struct PFsa_op_t   *child[PFSA_OP_MAXCHILD]; /* child list */

    unsigned int        refctr;

    bool                distinct;

    unsigned            bit_reset:1;      /* used to reset the dag bit
                                             in a DAG traversal */
    unsigned            bit_dag:1;        /* enables DAG traversal */
    int                 node_id;          /* specifies the id of this operator
                                             node; required exclusively to
                                             create dot output. */
    PFsqlalg2sql_ann_t *sql_ann;          /* SQL annotations used during SQL
                                             code generation. */
};
typedef struct PFsa_op_t PFsa_op_t;

/* Annotation for translation (typedef see logical.h) */
struct PFsa_ann_t {
    PFsa_op_t         *op;                /* SQL algebra operator */
    PFsa_exprlist_t   *prj_list;          /* projection list */
    PFsa_exprlist_t   *sel_list;          /* conjunctive list
                                             of selection predicates */
};

/* -------------------- Auxiliary functions --------------------*/

/* Auxiliary function to get schema from a list of expressions
   functions (needed in lalg2sqlalg.c) */
PFalg_schema_t PFsa_schema_from_exprlist (PFsa_exprlist_t *expr_list);

/* Auxiliary function to determine if all columns that are
   referenced in @a expr are columns of @a schema (also
   needed in sqlalgebra/opt/antisemijoin.c) */
bool PFsa_expr_cols_in_schema (PFsa_expr_t *expr, PFalg_schema_t schema);

/* --------------- Constructor stubs for expressions --------------- */

/* Constructor for function expression */
PFsa_expr_t * PFsqlalg_expr_func (PFsa_expr_func_name name,
                                  PFsa_exprlist_t *child_list,
                                  PFalg_col_t res_col);

/* Constructor for number generating function expression */
PFsa_expr_t * PFsqlalg_expr_num_gen (PFsa_num_gen_kind_t kind,
                                     PFsa_exprlist_t *sort_list,
                                     PFsa_exprlist_t *part_list,
                                     PFalg_col_t res_col);

/* Constructor for comparison expression */
PFsa_expr_t * PFsqlalg_expr_comp (PFsa_expr_t *n1, PFsa_expr_t *n2,
                                  PFsa_comp_kind_t kind, PFalg_col_t res_col);

/* Constructor for aggr expression */
PFsa_expr_t * PFsqlalg_expr_aggr (PFsa_expr_t *n, PFsa_aggr_kind_t aggr_kind,
                                PFalg_col_t res_col);

/* Constructor for convert expression */
PFsa_expr_t * PFsqlalg_expr_convert (PFsa_expr_t *n, PFalg_simple_type_t type,
                                   PFalg_col_t res_col);

/* Constructor for in list expression */
PFsa_expr_t * PFsqlalg_expr_in (PFalg_col_t col,
                                PFsa_exprlist_t *in_list,
                                PFalg_col_t res_col);

/* Constructor for column expression */
PFsa_expr_t * PFsqlalg_expr_column (PFalg_col_t col, PFalg_simple_type_t type);

/* Constructor for atom expression */
PFsa_expr_t * PFsqlalg_expr_atom (PFalg_col_t res_col, PFalg_atom_t atom);


/* --------------- Constructor stubs for operators --------------- */

/* Constructor for nil node operator */
PFsa_op_t * PFsqlalg_op_nil_node (void);

/* Constructor for serialize operator */
PFsa_op_t * PFsqlalg_op_serialize_rel (PFsa_op_t *DAG, PFsa_op_t *side_effects,
                                  PFalg_col_t iter,
                                  PFalg_collist_t *order_list,
                                  PFalg_collist_t *items);

/* Constructor for project operator */
PFsa_op_t * PFsqlalg_op_project (PFsa_op_t *n,
                                 bool distinct_flag,
                                 PFsa_exprlist_t *expr_list);

/* Constructor for select operator */
PFsa_op_t * PFsqlalg_op_select (PFsa_op_t *n, PFsa_exprlist_t *expr_list);

/* Constructor for literal table operator */
PFsa_op_t * PFsqlalg_op_literal_table (PFalg_schema_t names,
                                       unsigned int tuples_count,
                                       PFalg_tuple_t *tuples);

/* Constructor for table operator */
PFsa_op_t * PFsqlalg_op_table (char* name, PFalg_schema_t schema,
                               PFsa_exprlist_t *expr_list,
                               PFsa_exprlist_t *col_names);

/* Constructor for union operator */
PFsa_op_t * PFsqlalg_op_union (PFsa_op_t *n1, PFsa_op_t *n2);

/* Constructor for except operator */
PFsa_op_t * PFsqlalg_op_except (PFsa_op_t *n1, PFsa_op_t *n2);

/* Constructor for groupby operator */
PFsa_op_t * PFsqlalg_op_groupby (PFsa_op_t *n, PFsa_exprlist_t *grp_list,
                            PFsa_exprlist_t *prj_list);

/* Constructor for join operator */
PFsa_op_t * PFsqlalg_op_join (PFsa_op_t *n1, PFsa_op_t *n2,
                              PFsa_exprlist_t *expr_list);

/* Constructor for semijoin operator */
PFsa_op_t * PFsqlalg_op_semijoin (PFsa_op_t *n1, PFsa_op_t *n2,
                                  PFsa_exprlist_t *expr_list);

/* Constructor for antisemijoin operator */
PFsa_op_t * PFsqlalg_op_antisemijoin (PFsa_op_t *n1, PFsa_op_t *n2,
                                      PFsa_exprlist_t *expr_list);

/* Constructor for cross operator */
PFsa_op_t * PFsqlalg_op_cross (PFsa_op_t *n1, PFsa_op_t *n2);

#endif  /* SQLALG_H */

/* vim:set shiftwidth=4 expandtab: */
