/**
 * @file
 *
 * Mnemonic abbreviations for SQL algebra expression lists.
 *
 * @if COPYRIGHT
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * @endif COPYRIGHT
 *
 * $Id$
 */

#ifndef SQLALG_MNEMONIC_H
#define SQLALG_MNEMONIC_H

/** abbreviation for expression list constructor */
#define el(s)               PFsqlalg_exprlist((s))
/** abbreviation for expression list accessors */
#define elat(el,i)          PFsqlalg_exprlist_at((el),(i))
#define eltop(el)           PFsqlalg_exprlist_top((el))
#define eladd(el)           PFsqlalg_exprlist_add((el))
#define elsize(el)          PFsqlalg_exprlist_size((el))
#define elcopy(el)          PFsqlalg_exprlist_copy((el))
#define elconcat(el1, el2)  PFsqlalg_exprlist_concat((el1),(el2))

#endif /* SQLALG_MNEMONIC_H */

/* vim:set shiftwidth=4 expandtab: */
