/* Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.pathfinder-xquery.org/license
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2011 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *//**
 *
 * @file
 *
 * Functions related to the traversal of SQL algebra DAGs.
 */

#ifndef SQLALG_DAG_H
#define SQLALG_DAG_H

#include "sqlalg.h"

/* --------------- DAG traversal functions --------------- */

/* Functions to start DAG traversal */

/* Reset SQL algebra DAG to allow another traversal */
void PFsqlalg_dag_reset(PFsa_op_t *n);

/* Create node ids for all operators and expressions in a SQL algebra DAG */
void PFsqlalg_create_node_id (PFsa_op_t *n);

/* Reset node ids of all operators and expressions in a SQL algebra DAG */
void PFsqlalg_reset_node_id (PFsa_op_t *n);

/* Infer reference counters in SQL algebra DAG */
void PFsqlalg_infer_refctr (PFsa_op_t *n);

/* Find operator of kind @a kind in plan @a root. This function is
   itended to be called in a while condition: As long as there are
   more operators of kind @a kind in plan @a root, these operators
   are returned. If no more operators remain, NULL is returned.
   Example: while ((op = PFsqlalg_find_op (kind, root))) {
                do something with op
            }
   Attention: If you quit the while loop earlier, you have to make
   sure that PFsqlalg_dag_reset(root) is called. */
PFsa_op_t * PFsqlalg_find_op (PFsa_op_kind_t op_kind, PFsa_op_t *root);

#endif  /* SQLALG_DAG_H */

/* vim:set shiftwidth=4 expandtab: */
