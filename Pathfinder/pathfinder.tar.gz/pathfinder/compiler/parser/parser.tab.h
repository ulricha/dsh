/* A Bison parser, made by GNU Bison 2.4.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006,
   2009, 2010 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     encoding_StringLiteral = 258,
     StringLiteral = 259,
     after = 260,
     ancestor_colon_colon = 261,
     ancestor_or_self_colon_colon = 262,
     and = 263,
     apos = 264,
     as = 265,
     ascending = 266,
     as_first_into = 267,
     as_last_into = 268,
     at_dollar = 269,
     atsign = 270,
     attribute_colon_colon = 271,
     attribute_lbrace = 272,
     attribute_lparen = 273,
     before = 274,
     case_ = 275,
     cast_as = 276,
     castable_as = 277,
     cdata_end = 278,
     cdata_start = 279,
     child_colon_colon = 280,
     collation = 281,
     colon_equals = 282,
     comma = 283,
     comment_lbrace = 284,
     comment_lparen = 285,
     copy_ns_inherit = 286,
     copy_ns_noinherit = 287,
     copy_ns_nopreserve = 288,
     copy_ns_preserve = 289,
     declare_base_uri = 290,
     declare_construction_preserve = 291,
     declare_construction_strip = 292,
     declare_default_collation = 293,
     declare_default_element = 294,
     declare_default_function = 295,
     declare_default_order = 296,
     declare_docmgmt_function = 297,
     declare_function = 298,
     declare_updating_function = 299,
     declare_copy_namespaces = 300,
     declare_namespace = 301,
     declare_ordering_ordered = 302,
     declare_ordering_unordered = 303,
     declare_variable_dollar = 304,
     declare_boundary_space_preserve = 305,
     declare_boundary_space_strip = 306,
     declare_option = 307,
     declare_revalidation_lax = 308,
     declare_revalidation_skip = 309,
     declare_revalidation_strict = 310,
     default_ = 311,
     default_element = 312,
     descendant_colon_colon = 313,
     descendant_or_self_colon_colon = 314,
     descending = 315,
     div_ = 316,
     do_delete = 317,
     do_insert = 318,
     do_rename = 319,
     do_replace = 320,
     do_replace_value_of = 321,
     document_lbrace = 322,
     document_node_lparen = 323,
     dollar = 324,
     dot = 325,
     dot_dot = 326,
     element_lbrace = 327,
     element_lparen = 328,
     else_ = 329,
     empty_greatest = 330,
     empty_least = 331,
     empty_sequence = 332,
     eq = 333,
     equals = 334,
     escape_apos = 335,
     escape_quot = 336,
     every_dollar = 337,
     except = 338,
     excl_equals = 339,
     execute_at = 340,
     external_ = 341,
     following_colon_colon = 342,
     following_sibling_colon_colon = 343,
     for_dollar = 344,
     ge = 345,
     greater_than = 346,
     greater_than_equal = 347,
     gt = 348,
     gt_gt = 349,
     hash_paren = 350,
     idiv = 351,
     if_lparen = 352,
     import_module = 353,
     import_schema = 354,
     in_ = 355,
     instance_of = 356,
     intersect = 357,
     into = 358,
     is = 359,
     item_lrparens = 360,
     lbrace = 361,
     lbrace_lbrace = 362,
     lbracket = 363,
     le = 364,
     less_than = 365,
     less_than_equal = 366,
     let_dollar = 367,
     lparen = 368,
     lt = 369,
     lt_lt = 370,
     lt_question_mark = 371,
     lt_slash = 372,
     minus = 373,
     mod_ = 374,
     modify = 375,
     module_namespace = 376,
     namespace = 377,
     ne = 378,
     node_lrparens = 379,
     or = 380,
     order_by = 381,
     ordered_lbrace = 382,
     paren_hash = 383,
     parent_colon_colon = 384,
     pi_lbrace = 385,
     pi_lparen = 386,
     pipe_ = 387,
     plus = 388,
     preceding_colon_colon = 389,
     preceding_sibling_colon_colon = 390,
     question_mark = 391,
     question_mark_gt = 392,
     quot_ = 393,
     rbrace = 394,
     rbrace_rbrace = 395,
     rbracket = 396,
     recurse = 397,
     return_ = 398,
     rparen = 399,
     satisfies = 400,
     schema_attribute_lparen = 401,
     schema_element_lparen = 402,
     seeded_by = 403,
     select_narrow_colon_colon = 404,
     select_wide_colon_colon = 405,
     self_colon_colon = 406,
     semicolon = 407,
     slash = 408,
     slash_gt = 409,
     slash_slash = 410,
     some_dollar = 411,
     stable_order_by = 412,
     star = 413,
     text_lbrace = 414,
     text_lparen = 415,
     then = 416,
     to_ = 417,
     transform_copy_dollar = 418,
     treat_as = 419,
     typeswitch_lparen = 420,
     union_ = 421,
     unordered_lbrace = 422,
     validate_lax_lbrace = 423,
     validate_lbrace = 424,
     validate_strict_lbrace = 425,
     where = 426,
     with = 427,
     with_dollar = 428,
     xml_comment_end = 429,
     xml_comment_start = 430,
     xquery_version = 431,
     AttrContentChar = 432,
     Attribute_QName_LBrace = 433,
     PFChar = 434,
     CharRef = 435,
     DecimalLiteral = 436,
     DoubleLiteral = 437,
     ElementContentChar = 438,
     Element_QName_LBrace = 439,
     EscapeApos = 440,
     EscapeQuot = 441,
     IntegerLiteral = 442,
     NCName = 443,
     NCName_Colon_Star = 444,
     PITarget = 445,
     PI_NCName_LBrace = 446,
     PragmaContents = 447,
     PredefinedEntityRef = 448,
     QName = 449,
     QName_LParen = 450,
     S = 451,
     Star_Colon_NCName = 452,
     at_URILiteral = 453,
     invalid_character = 454
   };
#endif
/* Tokens.  */
#define encoding_StringLiteral 258
#define StringLiteral 259
#define after 260
#define ancestor_colon_colon 261
#define ancestor_or_self_colon_colon 262
#define and 263
#define apos 264
#define as 265
#define ascending 266
#define as_first_into 267
#define as_last_into 268
#define at_dollar 269
#define atsign 270
#define attribute_colon_colon 271
#define attribute_lbrace 272
#define attribute_lparen 273
#define before 274
#define case_ 275
#define cast_as 276
#define castable_as 277
#define cdata_end 278
#define cdata_start 279
#define child_colon_colon 280
#define collation 281
#define colon_equals 282
#define comma 283
#define comment_lbrace 284
#define comment_lparen 285
#define copy_ns_inherit 286
#define copy_ns_noinherit 287
#define copy_ns_nopreserve 288
#define copy_ns_preserve 289
#define declare_base_uri 290
#define declare_construction_preserve 291
#define declare_construction_strip 292
#define declare_default_collation 293
#define declare_default_element 294
#define declare_default_function 295
#define declare_default_order 296
#define declare_docmgmt_function 297
#define declare_function 298
#define declare_updating_function 299
#define declare_copy_namespaces 300
#define declare_namespace 301
#define declare_ordering_ordered 302
#define declare_ordering_unordered 303
#define declare_variable_dollar 304
#define declare_boundary_space_preserve 305
#define declare_boundary_space_strip 306
#define declare_option 307
#define declare_revalidation_lax 308
#define declare_revalidation_skip 309
#define declare_revalidation_strict 310
#define default_ 311
#define default_element 312
#define descendant_colon_colon 313
#define descendant_or_self_colon_colon 314
#define descending 315
#define div_ 316
#define do_delete 317
#define do_insert 318
#define do_rename 319
#define do_replace 320
#define do_replace_value_of 321
#define document_lbrace 322
#define document_node_lparen 323
#define dollar 324
#define dot 325
#define dot_dot 326
#define element_lbrace 327
#define element_lparen 328
#define else_ 329
#define empty_greatest 330
#define empty_least 331
#define empty_sequence 332
#define eq 333
#define equals 334
#define escape_apos 335
#define escape_quot 336
#define every_dollar 337
#define except 338
#define excl_equals 339
#define execute_at 340
#define external_ 341
#define following_colon_colon 342
#define following_sibling_colon_colon 343
#define for_dollar 344
#define ge 345
#define greater_than 346
#define greater_than_equal 347
#define gt 348
#define gt_gt 349
#define hash_paren 350
#define idiv 351
#define if_lparen 352
#define import_module 353
#define import_schema 354
#define in_ 355
#define instance_of 356
#define intersect 357
#define into 358
#define is 359
#define item_lrparens 360
#define lbrace 361
#define lbrace_lbrace 362
#define lbracket 363
#define le 364
#define less_than 365
#define less_than_equal 366
#define let_dollar 367
#define lparen 368
#define lt 369
#define lt_lt 370
#define lt_question_mark 371
#define lt_slash 372
#define minus 373
#define mod_ 374
#define modify 375
#define module_namespace 376
#define namespace 377
#define ne 378
#define node_lrparens 379
#define or 380
#define order_by 381
#define ordered_lbrace 382
#define paren_hash 383
#define parent_colon_colon 384
#define pi_lbrace 385
#define pi_lparen 386
#define pipe_ 387
#define plus 388
#define preceding_colon_colon 389
#define preceding_sibling_colon_colon 390
#define question_mark 391
#define question_mark_gt 392
#define quot_ 393
#define rbrace 394
#define rbrace_rbrace 395
#define rbracket 396
#define recurse 397
#define return_ 398
#define rparen 399
#define satisfies 400
#define schema_attribute_lparen 401
#define schema_element_lparen 402
#define seeded_by 403
#define select_narrow_colon_colon 404
#define select_wide_colon_colon 405
#define self_colon_colon 406
#define semicolon 407
#define slash 408
#define slash_gt 409
#define slash_slash 410
#define some_dollar 411
#define stable_order_by 412
#define star 413
#define text_lbrace 414
#define text_lparen 415
#define then 416
#define to_ 417
#define transform_copy_dollar 418
#define treat_as 419
#define typeswitch_lparen 420
#define union_ 421
#define unordered_lbrace 422
#define validate_lax_lbrace 423
#define validate_lbrace 424
#define validate_strict_lbrace 425
#define where 426
#define with 427
#define with_dollar 428
#define xml_comment_end 429
#define xml_comment_start 430
#define xquery_version 431
#define AttrContentChar 432
#define Attribute_QName_LBrace 433
#define PFChar 434
#define CharRef 435
#define DecimalLiteral 436
#define DoubleLiteral 437
#define ElementContentChar 438
#define Element_QName_LBrace 439
#define EscapeApos 440
#define EscapeQuot 441
#define IntegerLiteral 442
#define NCName 443
#define NCName_Colon_Star 444
#define PITarget 445
#define PI_NCName_LBrace 446
#define PragmaContents 447
#define PredefinedEntityRef 448
#define QName 449
#define QName_LParen 450
#define S 451
#define Star_Colon_NCName 452
#define at_URILiteral 453
#define invalid_character 454




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1685 of yacc.c  */
#line 254 "parser.y"

    long long int   num;
    char           *dec;
    char           *dbl;
    char           *str;
    bool            bit;
    PFqname_raw_t   qname_raw;
    PFpnode_t      *pnode;
    struct phole_t  phole;
    PFptype_t       ptype;
    PFpaxis_t       axis;
    PFsort_t        mode;
    PFpoci_t        oci;
    PFarray_t      *buf;
    PFinsertmod_t   insert;



/* Line 1685 of yacc.c  */
#line 468 "y.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE pflval;

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE pflloc;

