#include <pf_config.h>
/* A Bison parser, made by GNU Bison 2.4.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006,
   2009, 2010 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.4.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 1

/* Substitute the variable and function names.  */
#define yyparse         pfparse
#define yylex           pflex
#define yyerror         pferror
#define yylval          pflval
#define yychar          pfchar
#define yydebug         pfdebug
#define yynerrs         pfnerrs
#define yylloc          pflloc

/* Copy the first part of user declarations.  */

/* Line 189 of yacc.c  */
#line 36 "parser.y"

#include "pathfinder.h"

#include "parser.h"
/* get a document by URL (if not in cache, fetch it) */
extern char* PFurlcache(char *url, int keep);

/* flush the url cache */
extern void PFurlcache_flush(void);

/* PFarray_t */
#include "array.h"
#include "oops.h"

/* isspace */
#include <ctype.h>
/* strcmp */
#include <string.h>

#include "scanner.h"

/* PFstrdup() */
#include "mem.h"

/* malloc/free */
#include <stdlib.h>

/** root node of the parse tree */
static PFpnode_t *root;

/* temporay node memory */
static PFpnode_t *c, *c1;

/** global query information */
static PFquery_t *PFquery;

/** parse standoff axis steps */
static bool standoff_axis_steps;

static void add_to_module_wl (char* id, char *ns, char *uri);

/* avoid `implicit declaration of yylex' warning */
extern int pflex (void);

/* bison error callback */
void pferror (const char *s);

/* construct a nil node */
#define nil(loc) leaf (p_nil, (loc))

/* bison: generate verbose parsing error messages */
#define YYERROR_VERBOSE 

/* tell bison which malloc/free to use (needed for bison 2.4.1 on Windows) */
#define YYMALLOC malloc
#define YYFREE free

#define leaf(t,loc)       p_leaf ((t), (loc))
#define wire1(t,loc,a)    p_wire1 ((t), (loc), (a))
#define wire2(t,loc,a,b)  p_wire2 ((t), (loc), (a), (b))

/*
 * fix-up the hole of an abstract syntax tree t and 
 * replace its c-th leaf by e:
 *
 *               t.root
 *                 / \
 *      t.hole --> -e--
 */
#define FIXUP(c,t,e) ((t).hole)->child[c] = (e)


/* scanner information to provide better error messages */
extern char         *pftext;
extern unsigned int  cur_col;
extern unsigned int  cur_row;

/**
 * True if we have been invoked via parse_module().
 *
 * For queries that contain "import module" instructions, we re-invoke
 * the parser for each imported module.  In that case we _only_ allow
 * modules to be read and refuse query scripts.
 */
static bool module_only;

/**
 * Module namespace we accept during parsing.
 *
 * If a module is imported, its associated namespace must match the
 * namespace given in the "import module" statement.  If this variable
 * is != NULL, we only accept modules with the given namespace.
 */
static char *req_module_ns;

/**
 * URI of the module that we are currently parsing.
 *
 * Only set for imported modules, NULL otherwise.
 */
static char *current_uri;

/**
 * Work list of modules that we have to load.
 *
 * Whenever we encounter an "import module" statement, we add an URI to
 * the list (if it is not in there already).  We process the work list
 * after parsing the main query file.
 */
static PFarray_t *modules;

/**
 * Each item in the work list is a id/namespace/URI triple.  The URI
 * denotes the URI to load the module from; the namespace is the
 * namespace that the module should be defined for (abort parsing
 * otherwise).
 */
typedef struct module_t {
    char *id;
    char *ns;
    char *uri;
} module_t;

/*
 * Check if the input string consists of whitespace only.
 * If this is the case and pres_boundary_space is set to false, the 
 * abstract syntax tree must be altered, i.e., we do not
 * create a text node but an empty sequence node.
 */
static bool is_whitespace (unsigned char *s);

/* recursively flatten a location path @a p */
static PFpnode_t *flatten_locpath (PFpnode_t *p, PFpnode_t *r);

/**
 * override default bison type for locations with custom type
 * defined in include/abssyn.h
 */
#define YYLTYPE PFloc_t

/** 
 * override bison default location tracking for a rule
 * of the form (rhs consists of n symbols, n >= 0):
 *                   lhs: rhs 
 */
#define YYLLOC_DEFAULT(lhs, rhs, n)                   \
  do                                                  \
      if ((n)) {                                      \
        (lhs).first_row  = (rhs)[1].first_row;        \
        (lhs).first_col  = (rhs)[1].first_col;        \
        (lhs).last_row   = (rhs)[(n)].last_row;       \
        (lhs).last_col   = (rhs)[(n)].last_col;       \
      }                                               \
      else                                            \
        (lhs) = (rhs)[0];                             \
 while (0)

/* calculate new location when joining two or more abssyn nodes */
static PFloc_t 
loc_rng (PFloc_t left, PFloc_t right) 
{
  PFloc_t loc;

  loc.first_row = left.first_row;
  loc.first_col = left.first_col;

  loc.last_row = right.last_row;
  loc.last_col = right.last_col;

  return loc;
}

/** calculate maximum location when joining two nodes */
static PFloc_t 
max_loc (PFloc_t loc1, PFloc_t loc2) 
{
    PFloc_t loc = loc1;
    /* verify if loc1's location begins after loc2's location;
     * in this case, extend loc1 to begin at loc2's start-location
     */
    if (loc1.first_row == loc2.first_row)
    {
        if (loc1.first_col > loc2.first_col)
            loc.first_col = loc2.first_col;
    }
    else if (loc1.first_row > loc2.first_row)
    {
        loc.first_row = loc2.first_row;
        loc.first_col = loc2.first_col;
    }

    /* verify if loc1's location ends before loc2's location;
     * in this case, extend loc1 to end at loc2's end-location
     */
    if (loc1.last_row == loc2.last_row)
    {
        if (loc1.last_col < loc2.last_col)
            loc.last_col = loc2.last_col;
    }
    else if (loc1.last_row < loc2.last_row)
    {
        loc.last_row = loc2.last_row;
        loc.last_col = loc2.last_col;
    }

    return loc;
}



/* Line 189 of yacc.c  */
#line 292 "y.tab.c"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     encoding_StringLiteral = 258,
     StringLiteral = 259,
     after = 260,
     ancestor_colon_colon = 261,
     ancestor_or_self_colon_colon = 262,
     and = 263,
     apos = 264,
     as = 265,
     ascending = 266,
     as_first_into = 267,
     as_last_into = 268,
     at_dollar = 269,
     atsign = 270,
     attribute_colon_colon = 271,
     attribute_lbrace = 272,
     attribute_lparen = 273,
     before = 274,
     case_ = 275,
     cast_as = 276,
     castable_as = 277,
     cdata_end = 278,
     cdata_start = 279,
     child_colon_colon = 280,
     collation = 281,
     colon_equals = 282,
     comma = 283,
     comment_lbrace = 284,
     comment_lparen = 285,
     copy_ns_inherit = 286,
     copy_ns_noinherit = 287,
     copy_ns_nopreserve = 288,
     copy_ns_preserve = 289,
     declare_base_uri = 290,
     declare_construction_preserve = 291,
     declare_construction_strip = 292,
     declare_default_collation = 293,
     declare_default_element = 294,
     declare_default_function = 295,
     declare_default_order = 296,
     declare_docmgmt_function = 297,
     declare_function = 298,
     declare_updating_function = 299,
     declare_copy_namespaces = 300,
     declare_namespace = 301,
     declare_ordering_ordered = 302,
     declare_ordering_unordered = 303,
     declare_variable_dollar = 304,
     declare_boundary_space_preserve = 305,
     declare_boundary_space_strip = 306,
     declare_option = 307,
     declare_revalidation_lax = 308,
     declare_revalidation_skip = 309,
     declare_revalidation_strict = 310,
     default_ = 311,
     default_element = 312,
     descendant_colon_colon = 313,
     descendant_or_self_colon_colon = 314,
     descending = 315,
     div_ = 316,
     do_delete = 317,
     do_insert = 318,
     do_rename = 319,
     do_replace = 320,
     do_replace_value_of = 321,
     document_lbrace = 322,
     document_node_lparen = 323,
     dollar = 324,
     dot = 325,
     dot_dot = 326,
     element_lbrace = 327,
     element_lparen = 328,
     else_ = 329,
     empty_greatest = 330,
     empty_least = 331,
     empty_sequence = 332,
     eq = 333,
     equals = 334,
     escape_apos = 335,
     escape_quot = 336,
     every_dollar = 337,
     except = 338,
     excl_equals = 339,
     execute_at = 340,
     external_ = 341,
     following_colon_colon = 342,
     following_sibling_colon_colon = 343,
     for_dollar = 344,
     ge = 345,
     greater_than = 346,
     greater_than_equal = 347,
     gt = 348,
     gt_gt = 349,
     hash_paren = 350,
     idiv = 351,
     if_lparen = 352,
     import_module = 353,
     import_schema = 354,
     in_ = 355,
     instance_of = 356,
     intersect = 357,
     into = 358,
     is = 359,
     item_lrparens = 360,
     lbrace = 361,
     lbrace_lbrace = 362,
     lbracket = 363,
     le = 364,
     less_than = 365,
     less_than_equal = 366,
     let_dollar = 367,
     lparen = 368,
     lt = 369,
     lt_lt = 370,
     lt_question_mark = 371,
     lt_slash = 372,
     minus = 373,
     mod_ = 374,
     modify = 375,
     module_namespace = 376,
     namespace = 377,
     ne = 378,
     node_lrparens = 379,
     or = 380,
     order_by = 381,
     ordered_lbrace = 382,
     paren_hash = 383,
     parent_colon_colon = 384,
     pi_lbrace = 385,
     pi_lparen = 386,
     pipe_ = 387,
     plus = 388,
     preceding_colon_colon = 389,
     preceding_sibling_colon_colon = 390,
     question_mark = 391,
     question_mark_gt = 392,
     quot_ = 393,
     rbrace = 394,
     rbrace_rbrace = 395,
     rbracket = 396,
     recurse = 397,
     return_ = 398,
     rparen = 399,
     satisfies = 400,
     schema_attribute_lparen = 401,
     schema_element_lparen = 402,
     seeded_by = 403,
     select_narrow_colon_colon = 404,
     select_wide_colon_colon = 405,
     self_colon_colon = 406,
     semicolon = 407,
     slash = 408,
     slash_gt = 409,
     slash_slash = 410,
     some_dollar = 411,
     stable_order_by = 412,
     star = 413,
     text_lbrace = 414,
     text_lparen = 415,
     then = 416,
     to_ = 417,
     transform_copy_dollar = 418,
     treat_as = 419,
     typeswitch_lparen = 420,
     union_ = 421,
     unordered_lbrace = 422,
     validate_lax_lbrace = 423,
     validate_lbrace = 424,
     validate_strict_lbrace = 425,
     where = 426,
     with = 427,
     with_dollar = 428,
     xml_comment_end = 429,
     xml_comment_start = 430,
     xquery_version = 431,
     AttrContentChar = 432,
     Attribute_QName_LBrace = 433,
     PFChar = 434,
     CharRef = 435,
     DecimalLiteral = 436,
     DoubleLiteral = 437,
     ElementContentChar = 438,
     Element_QName_LBrace = 439,
     EscapeApos = 440,
     EscapeQuot = 441,
     IntegerLiteral = 442,
     NCName = 443,
     NCName_Colon_Star = 444,
     PITarget = 445,
     PI_NCName_LBrace = 446,
     PragmaContents = 447,
     PredefinedEntityRef = 448,
     QName = 449,
     QName_LParen = 450,
     S = 451,
     Star_Colon_NCName = 452,
     at_URILiteral = 453,
     invalid_character = 454
   };
#endif
/* Tokens.  */
#define encoding_StringLiteral 258
#define StringLiteral 259
#define after 260
#define ancestor_colon_colon 261
#define ancestor_or_self_colon_colon 262
#define and 263
#define apos 264
#define as 265
#define ascending 266
#define as_first_into 267
#define as_last_into 268
#define at_dollar 269
#define atsign 270
#define attribute_colon_colon 271
#define attribute_lbrace 272
#define attribute_lparen 273
#define before 274
#define case_ 275
#define cast_as 276
#define castable_as 277
#define cdata_end 278
#define cdata_start 279
#define child_colon_colon 280
#define collation 281
#define colon_equals 282
#define comma 283
#define comment_lbrace 284
#define comment_lparen 285
#define copy_ns_inherit 286
#define copy_ns_noinherit 287
#define copy_ns_nopreserve 288
#define copy_ns_preserve 289
#define declare_base_uri 290
#define declare_construction_preserve 291
#define declare_construction_strip 292
#define declare_default_collation 293
#define declare_default_element 294
#define declare_default_function 295
#define declare_default_order 296
#define declare_docmgmt_function 297
#define declare_function 298
#define declare_updating_function 299
#define declare_copy_namespaces 300
#define declare_namespace 301
#define declare_ordering_ordered 302
#define declare_ordering_unordered 303
#define declare_variable_dollar 304
#define declare_boundary_space_preserve 305
#define declare_boundary_space_strip 306
#define declare_option 307
#define declare_revalidation_lax 308
#define declare_revalidation_skip 309
#define declare_revalidation_strict 310
#define default_ 311
#define default_element 312
#define descendant_colon_colon 313
#define descendant_or_self_colon_colon 314
#define descending 315
#define div_ 316
#define do_delete 317
#define do_insert 318
#define do_rename 319
#define do_replace 320
#define do_replace_value_of 321
#define document_lbrace 322
#define document_node_lparen 323
#define dollar 324
#define dot 325
#define dot_dot 326
#define element_lbrace 327
#define element_lparen 328
#define else_ 329
#define empty_greatest 330
#define empty_least 331
#define empty_sequence 332
#define eq 333
#define equals 334
#define escape_apos 335
#define escape_quot 336
#define every_dollar 337
#define except 338
#define excl_equals 339
#define execute_at 340
#define external_ 341
#define following_colon_colon 342
#define following_sibling_colon_colon 343
#define for_dollar 344
#define ge 345
#define greater_than 346
#define greater_than_equal 347
#define gt 348
#define gt_gt 349
#define hash_paren 350
#define idiv 351
#define if_lparen 352
#define import_module 353
#define import_schema 354
#define in_ 355
#define instance_of 356
#define intersect 357
#define into 358
#define is 359
#define item_lrparens 360
#define lbrace 361
#define lbrace_lbrace 362
#define lbracket 363
#define le 364
#define less_than 365
#define less_than_equal 366
#define let_dollar 367
#define lparen 368
#define lt 369
#define lt_lt 370
#define lt_question_mark 371
#define lt_slash 372
#define minus 373
#define mod_ 374
#define modify 375
#define module_namespace 376
#define namespace 377
#define ne 378
#define node_lrparens 379
#define or 380
#define order_by 381
#define ordered_lbrace 382
#define paren_hash 383
#define parent_colon_colon 384
#define pi_lbrace 385
#define pi_lparen 386
#define pipe_ 387
#define plus 388
#define preceding_colon_colon 389
#define preceding_sibling_colon_colon 390
#define question_mark 391
#define question_mark_gt 392
#define quot_ 393
#define rbrace 394
#define rbrace_rbrace 395
#define rbracket 396
#define recurse 397
#define return_ 398
#define rparen 399
#define satisfies 400
#define schema_attribute_lparen 401
#define schema_element_lparen 402
#define seeded_by 403
#define select_narrow_colon_colon 404
#define select_wide_colon_colon 405
#define self_colon_colon 406
#define semicolon 407
#define slash 408
#define slash_gt 409
#define slash_slash 410
#define some_dollar 411
#define stable_order_by 412
#define star 413
#define text_lbrace 414
#define text_lparen 415
#define then 416
#define to_ 417
#define transform_copy_dollar 418
#define treat_as 419
#define typeswitch_lparen 420
#define union_ 421
#define unordered_lbrace 422
#define validate_lax_lbrace 423
#define validate_lbrace 424
#define validate_strict_lbrace 425
#define where 426
#define with 427
#define with_dollar 428
#define xml_comment_end 429
#define xml_comment_start 430
#define xquery_version 431
#define AttrContentChar 432
#define Attribute_QName_LBrace 433
#define PFChar 434
#define CharRef 435
#define DecimalLiteral 436
#define DoubleLiteral 437
#define ElementContentChar 438
#define Element_QName_LBrace 439
#define EscapeApos 440
#define EscapeQuot 441
#define IntegerLiteral 442
#define NCName 443
#define NCName_Colon_Star 444
#define PITarget 445
#define PI_NCName_LBrace 446
#define PragmaContents 447
#define PredefinedEntityRef 448
#define QName 449
#define QName_LParen 450
#define S 451
#define Star_Colon_NCName 452
#define at_URILiteral 453
#define invalid_character 454




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 214 of yacc.c  */
#line 254 "parser.y"

    long long int   num;
    char           *dec;
    char           *dbl;
    char           *str;
    bool            bit;
    PFqname_raw_t   qname_raw;
    PFpnode_t      *pnode;
    struct phole_t  phole;
    PFptype_t       ptype;
    PFpaxis_t       axis;
    PFsort_t        mode;
    PFpoci_t        oci;
    PFarray_t      *buf;
    PFinsertmod_t   insert;



/* Line 214 of yacc.c  */
#line 745 "y.tab.c"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


/* Copy the second part of user declarations.  */


/* Line 264 of yacc.c  */
#line 770 "y.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
	     && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE) + sizeof (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  5
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1286

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  200
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  200
/* YYNRULES -- Number of rules.  */
#define YYNRULES  429
/* YYNRULES -- Number of states.  */
#define YYNSTATES  701

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   454

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
     165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,   186,   187,   188,   189,   190,   191,   192,   193,   194,
     195,   196,   197,   198,   199
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     6,     9,    10,    15,    16,    18,    21,
      24,    30,    33,    34,    38,    42,    46,    50,    51,    55,
      59,    63,    65,    67,    69,    71,    73,    75,    77,    79,
      81,    83,    85,    90,    92,    94,    98,   102,   106,   108,
     110,   113,   116,   121,   123,   125,   127,   129,   132,   135,
     139,   141,   146,   150,   151,   154,   155,   159,   163,   165,
     167,   169,   174,   180,   185,   186,   188,   190,   192,   198,
     204,   210,   216,   222,   223,   225,   227,   231,   233,   237,
     241,   242,   244,   248,   250,   252,   256,   258,   260,   262,
     264,   266,   268,   270,   272,   274,   276,   278,   284,   286,
     289,   291,   293,   294,   296,   297,   299,   302,   308,   317,
     318,   320,   323,   326,   331,   339,   342,   345,   348,   351,
     356,   360,   361,   363,   365,   366,   368,   370,   371,   374,
     379,   381,   383,   388,   396,   405,   407,   410,   411,   414,
     420,   421,   425,   433,   435,   439,   441,   445,   447,   451,
     455,   459,   461,   465,   467,   471,   475,   477,   481,   483,
     485,   487,   489,   491,   495,   499,   501,   505,   509,   511,
     515,   517,   521,   523,   527,   529,   533,   535,   538,   541,
     543,   545,   547,   549,   551,   553,   555,   557,   559,   561,
     563,   565,   567,   569,   571,   573,   575,   577,   581,   585,
     589,   594,   596,   599,   600,   602,   608,   610,   613,   616,
     618,   620,   624,   628,   630,   632,   634,   637,   639,   642,
     644,   647,   649,   652,   655,   657,   659,   661,   663,   665,
     667,   669,   671,   674,   676,   678,   680,   682,   684,   686,
     688,   691,   693,   695,   698,   701,   703,   705,   707,   709,
     711,   713,   715,   717,   719,   721,   723,   725,   728,   730,
     733,   737,   739,   741,   743,   745,   747,   749,   751,   753,
     755,   757,   759,   761,   763,   765,   768,   770,   773,   777,
     779,   783,   787,   791,   792,   794,   796,   800,   802,   804,
     806,   808,   810,   815,   825,   826,   828,   829,   832,   833,
     836,   840,   846,   850,   854,   855,   858,   860,   862,   864,
     867,   869,   871,   873,   875,   877,   879,   881,   883,   885,
     887,   889,   891,   894,   896,   898,   900,   902,   904,   908,
     910,   912,   913,   916,   921,   922,   925,   929,   931,   933,
     935,   937,   939,   941,   943,   947,   951,   958,   959,   961,
     963,   967,   974,   978,   982,   986,   993,   995,   998,  1001,
    1003,  1006,  1007,  1009,  1011,  1013,  1015,  1017,  1019,  1021,
    1023,  1025,  1027,  1029,  1031,  1033,  1035,  1037,  1039,  1041,
    1044,  1048,  1052,  1055,  1058,  1061,  1065,  1069,  1072,  1076,
    1082,  1084,  1086,  1090,  1092,  1095,  1099,  1105,  1112,  1114,
    1116,  1120,  1122,  1124,  1126,  1128,  1130,  1132,  1134,  1136,
    1141,  1143,  1145,  1147,  1149,  1151,  1154,  1159,  1164,  1169,
    1171,  1173,  1175,  1182,  1184,  1188,  1192,  1199,  1202,  1210
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     201,     0,    -1,   202,   204,    -1,   202,   205,    -1,    -1,
     176,     4,   203,   212,    -1,    -1,     3,    -1,   207,   242,
      -1,   206,   207,    -1,   121,   188,    79,   384,   212,    -1,
     208,   209,    -1,    -1,   215,   212,   208,    -1,   210,   212,
     208,    -1,   213,   212,   208,    -1,   211,   212,   208,    -1,
      -1,   232,   212,   209,    -1,   235,   212,   209,    -1,   216,
     212,   209,    -1,   214,    -1,   222,    -1,   223,    -1,   234,
      -1,   217,    -1,   218,    -1,   385,    -1,   219,    -1,   224,
      -1,   228,    -1,   152,    -1,    46,   188,    79,   384,    -1,
      50,    -1,    51,    -1,    39,   122,   384,    -1,    40,   122,
     384,    -1,    52,   194,     4,    -1,    47,    -1,    48,    -1,
      41,    75,    -1,    41,    76,    -1,    45,   220,    28,   221,
      -1,    34,    -1,    33,    -1,    31,    -1,    32,    -1,    38,
     384,    -1,    35,   384,    -1,    99,   225,   226,    -1,   384,
      -1,   122,   188,    79,   384,    -1,    57,   122,   384,    -1,
      -1,   198,   227,    -1,    -1,   227,    28,   384,    -1,    98,
     229,   226,    -1,   231,    -1,   230,    -1,   384,    -1,   122,
     188,    79,   384,    -1,    49,   321,   233,    27,   244,    -1,
      49,   321,   233,    86,    -1,    -1,   362,    -1,    36,    -1,
      37,    -1,    43,   195,   236,   237,   241,    -1,    43,   195,
     236,   237,    86,    -1,    44,   195,   236,   144,   241,    -1,
      44,   195,   236,   144,    86,    -1,    42,   195,   236,   144,
     241,    -1,    -1,   238,    -1,   144,    -1,   144,    10,   363,
      -1,   239,    -1,   239,    28,   238,    -1,    69,   321,   240,
      -1,    -1,   362,    -1,   106,   243,   139,    -1,   243,    -1,
     244,    -1,   244,    28,   243,    -1,   245,    -1,   263,    -1,
     266,    -1,   271,    -1,   386,    -1,   388,    -1,   390,    -1,
     389,    -1,   394,    -1,   272,    -1,   397,    -1,   246,   248,
     249,   143,   244,    -1,   247,    -1,   246,   247,    -1,   250,
      -1,   254,    -1,    -1,   256,    -1,    -1,   257,    -1,    89,
     251,    -1,   321,   233,   252,   100,   244,    -1,   321,   233,
     252,   100,   244,    28,    69,   251,    -1,    -1,   253,    -1,
      14,   321,    -1,   112,   255,    -1,   321,   233,    27,   244,
      -1,   321,   233,    27,   244,    28,    69,   255,    -1,   171,
     244,    -1,   126,   258,    -1,   157,   258,    -1,   244,   259,
      -1,   244,   259,    28,   258,    -1,   260,   261,   262,    -1,
      -1,    11,    -1,    60,    -1,    -1,    75,    -1,    76,    -1,
      -1,    26,     4,    -1,   264,   265,   145,   244,    -1,   156,
      -1,    82,    -1,   321,   233,   100,   244,    -1,   321,   233,
     100,   244,    28,    69,   265,    -1,   165,   243,   144,   267,
      56,   268,   143,   244,    -1,   269,    -1,   269,   267,    -1,
      -1,    69,   321,    -1,    20,   270,   363,   143,   244,    -1,
      -1,    69,   321,    10,    -1,    97,   243,   144,   161,   244,
      74,   244,    -1,   273,    -1,   272,   125,   273,    -1,   274,
      -1,   273,     8,   274,    -1,   275,    -1,   275,   288,   275,
      -1,   275,   287,   275,    -1,   275,   289,   275,    -1,   276,
      -1,   276,   162,   276,    -1,   277,    -1,   276,   133,   277,
      -1,   276,   118,   277,    -1,   279,    -1,   277,   278,   279,
      -1,   158,    -1,    61,    -1,    96,    -1,   119,    -1,   280,
      -1,   279,   166,   280,    -1,   279,   132,   280,    -1,   281,
      -1,   280,   102,   281,    -1,   280,    83,   281,    -1,   282,
      -1,   282,   101,   363,    -1,   283,    -1,   283,   164,   363,
      -1,   284,    -1,   284,    22,   361,    -1,   285,    -1,   285,
      21,   361,    -1,   286,    -1,   118,   285,    -1,   133,   285,
      -1,   290,    -1,   295,    -1,   291,    -1,    79,    -1,    84,
      -1,   110,    -1,   111,    -1,    91,    -1,    92,    -1,    78,
      -1,   123,    -1,   114,    -1,   109,    -1,    93,    -1,    90,
      -1,   104,    -1,   115,    -1,    94,    -1,   169,   243,   139,
      -1,   168,   243,   139,    -1,   170,   243,   139,    -1,   292,
     106,   293,   139,    -1,   294,    -1,   294,   292,    -1,    -1,
     243,    -1,   128,   196,   194,   192,    95,    -1,   153,    -1,
     153,   296,    -1,   155,   296,    -1,   296,    -1,   297,    -1,
     297,   153,   296,    -1,   297,   155,   296,    -1,   314,    -1,
     298,    -1,   302,    -1,   302,   315,    -1,   299,    -1,   299,
     315,    -1,   305,    -1,   305,   315,    -1,   308,    -1,   308,
     315,    -1,   300,   310,    -1,   301,    -1,    25,    -1,    58,
      -1,   151,    -1,    59,    -1,    88,    -1,    87,    -1,   310,
      -1,   303,   310,    -1,   304,    -1,   129,    -1,     6,    -1,
     135,    -1,   134,    -1,     7,    -1,    71,    -1,   306,   312,
      -1,   307,    -1,    16,    -1,    15,   312,    -1,   309,   310,
      -1,   149,    -1,   150,    -1,   367,    -1,   311,    -1,   194,
      -1,   313,    -1,   367,    -1,   311,    -1,   158,    -1,   189,
      -1,   197,    -1,   317,    -1,   317,   315,    -1,   316,    -1,
     316,   315,    -1,   108,   243,   141,    -1,   318,    -1,   320,
      -1,   322,    -1,   323,    -1,   326,    -1,   324,    -1,   325,
      -1,   329,    -1,   399,    -1,   319,    -1,     4,    -1,   187,
      -1,   181,    -1,   182,    -1,    69,   321,    -1,   194,    -1,
     113,   144,    -1,   113,   243,   144,    -1,    70,    -1,   127,
     243,   139,    -1,   167,   243,   139,    -1,   195,   327,   144,
      -1,    -1,   328,    -1,   244,    -1,   328,    28,   244,    -1,
     330,    -1,   352,    -1,   331,    -1,   344,    -1,   348,    -1,
     110,   194,   334,   154,    -1,   110,   194,   334,    91,   333,
     117,   194,   332,    91,    -1,    -1,   196,    -1,    -1,   341,
     333,    -1,    -1,   196,   334,    -1,   196,   335,   334,    -1,
     194,   332,    79,   332,   336,    -1,   138,   337,   138,    -1,
       9,   337,     9,    -1,    -1,   338,   337,    -1,   339,    -1,
     241,    -1,   340,    -1,   339,   340,    -1,   177,    -1,   186,
      -1,   185,    -1,   193,    -1,   180,    -1,   107,    -1,   140,
      -1,   330,    -1,   350,    -1,   342,    -1,   241,    -1,   343,
      -1,   342,   343,    -1,   183,    -1,   193,    -1,   180,    -1,
     107,    -1,   140,    -1,   175,   345,   174,    -1,   346,    -1,
     347,    -1,    -1,   347,   179,    -1,   116,   190,   349,   137,
      -1,    -1,   196,   346,    -1,    24,   351,    23,    -1,   346,
      -1,   353,    -1,   354,    -1,   357,    -1,   358,    -1,   359,
      -1,   360,    -1,    67,   243,   139,    -1,   184,   355,   139,
      -1,    72,   243,   139,   106,   355,   139,    -1,    -1,   356,
      -1,   243,    -1,   178,   355,   139,    -1,    17,   243,   139,
     106,   355,   139,    -1,   159,   243,   139,    -1,    29,   243,
     139,    -1,   191,   355,   139,    -1,   130,   243,   139,   106,
     355,   139,    -1,   366,    -1,   366,   136,    -1,    10,   363,
      -1,    77,    -1,   365,   364,    -1,    -1,   136,    -1,   158,
      -1,   133,    -1,   367,    -1,   105,    -1,   366,    -1,   194,
      -1,   369,    -1,   377,    -1,   373,    -1,   379,    -1,   375,
      -1,   372,    -1,   371,    -1,   370,    -1,   368,    -1,   124,
      -1,    68,   144,    -1,    68,   377,   144,    -1,    68,   379,
     144,    -1,   160,   144,    -1,    30,   144,    -1,   131,   144,
      -1,   131,   188,   144,    -1,   131,     4,   144,    -1,    18,
     144,    -1,    18,   374,   144,    -1,    18,   374,    28,   383,
     144,    -1,   381,    -1,   158,    -1,   146,   376,   144,    -1,
     381,    -1,    73,   144,    -1,    73,   378,   144,    -1,    73,
     378,    28,   383,   144,    -1,    73,   378,    28,   383,   136,
     144,    -1,   382,    -1,   158,    -1,   147,   380,   144,    -1,
     382,    -1,   194,    -1,   194,    -1,   194,    -1,     4,    -1,
      55,    -1,    53,    -1,    54,    -1,    63,   391,   387,   392,
      -1,    12,    -1,    13,    -1,   103,    -1,     5,    -1,    19,
      -1,    62,   392,    -1,    65,   392,   172,   244,    -1,    66,
     392,   172,   244,    -1,    64,   392,   103,   393,    -1,   244,
      -1,   244,    -1,   244,    -1,   163,   395,   120,   244,   143,
     244,    -1,   396,    -1,   396,    28,   395,    -1,   321,    27,
     244,    -1,   173,   398,   148,   244,   142,   244,    -1,   321,
     233,    -1,    85,   106,   244,   139,   106,   326,   139,    -1,
      85,   384,   106,   326,   139,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   767,   767,   772,   781,   783,   803,   804,   809,   819,
     827,   845,   851,   855,   859,   862,   865,   880,   884,   887,
     890,   896,   897,   898,   899,   900,   901,   902,   903,   907,
     908,   912,   916,   926,   930,   937,   944,   954,   966,   970,
     977,   981,   988,   997,   998,  1002,  1003,  1007,  1017,  1027,
    1047,  1051,  1058,  1068,  1069,  1079,  1080,  1103,  1142,  1143,
    1146,  1152,  1164,  1171,  1180,  1181,  1185,  1187,  1192,  1202,
    1210,  1226,  1241,  1259,  1260,  1263,  1273,  1277,  1279,  1284,
    1289,  1298,  1303,  1307,  1311,  1315,  1320,  1321,  1322,  1323,
    1324,  1325,  1326,  1327,  1328,  1329,  1330,  1334,  1343,  1346,
    1351,  1352,  1355,  1356,  1359,  1360,  1364,  1367,  1380,  1396,
    1397,  1401,  1405,  1408,  1417,  1431,  1435,  1437,  1442,  1447,
    1455,  1462,  1463,  1464,  1467,  1468,  1469,  1472,  1473,  1477,
    1481,  1482,  1485,  1493,  1505,  1517,  1521,  1526,  1527,  1531,
    1540,  1541,  1545,  1554,  1555,  1560,  1561,  1566,  1567,  1569,
    1571,  1576,  1577,  1582,  1583,  1585,  1590,  1591,  1595,  1596,
    1597,  1598,  1602,  1603,  1605,  1610,  1611,  1613,  1618,  1619,
    1624,  1625,  1630,  1631,  1636,  1637,  1642,  1643,  1644,  1648,
    1649,  1650,  1654,  1655,  1656,  1657,  1658,  1659,  1663,  1664,
    1665,  1666,  1667,  1668,  1672,  1673,  1674,  1678,  1683,  1686,
    1692,  1696,  1698,  1702,  1703,  1707,  1717,  1719,  1722,  1745,
    1749,  1750,  1752,  1777,  1778,  1782,  1784,  1786,  1788,  1790,
    1792,  1795,  1797,  1803,  1805,  1811,  1812,  1813,  1814,  1815,
    1816,  1821,  1829,  1831,  1836,  1837,  1838,  1839,  1840,  1844,
    1854,  1856,  1861,  1865,  1873,  1879,  1889,  1903,  1905,  1911,
    1917,  1922,  1924,  1930,  1932,  1938,  1947,  1948,  1953,  1955,
    1964,  1968,  1969,  1970,  1971,  1972,  1973,  1974,  1975,  1976,
    1980,  1981,  1986,  1988,  1990,  1995,  1999,  2004,  2005,  2009,
    2013,  2018,  2023,  2034,  2035,  2038,  2040,  2053,  2054,  2058,
    2059,  2060,  2064,  2077,  2111,  2112,  2116,  2117,  2123,  2124,
    2126,  2135,  2144,  2145,  2149,  2150,  2154,  2164,  2168,  2179,
    2188,  2189,  2190,  2191,  2192,  2193,  2194,  2199,  2200,  2201,
    2219,  2222,  2233,  2243,  2244,  2245,  2246,  2247,  2251,  2256,
    2259,  2270,  2272,  2283,  2304,  2305,  2309,  2316,  2320,  2321,
    2322,  2323,  2324,  2325,  2329,  2334,  2342,  2348,  2349,  2353,
    2357,  2365,  2372,  2377,  2382,  2389,  2395,  2398,  2404,  2408,
    2411,  2417,  2418,  2419,  2420,  2424,  2425,  2426,  2430,  2436,
    2437,  2438,  2439,  2440,  2441,  2442,  2443,  2444,  2448,  2454,
    2457,  2460,  2466,  2472,  2478,  2481,  2489,  2498,  2501,  2505,
    2516,  2518,  2523,  2528,  2532,  2535,  2539,  2547,  2571,  2573,
    2578,  2583,  2587,  2591,  2595,  2599,  2605,  2608,  2611,  2617,
    2622,  2623,  2624,  2625,  2626,  2630,  2635,  2638,  2648,  2653,
    2657,  2661,  2665,  2673,  2675,  2679,  2686,  2693,  2699,  2701
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "encoding_StringLiteral",
  "StringLiteral", "\"after\"", "\"ancestor::\"", "\"ancestor-or-self::\"",
  "\"and\"", "\"'\"", "\"as\"", "\"ascending\"", "\"as first into\"",
  "\"as last into\"", "\"at $\"", "\"@\"", "\"attribute::\"",
  "\"attribute {\"", "\"attribute (\"", "\"before\"", "\"case\"",
  "\"cast as\"", "\"castable as\"", "\"]]>\"", "\"<![CDATA[\"",
  "\"child::\"", "\"collation\"", "\":=\"", "\",\"", "\"comment {\"",
  "\"comment (\"", "\"inherit\"", "\"no-inherit\"", "\"no-preserve\"",
  "\"preserve\"", "\"declare base-uri\"",
  "\"declare construction preserve\"", "\"declare construction strip\"",
  "\"declare default collation\"", "\"declare default element\"",
  "\"declare default function\"", "\"declare default order\"",
  "\"declare document management function\"", "\"declare function\"",
  "\"declare updating function\"", "\"declare copy-namespaces\"",
  "\"declare namespace\"", "\"declare ordering ordered\"",
  "\"declare ordering unordered\"", "\"declare variable $\"",
  "\"declare boundary-space preserve\"",
  "\"declare boundary-space strip\"", "\"declare option\"",
  "\"declare revalidation lax\"", "\"declare revalidation skip\"",
  "\"declare revalidation strict\"", "\"default\"", "\"default element\"",
  "\"descendant::\"", "\"descendant-or-self::\"", "\"descending\"",
  "\"div\"", "\"do delete\"", "\"do insert\"", "\"do rename\"",
  "\"do replace\"", "\"do replace value of\"", "\"document {\"",
  "\"document-node (\"", "\"$\"", "\".\"", "\"..\"", "\"element {\"",
  "\"element (\"", "\"else\"", "\"empty greatest\"", "\"empty least\"",
  "\"empty-sequence ()\"", "\"eq\"", "\"=\"", "\"''\"", "\"\\\"\\\"\"",
  "\"every $\"", "\"except\"", "\"!=\"", "\"execute at\"", "\"external\"",
  "\"following::\"", "\"following-sibling::\"", "\"for $\"", "\"ge\"",
  "\">\"", "\">=\"", "\"gt\"", "\">>\"", "\"#)\"", "\"idiv\"", "\"if (\"",
  "\"import module\"", "\"import schema\"", "\"in\"", "\"instance of\"",
  "\"intersect\"", "\"into\"", "\"is\"", "\"item ()\"", "\"{\"", "\"{{\"",
  "\"[\"", "\"le\"", "\"<\"", "\"<=\"", "\"let $\"", "\"(\"", "\"lt\"",
  "\"<<\"", "\"<?\"", "\"</\"", "\"-\"", "\"mod\"", "\"modify\"",
  "\"module namespace\"", "\"namespace\"", "\"ne\"", "\"node ()\"",
  "\"or\"", "\"order by\"", "\"ordered {\"", "\"(#\"", "\"parent::\"",
  "\"processing-instruction {\"", "\"processing-instruction (\"", "\"|\"",
  "\"+\"", "\"preceding::\"", "\"preceding-sibling::\"", "\"?\"", "\"?>\"",
  "\"\\\"\"", "\"}\"", "\"}}\"", "\"]\"", "\"recurse\"", "\"return\"",
  "\")\"", "\"satisfies\"", "\"schema-attribute (\"",
  "\"schema-element (\"", "\"seeded by\"", "\"select-narrow::\"",
  "\"select-wide::\"", "\"self::\"", "\";\"", "\"/\"", "\"/>\"", "\"//\"",
  "\"some $\"", "\"stable order by\"", "\"*\"", "\"text {\"", "\"text (\"",
  "\"then\"", "\"to\"", "\"transform copy $\"", "\"treat as\"",
  "\"typeswitch (\"", "\"union\"", "\"unordered {\"", "\"validate lax {\"",
  "\"validate {\"", "\"validate strict {\"", "\"where\"", "\"with\"",
  "\"with $\"", "\"-->\"", "\"<!--\"", "\"xquery version\"",
  "AttrContentChar", "Attribute_QName_LBrace", "PFChar", "CharRef",
  "DecimalLiteral", "DoubleLiteral", "ElementContentChar",
  "Element_QName_LBrace", "EscapeApos", "EscapeQuot", "IntegerLiteral",
  "NCName", "NCName_Colon_Star", "PITarget", "PI_NCName_LBrace",
  "PragmaContents", "PredefinedEntityRef", "QName", "QName_LParen", "S",
  "Star_Colon_NCName", "at_URILiteral", "invalid_character", "$accept",
  "Module", "VersionDecl", "OptEncoding_", "MainModule", "LibraryModule",
  "ModuleDecl", "Prolog", "SetterImportAndNSDecls_", "VarFunDecls_",
  "Setter", "Import", "Separator", "NamespaceDecl", "BoundarySpaceDecl",
  "DefaultNamespaceDecl", "OptionDecl", "OrderingModeDecl",
  "EmptyOrderDecl", "CopyNamespacesDecl", "PreserveMode", "InheritMode",
  "DefaultCollationDecl", "BaseURIDecl", "SchemaImport", "SchemaSrc_",
  "OptAtURILiterals_", "URILiterals_", "ModuleImport", "ModuleNS_",
  "ModuleNSWithoutPrefix", "ModuleNSWithPrefix", "VarDecl",
  "OptTypeDeclaration_", "ConstructionDecl", "FunctionDecl",
  "OptParamList_", "OptAsSequenceType_", "ParamList", "Param",
  "OptParamTypeDeclaration_", "EnclosedExpr", "QueryBody", "Expr",
  "ExprSingle", "FLWORExpr", "ForLetClauses_", "ForLetClause_",
  "OptWhereClause_", "OptOrderByClause_", "ForClause", "VarPosBindings_",
  "OptPositionalVar_", "PositionalVar", "LetClause", "LetBindings_",
  "WhereClause", "OrderByClause", "OrderSpecList", "OrderModifier",
  "OptAscendingDescending_", "OptEmptyGreatestLeast_",
  "OptCollationStringLiteral_", "QuantifiedExpr", "SomeEvery_",
  "VarBindings_", "TypeswitchExpr", "CaseClauses_", "OptDollarVarName_",
  "CaseClause", "OptDollarVarNameAs_", "IfExpr", "OrExpr", "AndExpr",
  "ComparisonExpr", "RangeExpr", "AdditiveExpr", "MultiplicativeExpr",
  "DivOp_", "UnionExpr", "IntersectExceptExpr", "InstanceofExpr",
  "TreatExpr", "CastableExpr", "CastExpr", "UnaryExpr", "ValueExpr",
  "GeneralComp", "ValueComp", "NodeComp", "ValidateExpr", "ExtensionExpr",
  "Pragmas_", "OptPragmaExpr_", "Pragma", "PathExpr", "RelativePathExpr",
  "StepExpr", "AxisStep", "ForwardStep", "ForwardAxis",
  "AbbrevForwardStep", "ReverseStep", "ReverseAxis", "AbbrevReverseStep",
  "AttribStep_", "AttributeAxis_", "AbbrevAttribStep_", "BurkStep_",
  "BurkAxis_", "NodeTest", "NameTest", "AttribNodeTest", "Wildcard",
  "FilterExpr", "PredicateList", "Predicate", "PrimaryExpr", "Literal",
  "NumericLiteral", "VarRef", "VarName", "ParenthesizedExpr",
  "ContextItemExpr", "OrderedExpr", "UnorderedExpr", "FunctionCall",
  "OptFuncArgList_", "FuncArgList_", "Constructor", "DirectConstructor",
  "DirElemConstructor", "OptS_", "DirElementContents_", "DirAttributeList",
  "DirAttribute_", "DirAttributeValue", "AttributeValueConts_",
  "AttributeValueCont_", "AttributeValueContTexts_",
  "AttributeValueContText_", "DirElemContent", "ElementContentTexts_",
  "ElementContentText_", "DirCommentConstructor", "DirCommentContents",
  "Characters_", "Chars_", "DirPIConstructor", "DirPIContents",
  "CDataSection", "CDataSectionContents", "ComputedConstructor",
  "CompDocConstructor", "CompElemConstructor", "OptContentExpr_",
  "ContentExpr", "CompAttrConstructor", "CompTextConstructor",
  "CompCommentConstructor", "CompPIConstructor", "SingleType",
  "TypeDeclaration", "SequenceType", "OptOccurrenceIndicator_", "ItemType",
  "AtomicType", "KindTest", "AnyKindTest", "DocumentTest", "TextTest",
  "CommentTest", "PITest", "AttributeTest", "AttribNameOrWildcard",
  "SchemaAttributeTest", "AttributeDeclaration", "ElementTest",
  "ElementNameOrWildcard", "SchemaElementTest", "ElementDeclaration",
  "AttributeName", "ElementName", "TypeName", "URILiteral",
  "RevalidationDecl", "InsertExpr", "InsertLoc_", "DeleteExpr",
  "ReplaceExpr", "RenameExpr", "SourceExpr", "TargetExpr", "NewNameExpr",
  "TransformExpr", "TransformBindings_", "TransformBinding_",
  "RecursiveExpr", "SeedVar", "XRPCCall", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,   406,   407,   408,   409,   410,   411,   412,   413,   414,
     415,   416,   417,   418,   419,   420,   421,   422,   423,   424,
     425,   426,   427,   428,   429,   430,   431,   432,   433,   434,
     435,   436,   437,   438,   439,   440,   441,   442,   443,   444,
     445,   446,   447,   448,   449,   450,   451,   452,   453,   454
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   200,   201,   201,   202,   202,   203,   203,   204,   205,
     206,   207,   208,   208,   208,   208,   208,   209,   209,   209,
     209,   210,   210,   210,   210,   210,   210,   210,   210,   211,
     211,   212,   213,   214,   214,   215,   215,   216,   217,   217,
     218,   218,   219,   220,   220,   221,   221,   222,   223,   224,
     225,   225,   225,   226,   226,   227,   227,   228,   229,   229,
     230,   231,   232,   232,   233,   233,   234,   234,   235,   235,
     235,   235,   235,   236,   236,   237,   237,   238,   238,   239,
     240,   240,   241,   242,   243,   243,   244,   244,   244,   244,
     244,   244,   244,   244,   244,   244,   244,   245,   246,   246,
     247,   247,   248,   248,   249,   249,   250,   251,   251,   252,
     252,   253,   254,   255,   255,   256,   257,   257,   258,   258,
     259,   260,   260,   260,   261,   261,   261,   262,   262,   263,
     264,   264,   265,   265,   266,   267,   267,   268,   268,   269,
     270,   270,   271,   272,   272,   273,   273,   274,   274,   274,
     274,   275,   275,   276,   276,   276,   277,   277,   278,   278,
     278,   278,   279,   279,   279,   280,   280,   280,   281,   281,
     282,   282,   283,   283,   284,   284,   285,   285,   285,   286,
     286,   286,   287,   287,   287,   287,   287,   287,   288,   288,
     288,   288,   288,   288,   289,   289,   289,   290,   290,   290,
     291,   292,   292,   293,   293,   294,   295,   295,   295,   295,
     296,   296,   296,   297,   297,   298,   298,   298,   298,   298,
     298,   298,   298,   299,   299,   300,   300,   300,   300,   300,
     300,   301,   302,   302,   303,   303,   303,   303,   303,   304,
     305,   305,   306,   307,   308,   309,   309,   310,   310,   311,
     311,   312,   312,   313,   313,   313,   314,   314,   315,   315,
     316,   317,   317,   317,   317,   317,   317,   317,   317,   317,
     318,   318,   319,   319,   319,   320,   321,   322,   322,   323,
     324,   325,   326,   327,   327,   328,   328,   329,   329,   330,
     330,   330,   331,   331,   332,   332,   333,   333,   334,   334,
     334,   335,   336,   336,   337,   337,   338,   338,   339,   339,
     340,   340,   340,   340,   340,   340,   340,   341,   341,   341,
     341,   342,   342,   343,   343,   343,   343,   343,   344,   345,
     346,   347,   347,   348,   349,   349,   350,   351,   352,   352,
     352,   352,   352,   352,   353,   354,   354,   355,   355,   356,
     357,   357,   358,   359,   360,   360,   361,   361,   362,   363,
     363,   364,   364,   364,   364,   365,   365,   365,   366,   367,
     367,   367,   367,   367,   367,   367,   367,   367,   368,   369,
     369,   369,   370,   371,   372,   372,   372,   373,   373,   373,
     374,   374,   375,   376,   377,   377,   377,   377,   378,   378,
     379,   380,   381,   382,   383,   384,   385,   385,   385,   386,
     387,   387,   387,   387,   387,   388,   389,   389,   390,   391,
     392,   393,   394,   395,   395,   396,   397,   398,   399,   399
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     2,     2,     0,     4,     0,     1,     2,     2,
       5,     2,     0,     3,     3,     3,     3,     0,     3,     3,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     4,     1,     1,     3,     3,     3,     1,     1,
       2,     2,     4,     1,     1,     1,     1,     2,     2,     3,
       1,     4,     3,     0,     2,     0,     3,     3,     1,     1,
       1,     4,     5,     4,     0,     1,     1,     1,     5,     5,
       5,     5,     5,     0,     1,     1,     3,     1,     3,     3,
       0,     1,     3,     1,     1,     3,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     5,     1,     2,
       1,     1,     0,     1,     0,     1,     2,     5,     8,     0,
       1,     2,     2,     4,     7,     2,     2,     2,     2,     4,
       3,     0,     1,     1,     0,     1,     1,     0,     2,     4,
       1,     1,     4,     7,     8,     1,     2,     0,     2,     5,
       0,     3,     7,     1,     3,     1,     3,     1,     3,     3,
       3,     1,     3,     1,     3,     3,     1,     3,     1,     1,
       1,     1,     1,     3,     3,     1,     3,     3,     1,     3,
       1,     3,     1,     3,     1,     3,     1,     2,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     3,     3,
       4,     1,     2,     0,     1,     5,     1,     2,     2,     1,
       1,     3,     3,     1,     1,     1,     2,     1,     2,     1,
       2,     1,     2,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     1,     1,     1,     1,     1,     1,     1,
       2,     1,     1,     2,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     1,     2,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     2,     1,     2,     3,     1,
       3,     3,     3,     0,     1,     1,     3,     1,     1,     1,
       1,     1,     4,     9,     0,     1,     0,     2,     0,     2,
       3,     5,     3,     3,     0,     2,     1,     1,     1,     2,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     1,     1,     1,     1,     1,     3,     1,
       1,     0,     2,     4,     0,     2,     3,     1,     1,     1,
       1,     1,     1,     1,     3,     3,     6,     0,     1,     1,
       3,     6,     3,     3,     3,     6,     1,     2,     2,     1,
       2,     0,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     2,
       3,     3,     2,     2,     2,     3,     3,     2,     3,     5,
       1,     1,     3,     1,     2,     3,     5,     6,     1,     1,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     4,
       1,     1,     1,     1,     1,     2,     4,     4,     4,     1,
       1,     1,     6,     1,     3,     3,     6,     2,     7,     5
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       4,     0,     0,    12,     6,     1,     0,    66,    67,     0,
       0,     0,     0,     0,     0,    38,    39,    33,    34,   407,
     408,   406,     0,     0,     0,     2,     3,    12,     0,    17,
       0,     0,     0,    21,     0,    25,    26,    28,    22,    23,
      29,    30,    24,    27,     7,     0,   405,    48,    47,     0,
       0,    40,    41,    44,    43,     0,     0,     0,    53,    59,
      58,    60,     0,     0,    53,    50,     0,     9,   271,   235,
     238,     0,   242,     0,     0,   225,     0,     0,   226,   228,
       0,     0,     0,     0,     0,     0,     0,     0,   279,   239,
       0,     0,   131,     0,   230,   229,     0,     0,     0,     0,
       0,     0,     0,   378,     0,     0,   234,     0,     0,     0,
     237,   236,     0,     0,   245,   246,   227,   206,     0,   130,
     253,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     331,   347,   273,   274,   347,   272,   254,   347,   249,   283,
     255,     8,    83,    84,    86,   102,    98,   100,   101,    87,
       0,    88,    89,    95,   143,   145,   147,   151,   153,   156,
     162,   165,   168,   170,   172,   174,   176,   179,   181,     0,
     201,   180,   209,   210,   214,   217,     0,   224,   215,     0,
     233,   219,     0,   241,   221,     0,   231,   248,   250,   213,
     256,   261,   270,   262,   263,   264,   266,   267,   265,   268,
     287,   289,   290,   291,   288,   338,   339,   340,   341,   342,
     343,   247,   377,   369,   376,   375,   374,   371,   373,   370,
     372,    90,    91,    93,    92,    94,    96,   269,     0,     0,
       0,     0,     0,    11,     0,     0,     0,    31,    12,    12,
      12,    12,     5,    35,    36,     0,     0,     0,    55,    57,
       0,     0,    49,     0,   252,   243,   251,     0,   387,   391,
     402,     0,   390,     0,   383,   420,   415,   419,     0,     0,
       0,     0,     0,   379,     0,     0,   276,   275,     0,   394,
     399,   403,     0,   398,     0,     0,   106,    64,     0,   298,
     112,    64,   277,     0,   334,   177,     0,     0,     0,     0,
     384,     0,   178,     0,   393,     0,   401,   207,   208,     0,
     382,     0,     0,   423,     0,     0,     0,     0,     0,    64,
       0,     0,   329,   330,   349,     0,   348,     0,     0,   285,
       0,   284,     0,     0,    99,   104,   103,     0,    64,     0,
       0,   188,   182,   183,   193,   186,   187,   192,   196,   194,
     191,   184,   185,   190,   195,   189,     0,     0,     0,     0,
       0,     0,   159,   160,   161,   158,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   203,   202,     0,     0,     0,
     218,   258,   223,   216,   232,   220,   240,   222,   244,   257,
      73,    73,    73,    64,     0,    17,    17,    17,    14,    16,
      15,    13,    45,    46,    42,    32,     0,    54,    52,     0,
       0,     0,     0,   388,   353,   413,   410,   411,   414,   412,
       0,     0,     0,     0,   344,   380,   381,     0,     0,   395,
       0,     0,     0,   109,    65,     0,   298,     0,     0,   278,
     331,     0,   280,     0,     0,   386,   385,   392,   400,   352,
       0,     0,     0,     0,   281,   198,   197,   199,   427,     0,
     328,   332,   350,   345,   354,   282,     0,    85,   115,     0,
       0,     0,   105,     0,     0,   144,   146,   149,   148,   150,
     155,   154,   152,   157,   164,   163,   167,   166,   359,   366,
     368,   169,   361,   367,   365,   171,   173,   356,   175,   204,
       0,   211,   212,     0,   259,     0,     0,    74,    77,     0,
       0,     0,    37,    20,    18,    19,    61,     0,    51,    10,
     347,   404,     0,   409,   421,   418,   416,   417,   347,     0,
       0,     0,   358,     0,     0,   110,     0,   294,   299,   298,
     296,   292,     0,   335,   333,     0,   347,   425,     0,   424,
     140,     0,   135,     0,   286,   121,   116,   117,     0,   129,
       0,   364,   362,   363,   360,   357,   200,   260,    80,     0,
       0,    75,     0,     0,     0,    63,    56,     0,   389,     0,
       0,   396,     0,   429,   111,     0,     0,   295,     0,   300,
     331,     0,   326,   327,   325,   323,   324,   320,   317,     0,
     296,   319,   321,   318,   113,   205,     0,     0,     0,     0,
     137,   136,     0,   122,   123,   118,   124,    97,   132,    79,
      81,    72,    78,     0,    69,    68,    71,    70,    62,   351,
     346,   397,     0,   107,     0,   294,   337,     0,     0,     0,
     297,   322,     0,   355,   422,     0,     0,     0,     0,   426,
       0,   125,   126,   127,     0,    76,   428,     0,   142,     0,
     336,    82,   294,     0,   141,     0,   138,     0,   119,     0,
     120,     0,     0,   304,   304,   301,     0,   114,   139,   134,
     128,   133,   108,   315,   316,   310,   314,   312,   311,   313,
     307,     0,   304,   306,   308,     0,   293,   303,   305,   309,
     302
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     2,     3,    45,    25,    26,    27,    28,    29,   233,
      30,    31,   238,    32,    33,    34,   234,    35,    36,    37,
      55,   404,    38,    39,    40,    64,   249,   407,    41,    58,
      59,    60,   235,   433,    42,   236,   506,   572,   507,   508,
     619,   690,   141,   324,   143,   144,   145,   146,   335,   471,
     147,   286,   534,   535,   148,   290,   336,   472,   556,   615,
     616,   653,   670,   149,   150,   337,   151,   551,   648,   552,
     609,   152,   153,   154,   155,   156,   157,   158,   366,   159,
     160,   161,   162,   163,   164,   165,   166,   356,   357,   358,
     167,   168,   169,   500,   170,   171,   172,   173,   174,   175,
     176,   177,   178,   179,   180,   181,   182,   183,   184,   185,
     186,   187,   255,   188,   189,   380,   381,   190,   191,   192,
     193,   287,   194,   195,   196,   197,   198,   330,   331,   199,
     200,   201,   588,   599,   437,   539,   675,   691,   692,   693,
     694,   600,   601,   602,   202,   321,   322,   323,   203,   441,
     603,   637,   204,   205,   206,   325,   326,   207,   208,   209,
     210,   496,   434,   491,   564,   492,   493,   211,   212,   213,
     214,   215,   216,   217,   261,   218,   303,   219,   282,   220,
     305,   262,   283,   522,    47,    43,   221,   420,   222,   223,
     224,   268,   266,   525,   225,   312,   313,   226,   320,   227
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -566
static const yytype_int16 yypact[] =
{
     -81,    48,    84,   188,   116,  -566,   127,  -566,  -566,   127,
      23,    81,   112,   197,   -29,  -566,  -566,  -566,  -566,  -566,
    -566,  -566,    33,    32,   -20,  -566,  -566,   276,   717,   163,
      56,    56,    56,  -566,    56,  -566,  -566,  -566,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,    56,  -566,  -566,  -566,   127,
     127,  -566,  -566,  -566,  -566,   183,   134,    71,    78,  -566,
    -566,  -566,    99,    92,    78,  -566,   190,  -566,  -566,  -566,
    -566,    25,  -566,   717,   -84,  -566,   717,   137,  -566,  -566,
     717,   717,   717,   717,   717,   717,   -12,    88,  -566,  -566,
     717,   -64,  -566,    34,  -566,  -566,    88,   717,    89,    88,
     531,    98,   903,  -566,   717,    93,  -566,   717,     3,   903,
    -566,  -566,    96,    97,  -566,  -566,  -566,  1089,  1089,  -566,
    -566,   717,   148,    88,   717,   717,   717,   717,   717,    88,
    -566,   717,  -566,  -566,   717,  -566,  -566,   717,  -566,   717,
    -566,  -566,  -566,   265,  -566,   -43,  -566,  -566,  -566,  -566,
      88,  -566,  -566,   169,   287,  -566,   254,     4,    -5,   -90,
      -6,  -566,   195,   133,   277,   279,  -566,  -566,  -566,   192,
     173,  -566,  -566,    46,  -566,   194,    25,  -566,   194,    25,
    -566,   194,    25,  -566,   194,    25,  -566,  -566,  -566,  -566,
     194,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,   108,   109,
     113,    88,   124,  -566,    56,    56,    56,  -566,   276,   276,
     276,   276,  -566,  -566,  -566,   213,   127,   228,  -566,  -566,
     127,   240,  -566,   127,  -566,  -566,  -566,   181,  -566,  -566,
    -566,     0,  -566,   186,  -566,  -566,  -566,  -566,    60,   225,
     162,   164,   196,  -566,   193,   205,  -566,  -566,   200,  -566,
    -566,  -566,     6,  -566,   717,   244,  -566,   341,   208,   158,
    -566,   341,  -566,   211,   160,  -566,   221,   167,   223,   232,
    -566,   234,  -566,   236,  -566,   237,  -566,  -566,  -566,   233,
    -566,   340,   262,   355,   241,   245,   248,   249,   252,   341,
     246,   222,  -566,   218,  -566,   259,  -566,   260,   261,  -566,
     257,   374,   717,   717,  -566,    39,  -566,   263,   341,   903,
     903,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,  -566,   903,   903,   903,   903,
     903,   903,  -566,  -566,  -566,  -566,   903,   903,   903,   903,
     903,    15,    15,   210,   210,   717,  -566,  1089,  1089,   717,
    -566,   194,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,
     336,   336,   336,   341,   402,   163,   163,   163,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,  -566,   127,   379,  -566,   127,
      56,   303,   216,  -566,  -566,  -566,  -566,  -566,  -566,  -566,
     717,   717,   717,   717,  -566,  -566,  -566,   305,   216,  -566,
     273,   220,    15,   399,  -566,   255,    66,   -42,   391,  -566,
    -566,   282,  -566,   230,   314,  -566,  -566,  -566,  -566,  -566,
     717,   717,    88,   403,  -566,  -566,  -566,  -566,  -566,   717,
    -566,  -566,  -566,  -566,  -566,  -566,   717,  -566,  -566,   717,
     717,   281,  -566,   717,   325,   287,  -566,  -566,  -566,  -566,
      -5,    -5,    49,   -90,    -6,    -6,  -566,  -566,  -566,  -566,
    -566,  -566,    44,  -566,  -566,  -566,  -566,   291,  -566,  -566,
     289,  -566,  -566,   288,  -566,    88,   286,  -566,   404,   290,
     292,    37,  -566,  -566,  -566,  -566,  -566,   127,  -566,  -566,
     717,  -566,   293,  -566,  -566,  -566,  -566,  -566,   717,    54,
     327,   296,  -566,    88,   331,  -566,   717,   242,  -566,   158,
       1,  -566,   717,  -566,  -566,   344,   717,  -566,   297,  -566,
     372,   386,   403,   301,  -566,    55,  -566,  -566,   717,  -566,
     717,  -566,  -566,  -566,  -566,  -566,  -566,  -566,   341,   338,
     336,   435,   -19,    52,   717,  -566,  -566,   307,  -566,   308,
     304,  -566,   220,  -566,  -566,   717,   375,  -566,   371,  -566,
    -566,   717,  -566,  -566,  -566,  -566,  -566,  -566,  -566,   334,
       1,    17,  -566,  -566,   424,  -566,   316,   717,    88,    15,
     384,  -566,   717,  -566,  -566,   429,   176,  -566,   430,  -566,
    -566,  -566,  -566,    15,  -566,  -566,  -566,  -566,  -566,  -566,
    -566,  -566,   320,   432,   717,   242,  -566,   438,   324,   270,
    -566,  -566,   396,  -566,  -566,   456,   326,    88,   328,  -566,
     717,  -566,  -566,   441,   401,  -566,  -566,   405,  -566,    10,
    -566,  -566,   242,    88,  -566,   717,  -566,   717,  -566,   464,
    -566,    88,    88,   -59,   -59,  -566,   381,  -566,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,
    -566,   466,   -59,    -7,  -566,   335,  -566,  -566,  -566,  -566,
    -566
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -566,  -566,  -566,  -566,  -566,  -566,  -566,   449,     9,  -140,
    -566,  -566,   -18,  -566,  -566,  -566,  -566,  -566,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,  -566,   413,  -566,  -566,  -566,
    -566,  -566,  -566,  -229,  -566,  -566,  -124,  -566,   -88,  -566,
    -566,  -380,  -566,   -22,   -80,  -566,  -566,   339,  -566,  -566,
    -566,  -193,  -566,  -566,  -566,  -182,  -566,  -566,  -455,  -566,
    -566,  -566,  -566,  -566,  -566,  -188,  -566,   -67,  -566,  -566,
    -566,  -566,  -566,   147,   149,   -92,   126,   -87,  -566,   122,
     -93,   -91,  -566,  -566,  -566,    27,  -566,  -566,  -566,  -566,
    -566,  -566,   321,  -566,  -566,  -566,  -107,  -566,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,  -566,
      61,   -31,   310,  -566,  -566,  -149,  -566,  -566,  -566,  -566,
    -566,   -79,  -566,  -566,  -566,  -566,  -413,  -566,  -566,  -566,
    -487,  -566,  -565,  -110,  -397,  -566,  -566,  -549,  -566,  -566,
    -200,  -566,  -566,  -106,  -566,  -566,  -416,  -566,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,  -125,  -566,  -566,  -566,  -566,
    -566,   123,   -72,  -346,  -566,  -566,   -89,   -66,  -566,  -566,
    -566,  -566,  -566,  -566,  -566,  -566,  -566,   412,  -566,   414,
    -566,   387,   388,    74,     8,  -566,  -566,  -566,  -566,  -566,
    -566,  -566,   -61,  -566,  -566,    51,  -566,  -566,  -566,  -566
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const yytype_uint16 yytable[] =
{
     265,   267,   265,   265,   265,   256,   142,   299,   277,   327,
     307,   308,   328,   239,   240,   557,   241,    48,   531,   673,
     291,   269,   270,   271,   543,   590,   495,   242,   412,   383,
      61,    65,   385,    74,   428,   387,    46,    46,    46,   538,
     254,   389,   367,    74,   311,    77,    96,   591,   683,   540,
     319,   257,     4,   598,   263,    77,   362,   243,   244,   329,
     258,    91,   438,   272,   574,   415,   613,   624,   278,    99,
     659,   338,   416,   417,   259,   288,   368,   369,   293,   418,
     279,   684,   296,    86,     5,   298,   532,   591,    91,    62,
     458,   363,   488,    86,   280,     1,   370,   676,    91,   309,
     683,   285,   314,   315,   316,   317,   318,   591,   592,   474,
     260,    98,   541,   598,   364,   614,   256,   101,   685,    44,
     489,   686,   359,   575,   592,   695,   687,   688,   333,   295,
     281,    46,   273,   684,   689,   113,   302,   360,   626,   103,
     284,   593,   589,   698,   413,    49,   108,   300,   674,   103,
     429,   254,   393,   365,    63,    57,   108,   593,   591,    56,
     597,   112,   113,   419,   511,   469,   361,   359,    66,   632,
     685,   112,   113,   686,   636,   122,   130,   561,   687,   688,
     562,   594,   360,   120,   595,   122,   689,    51,    52,   621,
     580,   301,   625,   627,   596,   668,   470,   594,   581,   377,
     595,   378,   563,    50,   430,   228,   229,   230,   237,   490,
     596,   245,   231,   246,   136,   232,   395,   396,   397,   138,
     597,   250,   140,     6,     7,     8,     9,    10,    11,    12,
      53,    54,   504,    13,    14,    15,    16,   382,    17,    18,
     384,    19,    20,    21,   402,   403,   388,   398,   399,   400,
     401,   651,   652,   468,   405,   513,   514,   515,   408,   247,
     537,   410,   436,   646,   477,   478,   479,   509,   510,   253,
     501,   502,   480,   481,   484,   485,   248,   655,   486,   487,
     251,   264,   276,   289,   497,   497,    22,    23,   294,   297,
     260,   281,   310,   332,   339,   340,   371,   372,   375,   373,
     374,   105,   379,   390,   391,   494,   494,   406,   392,    24,
     467,     6,     7,     8,     9,    10,    11,    12,   394,   409,
     411,    13,    14,    15,    16,   414,    17,    18,   421,    19,
      20,    21,   341,   342,   422,   424,   423,   425,   343,   427,
     265,   524,   526,   527,   344,   345,   346,   347,   348,   426,
     431,   432,   435,   499,   436,   439,   440,   503,   349,   523,
     442,   443,   444,   350,   351,   352,   494,   450,   353,   354,
     547,   548,   449,   311,    22,    23,   445,   355,   446,   553,
     447,   448,   451,   452,   454,   453,   554,   455,   456,   555,
     555,   457,   519,   559,   459,   577,   460,   461,   462,   463,
     464,   465,   466,   579,   490,   505,   512,   517,   473,   520,
     521,   528,   530,   533,   516,   139,   536,   518,   542,   544,
     546,   606,   545,   550,   558,   560,   568,   565,   566,   567,
     569,   585,   570,   582,   571,   583,   573,   578,   587,   605,
     607,   608,   610,   612,   591,   623,   629,   630,   631,   634,
     635,   639,   642,   647,   584,   643,   586,   650,   654,   656,
     657,   660,   604,   661,   662,   663,   664,   669,   680,   665,
     671,   667,   696,   700,   672,   697,    67,   252,   617,   682,
     618,   677,   622,   681,   334,   611,   475,   482,   483,   476,
     640,   376,   386,   699,   628,   641,   620,   498,   274,   304,
     275,   306,   529,   549,     0,   633,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   576,     0,   644,     0,   645,
       0,     0,   649,     0,     0,    68,     0,    69,    70,     0,
       0,     0,     0,   494,     0,     0,    71,    72,    73,    74,
       0,     0,     0,     0,   658,     0,    75,   494,     0,     0,
      76,    77,     0,     0,     0,     0,     0,     0,   666,   638,
     555,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   291,   678,     0,   679,     0,    78,
      79,     0,   338,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    89,    90,    91,     0,     0,     0,     0,     0,
       0,     0,     0,    92,     0,     0,    93,     0,    94,    95,
      96,     0,     0,     0,     0,     0,     0,     0,    97,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    98,     0,    99,   100,     0,     0,   101,     0,   102,
       0,     0,     0,     0,     0,   103,     0,     0,   104,   105,
     106,   107,   108,     0,   109,   110,   111,     0,     0,     0,
       0,     0,     0,     0,     0,   292,     0,   112,   113,     0,
     114,   115,   116,     0,   117,     0,   118,   119,     0,   120,
     121,   122,     0,     0,   123,     0,   124,     0,   125,   126,
     127,   128,     0,     0,   129,     0,   130,     0,     0,   131,
       0,     0,   132,   133,     0,   134,     0,     0,   135,     0,
     136,    68,   137,    69,    70,   138,   139,     0,   140,     0,
       0,     0,    71,    72,    73,    74,     0,     0,     0,     0,
       0,     0,    75,     0,     0,     0,    76,    77,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    78,    79,     0,     0,    80,
      81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
      91,     0,     0,     0,     0,     0,     0,     0,     0,    92,
       0,     0,    93,     0,    94,    95,    96,     0,     0,     0,
       0,     0,     0,     0,    97,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    98,     0,    99,
     100,     0,     0,   101,     0,   102,     0,     0,     0,     0,
       0,   103,     0,     0,   104,   105,   106,   107,   108,     0,
     109,   110,   111,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   112,   113,     0,   114,   115,   116,     0,
     117,     0,   118,   119,     0,   120,   121,   122,     0,     0,
     123,     0,   124,     0,   125,   126,   127,   128,     0,     0,
     129,     0,   130,     0,     0,   131,     0,     0,   132,   133,
       0,   134,     0,     0,   135,     0,   136,    68,   137,    69,
      70,   138,   139,     0,   140,     0,     0,     0,    71,    72,
      73,    74,     0,     0,     0,     0,     0,     0,    75,     0,
       0,     0,    76,    77,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    78,    79,     0,     0,     0,     0,     0,     0,     0,
      85,    86,    87,    88,    89,    90,    91,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    93,     0,
      94,    95,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    98,     0,     0,   100,     0,     0,   101,
       0,   102,     0,     0,     0,     0,     0,   103,     0,     0,
     104,   105,   106,   107,   108,     0,   109,   110,   111,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   112,
     113,     0,   114,   115,   116,     0,   117,     0,   118,     0,
       0,   120,   121,   122,     0,     0,     0,     0,     0,     0,
     125,   126,   127,   128,     0,     0,     0,     0,   130,     0,
       0,   131,     0,     0,   132,   133,     0,   134,     0,     0,
     135,     0,   136,    68,   137,    69,    70,   138,   139,     0,
     140,     0,     0,     0,    71,    72,    73,    74,     0,     0,
       0,     0,     0,     0,    75,     0,     0,     0,    76,    77,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    78,    79,     0,
       0,     0,     0,     0,     0,     0,    85,    86,    87,    88,
      89,    90,    91,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    93,     0,    94,    95,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    98,
       0,     0,   100,     0,     0,   101,     0,     0,     0,     0,
       0,     0,     0,   103,     0,     0,   104,     0,   106,   107,
     108,     0,     0,   110,   111,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   112,   113,     0,   114,   115,
     116,     0,     0,     0,     0,     0,     0,   120,   121,   122,
       0,     0,     0,     0,     0,     0,   125,     0,     0,     0,
       0,     0,     0,     0,   130,     0,     0,   131,     0,     0,
     132,   133,     0,   134,     0,     0,   135,     0,   136,     0,
     137,     0,     0,   138,   139,     0,   140
};

static const yytype_int16 yycheck[] =
{
      80,    81,    82,    83,    84,    71,    28,     4,    87,   134,
     117,   118,   137,    31,    32,   470,    34,     9,   431,     9,
      99,    82,    83,    84,   440,    24,   372,    45,    28,   178,
      22,    23,   181,    18,    28,   184,     4,     4,     4,   436,
      71,   190,   132,    18,   123,    30,    89,   106,   107,    91,
     129,    73,     4,   540,    76,    30,    61,    49,    50,   139,
     144,    73,   291,    85,    27,     5,    11,    86,    90,   112,
     635,   150,    12,    13,   158,    97,   166,    83,   100,    19,
     144,   140,   104,    68,     0,   107,   432,   106,    73,    57,
     319,    96,    77,    68,   158,   176,   102,   662,    73,   121,
     107,    93,   124,   125,   126,   127,   128,   106,   107,   338,
     194,   110,   154,   600,   119,    60,   182,   116,   177,     3,
     105,   180,   118,    86,   107,   674,   185,   186,   171,   102,
     194,     4,   144,   140,   193,   147,   109,   133,    86,   124,
     106,   140,   539,   692,   144,   122,   131,   144,   138,   124,
     144,   182,   231,   158,   122,   122,   131,   140,   106,   188,
     540,   146,   147,   103,   393,   126,   162,   118,   188,   582,
     177,   146,   147,   180,   590,   160,   175,   133,   185,   186,
     136,   180,   133,   158,   183,   160,   193,    75,    76,   569,
     136,   188,   572,   573,   193,   650,   157,   180,   144,   153,
     183,   155,   158,   122,   284,    42,    43,    44,   152,   194,
     193,    28,    49,    79,   189,    52,   234,   235,   236,   194,
     600,   122,   197,    35,    36,    37,    38,    39,    40,    41,
      33,    34,   381,    45,    46,    47,    48,   176,    50,    51,
     179,    53,    54,    55,    31,    32,   185,   238,   239,   240,
     241,    75,    76,   333,   246,   395,   396,   397,   250,   188,
     194,   253,   196,   609,   356,   357,   358,   391,   392,    79,
     377,   378,   359,   360,   367,   368,   198,   623,   369,   370,
     188,   144,   194,   194,   373,   374,    98,    99,   190,   196,
     194,   194,   144,    28,   125,     8,   101,   164,   106,    22,
      21,   128,   108,   195,   195,   371,   372,    79,   195,   121,
     332,    35,    36,    37,    38,    39,    40,    41,   194,    79,
     139,    45,    46,    47,    48,   139,    50,    51,   103,    53,
      54,    55,    78,    79,   172,   139,   172,   144,    84,   139,
     420,   421,   422,   423,    90,    91,    92,    93,    94,   144,
     106,    10,   144,   375,   196,   144,   196,   379,   104,   420,
     139,   194,   139,   109,   110,   111,   432,    27,   114,   115,
     450,   451,   139,   452,    98,    99,   144,   123,   144,   459,
     144,   144,   120,    28,   139,   144,   466,   139,   139,   469,
     470,   139,   410,   473,   148,   520,   174,   179,   139,   139,
     139,   144,    28,   528,   194,    69,     4,    28,   145,   106,
     194,   106,   139,    14,   406,   195,   161,   409,    27,   137,
     106,   546,   192,    20,   143,   100,   505,   136,   139,   141,
     144,   100,    28,   106,   144,   139,   144,   144,   196,    95,
     143,    69,    56,   142,   106,    10,   139,   139,   144,    74,
      79,   117,    28,    69,   533,   139,   536,    28,    28,   139,
      28,    23,   542,   139,   194,    69,    10,    26,     4,   143,
      69,   143,    91,   138,    69,     9,    27,    64,   558,   672,
     560,   663,   570,   671,   145,   552,   339,   361,   366,   340,
     600,   170,   182,   693,   574,   601,   568,   374,    86,   112,
      86,   113,   428,   452,    -1,   585,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   517,    -1,   607,    -1,   608,
      -1,    -1,   612,    -1,    -1,     4,    -1,     6,     7,    -1,
      -1,    -1,    -1,   609,    -1,    -1,    15,    16,    17,    18,
      -1,    -1,    -1,    -1,   634,    -1,    25,   623,    -1,    -1,
      29,    30,    -1,    -1,    -1,    -1,    -1,    -1,   647,   591,
     650,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   663,   665,    -1,   667,    -1,    58,
      59,    -1,   671,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    82,    -1,    -1,    85,    -1,    87,    88,
      89,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    97,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   110,    -1,   112,   113,    -1,    -1,   116,    -1,   118,
      -1,    -1,    -1,    -1,    -1,   124,    -1,    -1,   127,   128,
     129,   130,   131,    -1,   133,   134,   135,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   144,    -1,   146,   147,    -1,
     149,   150,   151,    -1,   153,    -1,   155,   156,    -1,   158,
     159,   160,    -1,    -1,   163,    -1,   165,    -1,   167,   168,
     169,   170,    -1,    -1,   173,    -1,   175,    -1,    -1,   178,
      -1,    -1,   181,   182,    -1,   184,    -1,    -1,   187,    -1,
     189,     4,   191,     6,     7,   194,   195,    -1,   197,    -1,
      -1,    -1,    15,    16,    17,    18,    -1,    -1,    -1,    -1,
      -1,    -1,    25,    -1,    -1,    -1,    29,    30,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    58,    59,    -1,    -1,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    82,
      -1,    -1,    85,    -1,    87,    88,    89,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    97,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   110,    -1,   112,
     113,    -1,    -1,   116,    -1,   118,    -1,    -1,    -1,    -1,
      -1,   124,    -1,    -1,   127,   128,   129,   130,   131,    -1,
     133,   134,   135,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   146,   147,    -1,   149,   150,   151,    -1,
     153,    -1,   155,   156,    -1,   158,   159,   160,    -1,    -1,
     163,    -1,   165,    -1,   167,   168,   169,   170,    -1,    -1,
     173,    -1,   175,    -1,    -1,   178,    -1,    -1,   181,   182,
      -1,   184,    -1,    -1,   187,    -1,   189,     4,   191,     6,
       7,   194,   195,    -1,   197,    -1,    -1,    -1,    15,    16,
      17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    25,    -1,
      -1,    -1,    29,    30,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      67,    68,    69,    70,    71,    72,    73,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    85,    -1,
      87,    88,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   110,    -1,    -1,   113,    -1,    -1,   116,
      -1,   118,    -1,    -1,    -1,    -1,    -1,   124,    -1,    -1,
     127,   128,   129,   130,   131,    -1,   133,   134,   135,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   146,
     147,    -1,   149,   150,   151,    -1,   153,    -1,   155,    -1,
      -1,   158,   159,   160,    -1,    -1,    -1,    -1,    -1,    -1,
     167,   168,   169,   170,    -1,    -1,    -1,    -1,   175,    -1,
      -1,   178,    -1,    -1,   181,   182,    -1,   184,    -1,    -1,
     187,    -1,   189,     4,   191,     6,     7,   194,   195,    -1,
     197,    -1,    -1,    -1,    15,    16,    17,    18,    -1,    -1,
      -1,    -1,    -1,    -1,    25,    -1,    -1,    -1,    29,    30,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    58,    59,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    67,    68,    69,    70,
      71,    72,    73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    85,    -1,    87,    88,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   110,
      -1,    -1,   113,    -1,    -1,   116,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   124,    -1,    -1,   127,    -1,   129,   130,
     131,    -1,    -1,   134,   135,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   146,   147,    -1,   149,   150,
     151,    -1,    -1,    -1,    -1,    -1,    -1,   158,   159,   160,
      -1,    -1,    -1,    -1,    -1,    -1,   167,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   175,    -1,    -1,   178,    -1,    -1,
     181,   182,    -1,   184,    -1,    -1,   187,    -1,   189,    -1,
     191,    -1,    -1,   194,   195,    -1,   197
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,   176,   201,   202,     4,     0,    35,    36,    37,    38,
      39,    40,    41,    45,    46,    47,    48,    50,    51,    53,
      54,    55,    98,    99,   121,   204,   205,   206,   207,   208,
     210,   211,   213,   214,   215,   217,   218,   219,   222,   223,
     224,   228,   234,   385,     3,   203,     4,   384,   384,   122,
     122,    75,    76,    33,    34,   220,   188,   122,   229,   230,
     231,   384,    57,   122,   225,   384,   188,   207,     4,     6,
       7,    15,    16,    17,    18,    25,    29,    30,    58,    59,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    82,    85,    87,    88,    89,    97,   110,   112,
     113,   116,   118,   124,   127,   128,   129,   130,   131,   133,
     134,   135,   146,   147,   149,   150,   151,   153,   155,   156,
     158,   159,   160,   163,   165,   167,   168,   169,   170,   173,
     175,   178,   181,   182,   184,   187,   189,   191,   194,   195,
     197,   242,   243,   244,   245,   246,   247,   250,   254,   263,
     264,   266,   271,   272,   273,   274,   275,   276,   277,   279,
     280,   281,   282,   283,   284,   285,   286,   290,   291,   292,
     294,   295,   296,   297,   298,   299,   300,   301,   302,   303,
     304,   305,   306,   307,   308,   309,   310,   311,   313,   314,
     317,   318,   319,   320,   322,   323,   324,   325,   326,   329,
     330,   331,   344,   348,   352,   353,   354,   357,   358,   359,
     360,   367,   368,   369,   370,   371,   372,   373,   375,   377,
     379,   386,   388,   389,   390,   394,   397,   399,    42,    43,
      44,    49,    52,   209,   216,   232,   235,   152,   212,   212,
     212,   212,   212,   384,   384,    28,    79,   188,   198,   226,
     122,   188,   226,    79,   311,   312,   367,   243,   144,   158,
     194,   374,   381,   243,   144,   244,   392,   244,   391,   392,
     392,   392,   243,   144,   377,   379,   194,   321,   243,   144,
     158,   194,   378,   382,   106,   384,   251,   321,   243,   194,
     255,   321,   144,   243,   190,   285,   243,   196,   243,     4,
     144,   188,   285,   376,   381,   380,   382,   296,   296,   243,
     144,   321,   395,   396,   243,   243,   243,   243,   243,   321,
     398,   345,   346,   347,   243,   355,   356,   355,   355,   244,
     327,   328,    28,   171,   247,   248,   256,   265,   321,   125,
       8,    78,    79,    84,    90,    91,    92,    93,    94,   104,
     109,   110,   111,   114,   115,   123,   287,   288,   289,   118,
     133,   162,    61,    96,   119,   158,   278,   132,   166,    83,
     102,   101,   164,    22,    21,   106,   292,   153,   155,   108,
     315,   316,   310,   315,   310,   315,   312,   315,   310,   315,
     195,   195,   195,   321,   194,   212,   212,   212,   208,   208,
     208,   208,    31,    32,   221,   384,    79,   227,   384,    79,
     384,   139,    28,   144,   139,     5,    12,    13,    19,   103,
     387,   103,   172,   172,   139,   144,   144,   139,    28,   144,
     244,   106,    10,   233,   362,   144,   196,   334,   233,   144,
     196,   349,   139,   194,   139,   144,   144,   144,   144,   139,
      27,   120,    28,   144,   139,   139,   139,   139,   233,   148,
     174,   179,   139,   139,   139,   144,    28,   243,   244,   126,
     157,   249,   257,   145,   233,   273,   274,   275,   275,   275,
     277,   277,   276,   279,   280,   280,   281,   281,    77,   105,
     194,   363,   365,   366,   367,   363,   361,   366,   361,   243,
     293,   296,   296,   243,   315,    69,   236,   238,   239,   236,
     236,   233,     4,   209,   209,   209,   384,    28,   384,   212,
     106,   194,   383,   392,   244,   393,   244,   244,   106,   383,
     139,   326,   363,    14,   252,   253,   161,   194,   334,   335,
      91,   154,    27,   346,   137,   192,   106,   244,   244,   395,
      20,   267,   269,   244,   244,   244,   258,   258,   143,   244,
     100,   133,   136,   158,   364,   136,   139,   141,   321,   144,
      28,   144,   237,   144,    27,    86,   384,   355,   144,   355,
     136,   144,   106,   139,   321,   100,   244,   196,   332,   334,
      24,   106,   107,   140,   180,   183,   193,   241,   330,   333,
     341,   342,   343,   350,   244,    95,   355,   143,    69,   270,
      56,   267,   142,    11,    60,   259,   260,   244,   244,   240,
     362,   241,   238,    10,    86,   241,    86,   241,   244,   139,
     139,   144,   326,   244,    74,    79,   346,   351,   243,   117,
     333,   343,    28,   139,   244,   321,   363,    69,   268,   244,
      28,    75,    76,   261,    28,   363,   139,    28,   244,   332,
      23,   139,   194,    69,    10,   143,   321,   143,   258,    26,
     262,    69,    69,     9,   138,   336,   332,   255,   244,   244,
       4,   265,   251,   107,   140,   177,   180,   185,   186,   193,
     241,   337,   338,   339,   340,   337,    91,     9,   337,   340,
     138
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  However,
   YYFAIL appears to be in use.  Nevertheless, it is formally deprecated
   in Bison 2.4.2's NEWS entry, where a plan to phase it out is
   discussed.  */

#define YYFAIL		goto yyerrlab
#if defined YYFAIL
  /* This is here to suppress warnings from the GCC cpp's
     -Wunused-macros.  Normally we don't worry about that warning, but
     some users do, and we want to make it easy for users to remove
     YYFAIL uses, which will produce warnings from Bison 2.5.  */
#endif

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value, Location); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
#endif
{
  if (!yyvaluep)
    return;
  YYUSE (yylocationp);
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");
  yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, YYLTYPE *yylsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yylsp, yyrule)
    YYSTYPE *yyvsp;
    YYLTYPE *yylsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       , &(yylsp[(yyi + 1) - (yynrhs)])		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, yylsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yydestruct (yymsg, yytype, yyvaluep, yylocationp)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  YYUSE (yyvaluep);
  YYUSE (yylocationp);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}

/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Location data for the lookahead symbol.  */
YYLTYPE yylloc;

/* Number of syntax errors so far.  */
int yynerrs;



/*-------------------------.
| yyparse or yypush_parse.  |
`-------------------------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{


    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.
       `yyls': related to locations.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    /* The location stack.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls;
    YYLTYPE *yylsp;

    /* The locations where the error started and ended.  */
    YYLTYPE yyerror_range[3];

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yyls = yylsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;
  yylsp = yyls;

#if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  /* Initialize the default location before parsing starts.  */
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 1;
#endif

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;
	YYLTYPE *yyls1 = yyls;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);

	yyls = yyls1;
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
	YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;
  *++yylsp = yylloc;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location.  */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

/* Line 1464 of yacc.c  */
#line 768 "parser.y"
    { /* assign parse tree root
                               * version declaration is in global variable */
                              root = (yyval.pnode) = (yyvsp[(2) - (2)].pnode);
                            }
    break;

  case 3:

/* Line 1464 of yacc.c  */
#line 773 "parser.y"
    { /* assign parse tree root
                               * version declaration is in global variable */
                              root = (yyval.pnode) = (yyvsp[(2) - (2)].pnode);
                            }
    break;

  case 4:

/* Line 1464 of yacc.c  */
#line 781 "parser.y"
    { PFquery->version = "1.0";
                              PFquery->encoding = "UTF-8"; }
    break;

  case 5:

/* Line 1464 of yacc.c  */
#line 785 "parser.y"
    { PFquery->version = (yyvsp[(2) - (4)].str); PFquery->encoding = (yyvsp[(3) - (4)].str); 
                              if (strcmp (PFquery->version, "1.0")) {
                                  PFinfo_loc (OOPS_PARSE, (yyloc),
                                      "only XQuery version '1.0' is supported");
                                  YYERROR;
                              }
                              if (strcmp (PFquery->encoding, "UTF-8")
                                  && strcmp (PFquery->encoding, "utf-8")) {
                                  PFinfo_loc (OOPS_PARSE, (yyloc),
                                      "only XQueries in UTF-8 encoding are "
                                      "supported, not in '%s' encoding",
                                      PFquery->encoding);
                                  YYERROR;
                              }
                            }
    break;

  case 6:

/* Line 1464 of yacc.c  */
#line 803 "parser.y"
    { (yyval.str) = "UTF-8"; }
    break;

  case 7:

/* Line 1464 of yacc.c  */
#line 805 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 8:

/* Line 1464 of yacc.c  */
#line 810 "parser.y"
    {
                              if (module_only)
                                  PFoops (OOPS_MODULEIMPORT,
                                          "\"import module\" references a "
                                          "query, not a module");
                              (yyval.pnode) = wire2 (p_main_mod, (yyloc), (yyvsp[(1) - (2)].pnode), (yyvsp[(2) - (2)].pnode)); }
    break;

  case 9:

/* Line 1464 of yacc.c  */
#line 820 "parser.y"
    { (yyval.pnode) = wire2 (p_lib_mod, (yyloc), (yyvsp[(1) - (2)].pnode), (yyvsp[(2) - (2)].pnode));
                              if (current_uri)
                                  (yyval.pnode)->sem.str = PFstrdup (current_uri);
                            }
    break;

  case 10:

/* Line 1464 of yacc.c  */
#line 829 "parser.y"
    {
                              if (req_module_ns && strcmp (req_module_ns, (yyvsp[(4) - (5)].str)))
                                  PFoops (OOPS_MODULEIMPORT,
                                          "module namespace does not match "
                                          "import statement (`%s' vs. `%s')",
                                          (yyvsp[(4) - (5)].str), req_module_ns);

                              ((yyval.pnode) = wire1 (p_mod_ns,
                                           (yyloc),
                                           (c = leaf (p_lit_str, (yylsp[(4) - (5)])),
                                            c->sem.str = (yyvsp[(4) - (5)].str),
                                            c)))->sem.str = (yyvsp[(2) - (5)].str);
                            }
    break;

  case 11:

/* Line 1464 of yacc.c  */
#line 846 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (2)].phole).root;
                              (yyvsp[(1) - (2)].phole).hole->child[1] = (yyvsp[(2) - (2)].phole).root; }
    break;

  case 12:

/* Line 1464 of yacc.c  */
#line 851 "parser.y"
    { (yyval.phole).root
                                  = (yyval.phole).hole
                                  = wire2 (p_decl_imps, (yyloc), nil ((yyloc)), nil ((yyloc)));
                            }
    break;

  case 13:

/* Line 1464 of yacc.c  */
#line 857 "parser.y"
    { (yyval.phole).root = wire2 (p_decl_imps, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].phole).root);
                              (yyval.phole).hole = (yyvsp[(3) - (3)].phole).hole; }
    break;

  case 14:

/* Line 1464 of yacc.c  */
#line 860 "parser.y"
    { (yyval.phole).root = wire2 (p_decl_imps, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].phole).root);
                              (yyval.phole).hole = (yyvsp[(3) - (3)].phole).hole; }
    break;

  case 15:

/* Line 1464 of yacc.c  */
#line 863 "parser.y"
    { (yyval.phole).root = wire2 (p_decl_imps, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].phole).root);
                              (yyval.phole).hole = (yyvsp[(3) - (3)].phole).hole; }
    break;

  case 16:

/* Line 1464 of yacc.c  */
#line 866 "parser.y"
    { (yyval.phole).root
                                  = wire2 (p_decl_imps, (yyloc),
                                           (yyvsp[(1) - (3)].phole).root,
                                           (yyvsp[(1) - (3)].phole).hole
                                             ? wire2 (p_decl_imps,
                                                      loc_rng((yyvsp[(1) - (3)].phole).hole->loc, (yylsp[(3) - (3)])),
                                                      (yyvsp[(1) - (3)].phole).hole,
                                                      (yyvsp[(3) - (3)].phole).root)
                                             : (yyvsp[(3) - (3)].phole).root);
                              (yyval.phole).hole = (yyvsp[(3) - (3)].phole).hole;
                            }
    break;

  case 17:

/* Line 1464 of yacc.c  */
#line 880 "parser.y"
    { (yyval.phole).root
                                  = (yyval.phole).hole
                                  = wire2 (p_decl_imps, (yyloc), nil ((yyloc)), nil ((yyloc)));
                            }
    break;

  case 18:

/* Line 1464 of yacc.c  */
#line 885 "parser.y"
    { (yyval.phole).root = wire2 (p_decl_imps, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].phole).root);
                              (yyval.phole).hole = (yyvsp[(3) - (3)].phole).hole; }
    break;

  case 19:

/* Line 1464 of yacc.c  */
#line 888 "parser.y"
    { (yyval.phole).root = wire2 (p_decl_imps, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].phole).root);
                              (yyval.phole).hole = (yyvsp[(3) - (3)].phole).hole; }
    break;

  case 20:

/* Line 1464 of yacc.c  */
#line 891 "parser.y"
    { (yyval.phole).root = wire2 (p_decl_imps, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].phole).root);
                              (yyval.phole).hole = (yyvsp[(3) - (3)].phole).hole; }
    break;

  case 21:

/* Line 1464 of yacc.c  */
#line 896 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 22:

/* Line 1464 of yacc.c  */
#line 897 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 23:

/* Line 1464 of yacc.c  */
#line 898 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 24:

/* Line 1464 of yacc.c  */
#line 899 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 25:

/* Line 1464 of yacc.c  */
#line 900 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 26:

/* Line 1464 of yacc.c  */
#line 901 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 27:

/* Line 1464 of yacc.c  */
#line 902 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 28:

/* Line 1464 of yacc.c  */
#line 903 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 29:

/* Line 1464 of yacc.c  */
#line 907 "parser.y"
    { (yyval.phole) = (yyvsp[(1) - (1)].phole); }
    break;

  case 30:

/* Line 1464 of yacc.c  */
#line 908 "parser.y"
    { (yyval.phole) = (yyvsp[(1) - (1)].phole); }
    break;

  case 32:

/* Line 1464 of yacc.c  */
#line 917 "parser.y"
    { ((yyval.pnode) = wire1 (p_ns_decl, 
                                           (yyloc),
                                           (c = leaf (p_lit_str, (yylsp[(4) - (4)])),
                                            c->sem.str = (yyvsp[(4) - (4)].str),
                                            c)))->sem.str = (yyvsp[(2) - (4)].str);
                            }
    break;

  case 33:

/* Line 1464 of yacc.c  */
#line 927 "parser.y"
    { ((yyval.pnode) = leaf (p_boundspc_decl, (yyloc)))->sem.tru = true;
                              PFquery->pres_boundary_space = true;
                            }
    break;

  case 34:

/* Line 1464 of yacc.c  */
#line 931 "parser.y"
    { ((yyval.pnode) = leaf (p_boundspc_decl,(yyloc)))->sem.tru = false;
                              PFquery->pres_boundary_space = false;
                            }
    break;

  case 35:

/* Line 1464 of yacc.c  */
#line 938 "parser.y"
    { (yyval.pnode) = wire1 (p_ens_decl,
                                          (yyloc),
                                          (c = leaf (p_lit_str, (yylsp[(3) - (3)])),
                                           c->sem.str = (yyvsp[(3) - (3)].str),
                                           c));
                            }
    break;

  case 36:

/* Line 1464 of yacc.c  */
#line 945 "parser.y"
    { (yyval.pnode) = wire1 (p_fns_decl,
                                          (yyloc),
                                          (c = leaf (p_lit_str, (yylsp[(3) - (3)])),
                                           c->sem.str = (yyvsp[(3) - (3)].str),
                                           c));
                            }
    break;

  case 37:

/* Line 1464 of yacc.c  */
#line 955 "parser.y"
    {
                              (yyval.pnode) = wire1 (p_option,
                                          (yyloc),
                                          (c = leaf (p_lit_str, (yylsp[(3) - (3)])),
                                           c->sem.str = (yyvsp[(3) - (3)].str),
                                           c));
                              (yyval.pnode)->sem.qname_raw = (yyvsp[(2) - (3)].qname_raw);
                            }
    break;

  case 38:

/* Line 1464 of yacc.c  */
#line 967 "parser.y"
    { ((yyval.pnode) = leaf (p_ordering_mode,
                                          (yyloc)))->sem.tru = true;
                            }
    break;

  case 39:

/* Line 1464 of yacc.c  */
#line 971 "parser.y"
    { ((yyval.pnode) = leaf (p_ordering_mode,
                                          (yyloc)))->sem.tru = false;
                            }
    break;

  case 40:

/* Line 1464 of yacc.c  */
#line 978 "parser.y"
    { ((yyval.pnode) = leaf (p_def_order,
                                          (yyloc)))->sem.mode.empty = p_greatest;
                            }
    break;

  case 41:

/* Line 1464 of yacc.c  */
#line 982 "parser.y"
    { ((yyval.pnode) = leaf (p_def_order,
                                          (yyloc)))->sem.mode.empty = p_least;
                            }
    break;

  case 42:

/* Line 1464 of yacc.c  */
#line 990 "parser.y"
    { (yyval.pnode) = leaf (p_copy_ns, (yyloc));
                              (yyval.pnode)->sem.copy_ns.preserve = (yyvsp[(2) - (4)].bit);
                              (yyval.pnode)->sem.copy_ns.inherit  = (yyvsp[(4) - (4)].bit);
                            }
    break;

  case 43:

/* Line 1464 of yacc.c  */
#line 997 "parser.y"
    { (yyval.bit) = true; }
    break;

  case 44:

/* Line 1464 of yacc.c  */
#line 998 "parser.y"
    { (yyval.bit) = false; }
    break;

  case 45:

/* Line 1464 of yacc.c  */
#line 1002 "parser.y"
    { (yyval.bit) = true; }
    break;

  case 46:

/* Line 1464 of yacc.c  */
#line 1003 "parser.y"
    { (yyval.bit) = false; }
    break;

  case 47:

/* Line 1464 of yacc.c  */
#line 1008 "parser.y"
    { (yyval.pnode) = wire1 (p_coll_decl,
                                          (yyloc),
                                          (c = leaf (p_lit_str, (yylsp[(2) - (2)])),
                                           c->sem.str = (yyvsp[(2) - (2)].str),
                                           c));
                            }
    break;

  case 48:

/* Line 1464 of yacc.c  */
#line 1018 "parser.y"
    { (yyval.pnode) = wire1 (p_base_uri,
                                          (yyloc),
                                          (c = leaf (p_lit_str, (yylsp[(2) - (2)])),
                                           c->sem.str = (yyvsp[(2) - (2)].str),
                                           c));
                            }
    break;

  case 49:

/* Line 1464 of yacc.c  */
#line 1028 "parser.y"
    { /* XQuery allows to merge a schema import
                               * and an associated namespace declaration:
                               *
                               * import schema namespace ns = "ns" [at "url"]
                               *
                               * which is equivalent to
                               *
                               * import schema "ns" [at "url"]
                               * namespace ns = "ns" 
                               *
                               * We thus return the schema import in $$[ROOT]
                               * and the namespace declaration in $$[HOLE]
                               * ($2[ROOT] == 0 if no namespace decl given)
                               */
                              (yyval.phole).root = wire2 (p_schm_imp, (yyloc), (yyvsp[(2) - (3)].phole).hole, (yyvsp[(3) - (3)].pnode));
                              (yyval.phole).hole = (yyvsp[(2) - (3)].phole).root;
                            }
    break;

  case 50:

/* Line 1464 of yacc.c  */
#line 1048 "parser.y"
    { (yyval.phole).root = NULL;
                              ((yyval.phole).hole = leaf (p_lit_str, (yyloc)))->sem.str = (yyvsp[(1) - (1)].str);
                            }
    break;

  case 51:

/* Line 1464 of yacc.c  */
#line 1052 "parser.y"
    { ((yyval.phole).root = wire1 (p_ns_decl, (yyloc),
                                                (c = leaf (p_lit_str, (yylsp[(4) - (4)])),
                                                 c->sem.str = (yyvsp[(4) - (4)].str),
                                                 c)))->sem.str = (yyvsp[(2) - (4)].str);
                              ((yyval.phole).hole = leaf (p_lit_str, (yylsp[(4) - (4)])))->sem.str = (yyvsp[(4) - (4)].str);
                            }
    break;

  case 52:

/* Line 1464 of yacc.c  */
#line 1059 "parser.y"
    { (yyval.phole).root = wire1 (p_ens_decl, (yyloc),
                                               (c = leaf (p_lit_str, (yylsp[(3) - (3)])),
                                                c->sem.str = (yyvsp[(3) - (3)].str),
                                                c));
                              ((yyval.phole).hole = leaf (p_lit_str, (yylsp[(3) - (3)])))->sem.str = (yyvsp[(3) - (3)].str);
                            }
    break;

  case 53:

/* Line 1464 of yacc.c  */
#line 1068 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 54:

/* Line 1464 of yacc.c  */
#line 1070 "parser.y"
    { (yyval.pnode) = wire2 (p_schm_ats, (yyloc),
                                          (c = leaf (p_lit_str, (yylsp[(1) - (2)])),
                                           c->sem.str = (yyvsp[(1) - (2)].str),
                                           c),
                                          (yyvsp[(2) - (2)].phole).root ? (yyvsp[(2) - (2)].phole).root : nil ((yyloc)));
                            }
    break;

  case 55:

/* Line 1464 of yacc.c  */
#line 1079 "parser.y"
    { (yyval.phole).root = (yyval.phole).hole = NULL; }
    break;

  case 56:

/* Line 1464 of yacc.c  */
#line 1081 "parser.y"
    {
                              if ((yyvsp[(1) - (3)].phole).root) {
                                  (yyval.phole).root = (yyvsp[(1) - (3)].phole).root;
                                  FIXUP (1, (yyvsp[(1) - (3)].phole),
                                         wire2 (p_schm_ats, (yyloc),
                                                (c = leaf (p_lit_str, (yylsp[(3) - (3)])),
                                                 c->sem.str = (yyvsp[(3) - (3)].str),
                                                 c),
                                                nil ((yylsp[(3) - (3)]))));
                              }
                              else {
                                  (yyval.phole).root = (yyval.phole).hole
                                          = wire2 (p_schm_ats, (yyloc),
                                                   (c = leaf (p_lit_str, (yylsp[(3) - (3)])),
                                                    c->sem.str = (yyvsp[(3) - (3)].str),
                                                    c),
                                                   nil ((yyloc)));
                              }
                            }
    break;

  case 57:

/* Line 1464 of yacc.c  */
#line 1104 "parser.y"
    { /* XQuery allows to merge a module import
                               * and an associated namespace declaration:
                               *
                               * import module namespace ns = "ns" [at "url"]
                               *
                               * which is equivalent to
                               *
                               * import module "ns" [at "url"]
                               * namespace ns = "ns" 
                               *
                               * We thus return the module import in $$.root
                               * and the namespace declaration in $$.hole
                               * ($2.root == NULL if no namespace decl given)
                               */

                              /* FIXME:
                               *   Does this code make sense?  We add the
                               *   module to the work list once for each
                               *   "at" URI given in the query.  This means
                               *   we load the module from each of the URIs
                               *   in turn?  Shouldn't we rather try each
                               *   of the URIs until we can successfully
                               *   load *one* of them?
                               */
                              for (c = (yyvsp[(3) - (3)].pnode);
                                   c->kind == p_schm_ats;
                                   c = c->child[1])
                                  add_to_module_wl (
                                      (yyvsp[(2) - (3)].phole).root
                                          ? (yyvsp[(2) - (3)].phole).root->sem.str : "", /* prefix */
                                      (yyvsp[(2) - (3)].phole).hole->sem.str,            /* namespc */
                                      c->child[0]->sem.str);       /* at URI */

                              (yyval.phole).root = wire2 (p_mod_imp, (yyloc), (yyvsp[(2) - (3)].phole).hole, (yyvsp[(3) - (3)].pnode));
                              (yyval.phole).hole = (yyvsp[(2) - (3)].phole).root;
                            }
    break;

  case 58:

/* Line 1464 of yacc.c  */
#line 1142 "parser.y"
    { (yyval.phole) = (yyvsp[(1) - (1)].phole); }
    break;

  case 59:

/* Line 1464 of yacc.c  */
#line 1143 "parser.y"
    { (yyval.phole) = (yyvsp[(1) - (1)].phole); }
    break;

  case 60:

/* Line 1464 of yacc.c  */
#line 1147 "parser.y"
    { (yyval.phole).root = NULL;
                              ((yyval.phole).hole = leaf (p_lit_str, (yyloc)))->sem.str = (yyvsp[(1) - (1)].str);
                            }
    break;

  case 61:

/* Line 1464 of yacc.c  */
#line 1153 "parser.y"
    { ((yyval.phole).root = wire1 (p_ns_decl, (yyloc),
                                                (c = leaf (p_lit_str, (yylsp[(4) - (4)])),
                                                 c->sem.str = (yyvsp[(4) - (4)].str),
                                                 c)))->sem.str = (yyvsp[(2) - (4)].str);
                              ((yyval.phole).hole = leaf (p_lit_str, (yylsp[(4) - (4)])))->sem.str = (yyvsp[(4) - (4)].str);
                            }
    break;

  case 62:

/* Line 1464 of yacc.c  */
#line 1166 "parser.y"
    { (yyval.pnode) = wire2 (p_var_decl, (yyloc),
                                     wire2 (p_var_type, loc_rng ((yylsp[(2) - (5)]), (yylsp[(3) - (5)])),
                                            (yyvsp[(2) - (5)].pnode), (yyvsp[(3) - (5)].pnode)),
                                     (yyvsp[(5) - (5)].pnode));
                            }
    break;

  case 63:

/* Line 1464 of yacc.c  */
#line 1173 "parser.y"
    { (yyval.pnode) = wire2 (p_var_decl, (yyloc),
                                     wire2 (p_var_type, loc_rng ((yylsp[(2) - (4)]), (yylsp[(3) - (4)])),
                                            (yyvsp[(2) - (4)].pnode), (yyvsp[(3) - (4)].pnode)),
                                     leaf (p_external, (yylsp[(4) - (4)])));
                            }
    break;

  case 64:

/* Line 1464 of yacc.c  */
#line 1180 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 65:

/* Line 1464 of yacc.c  */
#line 1181 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 66:

/* Line 1464 of yacc.c  */
#line 1186 "parser.y"
    { ((yyval.pnode) = leaf (p_constr_decl, (yyloc)))->sem.tru = true; }
    break;

  case 67:

/* Line 1464 of yacc.c  */
#line 1188 "parser.y"
    { ((yyval.pnode) = leaf (p_constr_decl, (yyloc)))->sem.tru = false;}
    break;

  case 68:

/* Line 1464 of yacc.c  */
#line 1194 "parser.y"
    { c = wire2 (p_fun_decl, (yyloc),
                                         wire2 (p_fun_sig, loc_rng ((yylsp[(2) - (5)]), (yylsp[(4) - (5)])),
                                                (yyvsp[(3) - (5)].pnode), (yyvsp[(4) - (5)].pnode)),
                                         (yyvsp[(5) - (5)].pnode));
                              c->sem.qname_raw = (yyvsp[(2) - (5)].qname_raw);
                              (yyval.pnode) = c;

                            }
    break;

  case 69:

/* Line 1464 of yacc.c  */
#line 1204 "parser.y"
    { ((yyval.pnode) = wire2 (p_fun_decl, (yyloc),
                                           wire2 (p_fun_sig, loc_rng ((yylsp[(2) - (5)]), (yylsp[(4) - (5)])),
                                                  (yyvsp[(3) - (5)].pnode), (yyvsp[(4) - (5)].pnode)),
                                           leaf (p_external, (yylsp[(5) - (5)]))))
                                   ->sem.qname_raw = (yyvsp[(2) - (5)].qname_raw);
                            }
    break;

  case 70:

/* Line 1464 of yacc.c  */
#line 1212 "parser.y"
    { c = wire2 (p_fun_decl, (yyloc),
                                         wire2 (p_fun_sig, loc_rng ((yylsp[(2) - (5)]), (yylsp[(4) - (5)])),
                                                (yyvsp[(3) - (5)].pnode), 
                                                (c1 = wire1 (
                                                       p_seq_ty, (yyloc),
                                                       wire1 (p_stmt_ty, (yyloc),
                                                              nil ((yylsp[(4) - (5)])))),
                                                 c1->sem.oci = p_zero_or_more,
                                                 c1)),
                                         (yyvsp[(5) - (5)].pnode));
                              c->sem.qname_raw = (yyvsp[(2) - (5)].qname_raw);
                              (yyval.pnode) = c;

                            }
    break;

  case 71:

/* Line 1464 of yacc.c  */
#line 1228 "parser.y"
    { ((yyval.pnode) = wire2 (p_fun_decl, (yyloc),
                                           wire2 (p_fun_sig, loc_rng ((yylsp[(2) - (5)]), (yylsp[(4) - (5)])),
                                                  (yyvsp[(3) - (5)].pnode),
                                                  (c = wire1 (
                                                         p_seq_ty, (yyloc),
                                                         wire1 (p_stmt_ty, (yyloc),
                                                                nil ((yylsp[(4) - (5)])))),
                                                   c->sem.oci = p_zero_or_more,
                                                   c)),
                                           leaf (p_external, (yylsp[(5) - (5)]))))
                                   ->sem.qname_raw = (yyvsp[(2) - (5)].qname_raw);

                            }
    break;

  case 72:

/* Line 1464 of yacc.c  */
#line 1243 "parser.y"
    { c = wire2 (p_fun_decl, (yyloc),
                                         wire2 (p_fun_sig, loc_rng ((yylsp[(2) - (5)]), (yylsp[(4) - (5)])),
                                                (yyvsp[(3) - (5)].pnode), 
                                                (c1 = wire1 (
                                                       p_seq_ty, (yyloc),
                                                       wire1 (p_docmgmt_ty, (yyloc),
                                                              nil ((yylsp[(4) - (5)])))),
                                                 c1->sem.oci = p_zero_or_more,
                                                 c1)),
                                         (yyvsp[(5) - (5)].pnode));
                              c->sem.qname_raw = (yyvsp[(2) - (5)].qname_raw);
                              (yyval.pnode) = c;

                            }
    break;

  case 73:

/* Line 1464 of yacc.c  */
#line 1259 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 74:

/* Line 1464 of yacc.c  */
#line 1260 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 75:

/* Line 1464 of yacc.c  */
#line 1264 "parser.y"
    { /* W3C XQuery Section 4.15:
                               * ``If the result type is omitted from a
                               * function declaration, its default result
                               * type is item*.''
                               */
                              ((yyval.pnode) = wire1 (p_seq_ty, (yyloc),
                                           wire1 (p_item_ty, (yyloc), nil ((yyloc)))))
                                ->sem.oci = p_zero_or_more;
                            }
    break;

  case 76:

/* Line 1464 of yacc.c  */
#line 1273 "parser.y"
    { (yyval.pnode) = (yyvsp[(3) - (3)].pnode); }
    break;

  case 77:

/* Line 1464 of yacc.c  */
#line 1278 "parser.y"
    { (yyval.pnode) = wire2 (p_params, (yyloc), (yyvsp[(1) - (1)].pnode), nil ((yyloc))); }
    break;

  case 78:

/* Line 1464 of yacc.c  */
#line 1280 "parser.y"
    { (yyval.pnode) = wire2 (p_params, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 79:

/* Line 1464 of yacc.c  */
#line 1285 "parser.y"
    { (yyval.pnode) = wire2 (p_param, (yyloc), (yyvsp[(3) - (3)].pnode), (yyvsp[(2) - (3)].pnode)); }
    break;

  case 80:

/* Line 1464 of yacc.c  */
#line 1289 "parser.y"
    { /* W3C XQuery Section 4.15:
                               * ``If a function parameter is declared using
                               * a name but no type, its default type is
                               * item*.''
                               */
                              ((yyval.pnode) = wire1 (p_seq_ty, (yyloc),
                                           wire1 (p_item_ty, (yyloc), nil ((yyloc)))))
                                ->sem.oci = p_zero_or_more;
                            }
    break;

  case 81:

/* Line 1464 of yacc.c  */
#line 1298 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 82:

/* Line 1464 of yacc.c  */
#line 1303 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (3)].pnode); }
    break;

  case 83:

/* Line 1464 of yacc.c  */
#line 1307 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 84:

/* Line 1464 of yacc.c  */
#line 1312 "parser.y"
    { (yyval.pnode) = wire2 (p_exprseq, (yyloc),
                                          (yyvsp[(1) - (1)].pnode),
                                          leaf (p_empty_seq, (yylsp[(1) - (1)]))); }
    break;

  case 85:

/* Line 1464 of yacc.c  */
#line 1316 "parser.y"
    { (yyval.pnode) = wire2 (p_exprseq, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 86:

/* Line 1464 of yacc.c  */
#line 1320 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 87:

/* Line 1464 of yacc.c  */
#line 1321 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 88:

/* Line 1464 of yacc.c  */
#line 1322 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 89:

/* Line 1464 of yacc.c  */
#line 1323 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 90:

/* Line 1464 of yacc.c  */
#line 1324 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 91:

/* Line 1464 of yacc.c  */
#line 1325 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 92:

/* Line 1464 of yacc.c  */
#line 1326 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 93:

/* Line 1464 of yacc.c  */
#line 1327 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 94:

/* Line 1464 of yacc.c  */
#line 1328 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 95:

/* Line 1464 of yacc.c  */
#line 1329 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 96:

/* Line 1464 of yacc.c  */
#line 1330 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 97:

/* Line 1464 of yacc.c  */
#line 1336 "parser.y"
    { (yyval.pnode) = wire2 (p_flwr, (yyloc), (yyvsp[(1) - (5)].phole).root,
                                     wire2 (p_where, loc_rng ((yylsp[(2) - (5)]), (yylsp[(5) - (5)])), (yyvsp[(2) - (5)].pnode),
                                       wire2 (p_ord_ret, loc_rng ((yylsp[(3) - (5)]), (yylsp[(5) - (5)])), (yyvsp[(3) - (5)].pnode),
                                         (yyvsp[(5) - (5)].pnode))));
                            }
    break;

  case 98:

/* Line 1464 of yacc.c  */
#line 1344 "parser.y"
    { (yyval.phole) = (yyvsp[(1) - (1)].phole); }
    break;

  case 99:

/* Line 1464 of yacc.c  */
#line 1347 "parser.y"
    { FIXUP (1, (yyvsp[(1) - (2)].phole), (yyvsp[(2) - (2)].phole).root);
                              (yyval.phole).hole = (yyvsp[(2) - (2)].phole).hole; (yyval.phole).root = (yyvsp[(1) - (2)].phole).root; }
    break;

  case 100:

/* Line 1464 of yacc.c  */
#line 1351 "parser.y"
    { (yyval.phole) = (yyvsp[(1) - (1)].phole); }
    break;

  case 101:

/* Line 1464 of yacc.c  */
#line 1352 "parser.y"
    { (yyval.phole) = (yyvsp[(1) - (1)].phole); }
    break;

  case 102:

/* Line 1464 of yacc.c  */
#line 1355 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 103:

/* Line 1464 of yacc.c  */
#line 1356 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 104:

/* Line 1464 of yacc.c  */
#line 1359 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 105:

/* Line 1464 of yacc.c  */
#line 1360 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 106:

/* Line 1464 of yacc.c  */
#line 1364 "parser.y"
    { (yyval.phole) = (yyvsp[(2) - (2)].phole); }
    break;

  case 107:

/* Line 1464 of yacc.c  */
#line 1369 "parser.y"
    { (yyval.phole).root = (yyval.phole).hole = 
                                wire2 (p_binds, (yyloc),
                                  wire2 (p_bind, (yyloc),
                                    wire2 (p_vars, loc_rng ((yylsp[(1) - (5)]), (yylsp[(3) - (5)])),
                                      wire2 (p_var_type, loc_rng ((yylsp[(1) - (5)]), (yylsp[(2) - (5)])),
                                             (yyvsp[(1) - (5)].pnode),
                                             (yyvsp[(2) - (5)].pnode)),
                                      (yyvsp[(3) - (5)].pnode)),
                                    (yyvsp[(5) - (5)].pnode)),
                                  nil ((yyloc)));
                            }
    break;

  case 108:

/* Line 1464 of yacc.c  */
#line 1382 "parser.y"
    { (yyval.phole).hole = (yyvsp[(8) - (8)].phole).hole;
                              (yyval.phole).root = 
                                wire2 (p_binds, (yyloc),
                                  wire2 (p_bind, (yyloc),
                                    wire2 (p_vars, loc_rng ((yylsp[(1) - (8)]), (yylsp[(3) - (8)])),
                                      wire2 (p_var_type, loc_rng ((yylsp[(1) - (8)]), (yylsp[(2) - (8)])),
                                             (yyvsp[(1) - (8)].pnode),
                                             (yyvsp[(2) - (8)].pnode)),
                                      (yyvsp[(3) - (8)].pnode)),
                                    (yyvsp[(5) - (8)].pnode)),
                                  (yyvsp[(8) - (8)].phole).root);
                            }
    break;

  case 109:

/* Line 1464 of yacc.c  */
#line 1396 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 110:

/* Line 1464 of yacc.c  */
#line 1397 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 111:

/* Line 1464 of yacc.c  */
#line 1401 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (2)].pnode); }
    break;

  case 112:

/* Line 1464 of yacc.c  */
#line 1405 "parser.y"
    { (yyval.phole) = (yyvsp[(2) - (2)].phole); }
    break;

  case 113:

/* Line 1464 of yacc.c  */
#line 1409 "parser.y"
    { (yyval.phole).root = (yyval.phole).hole = 
                                wire2 (p_binds, (yyloc),
                                  wire2 (p_let, (yyloc),
                                    wire2 (p_var_type, loc_rng ((yylsp[(1) - (4)]), (yylsp[(2) - (4)])),
                                      (yyvsp[(1) - (4)].pnode), (yyvsp[(2) - (4)].pnode)),
                                    (yyvsp[(4) - (4)].pnode)),
                                  nil ((yyloc)));
                            }
    break;

  case 114:

/* Line 1464 of yacc.c  */
#line 1419 "parser.y"
    { (yyval.phole).hole = (yyvsp[(7) - (7)].phole).hole;
                              (yyval.phole).root = 
                                wire2 (p_binds, (yyloc),
                                  wire2 (p_let, (yyloc),
                                    wire2 (p_var_type, loc_rng ((yylsp[(1) - (7)]), (yylsp[(2) - (7)])),
                                      (yyvsp[(1) - (7)].pnode), (yyvsp[(2) - (7)].pnode)),
                                    (yyvsp[(4) - (7)].pnode)),
                                  (yyvsp[(7) - (7)].phole).root);
                            }
    break;

  case 115:

/* Line 1464 of yacc.c  */
#line 1431 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (2)].pnode); }
    break;

  case 116:

/* Line 1464 of yacc.c  */
#line 1436 "parser.y"
    {((yyval.pnode) = wire1 (p_orderby, (yyloc), (yyvsp[(2) - (2)].pnode)))->sem.tru = false;}
    break;

  case 117:

/* Line 1464 of yacc.c  */
#line 1438 "parser.y"
    {((yyval.pnode) = wire1 (p_orderby, (yyloc), (yyvsp[(2) - (2)].pnode)))->sem.tru = true;}
    break;

  case 118:

/* Line 1464 of yacc.c  */
#line 1443 "parser.y"
    { ((yyval.pnode) = wire2 (p_orderspecs, (yyloc),
                                           (yyvsp[(1) - (2)].pnode),
                                           nil ((yyloc))))->sem.mode = (yyvsp[(2) - (2)].mode);
                            }
    break;

  case 119:

/* Line 1464 of yacc.c  */
#line 1448 "parser.y"
    { ((yyval.pnode) = wire2 (p_orderspecs, (yyloc),
                                           (yyvsp[(1) - (4)].pnode),
                                           (yyvsp[(4) - (4)].pnode)))->sem.mode = (yyvsp[(2) - (4)].mode);
                            }
    break;

  case 120:

/* Line 1464 of yacc.c  */
#line 1457 "parser.y"
    { (yyval.mode).dir = (yyvsp[(1) - (3)].num) == 0 ? p_asc : p_desc;
                              (yyval.mode).empty = (yyvsp[(2) - (3)].num) == 0 ? p_greatest : p_least;
                              (yyval.mode).coll = (yyvsp[(3) - (3)].str); }
    break;

  case 121:

/* Line 1464 of yacc.c  */
#line 1462 "parser.y"
    { (yyval.num) = p_asc; }
    break;

  case 122:

/* Line 1464 of yacc.c  */
#line 1463 "parser.y"
    { (yyval.num) = p_asc; }
    break;

  case 123:

/* Line 1464 of yacc.c  */
#line 1464 "parser.y"
    { (yyval.num) = p_desc; }
    break;

  case 124:

/* Line 1464 of yacc.c  */
#line 1467 "parser.y"
    { (yyval.num) = p_least; }
    break;

  case 125:

/* Line 1464 of yacc.c  */
#line 1468 "parser.y"
    { (yyval.num) = p_greatest; }
    break;

  case 126:

/* Line 1464 of yacc.c  */
#line 1469 "parser.y"
    { (yyval.num) = p_least; }
    break;

  case 127:

/* Line 1464 of yacc.c  */
#line 1472 "parser.y"
    { (yyval.str) = NULL; }
    break;

  case 128:

/* Line 1464 of yacc.c  */
#line 1473 "parser.y"
    { (yyval.str) = (yyvsp[(2) - (2)].str); }
    break;

  case 129:

/* Line 1464 of yacc.c  */
#line 1478 "parser.y"
    { (yyval.pnode) = wire2 ((yyvsp[(1) - (4)].ptype), (yyloc), (yyvsp[(2) - (4)].pnode), (yyvsp[(4) - (4)].pnode)); }
    break;

  case 130:

/* Line 1464 of yacc.c  */
#line 1481 "parser.y"
    { (yyval.ptype) = p_some; }
    break;

  case 131:

/* Line 1464 of yacc.c  */
#line 1482 "parser.y"
    { (yyval.ptype) = p_every; }
    break;

  case 132:

/* Line 1464 of yacc.c  */
#line 1486 "parser.y"
    { (yyval.pnode) = wire2 (p_binds, (yyloc),
                                     wire2 (p_bind, (yyloc),
                                       wire2 (p_vars, (yylsp[(1) - (4)]),
                                         wire2 (p_var_type, (yylsp[(1) - (4)]), (yyvsp[(1) - (4)].pnode), (yyvsp[(2) - (4)].pnode)),
                                         nil ((yylsp[(2) - (4)]))),
                                       (yyvsp[(4) - (4)].pnode)),
                                     nil ((yyloc))); }
    break;

  case 133:

/* Line 1464 of yacc.c  */
#line 1495 "parser.y"
    { (yyval.pnode) = wire2 (p_binds, (yyloc),
                                     wire2 (p_bind, (yyloc),
                                       wire2 (p_vars, (yylsp[(1) - (7)]),
                                         wire2 (p_var_type, (yylsp[(1) - (7)]), (yyvsp[(1) - (7)].pnode), (yyvsp[(2) - (7)].pnode)),
                                         nil ((yylsp[(2) - (7)]))),
                                       (yyvsp[(4) - (7)].pnode)),
                                     (yyvsp[(7) - (7)].pnode)); }
    break;

  case 134:

/* Line 1464 of yacc.c  */
#line 1507 "parser.y"
    { FIXUP (1,
                                     (yyvsp[(4) - (8)].phole),
                                     wire2 (p_cases, loc_rng ((yylsp[(5) - (8)]), (yylsp[(8) - (8)])),
                                       wire2 (p_default, loc_rng ((yylsp[(5) - (8)]), (yylsp[(8) - (8)])),
                                              (yyvsp[(6) - (8)].pnode), (yyvsp[(8) - (8)].pnode)),
                                       nil ((yyloc))));
                              (yyval.pnode) = wire2 (p_typeswitch, (yyloc), (yyvsp[(2) - (8)].pnode), (yyvsp[(4) - (8)].phole).root);
                            }
    break;

  case 135:

/* Line 1464 of yacc.c  */
#line 1518 "parser.y"
    { (yyval.phole).root
                                  = (yyval.phole).hole
                                  = wire2 (p_cases, (yyloc), (yyvsp[(1) - (1)].pnode), nil ((yyloc))); }
    break;

  case 136:

/* Line 1464 of yacc.c  */
#line 1522 "parser.y"
    { (yyval.phole).root = wire2 (p_cases, (yyloc), (yyvsp[(1) - (2)].pnode), (yyvsp[(2) - (2)].phole).root);
                              (yyval.phole).hole = (yyvsp[(2) - (2)].phole).hole; }
    break;

  case 137:

/* Line 1464 of yacc.c  */
#line 1526 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 138:

/* Line 1464 of yacc.c  */
#line 1527 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (2)].pnode); }
    break;

  case 139:

/* Line 1464 of yacc.c  */
#line 1533 "parser.y"
    { (yyval.pnode) = wire2 (p_case, (yyloc),
                                     wire2 (p_var_type, loc_rng ((yylsp[(2) - (5)]), (yylsp[(3) - (5)])),
                                            (yyvsp[(2) - (5)].pnode), (yyvsp[(3) - (5)].pnode)),
                                     (yyvsp[(5) - (5)].pnode));
                            }
    break;

  case 140:

/* Line 1464 of yacc.c  */
#line 1540 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 141:

/* Line 1464 of yacc.c  */
#line 1541 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (3)].pnode); }
    break;

  case 142:

/* Line 1464 of yacc.c  */
#line 1546 "parser.y"
    { (yyval.pnode) = wire2 (p_if, (yyloc),
                                          (yyvsp[(2) - (7)].pnode),
                                          wire2 (p_then_else, loc_rng ((yylsp[(4) - (7)]), (yylsp[(7) - (7)])),
                                                 (yyvsp[(5) - (7)].pnode), (yyvsp[(7) - (7)].pnode)));
                            }
    break;

  case 143:

/* Line 1464 of yacc.c  */
#line 1554 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 144:

/* Line 1464 of yacc.c  */
#line 1556 "parser.y"
    { (yyval.pnode) = wire2 (p_or, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 145:

/* Line 1464 of yacc.c  */
#line 1560 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 146:

/* Line 1464 of yacc.c  */
#line 1562 "parser.y"
    { (yyval.pnode) = wire2 (p_and, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 147:

/* Line 1464 of yacc.c  */
#line 1566 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 148:

/* Line 1464 of yacc.c  */
#line 1568 "parser.y"
    { (yyval.pnode) = wire2 ((yyvsp[(2) - (3)].ptype), (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 149:

/* Line 1464 of yacc.c  */
#line 1570 "parser.y"
    { (yyval.pnode) = wire2 ((yyvsp[(2) - (3)].ptype), (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 150:

/* Line 1464 of yacc.c  */
#line 1572 "parser.y"
    { (yyval.pnode) = wire2 ((yyvsp[(2) - (3)].ptype), (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 151:

/* Line 1464 of yacc.c  */
#line 1576 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 152:

/* Line 1464 of yacc.c  */
#line 1578 "parser.y"
    { (yyval.pnode) = wire2 (p_range, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 153:

/* Line 1464 of yacc.c  */
#line 1582 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 154:

/* Line 1464 of yacc.c  */
#line 1584 "parser.y"
    { (yyval.pnode) = wire2 (p_plus, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 155:

/* Line 1464 of yacc.c  */
#line 1586 "parser.y"
    { (yyval.pnode) = wire2 (p_minus, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 156:

/* Line 1464 of yacc.c  */
#line 1590 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 157:

/* Line 1464 of yacc.c  */
#line 1592 "parser.y"
    { (yyval.pnode) = wire2 ((yyvsp[(2) - (3)].ptype), (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 158:

/* Line 1464 of yacc.c  */
#line 1595 "parser.y"
    { (yyval.ptype) = p_mult; }
    break;

  case 159:

/* Line 1464 of yacc.c  */
#line 1596 "parser.y"
    { (yyval.ptype) = p_div; }
    break;

  case 160:

/* Line 1464 of yacc.c  */
#line 1597 "parser.y"
    { (yyval.ptype) = p_idiv; }
    break;

  case 161:

/* Line 1464 of yacc.c  */
#line 1598 "parser.y"
    { (yyval.ptype) = p_mod; }
    break;

  case 162:

/* Line 1464 of yacc.c  */
#line 1602 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 163:

/* Line 1464 of yacc.c  */
#line 1604 "parser.y"
    { (yyval.pnode) = wire2 (p_union, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 164:

/* Line 1464 of yacc.c  */
#line 1606 "parser.y"
    { (yyval.pnode) = wire2 (p_union, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 165:

/* Line 1464 of yacc.c  */
#line 1610 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 166:

/* Line 1464 of yacc.c  */
#line 1612 "parser.y"
    { (yyval.pnode) = wire2 (p_intersect, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 167:

/* Line 1464 of yacc.c  */
#line 1614 "parser.y"
    { (yyval.pnode) = wire2 (p_except, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 168:

/* Line 1464 of yacc.c  */
#line 1618 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 169:

/* Line 1464 of yacc.c  */
#line 1620 "parser.y"
    { (yyval.pnode) = wire2 (p_instof, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 170:

/* Line 1464 of yacc.c  */
#line 1624 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 171:

/* Line 1464 of yacc.c  */
#line 1626 "parser.y"
    { (yyval.pnode) = wire2 (p_treat, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 172:

/* Line 1464 of yacc.c  */
#line 1630 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 173:

/* Line 1464 of yacc.c  */
#line 1632 "parser.y"
    { (yyval.pnode) = wire2 (p_castable, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 174:

/* Line 1464 of yacc.c  */
#line 1636 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 175:

/* Line 1464 of yacc.c  */
#line 1638 "parser.y"
    { (yyval.pnode) = wire2 (p_cast, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 176:

/* Line 1464 of yacc.c  */
#line 1642 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 177:

/* Line 1464 of yacc.c  */
#line 1643 "parser.y"
    { (yyval.pnode) = wire1 (p_uminus, (yyloc), (yyvsp[(2) - (2)].pnode)); }
    break;

  case 178:

/* Line 1464 of yacc.c  */
#line 1644 "parser.y"
    { (yyval.pnode) = wire1 (p_uplus, (yyloc), (yyvsp[(2) - (2)].pnode)); }
    break;

  case 179:

/* Line 1464 of yacc.c  */
#line 1648 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 180:

/* Line 1464 of yacc.c  */
#line 1649 "parser.y"
    { (yyval.pnode) = flatten_locpath ((yyvsp[(1) - (1)].pnode), NULL); }
    break;

  case 181:

/* Line 1464 of yacc.c  */
#line 1650 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 182:

/* Line 1464 of yacc.c  */
#line 1654 "parser.y"
    { (yyval.ptype) = p_eq; }
    break;

  case 183:

/* Line 1464 of yacc.c  */
#line 1655 "parser.y"
    { (yyval.ptype) = p_ne; }
    break;

  case 184:

/* Line 1464 of yacc.c  */
#line 1656 "parser.y"
    { (yyval.ptype) = p_lt; }
    break;

  case 185:

/* Line 1464 of yacc.c  */
#line 1657 "parser.y"
    { (yyval.ptype) = p_le; }
    break;

  case 186:

/* Line 1464 of yacc.c  */
#line 1658 "parser.y"
    { (yyval.ptype) = p_gt; }
    break;

  case 187:

/* Line 1464 of yacc.c  */
#line 1659 "parser.y"
    { (yyval.ptype) = p_ge; }
    break;

  case 188:

/* Line 1464 of yacc.c  */
#line 1663 "parser.y"
    { (yyval.ptype) = p_val_eq; }
    break;

  case 189:

/* Line 1464 of yacc.c  */
#line 1664 "parser.y"
    { (yyval.ptype) = p_val_ne; }
    break;

  case 190:

/* Line 1464 of yacc.c  */
#line 1665 "parser.y"
    { (yyval.ptype) = p_val_lt; }
    break;

  case 191:

/* Line 1464 of yacc.c  */
#line 1666 "parser.y"
    { (yyval.ptype) = p_val_le; }
    break;

  case 192:

/* Line 1464 of yacc.c  */
#line 1667 "parser.y"
    { (yyval.ptype) = p_val_gt; }
    break;

  case 193:

/* Line 1464 of yacc.c  */
#line 1668 "parser.y"
    { (yyval.ptype) = p_val_ge; }
    break;

  case 194:

/* Line 1464 of yacc.c  */
#line 1672 "parser.y"
    { (yyval.ptype) = p_is; }
    break;

  case 195:

/* Line 1464 of yacc.c  */
#line 1673 "parser.y"
    { (yyval.ptype) = p_ltlt; }
    break;

  case 196:

/* Line 1464 of yacc.c  */
#line 1674 "parser.y"
    { (yyval.ptype) = p_gtgt; }
    break;

  case 197:

/* Line 1464 of yacc.c  */
#line 1679 "parser.y"
    { /* No validation mode means `strict'
                                 (W3C XQuery Sect. 3.13). */
                              ((yyval.pnode) = wire1 (p_validate, (yyloc), (yyvsp[(2) - (3)].pnode)))
                                ->sem.tru = true; }
    break;

  case 198:

/* Line 1464 of yacc.c  */
#line 1684 "parser.y"
    { ((yyval.pnode) = wire1 (p_validate, (yyloc), (yyvsp[(2) - (3)].pnode)))
                                ->sem.tru = false; }
    break;

  case 199:

/* Line 1464 of yacc.c  */
#line 1687 "parser.y"
    { ((yyval.pnode) = wire1 (p_validate, (yyloc), (yyvsp[(2) - (3)].pnode)))
                                ->sem.tru = true; }
    break;

  case 200:

/* Line 1464 of yacc.c  */
#line 1693 "parser.y"
    { (yyval.pnode) = p_wire2 (p_ext_expr, (yyloc), (yyvsp[(1) - (4)].pnode), (yyvsp[(3) - (4)].pnode)); }
    break;

  case 201:

/* Line 1464 of yacc.c  */
#line 1697 "parser.y"
    { (yyval.pnode) = p_wire2 (p_pragmas, (yyloc), (yyvsp[(1) - (1)].pnode), nil ((yyloc))); }
    break;

  case 202:

/* Line 1464 of yacc.c  */
#line 1699 "parser.y"
    { (yyval.pnode) = p_wire2 (p_pragmas, (yyloc), (yyvsp[(1) - (2)].pnode), (yyvsp[(2) - (2)].pnode)); }
    break;

  case 203:

/* Line 1464 of yacc.c  */
#line 1702 "parser.y"
    { (yyval.pnode) = nil((yyloc)); }
    break;

  case 204:

/* Line 1464 of yacc.c  */
#line 1703 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 205:

/* Line 1464 of yacc.c  */
#line 1708 "parser.y"
    { (yyval.pnode) = p_leaf (p_pragma, (yyloc));
                              (yyval.pnode)->sem.pragma.qn.qname_raw = (yyvsp[(3) - (5)].qname_raw);
                              (yyval.pnode)->sem.pragma.content   = (yyvsp[(4) - (5)].str);
                            }
    break;

  case 206:

/* Line 1464 of yacc.c  */
#line 1718 "parser.y"
    { (yyval.pnode) = leaf (p_root, (yyloc)); }
    break;

  case 207:

/* Line 1464 of yacc.c  */
#line 1720 "parser.y"
    { (yyval.pnode) = wire2 (p_locpath, (yyloc),
                                          (yyvsp[(2) - (2)].pnode), leaf (p_root, (yylsp[(1) - (2)]))); }
    break;

  case 208:

/* Line 1464 of yacc.c  */
#line 1723 "parser.y"
    { (yyval.pnode) = wire2 (
                                    p_locpath,
                                    (yyloc),
                                    wire2 (
                                     p_locpath,
                                     (yyloc),
                                     (yyvsp[(2) - (2)].pnode),
                                     wire2 (
                                      p_locpath,
                                      (yylsp[(1) - (2)]),
                                      (c = wire1 (
                                            p_step,
                                            (yylsp[(1) - (2)]),
                                            (c1 = wire1 (p_node_ty,
                                                         (yylsp[(1) - (2)]), nil ((yylsp[(1) - (2)]))),
                                             c1->sem.kind = p_kind_node,
                                             c1)),
                                       c->sem.axis = p_descendant_or_self,
                                       c),
                                      leaf (p_dot, (yylsp[(1) - (2)])))),
                                    leaf (p_root, (yylsp[(1) - (2)])));
                            }
    break;

  case 209:

/* Line 1464 of yacc.c  */
#line 1745 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 210:

/* Line 1464 of yacc.c  */
#line 1749 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 211:

/* Line 1464 of yacc.c  */
#line 1751 "parser.y"
    { (yyval.pnode) = wire2 (p_locpath, (yyloc), (yyvsp[(3) - (3)].pnode), (yyvsp[(1) - (3)].pnode)); }
    break;

  case 212:

/* Line 1464 of yacc.c  */
#line 1753 "parser.y"
    { (yyval.pnode) = wire2 (
                                    p_locpath,
                                    (yyloc),
                                    wire2 (
                                     p_locpath,
                                     (yyloc),
                                     (yyvsp[(3) - (3)].pnode),
                                     wire2 (
                                      p_locpath, (yylsp[(2) - (3)]),
                                      (c = wire1 (
                                            p_step,
                                            (yylsp[(2) - (3)]),
                                            (c1 = wire1 (p_node_ty, (yylsp[(2) - (3)]),
                                                         nil ((yylsp[(2) - (3)]))),
                                             c1->sem.kind = p_kind_node,
                                             c1)),
                                       c->sem.axis = p_descendant_or_self,
                                       c),
                                      leaf (p_dot, (yylsp[(2) - (3)])))),
                                    (yyvsp[(1) - (3)].pnode));
                            }
    break;

  case 213:

/* Line 1464 of yacc.c  */
#line 1777 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 214:

/* Line 1464 of yacc.c  */
#line 1778 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 215:

/* Line 1464 of yacc.c  */
#line 1783 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 216:

/* Line 1464 of yacc.c  */
#line 1785 "parser.y"
    { FIXUP (0, (yyvsp[(2) - (2)].phole), (yyvsp[(1) - (2)].pnode)); (yyval.pnode) = (yyvsp[(2) - (2)].phole).root; }
    break;

  case 217:

/* Line 1464 of yacc.c  */
#line 1787 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 218:

/* Line 1464 of yacc.c  */
#line 1789 "parser.y"
    { FIXUP (0, (yyvsp[(2) - (2)].phole), (yyvsp[(1) - (2)].pnode)); (yyval.pnode) = (yyvsp[(2) - (2)].phole).root; }
    break;

  case 219:

/* Line 1464 of yacc.c  */
#line 1791 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 220:

/* Line 1464 of yacc.c  */
#line 1793 "parser.y"
    { FIXUP (0, (yyvsp[(2) - (2)].phole), (yyvsp[(1) - (2)].pnode)); (yyval.pnode) = (yyvsp[(2) - (2)].phole).root; }
    break;

  case 221:

/* Line 1464 of yacc.c  */
#line 1796 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 222:

/* Line 1464 of yacc.c  */
#line 1798 "parser.y"
    { FIXUP (0, (yyvsp[(2) - (2)].phole), (yyvsp[(1) - (2)].pnode)); (yyval.pnode) = (yyvsp[(2) - (2)].phole).root; }
    break;

  case 223:

/* Line 1464 of yacc.c  */
#line 1804 "parser.y"
    { ((yyval.pnode) = wire1 (p_step, (yyloc), (yyvsp[(2) - (2)].pnode)))->sem.axis = (yyvsp[(1) - (2)].axis); }
    break;

  case 224:

/* Line 1464 of yacc.c  */
#line 1806 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 225:

/* Line 1464 of yacc.c  */
#line 1811 "parser.y"
    { (yyval.axis) = p_child; }
    break;

  case 226:

/* Line 1464 of yacc.c  */
#line 1812 "parser.y"
    { (yyval.axis) = p_descendant; }
    break;

  case 227:

/* Line 1464 of yacc.c  */
#line 1813 "parser.y"
    { (yyval.axis) = p_self; }
    break;

  case 228:

/* Line 1464 of yacc.c  */
#line 1814 "parser.y"
    { (yyval.axis) = p_descendant_or_self;}
    break;

  case 229:

/* Line 1464 of yacc.c  */
#line 1815 "parser.y"
    { (yyval.axis) = p_following_sibling; }
    break;

  case 230:

/* Line 1464 of yacc.c  */
#line 1816 "parser.y"
    { (yyval.axis) = p_following; }
    break;

  case 231:

/* Line 1464 of yacc.c  */
#line 1822 "parser.y"
    { ((yyval.pnode) = wire1 (p_step,
                                             (yyloc),
                                             (yyvsp[(1) - (1)].pnode)))->sem.axis = p_child;
                            }
    break;

  case 232:

/* Line 1464 of yacc.c  */
#line 1830 "parser.y"
    { ((yyval.pnode) = wire1 (p_step, (yyloc), (yyvsp[(2) - (2)].pnode)))->sem.axis = (yyvsp[(1) - (2)].axis); }
    break;

  case 233:

/* Line 1464 of yacc.c  */
#line 1832 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 234:

/* Line 1464 of yacc.c  */
#line 1836 "parser.y"
    { (yyval.axis) = p_parent; }
    break;

  case 235:

/* Line 1464 of yacc.c  */
#line 1837 "parser.y"
    { (yyval.axis) = p_ancestor; }
    break;

  case 236:

/* Line 1464 of yacc.c  */
#line 1838 "parser.y"
    { (yyval.axis) = p_preceding_sibling; }
    break;

  case 237:

/* Line 1464 of yacc.c  */
#line 1839 "parser.y"
    { (yyval.axis) = p_preceding; }
    break;

  case 238:

/* Line 1464 of yacc.c  */
#line 1840 "parser.y"
    { (yyval.axis) = p_ancestor_or_self; }
    break;

  case 239:

/* Line 1464 of yacc.c  */
#line 1845 "parser.y"
    { ((yyval.pnode) = wire1 (p_step,
                                           (yyloc),
                                           (c = wire1 (p_node_ty, (yyloc), nil ((yyloc))),
                                            c->sem.kind = p_kind_node,
                                            c)))->sem.axis = p_parent;
                            }
    break;

  case 240:

/* Line 1464 of yacc.c  */
#line 1855 "parser.y"
    { ((yyval.pnode) = wire1 (p_step, (yyloc), (yyvsp[(2) - (2)].pnode)))->sem.axis = (yyvsp[(1) - (2)].axis); }
    break;

  case 241:

/* Line 1464 of yacc.c  */
#line 1857 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 242:

/* Line 1464 of yacc.c  */
#line 1861 "parser.y"
    { (yyval.axis) = p_attribute; }
    break;

  case 243:

/* Line 1464 of yacc.c  */
#line 1866 "parser.y"
    { ((yyval.pnode) = wire1 (p_step,
                                           (yyloc),
                                           (yyvsp[(2) - (2)].pnode)))->sem.axis = p_attribute;
                            }
    break;

  case 244:

/* Line 1464 of yacc.c  */
#line 1874 "parser.y"
    { /* Burkowski Axis (can only be used if
                                 corresponding compiler flag is set) */
                              ((yyval.pnode) = wire1 (p_step, (yyloc), (yyvsp[(2) - (2)].pnode)))->sem.axis = (yyvsp[(1) - (2)].axis); }
    break;

  case 245:

/* Line 1464 of yacc.c  */
#line 1880 "parser.y"
    { 
                              if (!standoff_axis_steps) {
                                PFoops (OOPS_PARSE,
                                      "invalid character "
                                      "(StandOff was not enabled)");
                              } else {
                                (yyval.axis) = p_select_narrow; 
                              }
                            }
    break;

  case 246:

/* Line 1464 of yacc.c  */
#line 1890 "parser.y"
    { 
                              if (!standoff_axis_steps) {
                                PFoops (OOPS_PARSE,
                                      "invalid character "
                                      "(StandOff was not enabled)");
                              } else {
                                (yyval.axis) = p_select_wide; 
                              }
                            }
    break;

  case 247:

/* Line 1464 of yacc.c  */
#line 1904 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 248:

/* Line 1464 of yacc.c  */
#line 1906 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), (yyvsp[(1) - (1)].pnode)))
                                ->sem.kind = p_kind_elem; }
    break;

  case 249:

/* Line 1464 of yacc.c  */
#line 1912 "parser.y"
    { (yyval.pnode) = wire2 (p_req_ty, (yyloc),
                                          (c = leaf (p_req_name, (yyloc)),
                                           c->sem.qname_raw = (yyvsp[(1) - (1)].qname_raw),
                                           c),
                                          nil ((yyloc))); }
    break;

  case 250:

/* Line 1464 of yacc.c  */
#line 1918 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 251:

/* Line 1464 of yacc.c  */
#line 1923 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 252:

/* Line 1464 of yacc.c  */
#line 1925 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), (yyvsp[(1) - (1)].pnode)))
                                ->sem.kind = p_kind_attr; }
    break;

  case 253:

/* Line 1464 of yacc.c  */
#line 1931 "parser.y"
    { (yyval.pnode) = wire2 (p_req_ty, (yyloc), nil ((yyloc)), nil ((yyloc))); }
    break;

  case 254:

/* Line 1464 of yacc.c  */
#line 1933 "parser.y"
    { (yyval.pnode) = wire2 (p_req_ty, (yyloc),
                                          (c = leaf (p_req_name, (yyloc)),
                                           c->sem.qname_raw = (yyvsp[(1) - (1)].qname_raw),
                                           c),
                                          nil ((yyloc))); }
    break;

  case 255:

/* Line 1464 of yacc.c  */
#line 1939 "parser.y"
    { (yyval.pnode) = wire2 (p_req_ty, (yyloc),
                                          (c = leaf (p_req_name, (yyloc)),
                                           c->sem.qname_raw = (yyvsp[(1) - (1)].qname_raw),
                                           c),
                                          nil ((yyloc))); }
    break;

  case 256:

/* Line 1464 of yacc.c  */
#line 1947 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 257:

/* Line 1464 of yacc.c  */
#line 1949 "parser.y"
    { FIXUP (0, (yyvsp[(2) - (2)].phole), (yyvsp[(1) - (2)].pnode)); (yyval.pnode) = (yyvsp[(2) - (2)].phole).root; }
    break;

  case 258:

/* Line 1464 of yacc.c  */
#line 1954 "parser.y"
    { (yyval.phole).root = (yyval.phole).hole = wire2 (p_pred, (yylsp[(1) - (1)]), NULL, (yyvsp[(1) - (1)].pnode));}
    break;

  case 259:

/* Line 1464 of yacc.c  */
#line 1956 "parser.y"
    { (yyval.phole).hole
                                  = (yyvsp[(2) - (2)].phole).hole->child[0]
                                  = wire2 (p_pred, (yylsp[(1) - (2)]), NULL, (yyvsp[(1) - (2)].pnode));
                              (yyval.phole).root = (yyvsp[(2) - (2)].phole).root;
                            }
    break;

  case 260:

/* Line 1464 of yacc.c  */
#line 1964 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (3)].pnode); }
    break;

  case 261:

/* Line 1464 of yacc.c  */
#line 1968 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 262:

/* Line 1464 of yacc.c  */
#line 1969 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 263:

/* Line 1464 of yacc.c  */
#line 1970 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 264:

/* Line 1464 of yacc.c  */
#line 1971 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 265:

/* Line 1464 of yacc.c  */
#line 1972 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 266:

/* Line 1464 of yacc.c  */
#line 1973 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 267:

/* Line 1464 of yacc.c  */
#line 1974 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 268:

/* Line 1464 of yacc.c  */
#line 1975 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 269:

/* Line 1464 of yacc.c  */
#line 1976 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 270:

/* Line 1464 of yacc.c  */
#line 1980 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 271:

/* Line 1464 of yacc.c  */
#line 1982 "parser.y"
    { ((yyval.pnode) = leaf (p_lit_str, (yyloc)))->sem.str = (yyvsp[(1) - (1)].str); }
    break;

  case 272:

/* Line 1464 of yacc.c  */
#line 1987 "parser.y"
    { ((yyval.pnode) = leaf (p_lit_int, (yyloc)))->sem.num = (yyvsp[(1) - (1)].num); }
    break;

  case 273:

/* Line 1464 of yacc.c  */
#line 1989 "parser.y"
    { ((yyval.pnode) = leaf (p_lit_dec, (yyloc)))->sem.dec = (yyvsp[(1) - (1)].dec); }
    break;

  case 274:

/* Line 1464 of yacc.c  */
#line 1991 "parser.y"
    { ((yyval.pnode) = leaf (p_lit_dbl, (yyloc)))->sem.dbl = (yyvsp[(1) - (1)].dbl); }
    break;

  case 275:

/* Line 1464 of yacc.c  */
#line 1995 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (2)].pnode); }
    break;

  case 276:

/* Line 1464 of yacc.c  */
#line 2000 "parser.y"
    { ((yyval.pnode) = leaf (p_varref, (yyloc)))->sem.qname_raw = (yyvsp[(1) - (1)].qname_raw); }
    break;

  case 277:

/* Line 1464 of yacc.c  */
#line 2004 "parser.y"
    { (yyval.pnode) = leaf (p_empty_seq, (yyloc)); }
    break;

  case 278:

/* Line 1464 of yacc.c  */
#line 2005 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (3)].pnode); }
    break;

  case 279:

/* Line 1464 of yacc.c  */
#line 2009 "parser.y"
    { (yyval.pnode) = leaf (p_dot, (yyloc)); }
    break;

  case 280:

/* Line 1464 of yacc.c  */
#line 2014 "parser.y"
    { (yyval.pnode) = wire1 (p_ordered, (yyloc), (yyvsp[(2) - (3)].pnode)); }
    break;

  case 281:

/* Line 1464 of yacc.c  */
#line 2019 "parser.y"
    { (yyval.pnode) = wire1 (p_unordered, (yyloc), (yyvsp[(2) - (3)].pnode)); }
    break;

  case 282:

/* Line 1464 of yacc.c  */
#line 2024 "parser.y"
    { c = wire1 (p_fun_ref, (yyloc), (yyvsp[(2) - (3)].pnode));
                              /* FIXME:
                               *   This is not the parser's job!
                               *   Do this during function resolution!
                               */
                              c->sem.qname_raw = (yyvsp[(1) - (3)].qname_raw);
                              (yyval.pnode) = c;
                            }
    break;

  case 283:

/* Line 1464 of yacc.c  */
#line 2034 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 284:

/* Line 1464 of yacc.c  */
#line 2035 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 285:

/* Line 1464 of yacc.c  */
#line 2039 "parser.y"
    { (yyval.pnode) = wire2 (p_args, (yyloc), (yyvsp[(1) - (1)].pnode), nil ((yylsp[(1) - (1)]))); }
    break;

  case 286:

/* Line 1464 of yacc.c  */
#line 2041 "parser.y"
    { /* FIXME: For compatibility with the parser that
                               * had followed the Nov 2002 draft, build up
                               * this list in a backward fashion. Core mapping
                               * will reverse this again.
                               * (If you want to change the order here, just
                               * swap FuncArgList_ and ExprSingle in the rule
                               * and the parameters of the below wire2 call.
                               */
                              (yyval.pnode) = wire2 (p_args, (yyloc), (yyvsp[(3) - (3)].pnode), (yyvsp[(1) - (3)].pnode)); }
    break;

  case 287:

/* Line 1464 of yacc.c  */
#line 2053 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 288:

/* Line 1464 of yacc.c  */
#line 2054 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 289:

/* Line 1464 of yacc.c  */
#line 2058 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 290:

/* Line 1464 of yacc.c  */
#line 2059 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 291:

/* Line 1464 of yacc.c  */
#line 2060 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 292:

/* Line 1464 of yacc.c  */
#line 2065 "parser.y"
    { if ((yyvsp[(3) - (4)].phole).root)
                                (yyvsp[(3) - (4)].phole).hole->child[1] = leaf (p_empty_seq, (yylsp[(3) - (4)]));
                              else
                                (yyvsp[(3) - (4)].phole).root = leaf (p_empty_seq, (yylsp[(3) - (4)]));

                              (yyval.pnode) = wire2 (p_elem,
                                          (yyloc),
                                          (c = leaf (p_tag, (yylsp[(2) - (4)])),
                                           c->sem.qname_raw = (yyvsp[(2) - (4)].qname_raw),
                                           c),
                                          (yyvsp[(3) - (4)].phole).root);
                            }
    break;

  case 293:

/* Line 1464 of yacc.c  */
#line 2080 "parser.y"
    { /*
                               * XML well-formedness check:
                               * start and end tag must match
                               *
                               * Note: This is in line with the W3C specs.
                               *       Tag names must exactly match, including
                               *       their namespace prefixes.
                               */ 
                              if (PFqname_raw_eq ((yyvsp[(2) - (9)].qname_raw), (yyvsp[(7) - (9)].qname_raw))) {
                                PFinfo_loc (OOPS_TAGMISMATCH, (yyloc),
                                            "<%s> and </%s>",
                                            PFqname_raw_str ((yyvsp[(2) - (9)].qname_raw)),
                                            PFqname_raw_str ((yyvsp[(7) - (9)].qname_raw)));
                                YYERROR;
                              }

                              /* merge attribute list and element content */
                               if ((yyvsp[(3) - (9)].phole).root)
                                 FIXUP (1, (yyvsp[(3) - (9)].phole), (yyvsp[(5) - (9)].pnode));
                               else
                                 (yyvsp[(3) - (9)].phole).root = (yyvsp[(5) - (9)].pnode);

                               (yyval.pnode) = wire2 (p_elem,
                                           (yyloc),
                                           (c = leaf (p_tag, (yylsp[(2) - (9)])),
                                            c->sem.qname_raw = (yyvsp[(2) - (9)].qname_raw),
                                            c),
                                           (yyvsp[(3) - (9)].phole).root);
                            }
    break;

  case 296:

/* Line 1464 of yacc.c  */
#line 2116 "parser.y"
    { (yyval.pnode) = leaf (p_empty_seq, (yyloc)); }
    break;

  case 297:

/* Line 1464 of yacc.c  */
#line 2118 "parser.y"
    { (yyval.pnode) = wire2 (p_contseq, (yyloc), (yyvsp[(1) - (2)].pnode), (yyvsp[(2) - (2)].pnode)); }
    break;

  case 298:

/* Line 1464 of yacc.c  */
#line 2123 "parser.y"
    { (yyval.phole).root = (yyval.phole).hole = NULL; }
    break;

  case 299:

/* Line 1464 of yacc.c  */
#line 2125 "parser.y"
    { (yyval.phole) = (yyvsp[(2) - (2)].phole); }
    break;

  case 300:

/* Line 1464 of yacc.c  */
#line 2127 "parser.y"
    { (yyval.phole).root
                                  = (yyval.phole).hole
                                  = wire2 (p_contseq, (yyloc), (yyvsp[(2) - (3)].pnode), (yyvsp[(3) - (3)].phole).root);
                              if ((yyvsp[(3) - (3)].phole).root)
                                  (yyval.phole).hole = (yyvsp[(3) - (3)].phole).hole;
                            }
    break;

  case 301:

/* Line 1464 of yacc.c  */
#line 2136 "parser.y"
    { (yyval.pnode) = wire2 (p_attr, (yyloc),
                                          (c = leaf (p_tag, (yylsp[(1) - (5)])),
                                           c->sem.qname_raw = (yyvsp[(1) - (5)].qname_raw),
                                           c), (yyvsp[(5) - (5)].pnode));
                            }
    break;

  case 302:

/* Line 1464 of yacc.c  */
#line 2144 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (3)].pnode); }
    break;

  case 303:

/* Line 1464 of yacc.c  */
#line 2145 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (3)].pnode); }
    break;

  case 304:

/* Line 1464 of yacc.c  */
#line 2149 "parser.y"
    { (yyval.pnode) = leaf (p_empty_seq, (yyloc)); }
    break;

  case 305:

/* Line 1464 of yacc.c  */
#line 2151 "parser.y"
    { (yyval.pnode) = wire2 (p_contseq, (yyloc), (yyvsp[(1) - (2)].pnode), (yyvsp[(2) - (2)].pnode)); }
    break;

  case 306:

/* Line 1464 of yacc.c  */
#line 2155 "parser.y"
    { /* add trailing '\0' to string */
                              *((char *) PFarray_add ((yyvsp[(1) - (1)].buf))) = '\0';

                              (yyval.pnode) = wire2 (p_contseq, (yylsp[(1) - (1)]),
                                          (c = leaf (p_lit_str, (yylsp[(1) - (1)])),
                                           c->sem.str = PFarray_at ((yyvsp[(1) - (1)].buf), 0),
                                           c),
                                          leaf (p_empty_seq, (yylsp[(1) - (1)]))
                                         ); }
    break;

  case 307:

/* Line 1464 of yacc.c  */
#line 2165 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 308:

/* Line 1464 of yacc.c  */
#line 2169 "parser.y"
    {   /*
                                 * initialize new dynamic array and insert
                                 * one (UTF-8) character
                                 */
                                (yyval.buf) = PFarray (sizeof (char), 512);
                                while (*((yyvsp[(1) - (1)].str))) {
                                    *((char *) PFarray_add ((yyval.buf))) = *((yyvsp[(1) - (1)].str));
                                    ((yyvsp[(1) - (1)].str))++;
                                }
                            }
    break;

  case 309:

/* Line 1464 of yacc.c  */
#line 2180 "parser.y"
    {   /* append one (UTF-8) charater to array */
                                while (*((yyvsp[(2) - (2)].str))) {
                                    *((char *) PFarray_add ((yyvsp[(1) - (2)].buf))) = *((yyvsp[(2) - (2)].str));
                                    ((yyvsp[(2) - (2)].str))++;
                                }
                            }
    break;

  case 310:

/* Line 1464 of yacc.c  */
#line 2188 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 311:

/* Line 1464 of yacc.c  */
#line 2189 "parser.y"
    { (yyval.str) = "\""; }
    break;

  case 312:

/* Line 1464 of yacc.c  */
#line 2190 "parser.y"
    { (yyval.str) = "'"; }
    break;

  case 313:

/* Line 1464 of yacc.c  */
#line 2191 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 314:

/* Line 1464 of yacc.c  */
#line 2192 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 315:

/* Line 1464 of yacc.c  */
#line 2193 "parser.y"
    { (yyval.str) = "{"; }
    break;

  case 316:

/* Line 1464 of yacc.c  */
#line 2194 "parser.y"
    { (yyval.str) = "}"; }
    break;

  case 317:

/* Line 1464 of yacc.c  */
#line 2199 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 318:

/* Line 1464 of yacc.c  */
#line 2200 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 319:

/* Line 1464 of yacc.c  */
#line 2202 "parser.y"
    { /* add trailing '\0' to string */
                              *((char *) PFarray_add ((yyvsp[(1) - (1)].buf))) = '\0';
                                             
                              /* xmlspace handling */
                              if ((! PFquery->pres_boundary_space) &&
                                  (is_whitespace (PFarray_at ((yyvsp[(1) - (1)].buf), 0))))
                                (yyval.pnode) = leaf (p_empty_seq, (yylsp[(1) - (1)]));
                              else
                                (yyval.pnode) = wire1 (p_text, (yylsp[(1) - (1)]),
                                            wire2 (p_exprseq, (yylsp[(1) - (1)]),
                                                   (c = leaf (p_lit_str, (yylsp[(1) - (1)])),
                                                    c->sem.str = 
                                                      PFarray_at ((yyvsp[(1) - (1)].buf), 0),
                                                    c),
                                                   leaf (p_empty_seq, (yylsp[(1) - (1)]))
                                                  )); 
                            }
    break;

  case 320:

/* Line 1464 of yacc.c  */
#line 2219 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 321:

/* Line 1464 of yacc.c  */
#line 2223 "parser.y"
    {   /*
                                 * initialize new dynamic array and insert
                                 * one (UTF-8) character
                                 */
                                (yyval.buf) = PFarray (sizeof (char), 512);
                                while (*((yyvsp[(1) - (1)].str))) {
                                    *((char *) PFarray_add ((yyval.buf))) = *((yyvsp[(1) - (1)].str));
                                    ((yyvsp[(1) - (1)].str))++;
                                }
                            }
    break;

  case 322:

/* Line 1464 of yacc.c  */
#line 2234 "parser.y"
    {   /* append one (UTF-8) charater to array */
                                while (*((yyvsp[(2) - (2)].str))) {
                                    *((char *) PFarray_add ((yyvsp[(1) - (2)].buf))) = *((yyvsp[(2) - (2)].str));
                                    ((yyvsp[(2) - (2)].str))++;
                                }
                                (yyval.buf) = (yyvsp[(1) - (2)].buf);
                            }
    break;

  case 323:

/* Line 1464 of yacc.c  */
#line 2243 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 324:

/* Line 1464 of yacc.c  */
#line 2244 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 325:

/* Line 1464 of yacc.c  */
#line 2245 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 326:

/* Line 1464 of yacc.c  */
#line 2246 "parser.y"
    { (yyval.str) = "{"; }
    break;

  case 327:

/* Line 1464 of yacc.c  */
#line 2247 "parser.y"
    { (yyval.str) = "}"; }
    break;

  case 328:

/* Line 1464 of yacc.c  */
#line 2252 "parser.y"
    { (yyval.pnode) = wire1 (p_comment, (yyloc), (yyvsp[(2) - (3)].pnode)); }
    break;

  case 329:

/* Line 1464 of yacc.c  */
#line 2256 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 330:

/* Line 1464 of yacc.c  */
#line 2260 "parser.y"
    { /* add trailing '\0' to string */
                              *((char *) PFarray_add ((yyvsp[(1) - (1)].buf))) = '\0';

                              (yyval.pnode) = leaf (p_lit_str, (yylsp[(1) - (1)]));
                              (yyval.pnode)->sem.str = (char *) PFarray_at ((yyvsp[(1) - (1)].buf), 0);
                            }
    break;

  case 331:

/* Line 1464 of yacc.c  */
#line 2270 "parser.y"
    { /* initialize new dynamic array */
                              (yyval.buf) = PFarray (sizeof (char), 512); }
    break;

  case 332:

/* Line 1464 of yacc.c  */
#line 2273 "parser.y"
    {   /* append one (UTF-8) charater to array */
                                while (*((yyvsp[(2) - (2)].str))) {
                                    *((char *) PFarray_add ((yyvsp[(1) - (2)].buf))) = *((yyvsp[(2) - (2)].str));
                                    ((yyvsp[(2) - (2)].str))++;
                                }
                                (yyval.buf) = (yyvsp[(1) - (2)].buf);
                            }
    break;

  case 333:

/* Line 1464 of yacc.c  */
#line 2284 "parser.y"
    { 
                              if ((strlen ((yyvsp[(2) - (4)].str)) == 3)
                                   && ((yyvsp[(2) - (4)].str)[0] == 'x' || (yyvsp[(2) - (4)].str)[0] == 'X')
                                   && ((yyvsp[(2) - (4)].str)[1] == 'm' || (yyvsp[(2) - (4)].str)[1] == 'M')
                                   && ((yyvsp[(2) - (4)].str)[2] == 'l' || (yyvsp[(2) - (4)].str)[2] == 'L')) {
                                  PFinfo_loc (OOPS_PARSE, (yyloc),
                                              "`xml' is reserved and may not "
                                              "be used as a PI target.");
                                  YYERROR;
                              }

                              (yyval.pnode) = wire2 (p_pi, (yyloc),
                                          (c = leaf (p_lit_str, (yyloc)),
                                           c->sem.str = (yyvsp[(2) - (4)].str),
                                           c),
                                          (yyvsp[(3) - (4)].pnode));
                            }
    break;

  case 334:

/* Line 1464 of yacc.c  */
#line 2304 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 335:

/* Line 1464 of yacc.c  */
#line 2305 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (2)].pnode); }
    break;

  case 336:

/* Line 1464 of yacc.c  */
#line 2310 "parser.y"
    { (yyval.pnode) = wire1 (p_text, (yyloc),
                                          wire2 (p_exprseq, (yylsp[(2) - (3)]), (yyvsp[(2) - (3)].pnode),
                                                 leaf (p_empty_seq, (yylsp[(2) - (3)])))); }
    break;

  case 337:

/* Line 1464 of yacc.c  */
#line 2316 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 338:

/* Line 1464 of yacc.c  */
#line 2320 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 339:

/* Line 1464 of yacc.c  */
#line 2321 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 340:

/* Line 1464 of yacc.c  */
#line 2322 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 341:

/* Line 1464 of yacc.c  */
#line 2323 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 342:

/* Line 1464 of yacc.c  */
#line 2324 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 343:

/* Line 1464 of yacc.c  */
#line 2325 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 344:

/* Line 1464 of yacc.c  */
#line 2330 "parser.y"
    { (yyval.pnode) = wire1 (p_doc, (yyloc), (yyvsp[(2) - (3)].pnode)); }
    break;

  case 345:

/* Line 1464 of yacc.c  */
#line 2335 "parser.y"
    { (yyval.pnode) = wire2 (p_elem, (yyloc),
                                          (c = leaf (p_tag, (yylsp[(1) - (3)])),
                                           c->sem.qname_raw = (yyvsp[(1) - (3)].qname_raw),
                                           c),
                                          wire2 (p_contseq, (yylsp[(2) - (3)]), (yyvsp[(2) - (3)].pnode),
                                                 leaf (p_empty_seq, (yylsp[(2) - (3)]))));
                            }
    break;

  case 346:

/* Line 1464 of yacc.c  */
#line 2343 "parser.y"
    { (yyval.pnode) = wire2 (p_elem, (yyloc), (yyvsp[(2) - (6)].pnode),
                                          wire2 (p_contseq, (yylsp[(5) - (6)]), (yyvsp[(5) - (6)].pnode),
                                                 leaf (p_empty_seq, (yylsp[(2) - (6)])))); }
    break;

  case 347:

/* Line 1464 of yacc.c  */
#line 2348 "parser.y"
    { (yyval.pnode) = leaf (p_empty_seq, (yyloc)); }
    break;

  case 348:

/* Line 1464 of yacc.c  */
#line 2349 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 349:

/* Line 1464 of yacc.c  */
#line 2353 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 350:

/* Line 1464 of yacc.c  */
#line 2358 "parser.y"
    { (yyval.pnode) = wire2 (p_attr, (yyloc),
                                          (c = leaf (p_tag, (yylsp[(1) - (3)])),
                                           c->sem.qname_raw = (yyvsp[(1) - (3)].qname_raw),
                                           c),
                                          wire2 (p_contseq, (yylsp[(2) - (3)]), (yyvsp[(2) - (3)].pnode),
                                                 leaf (p_empty_seq, (yylsp[(2) - (3)]))));
                            }
    break;

  case 351:

/* Line 1464 of yacc.c  */
#line 2366 "parser.y"
    { (yyval.pnode) = wire2 (p_attr, (yyloc), (yyvsp[(2) - (6)].pnode),
                                          wire2 (p_contseq, (yylsp[(5) - (6)]), (yyvsp[(5) - (6)].pnode),
                                                 leaf (p_empty_seq, (yylsp[(5) - (6)])))); }
    break;

  case 352:

/* Line 1464 of yacc.c  */
#line 2373 "parser.y"
    { (yyval.pnode) = wire1 (p_text, (yyloc), (yyvsp[(2) - (3)].pnode)); }
    break;

  case 353:

/* Line 1464 of yacc.c  */
#line 2378 "parser.y"
    { (yyval.pnode) = wire1 (p_comment, (yyloc), (yyvsp[(2) - (3)].pnode)); }
    break;

  case 354:

/* Line 1464 of yacc.c  */
#line 2383 "parser.y"
    { (yyval.pnode) = wire2 (p_pi, (yyloc),
                                          (c = leaf (p_lit_str, (yylsp[(2) - (3)])),
                                           c->sem.str = (yyvsp[(1) - (3)].str),
                                           c),
                                          wire2 (p_contseq, (yylsp[(2) - (3)]), (yyvsp[(2) - (3)].pnode),
                                                 leaf (p_empty_seq, (yylsp[(2) - (3)])))); }
    break;

  case 355:

/* Line 1464 of yacc.c  */
#line 2391 "parser.y"
    { (yyval.pnode) = wire2 (p_pi, (yyloc), (yyvsp[(2) - (6)].pnode), (yyvsp[(5) - (6)].pnode)); }
    break;

  case 356:

/* Line 1464 of yacc.c  */
#line 2396 "parser.y"
    { ((yyval.pnode) = wire1 (p_seq_ty, (yyloc), (yyvsp[(1) - (1)].pnode)))
                                ->sem.oci = p_one; }
    break;

  case 357:

/* Line 1464 of yacc.c  */
#line 2399 "parser.y"
    { ((yyval.pnode) = wire1 (p_seq_ty, (yyloc), (yyvsp[(1) - (2)].pnode)))
                                ->sem.oci = p_zero_or_one; }
    break;

  case 358:

/* Line 1464 of yacc.c  */
#line 2404 "parser.y"
    { (yyval.pnode) = (yyvsp[(2) - (2)].pnode); }
    break;

  case 359:

/* Line 1464 of yacc.c  */
#line 2409 "parser.y"
    { ((yyval.pnode) = wire1 (p_seq_ty, (yyloc), leaf (p_empty_ty, (yyloc))))
                                ->sem.oci = p_one; }
    break;

  case 360:

/* Line 1464 of yacc.c  */
#line 2412 "parser.y"
    { ((yyval.pnode) = wire1 (p_seq_ty, (yyloc), (yyvsp[(1) - (2)].pnode)))->sem.oci = (yyvsp[(2) - (2)].oci); }
    break;

  case 361:

/* Line 1464 of yacc.c  */
#line 2417 "parser.y"
    { (yyval.oci) = p_one; }
    break;

  case 362:

/* Line 1464 of yacc.c  */
#line 2418 "parser.y"
    { (yyval.oci) = p_zero_or_one; }
    break;

  case 363:

/* Line 1464 of yacc.c  */
#line 2419 "parser.y"
    { (yyval.oci) = p_zero_or_more; }
    break;

  case 364:

/* Line 1464 of yacc.c  */
#line 2420 "parser.y"
    { (yyval.oci) = p_one_or_more; }
    break;

  case 365:

/* Line 1464 of yacc.c  */
#line 2424 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 366:

/* Line 1464 of yacc.c  */
#line 2425 "parser.y"
    { (yyval.pnode) = wire1 (p_item_ty, (yyloc), nil ((yyloc))); }
    break;

  case 367:

/* Line 1464 of yacc.c  */
#line 2426 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 368:

/* Line 1464 of yacc.c  */
#line 2431 "parser.y"
    { ((yyval.pnode) = wire1 (p_atom_ty, (yyloc), nil ((yyloc))))
                                ->sem.qname_raw = (yyvsp[(1) - (1)].qname_raw); }
    break;

  case 369:

/* Line 1464 of yacc.c  */
#line 2436 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 370:

/* Line 1464 of yacc.c  */
#line 2437 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 371:

/* Line 1464 of yacc.c  */
#line 2438 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 372:

/* Line 1464 of yacc.c  */
#line 2439 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 373:

/* Line 1464 of yacc.c  */
#line 2440 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 374:

/* Line 1464 of yacc.c  */
#line 2441 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 375:

/* Line 1464 of yacc.c  */
#line 2442 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 376:

/* Line 1464 of yacc.c  */
#line 2443 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 377:

/* Line 1464 of yacc.c  */
#line 2444 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 378:

/* Line 1464 of yacc.c  */
#line 2449 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), nil ((yyloc))))
                                ->sem.kind = p_kind_node; }
    break;

  case 379:

/* Line 1464 of yacc.c  */
#line 2455 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), nil ((yyloc))))
                                ->sem.kind = p_kind_doc; }
    break;

  case 380:

/* Line 1464 of yacc.c  */
#line 2458 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), (yyvsp[(2) - (3)].pnode)))
                                ->sem.kind = p_kind_doc; }
    break;

  case 381:

/* Line 1464 of yacc.c  */
#line 2461 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), (yyvsp[(2) - (3)].pnode)))
                                ->sem.kind = p_kind_doc; }
    break;

  case 382:

/* Line 1464 of yacc.c  */
#line 2467 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), nil ((yyloc))))
                                ->sem.kind = p_kind_text; }
    break;

  case 383:

/* Line 1464 of yacc.c  */
#line 2473 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), nil ((yyloc))))
                                ->sem.kind = p_kind_comment; }
    break;

  case 384:

/* Line 1464 of yacc.c  */
#line 2479 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), nil ((yyloc))))
                                ->sem.kind = p_kind_pi; }
    break;

  case 385:

/* Line 1464 of yacc.c  */
#line 2482 "parser.y"
    { /* semantics for p-i(NCName) and
                               * p-i(StringLiteral) are identical. */
                              ((yyval.pnode) = wire1 (p_node_ty, (yyloc),
                                           (c = leaf (p_lit_str, (yylsp[(2) - (3)])),
                                            c->sem.str = (yyvsp[(2) - (3)].str),
                                            c)))
                                ->sem.kind = p_kind_pi; }
    break;

  case 386:

/* Line 1464 of yacc.c  */
#line 2490 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc),
                                           (c = leaf (p_lit_str, (yylsp[(2) - (3)])),
                                            c->sem.str = (yyvsp[(2) - (3)].str),
                                            c)))
                                ->sem.kind = p_kind_pi; }
    break;

  case 387:

/* Line 1464 of yacc.c  */
#line 2499 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), nil ((yyloc))))
                                ->sem.kind = p_kind_attr; }
    break;

  case 388:

/* Line 1464 of yacc.c  */
#line 2502 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc),
                                           wire2 (p_req_ty, (yyloc), (yyvsp[(2) - (3)].pnode), nil ((yyloc)))))
                                ->sem.kind = p_kind_attr; }
    break;

  case 389:

/* Line 1464 of yacc.c  */
#line 2506 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc),
                                           wire2 (p_req_ty, (yyloc),
                                                  (yyvsp[(2) - (5)].pnode),
                                                  (c = leaf (p_named_ty, (yylsp[(4) - (5)])),
                                                   c->sem.qname_raw = (yyvsp[(4) - (5)].qname_raw),
                                                   c))))
                                ->sem.kind = p_kind_attr; }
    break;

  case 390:

/* Line 1464 of yacc.c  */
#line 2517 "parser.y"
    { ((yyval.pnode) = leaf (p_req_name,(yyloc)))->sem.qname_raw = (yyvsp[(1) - (1)].qname_raw); }
    break;

  case 391:

/* Line 1464 of yacc.c  */
#line 2519 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 392:

/* Line 1464 of yacc.c  */
#line 2524 "parser.y"
    { ((yyval.pnode) = leaf (p_schm_attr,(yyloc)))->sem.qname_raw = (yyvsp[(2) - (3)].qname_raw);}
    break;

  case 393:

/* Line 1464 of yacc.c  */
#line 2528 "parser.y"
    { (yyval.qname_raw) = (yyvsp[(1) - (1)].qname_raw); }
    break;

  case 394:

/* Line 1464 of yacc.c  */
#line 2533 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc), nil ((yyloc))))
                                ->sem.kind = p_kind_elem; }
    break;

  case 395:

/* Line 1464 of yacc.c  */
#line 2536 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc),
                                           wire2 (p_req_ty, (yyloc), (yyvsp[(2) - (3)].pnode), nil ((yyloc)))))
                                ->sem.kind = p_kind_elem; }
    break;

  case 396:

/* Line 1464 of yacc.c  */
#line 2540 "parser.y"
    { ((yyval.pnode) = wire1 (p_node_ty, (yyloc),
                                           wire2 (p_req_ty, (yyloc),
                                                  (yyvsp[(2) - (5)].pnode),
                                                  (c = leaf (p_named_ty, (yylsp[(4) - (5)])),
                                                   c->sem.qname_raw = (yyvsp[(4) - (5)].qname_raw),
                                                   c))))
                                ->sem.kind = p_kind_elem; }
    break;

  case 397:

/* Line 1464 of yacc.c  */
#line 2549 "parser.y"
    { /* FIXME: We currently ignore the '?'.
                               *
                               * Semantics of the '?': Identical to semantics
                               * without, but additionally allows elements that
                               * have their `nilled' property set. (We don't
                               * implement `nilled' anyway.)
                               */
                              PFinfo_loc (OOPS_NOTICE, (yylsp[(5) - (6)]),
                                          "`?' modifier in element type test "
                                          "is not supported and will be "
                                          "ignored.");
                              ((yyval.pnode) = wire1 (p_node_ty, (yyloc),
                                           wire2 (p_req_ty, (yyloc),
                                                  (yyvsp[(2) - (6)].pnode),
                                                  (c = leaf (p_named_ty, (yylsp[(4) - (6)])),
                                                   c->sem.qname_raw = (yyvsp[(4) - (6)].qname_raw),
                                                   c))))
                                ->sem.kind = p_kind_elem;
                            }
    break;

  case 398:

/* Line 1464 of yacc.c  */
#line 2572 "parser.y"
    { ((yyval.pnode) = leaf (p_req_name,(yyloc)))->sem.qname_raw = (yyvsp[(1) - (1)].qname_raw); }
    break;

  case 399:

/* Line 1464 of yacc.c  */
#line 2574 "parser.y"
    { (yyval.pnode) = nil ((yyloc)); }
    break;

  case 400:

/* Line 1464 of yacc.c  */
#line 2579 "parser.y"
    { ((yyval.pnode) = leaf (p_schm_elem,(yyloc)))->sem.qname_raw = (yyvsp[(2) - (3)].qname_raw);}
    break;

  case 401:

/* Line 1464 of yacc.c  */
#line 2583 "parser.y"
    { (yyval.qname_raw) = (yyvsp[(1) - (1)].qname_raw); }
    break;

  case 402:

/* Line 1464 of yacc.c  */
#line 2587 "parser.y"
    { (yyval.qname_raw) = (yyvsp[(1) - (1)].qname_raw); }
    break;

  case 403:

/* Line 1464 of yacc.c  */
#line 2591 "parser.y"
    { (yyval.qname_raw) = (yyvsp[(1) - (1)].qname_raw); }
    break;

  case 404:

/* Line 1464 of yacc.c  */
#line 2595 "parser.y"
    { (yyval.qname_raw) = (yyvsp[(1) - (1)].qname_raw); }
    break;

  case 405:

/* Line 1464 of yacc.c  */
#line 2599 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 406:

/* Line 1464 of yacc.c  */
#line 2606 "parser.y"
    { ((yyval.pnode) = p_leaf (p_revalid, (yyloc)))
                                  ->sem.revalid = revalid_strict; }
    break;

  case 407:

/* Line 1464 of yacc.c  */
#line 2609 "parser.y"
    { ((yyval.pnode) = p_leaf (p_revalid, (yyloc)))
                                  ->sem.revalid = revalid_lax; }
    break;

  case 408:

/* Line 1464 of yacc.c  */
#line 2612 "parser.y"
    { ((yyval.pnode) = p_leaf (p_revalid, (yyloc)))
                                  ->sem.revalid = revalid_skip; }
    break;

  case 409:

/* Line 1464 of yacc.c  */
#line 2618 "parser.y"
    { ((yyval.pnode) = p_wire2 (p_insert, (yyloc), (yyvsp[(2) - (4)].pnode), (yyvsp[(4) - (4)].pnode)))
                                  ->sem.insert = (yyvsp[(3) - (4)].insert); }
    break;

  case 410:

/* Line 1464 of yacc.c  */
#line 2622 "parser.y"
    { (yyval.insert) = p_first_into; }
    break;

  case 411:

/* Line 1464 of yacc.c  */
#line 2623 "parser.y"
    { (yyval.insert) = p_last_into; }
    break;

  case 412:

/* Line 1464 of yacc.c  */
#line 2624 "parser.y"
    { (yyval.insert) = p_into; }
    break;

  case 413:

/* Line 1464 of yacc.c  */
#line 2625 "parser.y"
    { (yyval.insert) = p_after; }
    break;

  case 414:

/* Line 1464 of yacc.c  */
#line 2626 "parser.y"
    { (yyval.insert) = p_before; }
    break;

  case 415:

/* Line 1464 of yacc.c  */
#line 2631 "parser.y"
    { (yyval.pnode) = p_wire1 (p_delete, (yyloc), (yyvsp[(2) - (2)].pnode)); }
    break;

  case 416:

/* Line 1464 of yacc.c  */
#line 2636 "parser.y"
    { ((yyval.pnode) = p_wire2 (p_replace, (yyloc), (yyvsp[(2) - (4)].pnode), (yyvsp[(4) - (4)].pnode)))
                                  ->sem.tru = false; }
    break;

  case 417:

/* Line 1464 of yacc.c  */
#line 2639 "parser.y"
    { ((yyval.pnode) = p_wire2 (p_replace, (yyloc), (yyvsp[(2) - (4)].pnode), (yyvsp[(4) - (4)].pnode)))
                                  ->sem.tru = true; }
    break;

  case 418:

/* Line 1464 of yacc.c  */
#line 2649 "parser.y"
    { (yyval.pnode) = p_wire2 (p_rename, (yyloc), (yyvsp[(2) - (4)].pnode), (yyvsp[(4) - (4)].pnode)); }
    break;

  case 419:

/* Line 1464 of yacc.c  */
#line 2653 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 420:

/* Line 1464 of yacc.c  */
#line 2657 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 421:

/* Line 1464 of yacc.c  */
#line 2661 "parser.y"
    { (yyval.pnode) = (yyvsp[(1) - (1)].pnode); }
    break;

  case 422:

/* Line 1464 of yacc.c  */
#line 2667 "parser.y"
    { (yyval.pnode) = p_wire2 (p_transform, (yyloc),
                                     (yyvsp[(2) - (6)].pnode),
                                     p_wire2 (p_modify, loc_rng ((yylsp[(3) - (6)]), (yylsp[(6) - (6)])),
                                              (yyvsp[(4) - (6)].pnode), (yyvsp[(6) - (6)].pnode))); }
    break;

  case 423:

/* Line 1464 of yacc.c  */
#line 2674 "parser.y"
    { (yyval.pnode) = p_wire2 (p_transbinds, (yyloc), (yyvsp[(1) - (1)].pnode), nil ((yyloc))); }
    break;

  case 424:

/* Line 1464 of yacc.c  */
#line 2676 "parser.y"
    { (yyval.pnode) = p_wire2 (p_transbinds, (yyloc), (yyvsp[(1) - (3)].pnode), (yyvsp[(3) - (3)].pnode)); }
    break;

  case 425:

/* Line 1464 of yacc.c  */
#line 2680 "parser.y"
    { (yyval.pnode) = p_wire2 (p_let, (yyloc),
                                     p_wire2 (p_var_type, (yylsp[(1) - (3)]), (yyvsp[(1) - (3)].pnode), nil ((yylsp[(1) - (3)]))),
                                     (yyvsp[(3) - (3)].pnode)); }
    break;

  case 426:

/* Line 1464 of yacc.c  */
#line 2688 "parser.y"
    { (yyval.pnode) = wire2 (p_recursion, (yyloc),
                                     (yyvsp[(2) - (6)].pnode),
                                     wire2 (p_seed, (yyloc), (yyvsp[(4) - (6)].pnode), (yyvsp[(6) - (6)].pnode))); }
    break;

  case 427:

/* Line 1464 of yacc.c  */
#line 2694 "parser.y"
    { (yyval.pnode) = wire2 (p_var_type, (yyloc), (yyvsp[(1) - (2)].pnode), (yyvsp[(2) - (2)].pnode)); }
    break;

  case 428:

/* Line 1464 of yacc.c  */
#line 2700 "parser.y"
    { (yyval.pnode) = wire2 (p_xrpc, (yyloc), (yyvsp[(3) - (7)].pnode), (yyvsp[(6) - (7)].pnode)); }
    break;

  case 429:

/* Line 1464 of yacc.c  */
#line 2702 "parser.y"
    { (yyval.pnode) = wire2 (p_xrpc, 
                                          (yyloc), 
                                          (c = leaf (p_lit_str, (yylsp[(2) - (5)])),
                                           c->sem.str = (yyvsp[(2) - (5)].str),
                                           c), 
                                          (yyvsp[(4) - (5)].pnode)); 
                            }
    break;



/* Line 1464 of yacc.c  */
#line 6601 "y.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }

  yyerror_range[1] = yylloc;

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval, &yylloc);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  yyerror_range[1] = yylsp[1-yylen];
  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp, yylsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;

  yyerror_range[2] = yylloc;
  /* Using YYLLOC is tempting, but would change the location of
     the lookahead.  YYLOC is available though.  */
  YYLLOC_DEFAULT (yyloc, yyerror_range, 2);
  *++yylsp = yyloc;

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval, &yylloc);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp, yylsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 1684 of yacc.c  */
#line 2712 "parser.y"


/** 
 * Check if the input string consists of whitespace only.
 * If this is the case and @c PFquery->pres_boundary_space
 * is set to false, the abstract syntax tree must be altered,
 * i.e., we do not create a text node but an empty sequence node.
 *
 * @param s string to test for non-whitespace characters
 * @return true if @c s consists of whitespace only
 */
static bool
is_whitespace (unsigned char *s)
{
    while (*s)
        if (! isspace (*s))
            return false;     
        else
            s++;

    return true;              
}
    
/**                            
 * Recursively flatten a location path @a p
 * (call this function with @a r initially @c NULL).
 *
 * @param p (possibly nested) location path
 * @param r ``Hole'' that will be filled during recursive calls.
 *          Call with @a r = @c NULL from outside.
 * @return flat location path
 */
static PFpnode_t *
flatten_locpath (PFpnode_t *p, PFpnode_t *r)
{
    if (p->kind == p_locpath) {
        if (r)
            switch (p->child[1]->kind) {
                case p_dot:
                    p->child[1] = r;
                    p->loc = max_loc(p->loc, r->loc);
                    break;
                case p_locpath:
                    p->child[1] = flatten_locpath (p->child[1], r);
                    break;
                default:
                    p->child[1] = wire2 (p_locpath,
                            max_loc (p->child[1]->loc, r->loc),
                            p->child[1], r);
            }
        if (p->child[0]->kind == p_locpath)
            return flatten_locpath (p->child[0], p->child[1]);
    }
    return p;
}

/**
 * Add an item to the work list of modules to import.  If it is
 * already in there, do nothing.
 *
 * @param id   namespace id
 * @param ns   namespace associated with this module
 * @param uri  URI where we will find the module definition.
 *
 *  import module [prefix =] ns at uri, uri, uri...
 */
static void
add_to_module_wl (char*id, char *ns, char *uri)
{
    for (unsigned int i = 0; i < PFarray_last (modules); i++)
        if ( !strcmp (((module_t *) PFarray_at (modules, i))->uri, uri) )
            return;

    *(module_t *) PFarray_add (modules)
        = (module_t) { .id = PFstrdup(id), .ns = PFstrdup (ns),
                       .uri = PFstrdup (uri) };
}

/**
 * Invoked by bison whenever a parsing error occurs.
 */
void pferror (const char *s)
{
    if (pftext && *pftext)
        PFinfo (OOPS_PARSE,
                "%s on line %d, column %d (next token is `%s')",
                s, cur_row, cur_col,
                pftext);
    else
        PFinfo (OOPS_PARSE,
                "%s on line %d, column %d",
                s, cur_row, cur_col);
}

char* pfinput = NULL; /* standard input of scanner, used by flex */
YYLTYPE pflloc; /* why ? */

/**
 * Parse an XQuery from the main-memory buffer pointed to by @a input.
 */
void
PFparse (char *input, PFpnode_t **r, PFquery_t *query, bool standoff)
{
#if YYDEBUG
    pfdebug = 1;
#endif
    PFquery = query;
    standoff_axis_steps = standoff;

    /* initialize lexical scanner */
    PFscanner_init (input);

    /* initialize work list of modules to load */
    modules = PFarray_default (sizeof (module_t));
    
    /* we don't explicitly ask for modules */
    module_only = false;
    current_uri = NULL;

    /* initialisation of yylloc */
    pflloc.first_row = pflloc.last_row = 1;
    pflloc.first_col = pflloc.last_col = 0;

    if (pfparse ())
        PFoops (OOPS_PARSE, "XQuery parsing failed");

    *r = root;
}

/**
 * Load and parse the module located at @a uri (has to be associated
 * with namespace @a ns).
 */
static PFpnode_t *
parse_module (char *ns, char *uri)
{
    char *buf = PFurlcache (uri, 1);

    if (buf == NULL)
        PFoops (OOPS_MODULEIMPORT, "error loading module from %s", uri);

    /*
     * remember the URI that we are currently parsing.  We will leave
     * this information in p_lib_mod nodes.
     */
    current_uri = uri;

    /* file is now loaded into main-memory */
    PFscanner_init (buf);

    /* initialisation of yylloc */
    pflloc.first_row = pflloc.last_row = 1;
    pflloc.first_col = pflloc.last_col = 0;
    
    req_module_ns = ns;

    if (pfparse ())
        PFoops (OOPS_PARSE, "error parsing module from %s", uri);

    return root;
}

/* initialize global variables */
void
PFparser_init (void)
{
    module_only = false;

    req_module_ns = NULL;
    current_uri = NULL;
    modules = NULL;
}

/**
 * Load and parse modules listed in working list and put them into
 * the parse tree @a r.
 */
void
PFparse_modules (PFpnode_t *r, PFquery_t *query, bool standoff)
{
    PFpnode_t *module;
    PFloc_t    noloc = (PFloc_t) { .first_row = 0, .first_col = 0,
                                   .last_row  = 0, .last_col  = 0};
    PFquery = query;
    standoff_axis_steps = standoff;

    /* only accept module from now on */
    module_only = true;

    for (unsigned int i = 0; i < PFarray_last (modules); i++) {

        module = parse_module (((module_t *) PFarray_at (modules, i))->ns,
                               ((module_t *) PFarray_at (modules, i))->uri);
        req_module_ns = NULL;

        /*
         * declarations are the left child of the root for queries,
         * right child otherwise.
         */
        if (r->kind == p_main_mod)
            r->child[0]
                = wire2 (p_decl_imps, noloc, module, r->child[0]);
        else
            r->child[1]
                = wire2 (p_decl_imps, noloc, module, r->child[1]);
    }
}

/* vim:set shiftwidth=4 expandtab: */

