#line 1 "milgen.brg"


/* Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.pathfinder-xquery.org/license
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2011 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *//**
 *
 * @file
 *
 * @brief Compile physical algebra tree into a MIL program
 *        (see also the @ref milgenDetail page).
 *
 * @page milgenDetail MIL Code generation
 *
 * @section phys2mil Physical algebra to MIL Code compilation
 *
 * The compilation from physical algebra is controlled by the function
 * #PFmilgen() and a Burg pattern matcher. It registers a global variable
 * #milprog which stores a MIL tree that is build during a bottom-up
 * traversal of the physical algebra DAG. The preferred way to extend
 * the MIL program is to use the macro #execute() which appends the new
 * commands to the MIL program. (More high-level information can be found
 * in the @ref milgenOverview Section in algebra.c.)
 *
 * MIL variables are used to provide for each operator, logical column,
 * and type the correct ``named'' BAT representations. We extend at compile
 * time every physical operator with a variable environment (#env_t) that maps
 * (column name, type) pairs to MIL variable names.
 *
 * The compilation procedure thus has to provide for each operator
 * -# the action code (by extending the MIL program) and
 *    .
 * -# has to fill the variable environment <code>p->env</code>
 *    (with the MIL variables used in the action code to store
 *     the result).
 *
 * If the environments are filled correctly every consuming parent operator
 * can refer to the result of its child by accessing the MIL variables in
 * the environment of its children. The bottom-up traversal ensures that
 * at runtime the respective MIL variables are already evaluated and visible.
 *
 * @subsection pin Pinning and Unpinning MIL variables
 *
 * We try to make use of variables as often as possible. We therefore keep
 * track which variables are already generated and how often they are going
 * to be used (pinned). As soon as a variable is not pinned anymore it will
 * be reused.
 *
 * If an operator needs local variables it can get a new free one from the
 * variable pool using the function #new_var() and an arbitrary pin count.
 * This pinned variable can be released at the end of the operator code again
 * by issuing #unpin() with the same count.
 *
 * Variables that are used to represent the result of an operator have
 * to pinned with <code>p->refctr</code> (the number of consuming parents).
 * For these variables is done automatically after the consumption.
 *
 */

#include "pf_config.h"
#include "pathfinder.h"

#include <assert.h>
#include <string.h>

#include "oops.h"
#include "mem.h"

#include "physical.h"
#include "alg_dag.h"
#include "properties.h"
#include "mil.h"
/* XRPC function call context */
#include "core.h"
/* use global options to lookup session information */
#include "options.h"

/* abbreviate MIL constructor calls */
#include "mil_mnemonic.h"

/* mnemonic column list accessors */
#include "alg_cl_mnemonic.h"

/* Easily access subtree-parts */
#include "child_mnemonic.h"

/* fold( define burg accessors */
/** @cond BRG */ /* make doxygen ignore brg specific code */

/* Accessors for the burg matcher */
typedef struct PFpa_op_t *NODEPTR_TYPE;

/* accessor to the node kind */
#define OP_LABEL(p)    ((p)->kind)

/* accessors to left and right child node */
#define LEFT_CHILD(p)  ((p)->child[0])
#define RIGHT_CHILD(p) ((p)->child[1])

/* the state determined during bottom-up labeling is stored here */
#define STATE_LABEL(p) ((p)->state_label)

/* If something goes wrong, call PFoops */
#define PANIC(...) PFoops (OOPS_BURG, __VA_ARGS__)

/** @endcond BRG */ /* make doxygen ignore brg specific code */
/* fold) */

#ifndef PFmilgen_PANIC
#define PFmilgen_PANIC	PANIC
#endif /* PFmilgen_PANIC */
#include <stdlib.h> /* for abort() */
#ifdef NDEBUG
#define PFmilgen_assert(x,y)	;
#else
#define PFmilgen_assert(x,y)	if(!(x)) {y; abort();}
#endif
static short PFmilgen_r1_nts[] ={ 5, 2, 0 };
static short PFmilgen_r2_nts[] ={ 5, 0 };
static short PFmilgen_r8_nts[] ={ 0 };
static short PFmilgen_r10_nts[] ={ 2, 0 };
static short PFmilgen_r11_nts[] ={ 2, 2, 0 };
static short PFmilgen_r102_nts[] ={ 4, 0 };
static short PFmilgen_r105_nts[] ={ 4, 3, 0 };
static short PFmilgen_r108_nts[] ={ 2, 3, 0 };
static short PFmilgen_r135_nts[] ={ 5, 2, 2, 6, 0 };
static short PFmilgen_r136_nts[] ={ 5, 2, 2, 0 };
static short PFmilgen_r137_nts[] ={ 2, 6, 0 };
static short PFmilgen_r140_nts[] ={ 5, 7, 2, 0 };
static short PFmilgen_r141_nts[] ={ 2, 2, 7, 0 };
static short PFmilgen_r142_nts[] ={ 2, 7, 0 };
static short PFmilgen_r150_nts[] ={ 8, 0 };
static short PFmilgen_r151_nts[] ={ 2, 9, 0 };
short *PFmilgen_nts[] = {
	0,
	PFmilgen_r1_nts,
	PFmilgen_r2_nts,
	0,
	0,
	0,
	0,
	0,
	PFmilgen_r8_nts,
	PFmilgen_r8_nts,
	PFmilgen_r10_nts,
	PFmilgen_r11_nts,
	PFmilgen_r11_nts,
	PFmilgen_r10_nts,
	PFmilgen_r11_nts,
	PFmilgen_r11_nts,
	PFmilgen_r11_nts,
	PFmilgen_r11_nts,
	PFmilgen_r11_nts,
	PFmilgen_r11_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r11_nts,
	PFmilgen_r11_nts,
	PFmilgen_r11_nts,
	PFmilgen_r11_nts,
	0,
	0,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	0,
	0,
	0,
	0,
	0,
	PFmilgen_r10_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFmilgen_r10_nts,
	0,
	PFmilgen_r10_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	0,
	PFmilgen_r10_nts,
	PFmilgen_r11_nts,
	PFmilgen_r10_nts,
	0,
	0,
	0,
	0,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r102_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r105_nts,
	PFmilgen_r102_nts,
	PFmilgen_r10_nts,
	PFmilgen_r108_nts,
	PFmilgen_r10_nts,
	PFmilgen_r108_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFmilgen_r1_nts,
	PFmilgen_r8_nts,
	PFmilgen_r1_nts,
	PFmilgen_r10_nts,
	0,
	0,
	PFmilgen_r135_nts,
	PFmilgen_r136_nts,
	PFmilgen_r137_nts,
	PFmilgen_r10_nts,
	0,
	PFmilgen_r140_nts,
	PFmilgen_r141_nts,
	PFmilgen_r142_nts,
	PFmilgen_r8_nts,
	PFmilgen_r8_nts,
	PFmilgen_r10_nts,
	0,
	0,
	0,
	0,
	PFmilgen_r150_nts,
	PFmilgen_r151_nts,
	PFmilgen_r151_nts,
	0,
	PFmilgen_r8_nts,
	0,
	0,
	0,
	0,
	0,
	PFmilgen_r11_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFmilgen_r10_nts,
	PFmilgen_r10_nts,
};
static unsigned char PFmilgen_serialize_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFmilgen_cross_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_dep_cross_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_leftjoin_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_eqjoin_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_semijoin_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_thetajoin_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_unq2_thetajoin_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_unq1_thetajoin_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_append_union_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_merge_union_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_intersect_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_difference_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_count_ext_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_fcns_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFmilgen_docnode_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFmilgen_element_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFmilgen_error_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_cache_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_trace_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFmilgen_trace_items_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFmilgen_trace_msg_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFmilgen_trace_map_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFmilgen_rec_fix_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_side_effects_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_rec_param_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */,
{    0,    2}	/* row 2 */
};
static unsigned char PFmilgen_rec_arg_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    2}	/* row 1 */,
{    0,    1}	/* row 2 */
};
static unsigned char PFmilgen_fun_call_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_fun_param_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFmilgen_string_join_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static struct {
	unsigned int f12:2;
	unsigned int f13:2;
	unsigned int f14:2;
	unsigned int f15:2;
	unsigned int f16:2;
	unsigned int f17:3;
	unsigned int f18:2;
	unsigned int f19:3;
	unsigned int f20:4;
	unsigned int f21:2;
	unsigned int f22:6;
	unsigned int f23:2;
} PFmilgen_plank_0[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  40,   0,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  57,   0,},	/* row 2 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  21,   0,},	/* row 3 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,},	/* row 4 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  44,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  45,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  43,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   8,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  32,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  10,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   9,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  41,   0,},	/* row 13 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  20,   0,},	/* row 14 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  18,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  19,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  54,   0,},	/* row 17 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  28,   0,},	/* row 18 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  29,   0,},	/* row 19 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   7,   0,   0,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   6,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,   0,},	/* row 22 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  22,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  47,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  16,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 28 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 30 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  48,   0,},	/* row 31 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   4,   0,},	/* row 32 */
	{   0,   0,   1,   2,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 33 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  46,   0,},	/* row 34 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  55,   0,},	/* row 35 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  17,   0,},	/* row 36 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  23,   0,},	/* row 37 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  31,   0,},	/* row 38 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  30,   0,},	/* row 39 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  39,   0,},	/* row 40 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  35,   0,},	/* row 41 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  24,   0,},	/* row 42 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  56,   0,},	/* row 43 */
	{   1,   0,   1,   1,   0,   1,   0,   3,   0,   0,   0,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  11,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  38,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  37,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  36,   0,},	/* row 49 */
	{   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   6,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   7,   0,},	/* row 54 */
	{   1,   0,   0,   0,   0,   3,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   1,   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  49,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   9,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  10,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   8,   0,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  51,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  52,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  53,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  50,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  14,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  42,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  27,   0,},	/* row 81 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  25,   0,},	/* row 82 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  26,   0,},	/* row 83 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  34,   0,},	/* row 84 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  33,   0,},	/* row 85 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  12,   0,},	/* row 86 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  13,   0,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  58,   0,},	/* row 88 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  15,   0,},	/* row 89 */
};
static struct {
	unsigned int f0:2;
	unsigned int f1:2;
	unsigned int f2:2;
	unsigned int f3:2;
	unsigned int f4:2;
	unsigned int f5:2;
	unsigned int f6:2;
	unsigned int f7:2;
	unsigned int f8:2;
	unsigned int f9:2;
	unsigned int f10:2;
	unsigned int f11:2;
} PFmilgen_plank_1[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 3 */
	{   0,   0,   0,   0,   0,   3,   1,   0,   0,   0,   0,   0,},	/* row 4 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 5 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 18 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 19 */
	{   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,},	/* row 22 */
	{   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   2,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 28 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 29 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 31 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 32 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 33 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 34 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 35 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 36 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 37 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 38 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 39 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 40 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 41 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 42 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 43 */
	{   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,   1,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,},	/* row 45 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 46 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   1,   1,   1,   3,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 62 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 66 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   1,   1,   2,   2,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   2,   1,   0,   0,   0,   0,   0,},	/* row 70 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 80 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 81 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 82 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 83 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 84 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 85 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 86 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 87 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   1,   1,   3,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 89 */
};
static short PFmilgen_eruleMap[] = {
    0,  105,  106,    0,  151,    0,  138,  137,    0,  154,	/* 0-9 */
  152,    0,    2,    1,    0,  143,  142,  141,    0,   16,	/* 10-19 */
  170,  160,  150,  145,  144,  140,  132,   22,   21,   20,	/* 20-29 */
   19,   18,   17,  171,   15,   14,   13,   12,   11,   10,	/* 30-39 */
    9,    8,  117,  104,  103,  102,  101,  100,   91,   90,	/* 40-49 */
   78,   77,   76,   75,   74,   73,   72,   71,   66,   65,	/* 50-59 */
   64,   62,   61,   60,   52,   50,   40,   34,   33,   32,	/* 60-69 */
   31,   30,   27,   26,   25,   24,   23,    0,  129,  135,	/* 70-79 */
  130,  131,  136,    0,  114,  112,  111,  110,  109,  108,	/* 80-89 */
  107,  116,  115,  113
};
#define PFmilgen_Query_rule(state)	PFmilgen_eruleMap[PFmilgen_plank_0[state].f23 +11]
#define PFmilgen_Rel_rule(state)	PFmilgen_eruleMap[PFmilgen_plank_0[state].f22 +18]
#define PFmilgen_Fcns_rule(state)	PFmilgen_eruleMap[PFmilgen_plank_0[state].f21 +0]
#define PFmilgen_Twig_rule(state)	PFmilgen_eruleMap[PFmilgen_plank_0[state].f20 +83]
#define PFmilgen_Side_rule(state)	PFmilgen_eruleMap[PFmilgen_plank_0[state].f19 +77]
#define PFmilgen_Map_rule(state)	PFmilgen_eruleMap[PFmilgen_plank_0[state].f18 +5]
#define PFmilgen_Rec_rule(state)	PFmilgen_eruleMap[PFmilgen_plank_0[state].f17 +14]
#define PFmilgen_FunRel_rule(state)	PFmilgen_eruleMap[PFmilgen_plank_0[state].f16 +3]
#define PFmilgen_Param_rule(state)	PFmilgen_eruleMap[PFmilgen_plank_0[state].f15 +8]

#ifdef __STDC__
int PFmilgen_rule(int state, int goalnt) {
#else
int PFmilgen_rule(state, goalnt) int state; int goalnt; {
#endif
	PFmilgen_assert(state >= 0 && state < 90, PFmilgen_PANIC("Bad state %d passed to PFmilgen_rule\n", state));
	switch(goalnt) {
	case 1:
		return PFmilgen_Query_rule(state);
	case 2:
		return PFmilgen_Rel_rule(state);
	case 3:
		return PFmilgen_Fcns_rule(state);
	case 4:
		return PFmilgen_Twig_rule(state);
	case 5:
		return PFmilgen_Side_rule(state);
	case 6:
		return PFmilgen_Map_rule(state);
	case 7:
		return PFmilgen_Rec_rule(state);
	case 8:
		return PFmilgen_FunRel_rule(state);
	case 9:
		return PFmilgen_Param_rule(state);
	default:
		PFmilgen_PANIC("Unknown nonterminal %d in PFmilgen_rule;\n", goalnt);
		abort();
		return 0;
	}
}

int PFmilgen_TEMP;
#define PFmilgen_serialize_state(l,r)	( (PFmilgen_TEMP = PFmilgen_serialize_transition[PFmilgen_plank_1[l].f0][PFmilgen_plank_1[r].f1]) ? PFmilgen_TEMP + 59 : 0 )
#define PFmilgen_lit_tbl_state	37
#define PFmilgen_empty_tbl_state	24
#define PFmilgen_attach_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 2 : 0 )
#define PFmilgen_cross_state(l,r)	( (PFmilgen_TEMP = PFmilgen_cross_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 13 : 0 )
#define PFmilgen_dep_cross_state(l,r)	( (PFmilgen_TEMP = PFmilgen_dep_cross_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 15 : 0 )
#define PFmilgen_dep_border_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 14 : 0 )
#define PFmilgen_leftjoin_state(l,r)	( (PFmilgen_TEMP = PFmilgen_leftjoin_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 35 : 0 )
#define PFmilgen_eqjoin_state(l,r)	( (PFmilgen_TEMP = PFmilgen_eqjoin_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 25 : 0 )
#define PFmilgen_semijoin_state(l,r)	( (PFmilgen_TEMP = PFmilgen_semijoin_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 58 : 0 )
#define PFmilgen_thetajoin_state(l,r)	( (PFmilgen_TEMP = PFmilgen_thetajoin_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 70 : 0 )
#define PFmilgen_unq2_thetajoin_state(l,r)	( (PFmilgen_TEMP = PFmilgen_unq2_thetajoin_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 86 : 0 )
#define PFmilgen_unq1_thetajoin_state(l,r)	( (PFmilgen_TEMP = PFmilgen_unq1_thetajoin_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 85 : 0 )
#define PFmilgen_project_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 45 : 0 )
#define PFmilgen_slice_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 62 : 0 )
#define PFmilgen_select_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 57 : 0 )
#define PFmilgen_val_select_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 87 : 0 )
#define PFmilgen_append_union_state(l,r)	( (PFmilgen_TEMP = PFmilgen_append_union_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 1 : 0 )
#define PFmilgen_merge_union_state(l,r)	( (PFmilgen_TEMP = PFmilgen_merge_union_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 42 : 0 )
#define PFmilgen_intersect_state(l,r)	( (PFmilgen_TEMP = PFmilgen_intersect_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 34 : 0 )
#define PFmilgen_difference_state(l,r)	( (PFmilgen_TEMP = PFmilgen_difference_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 16 : 0 )
#define PFmilgen_sort_distinct_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f3) ? PFmilgen_TEMP + 64 : 0 )
#define PFmilgen_std_sort_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 67 : 0 )
#define PFmilgen_refine_sort_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 56 : 0 )
#define PFmilgen_fun_1to1_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 30 : 0 )
#define PFmilgen_eq_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 24 : 0 )
#define PFmilgen_gt_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 33 : 0 )
#define PFmilgen_bool_not_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 5 : 0 )
#define PFmilgen_bool_and_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 4 : 0 )
#define PFmilgen_bool_or_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 6 : 0 )
#define PFmilgen_to_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 71 : 0 )
#define PFmilgen_count_ext_state(l,r)	( (PFmilgen_TEMP = PFmilgen_count_ext_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 12 : 0 )
#define PFmilgen_aggr_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 0 : 0 )
#define PFmilgen_mark_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 39 : 0 )
#define PFmilgen_rank_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f4) ? PFmilgen_TEMP + 46 : 0 )
#define PFmilgen_mark_grp_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 40 : 0 )
#define PFmilgen_type_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 83 : 0 )
#define PFmilgen_type_assert_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 84 : 0 )
#define PFmilgen_cast_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 9 : 0 )
#define PFmilgen_llscjoin_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 37 : 0 )
#define PFmilgen_llscjoin_dup_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 38 : 0 )
#define PFmilgen_doc_tbl_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 18 : 0 )
#define PFmilgen_doc_access_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 17 : 0 )
#define PFmilgen_twig_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f5) ? PFmilgen_TEMP + 80 : 0 )
#define PFmilgen_fcns_state(l,r)	( (PFmilgen_TEMP = PFmilgen_fcns_transition[PFmilgen_plank_1[l].f6][PFmilgen_plank_1[r].f7]) ? PFmilgen_TEMP + 27 : 0 )
#define PFmilgen_docnode_state(l,r)	( (PFmilgen_TEMP = PFmilgen_docnode_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f7]) ? PFmilgen_TEMP + 19 : 0 )
#define PFmilgen_element_state(l,r)	( (PFmilgen_TEMP = PFmilgen_element_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f7]) ? PFmilgen_TEMP + 21 : 0 )
#define PFmilgen_attribute_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 3 : 0 )
#define PFmilgen_textnode_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 69 : 0 )
#define PFmilgen_comment_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 10 : 0 )
#define PFmilgen_processi_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 44 : 0 )
#define PFmilgen_content_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 11 : 0 )
#define PFmilgen_slim_content_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 63 : 0 )
#define PFmilgen_merge_adjacent_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 41 : 0 )
#define PFmilgen_error_state(l,r)	( (PFmilgen_TEMP = PFmilgen_error_transition[PFmilgen_plank_1[l].f0][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 26 : 0 )
#define PFmilgen_nil_state	44
#define PFmilgen_cache_state(l,r)	( (PFmilgen_TEMP = PFmilgen_cache_transition[PFmilgen_plank_1[l].f0][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 7 : 0 )
#define PFmilgen_cache_border_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 8 : 0 )
#define PFmilgen_trace_state(l,r)	( (PFmilgen_TEMP = PFmilgen_trace_transition[PFmilgen_plank_1[l].f0][PFmilgen_plank_1[r].f8]) ? PFmilgen_TEMP + 72 : 0 )
#define PFmilgen_trace_items_state(l,r)	( (PFmilgen_TEMP = PFmilgen_trace_items_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f9]) ? PFmilgen_TEMP + 74 : 0 )
#define PFmilgen_trace_msg_state(l,r)	( (PFmilgen_TEMP = PFmilgen_trace_msg_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f10]) ? PFmilgen_TEMP + 78 : 0 )
#define PFmilgen_trace_map_state(l,r)	( (PFmilgen_TEMP = PFmilgen_trace_map_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f10]) ? PFmilgen_TEMP + 76 : 0 )
#define PFmilgen_rec_fix_state(l,r)	( (PFmilgen_TEMP = PFmilgen_rec_fix_transition[PFmilgen_plank_1[l].f11][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 53 : 0 )
#define PFmilgen_side_effects_state(l,r)	( (PFmilgen_TEMP = PFmilgen_side_effects_transition[PFmilgen_plank_1[l].f0][PFmilgen_plank_0[r].f12]) ? PFmilgen_TEMP + 61 : 0 )
#define PFmilgen_rec_param_state(l,r)	( (PFmilgen_TEMP = PFmilgen_rec_param_transition[PFmilgen_plank_0[l].f13][PFmilgen_plank_0[r].f12]) ? PFmilgen_TEMP + 54 : 0 )
#define PFmilgen_rec_arg_state(l,r)	( (PFmilgen_TEMP = PFmilgen_rec_arg_transition[PFmilgen_plank_1[l].f1][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 49 : 0 )
#define PFmilgen_rec_base_state	52
#define PFmilgen_rec_border_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 52 : 0 )
#define PFmilgen_fun_call_state(l,r)	( (PFmilgen_TEMP = PFmilgen_fun_call_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_0[r].f14]) ? PFmilgen_TEMP + 31 : 0 )
#define PFmilgen_fun_param_state(l,r)	( (PFmilgen_TEMP = PFmilgen_fun_param_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_0[r].f14]) ? PFmilgen_TEMP + 32 : 0 )
#define PFmilgen_string_join_state(l,r)	( (PFmilgen_TEMP = PFmilgen_string_join_transition[PFmilgen_plank_1[l].f2][PFmilgen_plank_1[r].f2]) ? PFmilgen_TEMP + 68 : 0 )
#define PFmilgen_findnodes_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 29 : 0 )
#define PFmilgen_vx_lookup_state(l)	( (PFmilgen_TEMP = PFmilgen_plank_1[l].f2) ? PFmilgen_TEMP + 88 : 0 )

#ifdef __STDC__
int PFmilgen_state(int op, int l, int r) {
#else
int PFmilgen_state(op, l, r) int op; int l; int r; {
#endif
	register int PFmilgen_TEMP;
#ifndef NDEBUG
	switch (op) {
	case 1:
	case 10:
	case 11:
	case 13:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 23:
	case 24:
	case 25:
	case 26:
	case 54:
	case 123:
	case 124:
	case 125:
	case 137:
	case 139:
	case 141:
	case 142:
	case 143:
	case 144:
	case 145:
	case 146:
	case 147:
	case 148:
	case 151:
	case 152:
	case 160:
		PFmilgen_assert(r >= 0 && r < 90, PFmilgen_PANIC("Bad state %d passed to PFmilgen_state\n", r));
		/*FALLTHROUGH*/
	case 4:
	case 12:
	case 19:
	case 20:
	case 21:
	case 22:
	case 27:
	case 28:
	case 29:
	case 30:
	case 40:
	case 42:
	case 45:
	case 46:
	case 47:
	case 50:
	case 55:
	case 60:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 100:
	case 101:
	case 120:
	case 121:
	case 122:
	case 126:
	case 127:
	case 128:
	case 129:
	case 130:
	case 131:
	case 132:
	case 140:
	case 150:
	case 170:
	case 171:
		PFmilgen_assert(l >= 0 && l < 90, PFmilgen_PANIC("Bad state %d passed to PFmilgen_state\n", l));
		/*FALLTHROUGH*/
	case 2:
	case 3:
	case 138:
	case 149:
		break;
	}
#endif
	switch (op) {
	default: PFmilgen_PANIC("Unknown op %d in PFmilgen_state\n", op); abort(); return 0;
	case 1:
		return PFmilgen_serialize_state(l,r);
	case 2:
		return PFmilgen_lit_tbl_state;
	case 3:
		return PFmilgen_empty_tbl_state;
	case 4:
		return PFmilgen_attach_state(l);
	case 10:
		return PFmilgen_cross_state(l,r);
	case 11:
		return PFmilgen_dep_cross_state(l,r);
	case 12:
		return PFmilgen_dep_border_state(l);
	case 13:
		return PFmilgen_leftjoin_state(l,r);
	case 14:
		return PFmilgen_eqjoin_state(l,r);
	case 15:
		return PFmilgen_semijoin_state(l,r);
	case 16:
		return PFmilgen_thetajoin_state(l,r);
	case 17:
		return PFmilgen_unq2_thetajoin_state(l,r);
	case 18:
		return PFmilgen_unq1_thetajoin_state(l,r);
	case 19:
		return PFmilgen_project_state(l);
	case 20:
		return PFmilgen_slice_state(l);
	case 21:
		return PFmilgen_select_state(l);
	case 22:
		return PFmilgen_val_select_state(l);
	case 23:
		return PFmilgen_append_union_state(l,r);
	case 24:
		return PFmilgen_merge_union_state(l,r);
	case 25:
		return PFmilgen_intersect_state(l,r);
	case 26:
		return PFmilgen_difference_state(l,r);
	case 27:
		return PFmilgen_sort_distinct_state(l);
	case 28:
		return PFmilgen_std_sort_state(l);
	case 29:
		return PFmilgen_refine_sort_state(l);
	case 30:
		return PFmilgen_fun_1to1_state(l);
	case 40:
		return PFmilgen_eq_state(l);
	case 42:
		return PFmilgen_gt_state(l);
	case 45:
		return PFmilgen_bool_not_state(l);
	case 46:
		return PFmilgen_bool_and_state(l);
	case 47:
		return PFmilgen_bool_or_state(l);
	case 50:
		return PFmilgen_to_state(l);
	case 54:
		return PFmilgen_count_ext_state(l,r);
	case 55:
		return PFmilgen_aggr_state(l);
	case 60:
		return PFmilgen_mark_state(l);
	case 61:
		return PFmilgen_rank_state(l);
	case 62:
		return PFmilgen_mark_grp_state(l);
	case 63:
		return PFmilgen_type_state(l);
	case 64:
		return PFmilgen_type_assert_state(l);
	case 65:
		return PFmilgen_cast_state(l);
	case 100:
		return PFmilgen_llscjoin_state(l);
	case 101:
		return PFmilgen_llscjoin_dup_state(l);
	case 120:
		return PFmilgen_doc_tbl_state(l);
	case 121:
		return PFmilgen_doc_access_state(l);
	case 122:
		return PFmilgen_twig_state(l);
	case 123:
		return PFmilgen_fcns_state(l,r);
	case 124:
		return PFmilgen_docnode_state(l,r);
	case 125:
		return PFmilgen_element_state(l,r);
	case 126:
		return PFmilgen_attribute_state(l);
	case 127:
		return PFmilgen_textnode_state(l);
	case 128:
		return PFmilgen_comment_state(l);
	case 129:
		return PFmilgen_processi_state(l);
	case 130:
		return PFmilgen_content_state(l);
	case 131:
		return PFmilgen_slim_content_state(l);
	case 132:
		return PFmilgen_merge_adjacent_state(l);
	case 137:
		return PFmilgen_error_state(l,r);
	case 138:
		return PFmilgen_nil_state;
	case 139:
		return PFmilgen_cache_state(l,r);
	case 140:
		return PFmilgen_cache_border_state(l);
	case 141:
		return PFmilgen_trace_state(l,r);
	case 142:
		return PFmilgen_trace_items_state(l,r);
	case 143:
		return PFmilgen_trace_msg_state(l,r);
	case 144:
		return PFmilgen_trace_map_state(l,r);
	case 145:
		return PFmilgen_rec_fix_state(l,r);
	case 146:
		return PFmilgen_side_effects_state(l,r);
	case 147:
		return PFmilgen_rec_param_state(l,r);
	case 148:
		return PFmilgen_rec_arg_state(l,r);
	case 149:
		return PFmilgen_rec_base_state;
	case 150:
		return PFmilgen_rec_border_state(l);
	case 151:
		return PFmilgen_fun_call_state(l,r);
	case 152:
		return PFmilgen_fun_param_state(l,r);
	case 160:
		return PFmilgen_string_join_state(l,r);
	case 170:
		return PFmilgen_findnodes_state(l);
	case 171:
		return PFmilgen_vx_lookup_state(l);
	}
}
#ifdef PFmilgen_STATE_LABEL
#define PFmilgen_INCLUDE_EXTRA
#else
#ifdef STATE_LABEL
#define PFmilgen_INCLUDE_EXTRA
#define PFmilgen_STATE_LABEL 	STATE_LABEL
#define PFmilgen_NODEPTR_TYPE	NODEPTR_TYPE
#define PFmilgen_LEFT_CHILD  	LEFT_CHILD
#define PFmilgen_OP_LABEL    	OP_LABEL
#define PFmilgen_RIGHT_CHILD 	RIGHT_CHILD
#endif /* STATE_LABEL */
#endif /* PFmilgen_STATE_LABEL */

#ifdef PFmilgen_INCLUDE_EXTRA

#ifdef __STDC__
int PFmilgen_label(PFmilgen_NODEPTR_TYPE n) {
#else
int PFmilgen_label(n) PFmilgen_NODEPTR_TYPE n; {
#endif
	PFmilgen_assert(n, PFmilgen_PANIC("NULL pointer passed to PFmilgen_label\n"));
	switch (PFmilgen_OP_LABEL(n)) {
	default: PFmilgen_PANIC("Bad op %d in PFmilgen_label\n", PFmilgen_OP_LABEL(n)); abort(); return 0;
	case 2:
	case 3:
	case 138:
	case 149:
		return PFmilgen_STATE_LABEL(n) = PFmilgen_state(PFmilgen_OP_LABEL(n), 0, 0);
	case 4:
	case 12:
	case 19:
	case 20:
	case 21:
	case 22:
	case 27:
	case 28:
	case 29:
	case 30:
	case 40:
	case 42:
	case 45:
	case 46:
	case 47:
	case 50:
	case 55:
	case 60:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 100:
	case 101:
	case 120:
	case 121:
	case 122:
	case 126:
	case 127:
	case 128:
	case 129:
	case 130:
	case 131:
	case 132:
	case 140:
	case 150:
	case 170:
	case 171:
		return PFmilgen_STATE_LABEL(n) = PFmilgen_state(PFmilgen_OP_LABEL(n), PFmilgen_label(PFmilgen_LEFT_CHILD(n)), 0);
	case 1:
	case 10:
	case 11:
	case 13:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 23:
	case 24:
	case 25:
	case 26:
	case 54:
	case 123:
	case 124:
	case 125:
	case 137:
	case 139:
	case 141:
	case 142:
	case 143:
	case 144:
	case 145:
	case 146:
	case 147:
	case 148:
	case 151:
	case 152:
	case 160:
		return PFmilgen_STATE_LABEL(n) = PFmilgen_state(PFmilgen_OP_LABEL(n), PFmilgen_label(PFmilgen_LEFT_CHILD(n)), PFmilgen_label(PFmilgen_RIGHT_CHILD(n)));
	}
}
#ifdef __STDC__
PFmilgen_NODEPTR_TYPE * PFmilgen_kids(PFmilgen_NODEPTR_TYPE p, int rulenumber, PFmilgen_NODEPTR_TYPE *kids) {
#else
PFmilgen_NODEPTR_TYPE * PFmilgen_kids(p, rulenumber, kids) PFmilgen_NODEPTR_TYPE p; int rulenumber; PFmilgen_NODEPTR_TYPE *kids; {
#endif
	PFmilgen_assert(p, PFmilgen_PANIC("NULL node pointer passed to PFmilgen_kids\n"));
	PFmilgen_assert(kids, PFmilgen_PANIC("NULL kids pointer passed to PFmilgen_kids\n"));
	switch (rulenumber) {
	default:
		PFmilgen_PANIC("Unknown Rule %d in PFmilgen_kids;\n", rulenumber);
		abort();
		/* NOTREACHED */
	case 31:
	case 32:
	case 73:
	case 74:
	case 103:
	case 104:
		kids[0] = PFmilgen_LEFT_CHILD(PFmilgen_LEFT_CHILD(p));
		break;
	case 135:
		kids[0] = PFmilgen_LEFT_CHILD(p);
		kids[1] = PFmilgen_LEFT_CHILD(PFmilgen_RIGHT_CHILD(p));
		kids[2] = PFmilgen_LEFT_CHILD(PFmilgen_RIGHT_CHILD(PFmilgen_RIGHT_CHILD(p)));
		kids[3] = PFmilgen_RIGHT_CHILD(PFmilgen_RIGHT_CHILD(PFmilgen_RIGHT_CHILD(p)));
		break;
	case 136:
		kids[0] = PFmilgen_LEFT_CHILD(p);
		kids[1] = PFmilgen_LEFT_CHILD(PFmilgen_RIGHT_CHILD(p));
		kids[2] = PFmilgen_LEFT_CHILD(PFmilgen_RIGHT_CHILD(PFmilgen_RIGHT_CHILD(p)));
		break;
	case 140:
	case 141:
		kids[0] = PFmilgen_LEFT_CHILD(PFmilgen_LEFT_CHILD(p));
		kids[1] = PFmilgen_RIGHT_CHILD(PFmilgen_LEFT_CHILD(p));
		kids[2] = PFmilgen_RIGHT_CHILD(p);
		break;
	case 142:
		kids[0] = PFmilgen_RIGHT_CHILD(PFmilgen_LEFT_CHILD(p));
		kids[1] = PFmilgen_RIGHT_CHILD(p);
		break;
	case 150:
		kids[0] = p;
		break;
	case 8:
	case 9:
	case 130:
	case 143:
	case 144:
	case 154:
		break;
	case 1:
	case 11:
	case 12:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 24:
	case 25:
	case 26:
	case 27:
	case 65:
	case 105:
	case 108:
	case 110:
	case 129:
	case 131:
	case 137:
	case 151:
	case 152:
	case 160:
		kids[0] = PFmilgen_LEFT_CHILD(p);
		kids[1] = PFmilgen_RIGHT_CHILD(p);
		break;
	case 2:
	case 10:
	case 13:
	case 20:
	case 21:
	case 22:
	case 23:
	case 30:
	case 33:
	case 34:
	case 40:
	case 50:
	case 52:
	case 60:
	case 61:
	case 62:
	case 64:
	case 66:
	case 71:
	case 72:
	case 75:
	case 76:
	case 77:
	case 78:
	case 90:
	case 91:
	case 100:
	case 101:
	case 102:
	case 106:
	case 107:
	case 109:
	case 111:
	case 112:
	case 113:
	case 114:
	case 115:
	case 116:
	case 117:
	case 132:
	case 138:
	case 145:
	case 170:
	case 171:
		kids[0] = PFmilgen_LEFT_CHILD(p);
		break;
	}
	return kids;
}
#ifdef __STDC__
PFmilgen_NODEPTR_TYPE PFmilgen_child(PFmilgen_NODEPTR_TYPE p, int index) {
#else
PFmilgen_NODEPTR_TYPE PFmilgen_child(p, index) PFmilgen_NODEPTR_TYPE p; int index; {
#endif
	PFmilgen_assert(p, PFmilgen_PANIC("NULL pointer passed to PFmilgen_child\n"));
	switch (index) {
	case 0:
		return PFmilgen_LEFT_CHILD(p);
	case 1:
		return PFmilgen_RIGHT_CHILD(p);
	}
	PFmilgen_PANIC("Bad index %d in PFmilgen_child;\n", index);
	abort();
	return 0;
}
#ifdef __STDC__
int PFmilgen_op_label(PFmilgen_NODEPTR_TYPE p) {
#else
int PFmilgen_op_label(p) PFmilgen_NODEPTR_TYPE p; {
#endif
	PFmilgen_assert(p, PFmilgen_PANIC("NULL pointer passed to PFmilgen_op_label\n"));
	return PFmilgen_OP_LABEL(p);
}
#ifdef __STDC__
int PFmilgen_state_label(PFmilgen_NODEPTR_TYPE p) {
#else
int PFmilgen_state_label(p) PFmilgen_NODEPTR_TYPE p; {
#endif
	PFmilgen_assert(p, PFmilgen_PANIC("NULL pointer passed to PFmilgen_state_label\n"));
	return PFmilgen_STATE_LABEL(p);
}
#endif /* PFmilgen_INCLUDE_EXTRA */
#define PFmilgen_Param_NT 9
#define PFmilgen_FunRel_NT 8
#define PFmilgen_Rec_NT 7
#define PFmilgen_Map_NT 6
#define PFmilgen_Side_NT 5
#define PFmilgen_Twig_NT 4
#define PFmilgen_Fcns_NT 3
#define PFmilgen_Rel_NT 2
#define PFmilgen_Query_NT 1
#define PFmilgen_NT 9
char * PFmilgen_opname[] = {
	0, /* 0 */
	"serialize", /* 1 */
	"lit_tbl", /* 2 */
	"empty_tbl", /* 3 */
	"attach", /* 4 */
	0, /* 5 */
	0, /* 6 */
	0, /* 7 */
	0, /* 8 */
	0, /* 9 */
	"cross", /* 10 */
	"dep_cross", /* 11 */
	"dep_border", /* 12 */
	"leftjoin", /* 13 */
	"eqjoin", /* 14 */
	"semijoin", /* 15 */
	"thetajoin", /* 16 */
	"unq2_thetajoin", /* 17 */
	"unq1_thetajoin", /* 18 */
	"project", /* 19 */
	"slice", /* 20 */
	"select", /* 21 */
	"val_select", /* 22 */
	"append_union", /* 23 */
	"merge_union", /* 24 */
	"intersect", /* 25 */
	"difference", /* 26 */
	"sort_distinct", /* 27 */
	"std_sort", /* 28 */
	"refine_sort", /* 29 */
	"fun_1to1", /* 30 */
	0, /* 31 */
	0, /* 32 */
	0, /* 33 */
	0, /* 34 */
	0, /* 35 */
	0, /* 36 */
	0, /* 37 */
	0, /* 38 */
	0, /* 39 */
	"eq", /* 40 */
	0, /* 41 */
	"gt", /* 42 */
	0, /* 43 */
	0, /* 44 */
	"bool_not", /* 45 */
	"bool_and", /* 46 */
	"bool_or", /* 47 */
	0, /* 48 */
	0, /* 49 */
	"to", /* 50 */
	0, /* 51 */
	0, /* 52 */
	0, /* 53 */
	"count_ext", /* 54 */
	"aggr", /* 55 */
	0, /* 56 */
	0, /* 57 */
	0, /* 58 */
	0, /* 59 */
	"mark", /* 60 */
	"rank", /* 61 */
	"mark_grp", /* 62 */
	"type", /* 63 */
	"type_assert", /* 64 */
	"cast", /* 65 */
	0, /* 66 */
	0, /* 67 */
	0, /* 68 */
	0, /* 69 */
	0, /* 70 */
	0, /* 71 */
	0, /* 72 */
	0, /* 73 */
	0, /* 74 */
	0, /* 75 */
	0, /* 76 */
	0, /* 77 */
	0, /* 78 */
	0, /* 79 */
	0, /* 80 */
	0, /* 81 */
	0, /* 82 */
	0, /* 83 */
	0, /* 84 */
	0, /* 85 */
	0, /* 86 */
	0, /* 87 */
	0, /* 88 */
	0, /* 89 */
	0, /* 90 */
	0, /* 91 */
	0, /* 92 */
	0, /* 93 */
	0, /* 94 */
	0, /* 95 */
	0, /* 96 */
	0, /* 97 */
	0, /* 98 */
	0, /* 99 */
	"llscjoin", /* 100 */
	"llscjoin_dup", /* 101 */
	0, /* 102 */
	0, /* 103 */
	0, /* 104 */
	0, /* 105 */
	0, /* 106 */
	0, /* 107 */
	0, /* 108 */
	0, /* 109 */
	0, /* 110 */
	0, /* 111 */
	0, /* 112 */
	0, /* 113 */
	0, /* 114 */
	0, /* 115 */
	0, /* 116 */
	0, /* 117 */
	0, /* 118 */
	0, /* 119 */
	"doc_tbl", /* 120 */
	"doc_access", /* 121 */
	"twig", /* 122 */
	"fcns", /* 123 */
	"docnode", /* 124 */
	"element", /* 125 */
	"attribute", /* 126 */
	"textnode", /* 127 */
	"comment", /* 128 */
	"processi", /* 129 */
	"content", /* 130 */
	"slim_content", /* 131 */
	"merge_adjacent", /* 132 */
	0, /* 133 */
	0, /* 134 */
	0, /* 135 */
	0, /* 136 */
	"error", /* 137 */
	"nil", /* 138 */
	"cache", /* 139 */
	"cache_border", /* 140 */
	"trace", /* 141 */
	"trace_items", /* 142 */
	"trace_msg", /* 143 */
	"trace_map", /* 144 */
	"rec_fix", /* 145 */
	"side_effects", /* 146 */
	"rec_param", /* 147 */
	"rec_arg", /* 148 */
	"rec_base", /* 149 */
	"rec_border", /* 150 */
	"fun_call", /* 151 */
	"fun_param", /* 152 */
	0, /* 153 */
	0, /* 154 */
	0, /* 155 */
	0, /* 156 */
	0, /* 157 */
	0, /* 158 */
	0, /* 159 */
	"string_join", /* 160 */
	0, /* 161 */
	0, /* 162 */
	0, /* 163 */
	0, /* 164 */
	0, /* 165 */
	0, /* 166 */
	0, /* 167 */
	0, /* 168 */
	0, /* 169 */
	"findnodes", /* 170 */
	"vx_lookup"
};
char PFmilgen_arity[] = {
	-1, /* 0 */
	2, /* 1 */
	0, /* 2 */
	0, /* 3 */
	1, /* 4 */
	-1, /* 5 */
	-1, /* 6 */
	-1, /* 7 */
	-1, /* 8 */
	-1, /* 9 */
	2, /* 10 */
	2, /* 11 */
	1, /* 12 */
	2, /* 13 */
	2, /* 14 */
	2, /* 15 */
	2, /* 16 */
	2, /* 17 */
	2, /* 18 */
	1, /* 19 */
	1, /* 20 */
	1, /* 21 */
	1, /* 22 */
	2, /* 23 */
	2, /* 24 */
	2, /* 25 */
	2, /* 26 */
	1, /* 27 */
	1, /* 28 */
	1, /* 29 */
	1, /* 30 */
	-1, /* 31 */
	-1, /* 32 */
	-1, /* 33 */
	-1, /* 34 */
	-1, /* 35 */
	-1, /* 36 */
	-1, /* 37 */
	-1, /* 38 */
	-1, /* 39 */
	1, /* 40 */
	-1, /* 41 */
	1, /* 42 */
	-1, /* 43 */
	-1, /* 44 */
	1, /* 45 */
	1, /* 46 */
	1, /* 47 */
	-1, /* 48 */
	-1, /* 49 */
	1, /* 50 */
	-1, /* 51 */
	-1, /* 52 */
	-1, /* 53 */
	2, /* 54 */
	1, /* 55 */
	-1, /* 56 */
	-1, /* 57 */
	-1, /* 58 */
	-1, /* 59 */
	1, /* 60 */
	1, /* 61 */
	1, /* 62 */
	1, /* 63 */
	1, /* 64 */
	1, /* 65 */
	-1, /* 66 */
	-1, /* 67 */
	-1, /* 68 */
	-1, /* 69 */
	-1, /* 70 */
	-1, /* 71 */
	-1, /* 72 */
	-1, /* 73 */
	-1, /* 74 */
	-1, /* 75 */
	-1, /* 76 */
	-1, /* 77 */
	-1, /* 78 */
	-1, /* 79 */
	-1, /* 80 */
	-1, /* 81 */
	-1, /* 82 */
	-1, /* 83 */
	-1, /* 84 */
	-1, /* 85 */
	-1, /* 86 */
	-1, /* 87 */
	-1, /* 88 */
	-1, /* 89 */
	-1, /* 90 */
	-1, /* 91 */
	-1, /* 92 */
	-1, /* 93 */
	-1, /* 94 */
	-1, /* 95 */
	-1, /* 96 */
	-1, /* 97 */
	-1, /* 98 */
	-1, /* 99 */
	1, /* 100 */
	1, /* 101 */
	-1, /* 102 */
	-1, /* 103 */
	-1, /* 104 */
	-1, /* 105 */
	-1, /* 106 */
	-1, /* 107 */
	-1, /* 108 */
	-1, /* 109 */
	-1, /* 110 */
	-1, /* 111 */
	-1, /* 112 */
	-1, /* 113 */
	-1, /* 114 */
	-1, /* 115 */
	-1, /* 116 */
	-1, /* 117 */
	-1, /* 118 */
	-1, /* 119 */
	1, /* 120 */
	1, /* 121 */
	1, /* 122 */
	2, /* 123 */
	2, /* 124 */
	2, /* 125 */
	1, /* 126 */
	1, /* 127 */
	1, /* 128 */
	1, /* 129 */
	1, /* 130 */
	1, /* 131 */
	1, /* 132 */
	-1, /* 133 */
	-1, /* 134 */
	-1, /* 135 */
	-1, /* 136 */
	2, /* 137 */
	0, /* 138 */
	2, /* 139 */
	1, /* 140 */
	2, /* 141 */
	2, /* 142 */
	2, /* 143 */
	2, /* 144 */
	2, /* 145 */
	2, /* 146 */
	2, /* 147 */
	2, /* 148 */
	0, /* 149 */
	1, /* 150 */
	2, /* 151 */
	2, /* 152 */
	-1, /* 153 */
	-1, /* 154 */
	-1, /* 155 */
	-1, /* 156 */
	-1, /* 157 */
	-1, /* 158 */
	-1, /* 159 */
	2, /* 160 */
	-1, /* 161 */
	-1, /* 162 */
	-1, /* 163 */
	-1, /* 164 */
	-1, /* 165 */
	-1, /* 166 */
	-1, /* 167 */
	-1, /* 168 */
	-1, /* 169 */
	1, /* 170 */
	1
};
int PFmilgen_max_op = 171;
int PFmilgen_max_state = 89;
#define PFmilgen_Max_state 89
char *PFmilgen_string[] = {
	0,
	"Query: serialize(Side, Rel)",
	"Query: serialize(Side, empty_tbl)",
	0,
	0,
	0,
	0,
	0,
	"Rel: lit_tbl",
	"Rel: empty_tbl",
	"Rel: attach(Rel)",
	"Rel: cross(Rel, Rel)",
	"Rel: dep_cross(Rel, Rel)",
	"Rel: dep_border(Rel)",
	"Rel: leftjoin(Rel, Rel)",
	"Rel: eqjoin(Rel, Rel)",
	"Rel: semijoin(Rel, Rel)",
	"Rel: thetajoin(Rel, Rel)",
	"Rel: unq2_thetajoin(Rel, Rel)",
	"Rel: unq1_thetajoin(Rel, Rel)",
	"Rel: project(Rel)",
	"Rel: slice(Rel)",
	"Rel: select(Rel)",
	"Rel: val_select(Rel)",
	"Rel: append_union(Rel, Rel)",
	"Rel: merge_union(Rel, Rel)",
	"Rel: intersect(Rel, Rel)",
	"Rel: difference(Rel, Rel)",
	0,
	0,
	"Rel: sort_distinct(Rel)",
	"Rel: sort_distinct(std_sort(Rel))",
	"Rel: sort_distinct(refine_sort(Rel))",
	"Rel: std_sort(Rel)",
	"Rel: refine_sort(Rel)",
	0,
	0,
	0,
	0,
	0,
	"Rel: fun_1to1(Rel)",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"Rel: eq(Rel)",
	0,
	"Rel: gt(Rel)",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"Rel: bool_not(Rel)",
	"Rel: bool_and(Rel)",
	"Rel: bool_or(Rel)",
	0,
	"Rel: to(Rel)",
	"Rel: count_ext(Rel, Rel)",
	"Rel: aggr(Rel)",
	0,
	0,
	0,
	0,
	"Rel: mark(Rel)",
	"Rel: rank(Rel)",
	"Rel: rank(std_sort(Rel))",
	"Rel: rank(refine_sort(Rel))",
	"Rel: mark_grp(Rel)",
	"Rel: type(Rel)",
	"Rel: type_assert(Rel)",
	"Rel: cast(Rel)",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"Rel: llscjoin(Rel)",
	"Rel: llscjoin_dup(Rel)",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"Rel: doc_tbl(Rel)",
	"Rel: doc_access(Rel)",
	"Rel: twig(Twig)",
	"Rel: twig(attribute(Rel))",
	"Rel: twig(textnode(Rel))",
	"Fcns: fcns(Twig, Fcns)",
	"Fcns: fcns(Twig, nil)",
	"Twig: docnode(Rel, nil)",
	"Twig: docnode(Rel, Fcns)",
	"Twig: element(Rel, nil)",
	"Twig: element(Rel, Fcns)",
	"Twig: attribute(Rel)",
	"Twig: textnode(Rel)",
	"Twig: comment(Rel)",
	"Twig: processi(Rel)",
	"Twig: content(Rel)",
	"Twig: slim_content(Rel)",
	"Rel: merge_adjacent(Rel)",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"Side: error(Side, Rel)",
	"Side: nil",
	"Side: cache(Side, Rel)",
	"Rel: cache_border(Rel)",
	0,
	0,
	"Side: trace(Side, trace_items(Rel, trace_msg(Rel, Map)))",
	"Side: trace(Side, trace_items(Rel, trace_msg(Rel, nil)))",
	"Map: trace_map(Rel, Map)",
	"Map: trace_map(Rel, nil)",
	0,
	"Rel: rec_fix(side_effects(Side, Rec), Rel)",
	"Rec: rec_param(rec_arg(Rel, Rel), Rec)",
	"Rec: rec_param(rec_arg(empty_tbl, Rel), Rec)",
	"Rec: nil",
	"Rel: rec_base",
	"Rel: rec_border(Rel)",
	0,
	0,
	0,
	0,
	"Rel: FunRel",
	"FunRel: fun_call(Rel, Param)",
	"Param: fun_param(Rel, Param)",
	0,
	"Param: nil",
	0,
	0,
	0,
	0,
	0,
	"Rel: string_join(Rel, Rel)",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"Rel: findnodes(Rel)",
	"Rel: vx_lookup(Rel)",
};
int PFmilgen_max_rule = 171;
#define PFmilgen_Max_rule 171
short PFmilgen_rule_descriptor_0[] = { 0, 0 };
short PFmilgen_rule_descriptor_1[] = {   -1,    1,   -5,   -2, };
short PFmilgen_rule_descriptor_2[] = {   -1,    1,   -5,    3, };
short PFmilgen_rule_descriptor_8[] = {   -2,    2, };
short PFmilgen_rule_descriptor_9[] = {   -2,    3, };
short PFmilgen_rule_descriptor_10[] = {   -2,    4,   -2, };
short PFmilgen_rule_descriptor_11[] = {   -2,   10,   -2,   -2, };
short PFmilgen_rule_descriptor_12[] = {   -2,   11,   -2,   -2, };
short PFmilgen_rule_descriptor_13[] = {   -2,   12,   -2, };
short PFmilgen_rule_descriptor_14[] = {   -2,   13,   -2,   -2, };
short PFmilgen_rule_descriptor_15[] = {   -2,   14,   -2,   -2, };
short PFmilgen_rule_descriptor_16[] = {   -2,   15,   -2,   -2, };
short PFmilgen_rule_descriptor_17[] = {   -2,   16,   -2,   -2, };
short PFmilgen_rule_descriptor_18[] = {   -2,   17,   -2,   -2, };
short PFmilgen_rule_descriptor_19[] = {   -2,   18,   -2,   -2, };
short PFmilgen_rule_descriptor_20[] = {   -2,   19,   -2, };
short PFmilgen_rule_descriptor_21[] = {   -2,   20,   -2, };
short PFmilgen_rule_descriptor_22[] = {   -2,   21,   -2, };
short PFmilgen_rule_descriptor_23[] = {   -2,   22,   -2, };
short PFmilgen_rule_descriptor_24[] = {   -2,   23,   -2,   -2, };
short PFmilgen_rule_descriptor_25[] = {   -2,   24,   -2,   -2, };
short PFmilgen_rule_descriptor_26[] = {   -2,   25,   -2,   -2, };
short PFmilgen_rule_descriptor_27[] = {   -2,   26,   -2,   -2, };
short PFmilgen_rule_descriptor_30[] = {   -2,   27,   -2, };
short PFmilgen_rule_descriptor_31[] = {   -2,   27,   28,   -2, };
short PFmilgen_rule_descriptor_32[] = {   -2,   27,   29,   -2, };
short PFmilgen_rule_descriptor_33[] = {   -2,   28,   -2, };
short PFmilgen_rule_descriptor_34[] = {   -2,   29,   -2, };
short PFmilgen_rule_descriptor_40[] = {   -2,   30,   -2, };
short PFmilgen_rule_descriptor_50[] = {   -2,   40,   -2, };
short PFmilgen_rule_descriptor_52[] = {   -2,   42,   -2, };
short PFmilgen_rule_descriptor_60[] = {   -2,   45,   -2, };
short PFmilgen_rule_descriptor_61[] = {   -2,   46,   -2, };
short PFmilgen_rule_descriptor_62[] = {   -2,   47,   -2, };
short PFmilgen_rule_descriptor_64[] = {   -2,   50,   -2, };
short PFmilgen_rule_descriptor_65[] = {   -2,   54,   -2,   -2, };
short PFmilgen_rule_descriptor_66[] = {   -2,   55,   -2, };
short PFmilgen_rule_descriptor_71[] = {   -2,   60,   -2, };
short PFmilgen_rule_descriptor_72[] = {   -2,   61,   -2, };
short PFmilgen_rule_descriptor_73[] = {   -2,   61,   28,   -2, };
short PFmilgen_rule_descriptor_74[] = {   -2,   61,   29,   -2, };
short PFmilgen_rule_descriptor_75[] = {   -2,   62,   -2, };
short PFmilgen_rule_descriptor_76[] = {   -2,   63,   -2, };
short PFmilgen_rule_descriptor_77[] = {   -2,   64,   -2, };
short PFmilgen_rule_descriptor_78[] = {   -2,   65,   -2, };
short PFmilgen_rule_descriptor_90[] = {   -2,  100,   -2, };
short PFmilgen_rule_descriptor_91[] = {   -2,  101,   -2, };
short PFmilgen_rule_descriptor_100[] = {   -2,  120,   -2, };
short PFmilgen_rule_descriptor_101[] = {   -2,  121,   -2, };
short PFmilgen_rule_descriptor_102[] = {   -2,  122,   -4, };
short PFmilgen_rule_descriptor_103[] = {   -2,  122,  126,   -2, };
short PFmilgen_rule_descriptor_104[] = {   -2,  122,  127,   -2, };
short PFmilgen_rule_descriptor_105[] = {   -3,  123,   -4,   -3, };
short PFmilgen_rule_descriptor_106[] = {   -3,  123,   -4,  138, };
short PFmilgen_rule_descriptor_107[] = {   -4,  124,   -2,  138, };
short PFmilgen_rule_descriptor_108[] = {   -4,  124,   -2,   -3, };
short PFmilgen_rule_descriptor_109[] = {   -4,  125,   -2,  138, };
short PFmilgen_rule_descriptor_110[] = {   -4,  125,   -2,   -3, };
short PFmilgen_rule_descriptor_111[] = {   -4,  126,   -2, };
short PFmilgen_rule_descriptor_112[] = {   -4,  127,   -2, };
short PFmilgen_rule_descriptor_113[] = {   -4,  128,   -2, };
short PFmilgen_rule_descriptor_114[] = {   -4,  129,   -2, };
short PFmilgen_rule_descriptor_115[] = {   -4,  130,   -2, };
short PFmilgen_rule_descriptor_116[] = {   -4,  131,   -2, };
short PFmilgen_rule_descriptor_117[] = {   -2,  132,   -2, };
short PFmilgen_rule_descriptor_129[] = {   -5,  137,   -5,   -2, };
short PFmilgen_rule_descriptor_130[] = {   -5,  138, };
short PFmilgen_rule_descriptor_131[] = {   -5,  139,   -5,   -2, };
short PFmilgen_rule_descriptor_132[] = {   -2,  140,   -2, };
short PFmilgen_rule_descriptor_135[] = {   -5,  141,   -5,  142,   -2,  143,   -2,   -6, };
short PFmilgen_rule_descriptor_136[] = {   -5,  141,   -5,  142,   -2,  143,   -2,  138, };
short PFmilgen_rule_descriptor_137[] = {   -6,  144,   -2,   -6, };
short PFmilgen_rule_descriptor_138[] = {   -6,  144,   -2,  138, };
short PFmilgen_rule_descriptor_140[] = {   -2,  145,  146,   -5,   -7,   -2, };
short PFmilgen_rule_descriptor_141[] = {   -7,  147,  148,   -2,   -2,   -7, };
short PFmilgen_rule_descriptor_142[] = {   -7,  147,  148,    3,   -2,   -7, };
short PFmilgen_rule_descriptor_143[] = {   -7,  138, };
short PFmilgen_rule_descriptor_144[] = {   -2,  149, };
short PFmilgen_rule_descriptor_145[] = {   -2,  150,   -2, };
short PFmilgen_rule_descriptor_150[] = {   -2,   -8, };
short PFmilgen_rule_descriptor_151[] = {   -8,  151,   -2,   -9, };
short PFmilgen_rule_descriptor_152[] = {   -9,  152,   -2,   -9, };
short PFmilgen_rule_descriptor_154[] = {   -9,  138, };
short PFmilgen_rule_descriptor_160[] = {   -2,  160,   -2,   -2, };
short PFmilgen_rule_descriptor_170[] = {   -2,  170,   -2, };
short PFmilgen_rule_descriptor_171[] = {   -2,  171,   -2, };
/* PFmilgen_rule_descriptors[0][1] = 1 iff grammar is normal form. */
short * PFmilgen_rule_descriptors[] = {
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_1,
	PFmilgen_rule_descriptor_2,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_8,
	PFmilgen_rule_descriptor_9,
	PFmilgen_rule_descriptor_10,
	PFmilgen_rule_descriptor_11,
	PFmilgen_rule_descriptor_12,
	PFmilgen_rule_descriptor_13,
	PFmilgen_rule_descriptor_14,
	PFmilgen_rule_descriptor_15,
	PFmilgen_rule_descriptor_16,
	PFmilgen_rule_descriptor_17,
	PFmilgen_rule_descriptor_18,
	PFmilgen_rule_descriptor_19,
	PFmilgen_rule_descriptor_20,
	PFmilgen_rule_descriptor_21,
	PFmilgen_rule_descriptor_22,
	PFmilgen_rule_descriptor_23,
	PFmilgen_rule_descriptor_24,
	PFmilgen_rule_descriptor_25,
	PFmilgen_rule_descriptor_26,
	PFmilgen_rule_descriptor_27,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_30,
	PFmilgen_rule_descriptor_31,
	PFmilgen_rule_descriptor_32,
	PFmilgen_rule_descriptor_33,
	PFmilgen_rule_descriptor_34,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_40,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_50,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_52,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_60,
	PFmilgen_rule_descriptor_61,
	PFmilgen_rule_descriptor_62,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_64,
	PFmilgen_rule_descriptor_65,
	PFmilgen_rule_descriptor_66,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_71,
	PFmilgen_rule_descriptor_72,
	PFmilgen_rule_descriptor_73,
	PFmilgen_rule_descriptor_74,
	PFmilgen_rule_descriptor_75,
	PFmilgen_rule_descriptor_76,
	PFmilgen_rule_descriptor_77,
	PFmilgen_rule_descriptor_78,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_90,
	PFmilgen_rule_descriptor_91,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_100,
	PFmilgen_rule_descriptor_101,
	PFmilgen_rule_descriptor_102,
	PFmilgen_rule_descriptor_103,
	PFmilgen_rule_descriptor_104,
	PFmilgen_rule_descriptor_105,
	PFmilgen_rule_descriptor_106,
	PFmilgen_rule_descriptor_107,
	PFmilgen_rule_descriptor_108,
	PFmilgen_rule_descriptor_109,
	PFmilgen_rule_descriptor_110,
	PFmilgen_rule_descriptor_111,
	PFmilgen_rule_descriptor_112,
	PFmilgen_rule_descriptor_113,
	PFmilgen_rule_descriptor_114,
	PFmilgen_rule_descriptor_115,
	PFmilgen_rule_descriptor_116,
	PFmilgen_rule_descriptor_117,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_129,
	PFmilgen_rule_descriptor_130,
	PFmilgen_rule_descriptor_131,
	PFmilgen_rule_descriptor_132,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_135,
	PFmilgen_rule_descriptor_136,
	PFmilgen_rule_descriptor_137,
	PFmilgen_rule_descriptor_138,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_140,
	PFmilgen_rule_descriptor_141,
	PFmilgen_rule_descriptor_142,
	PFmilgen_rule_descriptor_143,
	PFmilgen_rule_descriptor_144,
	PFmilgen_rule_descriptor_145,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_150,
	PFmilgen_rule_descriptor_151,
	PFmilgen_rule_descriptor_152,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_154,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_160,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_0,
	PFmilgen_rule_descriptor_170,
	PFmilgen_rule_descriptor_171,
};
short PFmilgen_cost[][4] = {
	{    0,    0,    0,    0}, /* (none) = 0 */
	{   10,    0,    0,    0}, /* Query: serialize(Side, Rel) = 1 */
	{   10,    0,    0,    0}, /* Query: serialize(Side, empty_tbl) = 2 */
	{    0,    0,    0,    0}, /* (none) = 3 */
	{    0,    0,    0,    0}, /* (none) = 4 */
	{    0,    0,    0,    0}, /* (none) = 5 */
	{    0,    0,    0,    0}, /* (none) = 6 */
	{    0,    0,    0,    0}, /* (none) = 7 */
	{   10,    0,    0,    0}, /* Rel: lit_tbl = 8 */
	{   10,    0,    0,    0}, /* Rel: empty_tbl = 9 */
	{   10,    0,    0,    0}, /* Rel: attach(Rel) = 10 */
	{   10,    0,    0,    0}, /* Rel: cross(Rel, Rel) = 11 */
	{   10,    0,    0,    0}, /* Rel: dep_cross(Rel, Rel) = 12 */
	{   10,    0,    0,    0}, /* Rel: dep_border(Rel) = 13 */
	{   10,    0,    0,    0}, /* Rel: leftjoin(Rel, Rel) = 14 */
	{   10,    0,    0,    0}, /* Rel: eqjoin(Rel, Rel) = 15 */
	{   10,    0,    0,    0}, /* Rel: semijoin(Rel, Rel) = 16 */
	{   10,    0,    0,    0}, /* Rel: thetajoin(Rel, Rel) = 17 */
	{   10,    0,    0,    0}, /* Rel: unq2_thetajoin(Rel, Rel) = 18 */
	{   10,    0,    0,    0}, /* Rel: unq1_thetajoin(Rel, Rel) = 19 */
	{   10,    0,    0,    0}, /* Rel: project(Rel) = 20 */
	{   10,    0,    0,    0}, /* Rel: slice(Rel) = 21 */
	{   10,    0,    0,    0}, /* Rel: select(Rel) = 22 */
	{   10,    0,    0,    0}, /* Rel: val_select(Rel) = 23 */
	{   10,    0,    0,    0}, /* Rel: append_union(Rel, Rel) = 24 */
	{   10,    0,    0,    0}, /* Rel: merge_union(Rel, Rel) = 25 */
	{   10,    0,    0,    0}, /* Rel: intersect(Rel, Rel) = 26 */
	{   10,    0,    0,    0}, /* Rel: difference(Rel, Rel) = 27 */
	{    0,    0,    0,    0}, /* (none) = 28 */
	{    0,    0,    0,    0}, /* (none) = 29 */
	{   10,    0,    0,    0}, /* Rel: sort_distinct(Rel) = 30 */
	{   10,    0,    0,    0}, /* Rel: sort_distinct(std_sort(Rel)) = 31 */
	{   10,    0,    0,    0}, /* Rel: sort_distinct(refine_sort(Rel)) = 32 */
	{   10,    0,    0,    0}, /* Rel: std_sort(Rel) = 33 */
	{   10,    0,    0,    0}, /* Rel: refine_sort(Rel) = 34 */
	{    0,    0,    0,    0}, /* (none) = 35 */
	{    0,    0,    0,    0}, /* (none) = 36 */
	{    0,    0,    0,    0}, /* (none) = 37 */
	{    0,    0,    0,    0}, /* (none) = 38 */
	{    0,    0,    0,    0}, /* (none) = 39 */
	{   10,    0,    0,    0}, /* Rel: fun_1to1(Rel) = 40 */
	{    0,    0,    0,    0}, /* (none) = 41 */
	{    0,    0,    0,    0}, /* (none) = 42 */
	{    0,    0,    0,    0}, /* (none) = 43 */
	{    0,    0,    0,    0}, /* (none) = 44 */
	{    0,    0,    0,    0}, /* (none) = 45 */
	{    0,    0,    0,    0}, /* (none) = 46 */
	{    0,    0,    0,    0}, /* (none) = 47 */
	{    0,    0,    0,    0}, /* (none) = 48 */
	{    0,    0,    0,    0}, /* (none) = 49 */
	{   10,    0,    0,    0}, /* Rel: eq(Rel) = 50 */
	{    0,    0,    0,    0}, /* (none) = 51 */
	{   10,    0,    0,    0}, /* Rel: gt(Rel) = 52 */
	{    0,    0,    0,    0}, /* (none) = 53 */
	{    0,    0,    0,    0}, /* (none) = 54 */
	{    0,    0,    0,    0}, /* (none) = 55 */
	{    0,    0,    0,    0}, /* (none) = 56 */
	{    0,    0,    0,    0}, /* (none) = 57 */
	{    0,    0,    0,    0}, /* (none) = 58 */
	{    0,    0,    0,    0}, /* (none) = 59 */
	{   10,    0,    0,    0}, /* Rel: bool_not(Rel) = 60 */
	{   10,    0,    0,    0}, /* Rel: bool_and(Rel) = 61 */
	{   10,    0,    0,    0}, /* Rel: bool_or(Rel) = 62 */
	{    0,    0,    0,    0}, /* (none) = 63 */
	{   10,    0,    0,    0}, /* Rel: to(Rel) = 64 */
	{   10,    0,    0,    0}, /* Rel: count_ext(Rel, Rel) = 65 */
	{   10,    0,    0,    0}, /* Rel: aggr(Rel) = 66 */
	{    0,    0,    0,    0}, /* (none) = 67 */
	{    0,    0,    0,    0}, /* (none) = 68 */
	{    0,    0,    0,    0}, /* (none) = 69 */
	{    0,    0,    0,    0}, /* (none) = 70 */
	{   10,    0,    0,    0}, /* Rel: mark(Rel) = 71 */
	{   10,    0,    0,    0}, /* Rel: rank(Rel) = 72 */
	{   10,    0,    0,    0}, /* Rel: rank(std_sort(Rel)) = 73 */
	{   10,    0,    0,    0}, /* Rel: rank(refine_sort(Rel)) = 74 */
	{   10,    0,    0,    0}, /* Rel: mark_grp(Rel) = 75 */
	{   10,    0,    0,    0}, /* Rel: type(Rel) = 76 */
	{   10,    0,    0,    0}, /* Rel: type_assert(Rel) = 77 */
	{   10,    0,    0,    0}, /* Rel: cast(Rel) = 78 */
	{    0,    0,    0,    0}, /* (none) = 79 */
	{    0,    0,    0,    0}, /* (none) = 80 */
	{    0,    0,    0,    0}, /* (none) = 81 */
	{    0,    0,    0,    0}, /* (none) = 82 */
	{    0,    0,    0,    0}, /* (none) = 83 */
	{    0,    0,    0,    0}, /* (none) = 84 */
	{    0,    0,    0,    0}, /* (none) = 85 */
	{    0,    0,    0,    0}, /* (none) = 86 */
	{    0,    0,    0,    0}, /* (none) = 87 */
	{    0,    0,    0,    0}, /* (none) = 88 */
	{    0,    0,    0,    0}, /* (none) = 89 */
	{   10,    0,    0,    0}, /* Rel: llscjoin(Rel) = 90 */
	{   10,    0,    0,    0}, /* Rel: llscjoin_dup(Rel) = 91 */
	{    0,    0,    0,    0}, /* (none) = 92 */
	{    0,    0,    0,    0}, /* (none) = 93 */
	{    0,    0,    0,    0}, /* (none) = 94 */
	{    0,    0,    0,    0}, /* (none) = 95 */
	{    0,    0,    0,    0}, /* (none) = 96 */
	{    0,    0,    0,    0}, /* (none) = 97 */
	{    0,    0,    0,    0}, /* (none) = 98 */
	{    0,    0,    0,    0}, /* (none) = 99 */
	{   10,    0,    0,    0}, /* Rel: doc_tbl(Rel) = 100 */
	{   10,    0,    0,    0}, /* Rel: doc_access(Rel) = 101 */
	{   10,    0,    0,    0}, /* Rel: twig(Twig) = 102 */
	{   10,    0,    0,    0}, /* Rel: twig(attribute(Rel)) = 103 */
	{   10,    0,    0,    0}, /* Rel: twig(textnode(Rel)) = 104 */
	{   10,    0,    0,    0}, /* Fcns: fcns(Twig, Fcns) = 105 */
	{   10,    0,    0,    0}, /* Fcns: fcns(Twig, nil) = 106 */
	{   10,    0,    0,    0}, /* Twig: docnode(Rel, nil) = 107 */
	{   10,    0,    0,    0}, /* Twig: docnode(Rel, Fcns) = 108 */
	{   10,    0,    0,    0}, /* Twig: element(Rel, nil) = 109 */
	{   10,    0,    0,    0}, /* Twig: element(Rel, Fcns) = 110 */
	{   10,    0,    0,    0}, /* Twig: attribute(Rel) = 111 */
	{   10,    0,    0,    0}, /* Twig: textnode(Rel) = 112 */
	{   10,    0,    0,    0}, /* Twig: comment(Rel) = 113 */
	{   10,    0,    0,    0}, /* Twig: processi(Rel) = 114 */
	{   10,    0,    0,    0}, /* Twig: content(Rel) = 115 */
	{   10,    0,    0,    0}, /* Twig: slim_content(Rel) = 116 */
	{   10,    0,    0,    0}, /* Rel: merge_adjacent(Rel) = 117 */
	{    0,    0,    0,    0}, /* (none) = 118 */
	{    0,    0,    0,    0}, /* (none) = 119 */
	{    0,    0,    0,    0}, /* (none) = 120 */
	{    0,    0,    0,    0}, /* (none) = 121 */
	{    0,    0,    0,    0}, /* (none) = 122 */
	{    0,    0,    0,    0}, /* (none) = 123 */
	{    0,    0,    0,    0}, /* (none) = 124 */
	{    0,    0,    0,    0}, /* (none) = 125 */
	{    0,    0,    0,    0}, /* (none) = 126 */
	{    0,    0,    0,    0}, /* (none) = 127 */
	{    0,    0,    0,    0}, /* (none) = 128 */
	{   10,    0,    0,    0}, /* Side: error(Side, Rel) = 129 */
	{   10,    0,    0,    0}, /* Side: nil = 130 */
	{   10,    0,    0,    0}, /* Side: cache(Side, Rel) = 131 */
	{   10,    0,    0,    0}, /* Rel: cache_border(Rel) = 132 */
	{    0,    0,    0,    0}, /* (none) = 133 */
	{    0,    0,    0,    0}, /* (none) = 134 */
	{   10,    0,    0,    0}, /* Side: trace(Side, trace_items(Rel, trace_msg(Rel, Map))) = 135 */
	{   10,    0,    0,    0}, /* Side: trace(Side, trace_items(Rel, trace_msg(Rel, nil))) = 136 */
	{   10,    0,    0,    0}, /* Map: trace_map(Rel, Map) = 137 */
	{   10,    0,    0,    0}, /* Map: trace_map(Rel, nil) = 138 */
	{    0,    0,    0,    0}, /* (none) = 139 */
	{   10,    0,    0,    0}, /* Rel: rec_fix(side_effects(Side, Rec), Rel) = 140 */
	{   10,    0,    0,    0}, /* Rec: rec_param(rec_arg(Rel, Rel), Rec) = 141 */
	{   10,    0,    0,    0}, /* Rec: rec_param(rec_arg(empty_tbl, Rel), Rec) = 142 */
	{   10,    0,    0,    0}, /* Rec: nil = 143 */
	{   10,    0,    0,    0}, /* Rel: rec_base = 144 */
	{   10,    0,    0,    0}, /* Rel: rec_border(Rel) = 145 */
	{    0,    0,    0,    0}, /* (none) = 146 */
	{    0,    0,    0,    0}, /* (none) = 147 */
	{    0,    0,    0,    0}, /* (none) = 148 */
	{    0,    0,    0,    0}, /* (none) = 149 */
	{   10,    0,    0,    0}, /* Rel: FunRel = 150 */
	{   10,    0,    0,    0}, /* FunRel: fun_call(Rel, Param) = 151 */
	{   10,    0,    0,    0}, /* Param: fun_param(Rel, Param) = 152 */
	{    0,    0,    0,    0}, /* (none) = 153 */
	{   10,    0,    0,    0}, /* Param: nil = 154 */
	{    0,    0,    0,    0}, /* (none) = 155 */
	{    0,    0,    0,    0}, /* (none) = 156 */
	{    0,    0,    0,    0}, /* (none) = 157 */
	{    0,    0,    0,    0}, /* (none) = 158 */
	{    0,    0,    0,    0}, /* (none) = 159 */
	{   10,    0,    0,    0}, /* Rel: string_join(Rel, Rel) = 160 */
	{    0,    0,    0,    0}, /* (none) = 161 */
	{    0,    0,    0,    0}, /* (none) = 162 */
	{    0,    0,    0,    0}, /* (none) = 163 */
	{    0,    0,    0,    0}, /* (none) = 164 */
	{    0,    0,    0,    0}, /* (none) = 165 */
	{    0,    0,    0,    0}, /* (none) = 166 */
	{    0,    0,    0,    0}, /* (none) = 167 */
	{    0,    0,    0,    0}, /* (none) = 168 */
	{    0,    0,    0,    0}, /* (none) = 169 */
	{   10,    0,    0,    0}, /* Rel: findnodes(Rel) = 170 */
	{   10,    0,    0,    0}, /* Rel: vx_lookup(Rel) = 171 */
};

short PFmilgen_delta_cost[90][10][4] = {
{{0}}, /* state 0 */
{ /* state #1: aggr(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: aggr(Rel) = 66 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #2: append_union(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: append_union(Rel, Rel) = 24 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #3: attach(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: attach(Rel) = 10 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #4: attribute(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: attribute(Rel) = 111 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #5: bool_and(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: bool_and(Rel) = 61 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #6: bool_not(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: bool_not(Rel) = 60 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #7: bool_or(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: bool_or(Rel) = 62 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #8: cache(nil, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: cache(Side, Rel) = 131 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #9: cache_border(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cache_border(Rel) = 132 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #10: cast(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cast(Rel) = 78 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #11: comment(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: comment(Rel) = 113 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #12: content(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: content(Rel) = 115 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #13: count_ext(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: count_ext(Rel, Rel) = 65 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #14: cross(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cross(Rel, Rel) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #15: dep_border(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: dep_border(Rel) = 13 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #16: dep_cross(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: dep_cross(Rel, Rel) = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #17: difference(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: difference(Rel, Rel) = 27 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #18: doc_access(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: doc_access(Rel) = 101 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #19: doc_tbl(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: doc_tbl(Rel) = 100 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #20: docnode(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: docnode(Rel, nil) = 107 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #21: docnode(rec_base, fcns(attribute(rec_base), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: docnode(Rel, Fcns) = 108 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #22: element(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: element(Rel, nil) = 109 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #23: element(rec_base, fcns(attribute(rec_base), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: element(Rel, Fcns) = 110 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #24: empty_tbl */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: empty_tbl = 9 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #25: eq(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: eq(Rel) = 50 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #26: eqjoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: eqjoin(Rel, Rel) = 15 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #27: error(nil, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: error(Side, Rel) = 129 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #28: fcns(attribute(rec_base), fcns(attribute(rec_base), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Fcns: fcns(Twig, Fcns) = 105 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #29: fcns(attribute(rec_base), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Fcns: fcns(Twig, nil) = 106 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #30: findnodes(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: findnodes(Rel) = 170 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #31: fun_1to1(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: fun_1to1(Rel) = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #32: fun_call(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: FunRel = 150 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunRel: fun_call(Rel, Param) = 151 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #33: fun_param(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Param: fun_param(Rel, Param) = 152 */
},
{ /* state #34: gt(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: gt(Rel) = 52 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #35: intersect(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: intersect(Rel, Rel) = 26 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #36: leftjoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: leftjoin(Rel, Rel) = 14 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #37: lit_tbl */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: lit_tbl = 8 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #38: llscjoin(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: llscjoin(Rel) = 90 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #39: llscjoin_dup(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: llscjoin_dup(Rel) = 91 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #40: mark(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: mark(Rel) = 71 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #41: mark_grp(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: mark_grp(Rel) = 75 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #42: merge_adjacent(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: merge_adjacent(Rel) = 117 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #43: merge_union(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: merge_union(Rel, Rel) = 25 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #44: nil */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Side: nil = 130 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rec: nil = 143 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Param: nil = 154 */
},
{ /* state #45: processi(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: processi(Rel) = 114 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #46: project(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: project(Rel) = 20 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #47: rank(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rank(Rel) = 72 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #48: rank(std_sort(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rank(std_sort(Rel)) = 73 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #49: rank(refine_sort(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rank(refine_sort(Rel)) = 74 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #50: rec_arg(empty_tbl, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #51: rec_arg(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #52: rec_base */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rec_base = 144 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #53: rec_border(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rec_border(Rel) = 145 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #54: rec_fix(side_effects(nil, nil), rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rec_fix(side_effects(Side, Rec), Rel) = 140 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #55: rec_param(rec_arg(rec_base, rec_base), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rec: rec_param(rec_arg(Rel, Rel), Rec) = 141 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #56: rec_param(rec_arg(empty_tbl, rec_base), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rec: rec_param(rec_arg(empty_tbl, Rel), Rec) = 142 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #57: refine_sort(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: refine_sort(Rel) = 34 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #58: select(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: select(Rel) = 22 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #59: semijoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: semijoin(Rel, Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #60: serialize(nil, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize(Side, empty_tbl) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #61: serialize(nil, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize(Side, Rel) = 1 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #62: side_effects(nil, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #63: slice(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: slice(Rel) = 21 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #64: slim_content(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: slim_content(Rel) = 116 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #65: sort_distinct(refine_sort(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: sort_distinct(refine_sort(Rel)) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #66: sort_distinct(std_sort(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: sort_distinct(std_sort(Rel)) = 31 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #67: sort_distinct(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: sort_distinct(Rel) = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #68: std_sort(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: std_sort(Rel) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #69: string_join(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: string_join(Rel, Rel) = 160 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #70: textnode(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: textnode(Rel) = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #71: thetajoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: thetajoin(Rel, Rel) = 17 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #72: to(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: to(Rel) = 64 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #73: trace(nil, trace_items(rec_base, trace_msg(rec_base, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: trace(Side, trace_items(Rel, trace_msg(Rel, nil))) = 136 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #74: trace(nil, trace_items(rec_base, trace_msg(rec_base, trace_map(rec_base, nil)))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: trace(Side, trace_items(Rel, trace_msg(Rel, Map))) = 135 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #75: trace_items(rec_base, trace_msg(rec_base, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #76: trace_items(rec_base, trace_msg(rec_base, trace_map(rec_base, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #77: trace_map(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Map: trace_map(Rel, nil) = 138 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #78: trace_map(rec_base, trace_map(rec_base, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Map: trace_map(Rel, Map) = 137 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #79: trace_msg(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #80: trace_msg(rec_base, trace_map(rec_base, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #81: twig(comment(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: twig(Twig) = 102 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #82: twig(textnode(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: twig(textnode(Rel)) = 104 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #83: twig(attribute(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: twig(attribute(Rel)) = 103 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #84: type(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: type(Rel) = 76 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #85: type_assert(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: type_assert(Rel) = 77 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #86: unq1_thetajoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: unq1_thetajoin(Rel, Rel) = 19 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #87: unq2_thetajoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: unq2_thetajoin(Rel, Rel) = 18 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #88: val_select(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: val_select(Rel) = 23 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #89: vx_lookup(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: vx_lookup(Rel) = 171 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
};

char * PFmilgen_state_string[] = {
" not a state", /* state 0 */
	"aggr(rec_base)", /* state #1 */
	"append_union(rec_base, rec_base)", /* state #2 */
	"attach(rec_base)", /* state #3 */
	"attribute(rec_base)", /* state #4 */
	"bool_and(rec_base)", /* state #5 */
	"bool_not(rec_base)", /* state #6 */
	"bool_or(rec_base)", /* state #7 */
	"cache(nil, rec_base)", /* state #8 */
	"cache_border(rec_base)", /* state #9 */
	"cast(rec_base)", /* state #10 */
	"comment(rec_base)", /* state #11 */
	"content(rec_base)", /* state #12 */
	"count_ext(rec_base, rec_base)", /* state #13 */
	"cross(rec_base, rec_base)", /* state #14 */
	"dep_border(rec_base)", /* state #15 */
	"dep_cross(rec_base, rec_base)", /* state #16 */
	"difference(rec_base, rec_base)", /* state #17 */
	"doc_access(rec_base)", /* state #18 */
	"doc_tbl(rec_base)", /* state #19 */
	"docnode(rec_base, nil)", /* state #20 */
	"docnode(rec_base, fcns(attribute(rec_base), nil))", /* state #21 */
	"element(rec_base, nil)", /* state #22 */
	"element(rec_base, fcns(attribute(rec_base), nil))", /* state #23 */
	"empty_tbl", /* state #24 */
	"eq(rec_base)", /* state #25 */
	"eqjoin(rec_base, rec_base)", /* state #26 */
	"error(nil, rec_base)", /* state #27 */
	"fcns(attribute(rec_base), fcns(attribute(rec_base), nil))", /* state #28 */
	"fcns(attribute(rec_base), nil)", /* state #29 */
	"findnodes(rec_base)", /* state #30 */
	"fun_1to1(rec_base)", /* state #31 */
	"fun_call(rec_base, nil)", /* state #32 */
	"fun_param(rec_base, nil)", /* state #33 */
	"gt(rec_base)", /* state #34 */
	"intersect(rec_base, rec_base)", /* state #35 */
	"leftjoin(rec_base, rec_base)", /* state #36 */
	"lit_tbl", /* state #37 */
	"llscjoin(rec_base)", /* state #38 */
	"llscjoin_dup(rec_base)", /* state #39 */
	"mark(rec_base)", /* state #40 */
	"mark_grp(rec_base)", /* state #41 */
	"merge_adjacent(rec_base)", /* state #42 */
	"merge_union(rec_base, rec_base)", /* state #43 */
	"nil", /* state #44 */
	"processi(rec_base)", /* state #45 */
	"project(rec_base)", /* state #46 */
	"rank(rec_base)", /* state #47 */
	"rank(std_sort(rec_base))", /* state #48 */
	"rank(refine_sort(rec_base))", /* state #49 */
	"rec_arg(empty_tbl, rec_base)", /* state #50 */
	"rec_arg(rec_base, rec_base)", /* state #51 */
	"rec_base", /* state #52 */
	"rec_border(rec_base)", /* state #53 */
	"rec_fix(side_effects(nil, nil), rec_base)", /* state #54 */
	"rec_param(rec_arg(rec_base, rec_base), nil)", /* state #55 */
	"rec_param(rec_arg(empty_tbl, rec_base), nil)", /* state #56 */
	"refine_sort(rec_base)", /* state #57 */
	"select(rec_base)", /* state #58 */
	"semijoin(rec_base, rec_base)", /* state #59 */
	"serialize(nil, empty_tbl)", /* state #60 */
	"serialize(nil, rec_base)", /* state #61 */
	"side_effects(nil, nil)", /* state #62 */
	"slice(rec_base)", /* state #63 */
	"slim_content(rec_base)", /* state #64 */
	"sort_distinct(refine_sort(rec_base))", /* state #65 */
	"sort_distinct(std_sort(rec_base))", /* state #66 */
	"sort_distinct(rec_base)", /* state #67 */
	"std_sort(rec_base)", /* state #68 */
	"string_join(rec_base, rec_base)", /* state #69 */
	"textnode(rec_base)", /* state #70 */
	"thetajoin(rec_base, rec_base)", /* state #71 */
	"to(rec_base)", /* state #72 */
	"trace(nil, trace_items(rec_base, trace_msg(rec_base, nil)))", /* state #73 */
	"trace(nil, trace_items(rec_base, trace_msg(rec_base, trace_map(rec_base, nil))))", /* state #74 */
	"trace_items(rec_base, trace_msg(rec_base, nil))", /* state #75 */
	"trace_items(rec_base, trace_msg(rec_base, trace_map(rec_base, nil)))", /* state #76 */
	"trace_map(rec_base, nil)", /* state #77 */
	"trace_map(rec_base, trace_map(rec_base, nil))", /* state #78 */
	"trace_msg(rec_base, nil)", /* state #79 */
	"trace_msg(rec_base, trace_map(rec_base, nil))", /* state #80 */
	"twig(comment(rec_base))", /* state #81 */
	"twig(textnode(rec_base))", /* state #82 */
	"twig(attribute(rec_base))", /* state #83 */
	"type(rec_base)", /* state #84 */
	"type_assert(rec_base)", /* state #85 */
	"unq1_thetajoin(rec_base, rec_base)", /* state #86 */
	"unq2_thetajoin(rec_base, rec_base)", /* state #87 */
	"val_select(rec_base)", /* state #88 */
	"vx_lookup(rec_base)", /* state #89 */
};
char *PFmilgen_ntname[] = {
	"Error: Nonterminals are > 0",
	"Query",
	"Rel",
	"Fcns",
	"Twig",
	"Side",
	"Map",
	"Rec",
	"FunRel",
	"Param",
	0
};

short PFmilgen_closure[10][10] = {
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,  150,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,},
};
#line 314 "milgen.brg"

/** @endcond */

/* fold( execute() / global milprog definition */
/**
 * @brief Global variable to collect the MIL program during compilation
 */
static PFmil_t *milprog;

/**
 * @brief Collect the MIL program in variable #milprog
 *
 * Processing of the physical plan is done bottom-up.
 * This is just the order in which we want to print our code.
 * So we keep the whole MIL program in the variable #milprog,
 * and append commands as we go. Think of it as @em executing
 * the commands right away.
 */
#define execute(...) milprog = seq (milprog, __VA_ARGS__)
/* fold) */

/* fold( mvar_t / global mvars / new_var() / pin() / unpin() definition */
/**
 * @brief Represents a MIL variable.
 *
 * The variable has a name (that is automatically generated).
 * The @a pins field keeps track of the number of references
 * to this variable.  A variable may not be destroyed before
 * @a pins drops to zero.
 */
struct mvar_t {
    PFmil_ident_t   name; /**< name of the variable */
    unsigned int    pins; /**< pin count of the variable */
};

/** short-hand for struct mvar_t */
typedef struct mvar_t mvar_t;

/**
 * @brief Global variable to reference all created variables
 *
 * Remember @em all variables that we deal with during the compiler
 * run in here.  We want to re-use variables as much as possible to
 * reduce the number of active variables in the MIL program.  This
 * should help MonetDB with its memory management.
 *
 * Each time we need a new variable, we try to re-use an old one
 * from here.  We thus search for a variable with pin count zero.
 * If we cannot find any, we create a new variable and append it to
 * the list.
 */
static PFarray_t *mvars;

/**
 * @brief running variable number.
 */
static unsigned int varno;

/**
 * @brief Create a ``new'' valid variable
 *
 * Will try to re-use an old, no longer needed, variable, if possible.
 * For this, the function searches #mvars for a variable with
 * @a pins = 0. If no such variable can be found, a new one will
 * be created and appended to the list.
 *
 * The new variable will be initialized with the pin count given
 * in @a pins.
 *
 * @param pins the initial pin count
 * @return The ``new'' valid variable
 */
static mvar_t *
new_var (unsigned int pins)
{
    mvar_t *var = NULL;

    assert (mvars);
    assert (varno < 10000);

    for (unsigned int i = 0; i < PFarray_last (mvars); i++)
        if ((var = *(mvar_t **) PFarray_at (mvars, i))->pins == 0) {
            var->pins = pins;
            return var;
        }

    /* If we were not successful, create a new entry */
    var = PFmalloc (sizeof (mvar_t));
    var->name = varno++;
    var->pins = pins;
    
    *(mvar_t **) PFarray_add (mvars) = var;

    return var;
}

/**
 * @brief Pin a variable (i.e., increment its pin count by @a count).
 *
 * @param v the variable whose pin count is increased
 * @param count the pin increment
 */
static void
pin (mvar_t *v, unsigned int count)
{
    v->pins += count;
}

/**
 * @brief Unpin a variable (i.e., decrement its pin count by @a count).
 *
 * If the pin count reaches zero, automatically generates a MIL
 * statement that assigns @c unused to the variable, marking it
 * a candidate for MonetDB's garbage collection.
 *
 * @param v the variable whose pin count is decreased
 * @param count the pin decrement
 */
static void
unpin (mvar_t *v, unsigned int count)
{
    if (v->pins < count) {
        PFinfo (OOPS_WARNING, "pin count for variable %s below zero",
                PFmil_var_str (v->name));
        v->pins = 0;
    } else
        v->pins -= count;
    if (!v->pins)
        execute (assgn (var (v->name), unused ()));
}


/* fold) */

/* fold( TYPE_MASK() / type_bit_check() / impl_types() / implty() definition */

/** @brief ``mask out'' the flags identifying non-attribute nodes */
#define TYPE_MASK(t)  ((t) & ~(aat_nkind | aat_nkind1))

/**
 * @brief Check if the algebra type represents only a single type bit
 *
 * @param ty the type representation that is going to be checked
 * @return the bool indicating if the input type consists of a single type bit
 */
static bool
type_bit_check (PFalg_simple_type_t ty)
{
    int count = 0;
    for (PFalg_simple_type_t t = 1; t; t <<= 1)
        if (t & ty) count++;

    return count == 1 && !(ty & (aat_nkind | aat_nkind1));
}

/**
 * @brief MIL implementation types for algebra types
 */
static PFmil_type_t
impl_types (PFalg_simple_type_t ty, PFalg_simple_type_t kind)
{
    if (kind & aat_docmgmt) {
        switch (ty) {
            case aat_docmgmt:
                return mty_lng;

            case aat_path:
            case aat_colnm:
            case aat_docnm:
                return mty_str;

            default:
                PFoops (OOPS_FATAL,
                        "illegal type in document management column");
                return mty_oid;
        }
    }
    else if (kind & aat_update) {
        switch (ty) {
            case aat_qname_id:
            case aat_qname_cont:
            case aat_pre:
            case aat_attr:
            case aat_frag:
            case aat_pre1:
            case aat_attr1:
            case aat_frag1:
                return mty_oid;

            case aat_update:
                return mty_lng;

            case aat_str:
            case aat_uA:
                return mty_str;

            default:
                PFoops (OOPS_FATAL,
                        "illegal type in update column");
                return mty_oid;
        }
    }
    else {
        switch (ty) {
            case aat_nat:
            case aat_qname_id:
            case aat_qname_cont:
            case aat_pre:
            case aat_attr:
            case aat_frag:
            case aat_error:
                return mty_oid;

            case aat_int:
                return mty_lng;

            case aat_str:
            case aat_uA:
                return mty_str;

            case aat_dec:
            case aat_dbl:
                return mty_dbl;

            case aat_bln:
                return mty_bit;

            case aat_dtime:
                return mty_timestamp;
            case aat_date:
                return mty_date;
            case aat_duration:
            case aat_gymonth:
            case aat_gyear:
            case aat_gmday:
            case aat_gmonth:
            case aat_gday:
                return mty_lng;
            case aat_time:
                return mty_daytime;
            case aat_ymduration:
                return mty_ymduration;
            case aat_dtduration:
                return mty_dtduration;

            default:
                PFoops (OOPS_FATAL,
                        "illegal type in query column");
                return mty_oid;
        }
    }
}

#ifndef NDEBUG
/** @brief implementation type for a given algebra type, as a MIL node */
#define implty(n,k) type (type_bit_check ((n))                     \
                          ? impl_types ((n),(k))                   \
                          : (assert (!"illegal type in implty()"), \
                             (PFmil_type_t) 0))
#else
/** @brief implementation type for a given algebra type, as a MIL node */
#define implty(n,k) type (impl_types ((n),(k)))
#endif
#define implty_(n)  implty((n),0)
/* fold) */

/* fold( env_t / new_env() / env_*() / VAR() / ANY_VAR() definition */
/**
 * @brief Environment entry.
 *
 * In each physical algebra tree node, we keep an environment
 * that maps a column/type combination to the #mvar_t struct
 * that holds the corresponding MIL variable.
 */
struct env_t {
    PFalg_col_t          col;
    PFalg_simple_type_t  ty;
    mvar_t              *mvar;
};
/** short-hand for struct env_t */
typedef struct env_t env_t;

/**
 * @brief Create a new (empty) environment for #env_t entries.
 *
 * With each node in the physical algebra DAG, we keep such an
 * environment that maps a column/type combination onto the
 * #mvar_t item that implements it. (Think of this as the mapping
 * from column/type to the BAT that represents that combination.
 */
static PFarray_t *
new_env (void)
{
    return PFarray (sizeof (env_t), 10);
}

/** @brief Add an item to environment for #env_t entries. */
static void
env_add_ (PFarray_t *env, PFalg_col_t col, PFalg_simple_type_t ty, mvar_t *v)
{
    *(env_t *) PFarray_add (env)
        = (env_t) { .col = col, .ty = ty, .mvar = v };
#ifndef NDEBUG
    execute ( comment ("    %s: %s(%s)",
                       PFmil_var_str (v->name),
                       PFcol_str (col),
                       PFalg_simple_type_str (ty)));
#endif
}
/** @brief Add an item to environment for #env_t entries. */
#define env_add(e,a,t,v) (type_bit_check ((t))           \
                          ? env_add_ ((e), (a), (t), (v)) \
                          : (assert (!"illegal type in env_add()")))

/** @brief Return #env_t environment size. */
static unsigned int
env_count (const PFarray_t *env)
{
    return PFarray_last (env);
}

/** @brief Return environment item at index @a i. */
static env_t
env_at (const PFarray_t *env, unsigned int i)
{
    assert (i < PFarray_last (env));

    return *(env_t *) PFarray_at ((PFarray_t *) env, i);
}

/**
 * @brief Worker for #env_mvar().
 *
 * Yields NULL if the MIL variable could not be found in the enviroment
 * @a env (in specific cases, this is not an error).
 */
static mvar_t *
env_mvar_unsafe (const PFarray_t *env, PFalg_col_t col, PFalg_simple_type_t ty)
{
    for (unsigned int i = 0; i < PFarray_last (env); i++) {

        env_t entry = *(env_t *) PFarray_at ((PFarray_t *) env, i);

        if (entry.col == col && entry.ty == ty)
            return entry.mvar;
    }
    return NULL;
}

/**
 * @brief Look up an entry in the environment @a env, given a combination
 *        of column (@a col) and type (@a ty) as the search key.
 */
static mvar_t *
#ifndef NDEBUG
#define env_mvar(e,a,t) (env_mvar_ ((e), (a), (t), __func__, __LINE__))
env_mvar_ (const PFarray_t *env, PFalg_col_t col, PFalg_simple_type_t ty,
           const char *func, const int line)
#else
env_mvar (const PFarray_t *env, PFalg_col_t col, PFalg_simple_type_t ty)
#endif
{
    mvar_t *mvar = env_mvar_unsafe (env, col, ty);

    if (mvar)
        return mvar;

#ifndef NDEBUG
    fprintf (stderr,
             "looking for col: %s, ty: 0x%X in function %s (line %i)\n",
             PFcol_str (col), ty, func, line);
    fprintf (stderr, "environment looks like:\n");
    for (unsigned int i = 0; i < PFarray_last (env); i++) {
        env_t entry = *(env_t *) PFarray_at ((PFarray_t *) env, i);

        fprintf (stderr, "  col: %s, type: 0x%X, mvar->name: %s\n",
                 PFcol_str (entry.col), entry.ty,
                 PFmil_var_str (entry.mvar->name));
    }
#endif

    PFoops (OOPS_FATAL,
            "column '%s' with type '0x%X' not found in environment",
            PFcol_str (col), ty);
    /* we don't ever get here */
    return NULL;
}

/**
 * @brief Look up a MIL variable in the environment @a env
 *        and return it as MIL code.
 */
#define VAR(e,a,t) (var (env_mvar ((e), (a), (t))->name))

/**
 * @brief Look up an @e arbitrary MIL variable in the environment
 *        @a env and return it as MIL code.
 */
#define ANY_VAR(e) (var (env_at ((e), 0).mvar->name))

/**
 * @brief Copy the complete environment.
 */
static void
env_copy (PFpa_op_t *p, PFarray_t *in_env)
{
    assert (p);
    assert (in_env);

    /* copy all the existing variables */
    for (unsigned int i = 0; i < env_count (in_env); i++) {
        env_t entry = env_at (in_env, i);
        env_add (p->env, entry.col, entry.ty, entry.mvar);
        pin (entry.mvar, p->refctr);
    }
}

/**
 * @brief env_map copies the the complete environment and
 *        aligns the columns with a given map relation (in @a v).
 */
static void
env_map (PFpa_op_t *p, PFarray_t *in_env, mvar_t *v)
{
    assert (p);
    assert (in_env);
    assert (v);

    for (unsigned int i = 0; i < env_count (in_env); i++) {
        mvar_t *tmp  = new_var (p->refctr);
        /* expand variables */
        execute (
            assgn (var (tmp->name),
                   leftjoin (var (v->name),
                             var (env_at (in_env, i).mvar->name))),
            /* because leftjoin does not know that we have
               exactly one match for each tuple in v,
               we need to make the heads void ourselves */
            assgn (var (tmp->name),
                   reverse (mark (reverse (var (tmp->name)),
                                  lit_oid (0)))));

        env_add (p->env,
                 env_at (in_env, i).col,
                 env_at (in_env, i).ty,
                 tmp);
    }
}
/* fold) */

/* fold( twig_state_t / global twig_state definition */
/**
 * @brief The state information necessary to build a twig
 *        of multiple node constructors in one go.
 */
struct twig_state_t {
    unsigned int pre;          /**< pre id in the twig tree */
    unsigned int parent;       /**< pre id of the parent in the twig tree */
    unsigned int size;         /**< static size value of a node */
    unsigned int level;        /**< static level of a twig node */
    PFarray_t   *elem_vars;    /**< ordered list of node constructor
                                    representations */
    PFarray_t   *attr_vars;    /**< ordered list of attribute constructor
                                    representations */
    PFmil_t     *loop;         /**< loop relation */
    bool         elem_content; /**< information if a content operator
                                    with element nodes appears in the twig */
};

/** @brief short-hand for struct twig_state_t */
typedef struct twig_state_t twig_state_t;

/** @brief current twig state */
static twig_state_t *twig_state;
/* fold) */

/* fold( new_trace_id() / global global_trace_id definition */

/** @brief global ID for tracing */
static unsigned int global_trace_id;

/**
 * @brief Return a ``new'' trace id. This id is used
 *        to refer to a certain trace relation.
 */
static unsigned int
new_trace_id (void)
{
    /* the trace_id corresponds to the oids
       in the trace containers */
    return global_trace_id++;
}
/* fold) */

/** @brief Function call parameter list. */
static PFarray_t *fun_params = NULL;

/** @brief The maximum number of non-terminals in the brg grammar rules */
#define MAX_KIDS 10
/** @brief A flag indicating whether the operators has been seen already */
#define SEEN(p) ((p)->bit_dag)

/** @brief mnemonic for a sort specification list */
#define sortby(...)     PFord_order_intro (__VA_ARGS__)

/* forward declaration */
static void reduce (PFpa_op_t * p, int goalnt);

/***********************************/
/* fold( reduce() helper functions */
/***********************************/
/** @brief Lookup the type of the @a col column in the schema of node @a n. */
static PFalg_simple_type_t
type_of (const PFpa_op_t *n, PFalg_col_t col)
{ /* fold( */
    assert (n);

    for (unsigned int i = 0; i < n->schema.count; i++)
        if (n->schema.items[i].name == col)
            return n->schema.items[i].type;

    PFoops (OOPS_FATAL,
            "cannot determine implementation type of algebra expression");

    assert (0); /* never reached due to "exit" in "PFoops" */
    return aat_nat; /* pacify picky compilers */
} /* fold) */

/** @brief Compile a physical algebra literal value into its MIL equivalent. */
static PFmil_t *
literal_ (PFalg_atom_t atom, PFalg_simple_type_t type)
{ /* fold( */

    if (atom.is_null)
        PFoops (OOPS_FATAL, "NULL values have not yet been implemented.");

    switch (type) {

        case aat_nat:  return lit_oid (atom.val.nat_);
        case aat_int:  return lit_lng (atom.val.int_);
        case aat_uA:
        case aat_str:  return lit_str (atom.val.str);
        case aat_dec:  return lit_dbl (atof(atom.val.dec_));
        case aat_dbl:  return lit_dbl (atof(atom.val.dbl));
        case aat_bln:  return lit_bit (atom.val.bln);
        case aat_qname_id:
            return add_qname (lit_str (PFqname_prefix (atom.val.qname)),
                              lit_str (PFqname_uri (atom.val.qname)),
                              lit_str (PFqname_loc (atom.val.qname)),
                              var (PF_MIL_VAR_WS));
        case aat_qname_cont:
            return var (PF_MIL_VAR_WS_CONT);

        default:
            break;
    }

    PFoops (OOPS_FATAL,
            "A relational algebra type (%u) has not yet "
            "been implemented.", atom.type);

    assert (0); /* never reached due to "exit" in "PFoops" */
    return NULL; /* pacify picky compilers */
} /* fold) */
/** @brief Compile a physical algebra literal value into its MIL equivalent. */
#define literal(a) (literal_ ((a), (a).type))

/**
 * @brief Generate MIL code for an intersection.
 *
 * @param p the intersection operator
 * @param left the schema of the arguments from the left input
 * @param right the schema of the arguments from the right input
 * @param[out] res the MIL variable the result is assigned to.
 */
static void
intersect (PFpa_op_t *p,
           PFalg_schema_t left, PFalg_schema_t right,
           mvar_t *res)
{ /* fold( */
    PFarray_t          *helper_vars = PFarray (sizeof (mvar_t *), 10);
    PFalg_col_t         lcol,
                        rcol;
    PFalg_simple_type_t lty  = 0,
                        rty  = 0;
    PFmil_t            *args = NULL;
    mvar_t             *l = NULL,
                       *r = NULL;

    assert (left.count == right.count);

    /* collect all arguments/columns for the intersection ... */
    for (unsigned int i = 0; i < left.count; i++) { /* fold( */
        lcol = left.items[i].name;
        rcol = right.items[i].name;
        lty  = left.items[i].type;
        rty  = right.items[i].type;

        /* cope with simple types */
        if (type_bit_check (lty) && lty == rty) {
            l = env_mvar (L(p)->env, lcol, lty);
            r = env_mvar (R(p)->env, rcol, rty);
        }
        /* cope with nodes */
        else if (!(~aat_node & lty) && !(~aat_node & rty)) {
            /* cope with conflicting nodes (attr vs. node) */
            if ((lty == aat_pnode && rty == aat_anode) ||
                (lty == aat_anode && rty == aat_pnode)) {
                args = arg (seqbase (new (type (mty_void),
                                          type (mty_oid)),
                                     lit_oid (0)),
                            seqbase (new (type (mty_void),
                                          type (mty_oid)),
                                     lit_oid (0)));
                break;
            }
            /* cope with normal nodes only */
            else if (lty == aat_pnode && rty == aat_pnode) {
                l = env_mvar (L(p)->env, lcol, aat_pre);
                r = env_mvar (R(p)->env, rcol, aat_pre);
            }
            /* cope with attribute nodes only */
            else if (lty == aat_anode && rty == aat_anode) {
                l = env_mvar (L(p)->env, lcol, aat_attr);
                r = env_mvar (R(p)->env, rcol, aat_attr);
            }
            /* cope with a mix of all possible nodes */
            else if (lty == aat_node && rty == aat_node) {
                mvar_t *lpre  = new_var (1),
                       *rpre  = new_var (1),
                       *lattr = new_var (1),
                       *rattr = new_var (1);

                *(mvar_t **) PFarray_add (helper_vars) = lpre;
                *(mvar_t **) PFarray_add (helper_vars) = rpre;
                *(mvar_t **) PFarray_add (helper_vars) = lattr;
                *(mvar_t **) PFarray_add (helper_vars) = rattr;

                /* We have to ensure that tuples with nil values
                   are not ignored. We therefore shift all pre
                   and attr id by one and replace nil by 0. This
                   way attributes only match attributes and
                   other nodes only match non-attribute nodes. */
                l = env_mvar (L(p)->env, lcol, aat_pre);
                r = env_mvar (R(p)->env, rcol, aat_pre);

                execute (
                    assgn (var (lpre->name),
                           mifthenelse (
                               misnil (var (l->name)),
                               project (var (l->name),
                                        lit_int (0)),
                               madd (mcast (type (mty_lng),
                                            var (l->name)),
                                     lit_int (1)))),
                    assgn (var (rpre->name),
                           mifthenelse (
                               misnil (var (r->name)),
                               project (var (r->name),
                                        lit_int (0)),
                               madd (mcast (type (mty_lng),
                                            var (r->name)),
                                     lit_int (1)))));

                /* add the pre column */
                if (!args)
                    args = arg (var (lpre->name), var (rpre->name));
                else
                    args = arg (args, arg (var (lpre->name),
                                           var (rpre->name)));

                l = env_mvar (L(p)->env, lcol, aat_attr);
                r = env_mvar (R(p)->env, rcol, aat_attr);

                execute (
                    assgn (var (lattr->name),
                           mifthenelse (
                               misnil (var (l->name)),
                               project (var (l->name),
                                        lit_int (0)),
                               madd (mcast (type (mty_lng),
                                            var (l->name)),
                                     lit_int (1)))),
                    assgn (var (rattr->name),
                           mifthenelse (
                               misnil (var (r->name)),
                               project (var (r->name),
                                        lit_int (0)),
                               madd (mcast (type (mty_lng),
                                            var (r->name)),
                                     lit_int (1)))));

                /* add the attr column */
                args = arg (args, arg (var (lattr->name), var (rattr->name)));

                l = env_mvar (L(p)->env, lcol, aat_frag);
                r = env_mvar (R(p)->env, rcol, aat_frag);

                args = arg (args, arg (var (l->name), var (r->name)));

                /* jump over the shared code as we already added
                   everything to the argument by hand. */
                continue;
            }
#ifndef NDEBUG
            else
                assert (!"thinking error in intersect translation");
#endif

            /* add the attr/pre column */
            if (!args)
                args = arg (var (l->name), var (r->name));
            else
                args = arg (args, arg (var (l->name),
                                       var (r->name)));
            l = env_mvar (L(p)->env, lcol, aat_frag);
            r = env_mvar (R(p)->env, rcol, aat_frag);
        }
        /* cope with QNames */
        else if (aat_qname == lty && aat_qname == rty) {
            mvar_t *luri_loc = new_var (1),
                   *ruri_loc = new_var (1);

            *(mvar_t **) PFarray_add (helper_vars) = luri_loc;
            *(mvar_t **) PFarray_add (helper_vars) = ruri_loc;

            execute (
                assgn (var (luri_loc->name),
                       mposjoin (VAR (L(p)->env, lcol, aat_qname_id),
                                 VAR (L(p)->env, lcol, aat_qname_cont),
                                 var (PF_MIL_VAR_QN_URI_LOC))),
                assgn (var (ruri_loc->name),
                       mposjoin (VAR (R(p)->env, rcol, aat_qname_id),
                                 VAR (R(p)->env, rcol, aat_qname_cont),
                                 var (PF_MIL_VAR_QN_URI_LOC))));

            if (!args)
                args = arg (var (luri_loc->name), var (ruri_loc->name));
            else
                args = arg (args, arg (var (luri_loc->name),
                                       var (ruri_loc->name)));

            /* jump over the shared code as we already added
               everything to the argument by hand. */
            continue;
        }
        else
            PFoops (OOPS_FATAL,
                    "cannot handle polymorphic join columns "
                    " in the intersect translation for MIL");

        if (!args)
            args = arg (var (l->name), var (r->name));
        else
            args = arg (args, arg (var (l->name), var (r->name)));
    } /* fold) */

    /* apply the multi-column equi-join */
    execute (assgn (var (res->name),
                    mc_intersect (args)));

    for (unsigned int i = 0; i < PFarray_last (helper_vars); i++)
        unpin (*(mvar_t **) PFarray_at (helper_vars, i), 1);
} /* fold) */

/**
 * @brief Generate MIL code that prepares the input
 *        for an (in)equality comparison.
 *
 * @param l the left input relation
 * @param r the right input relation
 * @param lcol the comparison column of the left input
 * @param rcol the comparison column of the right input
 * @param[out] lres the MIL variable which the result
 *                  of the preparation for the left input
 *                  is assigned to
 * @param[out] rres the MIL variable which the result
 *                  of the preparation for the right input
 *                  is assigned to
 */
static void
prepare_comp (PFpa_op_t *l, PFpa_op_t *r,
              PFalg_col_t lcol, PFalg_col_t rcol,
              mvar_t *lres, mvar_t *rres)
{ /* fold( */
    PFalg_simple_type_t lty = type_of (l, lcol),
                        rty = type_of (r, rcol);

    /* cope with simple types */
    if (type_bit_check (lty) && lty == rty) {
        execute (
            assgn (var (lres->name),
                   VAR (l->env, lcol, lty)),
            assgn (var (rres->name),
                   VAR (r->env, rcol, rty)));
    }
    /* cope with nodes */
    else if (!(~aat_node & lty) && !(~aat_node & rty)) {
        mvar_t *tmp_res = new_var (1),
               *lf      = env_mvar (l->env, lcol, aat_frag),
               *rf      = env_mvar (r->env, rcol, aat_frag);

        /* cope with normal nodes only */
        if (lty == aat_pnode && rty == aat_pnode) {
            mvar_t *lp = env_mvar (l->env, lcol, aat_pre);
            mvar_t *rp = env_mvar (r->env, rcol, aat_pre);
            execute (assgn (var (tmp_res->name),
                            zip_nodes (
                                var (lf->name),
                                var (lp->name),
                                nil (),
                                var (rf->name),
                                var (rp->name),
                                nil ())));
        }
        /* cope with attribute nodes only */
        else if (lty == aat_anode && rty == aat_anode) {
            mvar_t *la = env_mvar (l->env, lcol, aat_attr);
            mvar_t *ra = env_mvar (r->env, rcol, aat_attr);
            execute (assgn (var (tmp_res->name),
                            zip_nodes (
                                var (lf->name),
                                var (la->name),
                                nil (),
                                var (rf->name),
                                var (ra->name),
                                nil ())));
        }
        /* cope with a mix of all possible nodes */
        else if ((lty == aat_node && rty == aat_node) ||
                 (lty == aat_pnode && rty == aat_anode) ||
                 (lty == aat_anode && rty == aat_pnode)) {
            /* We have to ensure that tuples with nil values
               are not ignored. We therefore shift all pre
               and attr id by one and replace nil by 0. This
               way attributes only match attributes and
               other nodes only match non-attribute nodes. */
            mvar_t *lp = new_var (1);
            mvar_t *rp = new_var (1);
            mvar_t *la = new_var (1);
            mvar_t *ra = new_var (1);

            if (lty & aat_pre)
                execute (
                    assgn (var (lp->name), VAR (l->env, lcol, aat_pre)),
                    assgn (var (lp->name),
                           mifthenelse (
                               misnil (var (lp->name)),
                               project (var (lp->name),
                                        lit_int (0)),
                               madd (mcast (type (mty_lng),
                                            var (lp->name)),
                                     lit_int (1)))));
            else
                execute (
                    assgn (var (lp->name),
                           project (var (lf->name), lit_int (0))));

            if (rty & aat_pre)
                execute (
                    assgn (var (rp->name), VAR (r->env, rcol, aat_pre)),
                    assgn (var (rp->name),
                           mifthenelse (
                               misnil (var (rp->name)),
                               project (var (rp->name),
                                        lit_int (0)),
                               madd (mcast (type (mty_lng),
                                            var (rp->name)),
                                     lit_int (1)))));
            else
                execute (
                    assgn (var (rp->name),
                           project (var (rf->name), lit_int (0))));

            if (lty & aat_attr)
                execute (
                    assgn (var (la->name), VAR (l->env, lcol, aat_attr)),
                    assgn (var (la->name),
                           mifthenelse (
                               misnil (var (la->name)),
                               project (var (la->name),
                                        lit_int (0)),
                               madd (mcast (type (mty_lng),
                                            var (la->name)),
                                     lit_int (1)))));
            else
                execute (
                    assgn (var (la->name),
                           project (var (lf->name), lit_int (0))));

            if (rty & aat_attr)
                execute (
                    assgn (var (ra->name), VAR (r->env, rcol, aat_attr)),
                    assgn (var (ra->name),
                           mifthenelse (
                               misnil (var (ra->name)),
                               project (var (ra->name),
                                        lit_int (0)),
                               madd (mcast (type (mty_lng),
                                            var (ra->name)),
                                     lit_int (1)))));
            else
                execute (
                    assgn (var (ra->name),
                           project (var (rf->name), lit_int (0))));

            execute (
                assgn (var (tmp_res->name),
                       zip_nodes (
                           var (lf->name),
                           var (lp->name),
                           var (la->name),
                           var (rf->name),
                           var (rp->name),
                           var (ra->name))));
            unpin (lp, 1);
            unpin (rp, 1);
            unpin (la, 1);
            unpin (ra, 1);
        }
#ifndef NDEBUG
        else
            assert (!"thinking error in comparison");
#endif
        execute (assgn (var (lres->name),
                        fetch (var (tmp_res->name),
                               lit_int (0))),
                 assgn (var (rres->name),
                        fetch (var (tmp_res->name),
                               lit_int (1))));
        unpin (tmp_res, 1);
    }
    /* cope with QNames */
    else if (aat_qname == lty && aat_qname == rty) {
        execute (
            assgn (var (lres->name),
                   mposjoin (VAR (l->env, lcol, aat_qname_id),
                             VAR (l->env, lcol, aat_qname_cont),
                             var (PF_MIL_VAR_QN_URI_LOC))),
            assgn (var (rres->name),
                   mposjoin (VAR (r->env, rcol, aat_qname_id),
                             VAR (r->env, rcol, aat_qname_cont),
                             var (PF_MIL_VAR_QN_URI_LOC))));
    }
    else
        PFoops (OOPS_FATAL,
                "cannot handle polymorphic join columns "
                " in the thetajoin translation for MIL"
                " (got 0x%X and 0x%X)", lty, rty);
} /* fold) */

/**
 * @brief Generate MIL code that produces an order extend
 *        based on the order given in @a ord.
 *
 * @param p the order (extend) operator
 * @param ord the list of orderings that have to be applied
 * @param[out] res the MIL variable the extend is assigned to
 */
static void
order_extend (PFpa_op_t *p, PFord_ordering_t ord, mvar_t *res)
{ /* fold( */
    /*
     * Derive a single BAT from the multi-column grouping
     * (using functions from the xtables module).
     */
    PFalg_col_t col;
    bool        dir,
                initialized = false;

    for (unsigned int i = 0; i < PFord_count (ord); i++) {
        col = PFord_order_col_at (ord, i);
        dir = PFord_order_dir_at (ord, i);

        /* special case QNames -- here we need to look up the
           values */
        if (type_of (p, col) & aat_qname) {
            mvar_t *qn = new_var (1);
            execute (
                assgn (var (qn->name),
                       mposjoin (VAR (p->env, col, aat_qname_id),
                                 VAR (p->env, col, aat_qname_cont),
                                 var (PF_MIL_VAR_QN_URI_LOC))));
            if (!initialized) {
                execute (
                    assgn (var (res->name),
                           reverse (
                               sort (reverse (var (qn->name)), dir))));
                initialized = true;
            }
            else
                execute (
                    assgn (var (res->name),
                           ctrefine (var (res->name), var (qn->name),
                                     dir)));
            unpin (qn, 1);
        }
        else
            /* cope with all non-QName types */
            for (PFalg_simple_type_t t = 1; t; t <<= 1)
                if (t & TYPE_MASK(type_of (p, col)) &&
                    !(t & aat_qname)) {
                    if (!initialized) {
                        execute (
                            assgn (var (res->name),
                                   reverse (
                                       sort (
                                           reverse (
                                               VAR (p->env, col, t)),
                                           dir))));
                        initialized = true;
                    }
                    else
                        execute (
                            assgn (var (res->name),
                                   ctrefine (var (res->name),
                                             VAR (p->env, col, t),
                                             dir)));
                }
    }
} /* fold) */

/**
 * @brief Generate MIL code that extracts the QName references
 *        from a node column @a col in a given operator @a p.
 *
 * @param p the operator whose column values are used
 * @param col the column that holds the node references
 * @param[out] id the MIL variable the references to the QName
 *                entries are assigned to
 * @param[out] cont the MIL variable the containers to the respective
 *                  QName references are assigned to
 *
 * @return indicate if all rows provide a QName
 */
static bool
fn_node_name (PFpa_op_t *p, PFalg_col_t col, mvar_t *id, mvar_t *cont, bool set)
{ /* fold( */
    PFla_op_t          *origin     = PFprop_lineage (p->prop, col);
    bool                names_only = false;
    PFalg_simple_type_t ty         = type_of (p, col);

    if (ty == aat_pnode) {
        /* find all element nodes and extract their QName references */
        mvar_t  *kind      = new_var (1),
                *elem      = new_var (1),
                *elem_cont = new_var (1),
                *map       = new_var (1);
        PFmil_t *pre       = VAR (p->env, col, aat_pre),
                *pre_cont  = VAR (p->env, col, aat_frag);

        /* check if the input stems from an element step */
        if (origin && origin->kind == la_step_join &&
            origin->sem.step.item_res == PFprop_lineage_col (p->prop, col) &&
            origin->sem.step.spec.kind == node_kind_elem) {
            execute (
                assgn (var (id->name),
                       mposjoin (pre, pre_cont,
                                 fetch (var (PF_MIL_VAR_WS),
                                        var (PF_MIL_VAR_PRE_PROP)))),
                assgn (var (cont->name),
                       mposjoin (pre, pre_cont,
                                 fetch (var (PF_MIL_VAR_WS),
                                        var (PF_MIL_VAR_PRE_CONT)))));
            names_only = true;
        }
        else
            execute (
                assgn (var (kind->name),
                       mposjoin (
                           pre,
                           pre_cont,
                           fetch (var (PF_MIL_VAR_WS),
                                  var (PF_MIL_VAR_PRE_KIND)))),
                assgn (var (map->name),
                       hmark (select_ (var (kind->name),
                                       var (PF_MIL_VAR_KIND_ELEM)),
                              lit_oid (0))),
                assgn (var (elem->name),
                       leftfetchjoin (var (map->name), pre)),
                assgn (var (elem_cont->name),
                       leftfetchjoin (var (map->name), pre_cont)),
                assgn (var (id->name),
                       leftfetchjoin (
                           reverse (var (map->name)),
                           mposjoin (var (elem->name),
                                     var (elem_cont->name),
                                     fetch (var (PF_MIL_VAR_WS),
                                            var (PF_MIL_VAR_PRE_PROP))))),
                assgn (var (cont->name),
                       leftfetchjoin (
                           reverse (var (map->name)),
                           mposjoin (var (elem->name),
                                     var (elem_cont->name),
                                     fetch (var (PF_MIL_VAR_WS),
                                            var (PF_MIL_VAR_PRE_CONT))))));

        unpin (kind, 1);
        unpin (elem, 1);
        unpin (elem_cont, 1);
        unpin (map, 1);
    }
    else if (ty == aat_anode) {
        /* extract all QName references from the attributes */
        PFmil_t *attr      = VAR (p->env, col, aat_attr),
                *attr_cont = VAR (p->env, col, aat_frag);

        execute (
            assgn (var (id->name),
                   mposjoin (attr,
                             attr_cont,
                             fetch (var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_ATTR_QN)))),
            assgn (var (cont->name),
                   mposjoin (attr,
                             attr_cont,
                             fetch (var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_ATTR_CONT)))));
        names_only = true;
    }
    else {
        assert (ty == aat_node);

        /* split up nodes and attributes,
           find all element nodes and extract their QName references */
        mvar_t  *elem      = new_var (1),
                *elem_cont = new_var (1),
                *pre_sel   = new_var (1),
                *attr_sel  = new_var (1),

                *pid       = new_var (1),
                *pcont     = new_var (1),
                *aid       = new_var (1),
                *acont     = new_var (1),
                *res       = new_var (1),

                *attr_col  = env_mvar (p->env, col, aat_attr);
        PFmil_t *pre       = VAR (p->env, col, aat_pre),
                *pre_cont  = VAR (p->env, col, aat_frag),
                *attr      = VAR (p->env, col, aat_attr);

        execute (
            /* get all attributes */
            assgn (var (attr_sel->name),
                   hmark (
                       select2 (var (attr_col->name),
                                cast (type (mty_oid), nil ()),
                                cast (type (mty_oid), nil ())),
                       lit_oid (0))),
            /* get all attribute QNames */
            assgn (var (aid->name),
                   mposjoin (leftfetchjoin (var (attr_sel->name), attr),
                             leftfetchjoin (var (attr_sel->name), pre_cont),
                             fetch (var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_ATTR_QN)))),
            assgn (var (acont->name),
                   mposjoin (leftfetchjoin (var (attr_sel->name), attr),
                             leftfetchjoin (var (attr_sel->name), pre_cont),
                             fetch (var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_ATTR_CONT)))),
            /* get all other nodes */
            assgn (var (pre_sel->name),
                   hmark (
                       select_ (
                           misnil (var (attr_col->name)),
                           lit_bit (true)),
                       lit_oid (0))),
            /* get all element nodes */
            assgn (var (elem->name),
                   leftfetchjoin (var (pre_sel->name), pre)),
            assgn (var (elem_cont->name),
                   leftfetchjoin (var (pre_sel->name), pre_cont)),
            assgn (var (pre_sel->name),
                   leftfetchjoin (
                       reverse (var (pre_sel->name)),
                       mposjoin (var (elem->name),
                                 var (elem_cont->name),
                                 fetch (var (PF_MIL_VAR_WS),
                                        var (PF_MIL_VAR_PRE_KIND))))),
            assgn (var (pre_sel->name),
                   hmark (select_ (var (pre_sel->name),
                                   var (PF_MIL_VAR_KIND_ELEM)),
                          lit_oid (0))),
            assgn (var (elem->name),
                   leftfetchjoin (var (pre_sel->name), pre)),
            assgn (var (elem_cont->name),
                   leftfetchjoin (var (pre_sel->name), pre_cont)),
            /* get all element QNames */
            assgn (var (pid->name),
                   mposjoin (var (elem->name),
                             var (elem_cont->name),
                             fetch (var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_PRE_PROP)))),
            assgn (var (pcont->name),
                   mposjoin (var (elem->name),
                             var (elem_cont->name),
                             fetch (var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_PRE_CONT)))),
            /* combine the results */
            assgn (var (res->name),
                   merged_union (
                       arg (var (attr_sel->name),
                            arg (var (pre_sel->name),
                                 arg (var (aid->name),
                                      arg (var (pid->name),
                                           arg (var (acont->name),
                                                var (pcont->name)))))))),
            assgn (var (id->name),
                   leftfetchjoin (
                       reverse (fetch (var (res->name), lit_int (0))),
                       fetch (var (res->name), lit_int (1)))),
            assgn (var (cont->name),
                   leftfetchjoin (
                       reverse (fetch (var (res->name), lit_int (0))),
                       fetch (var (res->name), lit_int (2)))));

        unpin (elem, 1);
        unpin (elem_cont, 1);
        unpin (pre_sel, 1);
        unpin (attr_sel, 1);
        unpin (aid, 1);
        unpin (pid, 1);
        unpin (acont, 1);
        unpin (pcont, 1);
        unpin (res, 1);
    }

    /* remove the duplicates early -- before
       duplicates are removed based on strings */
    if (set &&
        /* avoid rewrite if we are not done afterwards */
        names_only) {
        /* we assign new head values here -- as we are sure that
           this logical column (BATs id & cont) is the only column
           that is used lateron */
        mvar_t *unq = new_var (1);
        execute (
            if_ (eq (count (tunique (var (cont->name))),
                     lit_int (1)),
                 seq (assgn (var (unq->name),
                             reverse (kunique (reverse (var (id->name))))),
                 seq (/* make sure that the output is sorted
                         in the input order again */
                      assgn (var (unq->name),
                             reverse (sort (var (unq->name), DIR_ASC))),
                 seq (assgn (var (id->name),
                             hmark (var (unq->name), lit_oid (0))),
                 seq (assgn (var (cont->name),
                             tmark (
                                 leftfetchjoin (var (unq->name),
                                                var (cont->name)),
                                 lit_oid (0))))))),
                 nop ()));
        unpin (unq, 1);
    }

    return names_only;
} /* fold) */

/**
 * @brief Generate MIL code that transforms strings into QNames.
 *
 * @param[in] in the MIL variable that refers to the BAT of input strings
 * @param[out] out the MIl variable the references to the QName
 *                 entries are assigned to
 */
static void
transform_QName (mvar_t *in, mvar_t *out)
{ /* fold( */
    mvar_t  *offset  = new_var (1);
    mvar_t  *prefix  = new_var (1);
    mvar_t  *local   = new_var (1);
    mvar_t  *err_str = new_var (1);

    /* split up strings using ``:'' as delimiter */
    /* FIXME: currently we we don't retrieve the URI */
    execute (
        assgn (var (err_str->name),
               check_qnames (var (in->name))),
        if_ (not (isnil (var (err_str->name))),
             error (arg (lit_str ("err:FORG0001. "
                                  "illegal QName '%s'."),
                         var (err_str->name))),
             nop ()),
        assgn (var (offset->name),
               msearch (var (in->name), lit_str (":"))),
        assgn (var (prefix->name),
               mstring2 (var (in->name),
                         lit_int (0),
                         var (offset->name))),
        assgn (var (local->name),
               mstring (var (in->name),
                        madd (lit_int (1),
                              var (offset->name)))),
        /* add_qnames changes the working set
           in 'var (PF_MIL_VAR_WS)' as side effect */
        assgn (var (out->name),
               add_qnames (
                   var (prefix->name),
                   project (var (prefix->name),
                            lit_str ("")),
                   var (local->name),
                   var (PF_MIL_VAR_WS))));

    unpin (offset, 1);
    unpin (prefix, 1);
    unpin (local, 1);
    unpin (err_str, 1);
} /* fold) */

/**
 * @brief Generate MIL code that copies QNames from arbitrary containers
 *        to the WS container.
 *
 * @param[in] in_qn_id the MIL variable the QName reference are bound to
 * @param[in] in_qn_cont the MIL variable the QName reference containers
 *                       are bound to
 * @param[out] qn_id the MIL variable the references to the QName
 *                   entries in the WS container are assigned to
 */
static void
copy_QName (mvar_t *in_qn_id, mvar_t *in_qn_cont, mvar_t *qn_id)
{ /* fold( */
    mvar_t  *qn_cont  = new_var (1),
            *qn_id_ws = new_var (1),
            *qn_bool  = new_var (1),
            *qn_map   = new_var (1),
            *prefix   = new_var (1),
            *uri      = new_var (1),
            *local    = new_var (1),
            *mu_res   = new_var (1);
    PFmil_t *bodymilprog,
            *oldmilprog;

    /* check if all QNames reside in the transient container
       - if not we need to copy them */
    oldmilprog = milprog;
    /* start new milprog for the nesting:
       'if (...) {...} else {}' */
    milprog = nop ();

    execute (
        assgn (var (qn_bool->name),
               meq (var (in_qn_cont->name), var (PF_MIL_VAR_WS_CONT))),
        assgn (var (qn_map->name),
               mirror (select_ (var (qn_bool->name),
                                lit_bit (false)))),
        assgn (var (qn_id->name),
               leftfetchjoin (
                   var (qn_map->name),
                   var (in_qn_id->name))),
        assgn (var (qn_cont->name),
               leftfetchjoin (
                   var (qn_map->name),
                   var (in_qn_cont->name))),
        assgn (var (prefix->name),
               mposjoin (var (qn_id->name),
                         var (qn_cont->name),
                         fetch (var (PF_MIL_VAR_WS),
                                var (PF_MIL_VAR_QN_PREFIX)))),
        assgn (var (uri->name),
               mposjoin (var (qn_id->name),
                         var (qn_cont->name),
                         fetch (var (PF_MIL_VAR_WS),
                                var (PF_MIL_VAR_QN_URI)))),
        assgn (var (local->name),
               mposjoin (var (qn_id->name),
                         var (qn_cont->name),
                         fetch (var (PF_MIL_VAR_WS),
                                var (PF_MIL_VAR_QN_LOC)))),
        assgn (var (qn_id->name),
               add_qnames (
                   var (prefix->name),
                   var (uri->name),
                   var (local->name),
                   var (PF_MIL_VAR_WS))),
        assgn (var (qn_id_ws->name),
               leftfetchjoin (
                   mirror (select_ (var (qn_bool->name),
                                    lit_bit (true))),
                   var (in_qn_id->name))),
        assgn (var (mu_res->name),
               merged_union (
                   arg (hmark (var (qn_id->name), lit_oid (0)),
                        arg (hmark (var (qn_id_ws->name), lit_oid (0)),
                             arg (tmark (var (qn_id->name), lit_oid (0)),
                                  tmark (var (qn_id_ws->name), lit_oid (0))
                                  ))))),
        assgn (var (qn_id->name),
               leftfetchjoin (
                   reverse (fetch (var (mu_res->name), lit_int (0))),
                   fetch (var (mu_res->name), lit_int (1)))));

    /* store nested MIL code */
    bodymilprog = milprog;
    /* activate old mil program */
    milprog = oldmilprog;

    /* fill in the MIL code for the QName transfer:
       if (count unchanged) { do nothing } else { transform ... } */
    execute (
        if_ (eq (count (select_ (var (in_qn_cont->name),
                                 var (PF_MIL_VAR_WS_CONT))),
                 count (var (in_qn_cont->name))),
        /* then */ assgn (var (qn_id->name), var (in_qn_id->name)),
        /* else */ bodymilprog));

    unpin (qn_cont, 1);
    unpin (qn_id_ws, 1);
    unpin (qn_bool, 1);
    unpin (qn_map, 1);
    unpin (prefix, 1);
    unpin (uri, 1);
    unpin (local, 1);
    unpin (mu_res, 1);
} /* fold) */

/**
 * @brief Translation of the cross product.
 *
 * @param p   The physical algebra tree node that we are to translate.
 *            This function will actually fill @a p's environment
 *            <code>p->env</code>.
 */
static void
cross_worker (PFpa_op_t *p)
{ /* fold( */
    mvar_t *v  = new_var (1);
    mvar_t *v1 = new_var (1);
    mvar_t *v2 = new_var (1);

    if (!env_count (L(p)->env) || !env_count (R(p)->env))
        PFoops (OOPS_FATAL, "Cross does not cope with empty schemas");

    /* The cross product of two relations with cardinality 1
       requires no MIL code. */
    if (PFprop_card (L(p)->prop) == 1 &&
        PFprop_card (R(p)->prop) == 1) {
        env_copy (p, L(p)->env);
        env_copy (p, R(p)->env);
    }
    else {
        /* evaluate the cross product and create two map relations */
        execute (
            assgn (var (v->name),
                   cross (
                       project (ANY_VAR(L(p)->env), nil ()),
                       reverse (project (ANY_VAR(R(p)->env), nil ())))),
            assgn (var (v1->name),
                   reverse (mark (var (v->name), lit_oid (0)))),
            assgn (var (v2->name),
                   reverse (mark (reverse (var (v->name)),
                                  lit_oid (0)))));

        /* map all columns from the left and the right argument */
        env_map (p, L(p)->env, v1);
        env_map (p, R(p)->env, v2);
    }

    unpin (v, 1);
    unpin (v1, 1);
    unpin (v2, 1);
} /* fold) */

#define llscj(p)     llscj_worker ((p), false)
#define llscj_dup(p) llscj_worker ((p), true)
/**
 * Translate loop-lifted staircase joins.
 */
static void
llscj_worker (PFpa_op_t *p, bool duplicates)
{ /* fold( */
    /* abbreviations for input expressions */
    PFord_ordering_t in  = p->sem.scjoin.in;
    PFord_ordering_t out = p->sem.scjoin.out;

    char *qn_uri = PFqname_uri (p->sem.scjoin.spec.qname),
         *qn_loc = PFqname_loc (p->sem.scjoin.spec.qname);

    PFmil_t *axis,    /* axis specifier */
            *code,    /* code indicating which additional tests
                         have to be applied (name or kind) */
            *order,   /* order specifier */
            *kind,    /* kind specifier */
            *uri,     /* namespace specifier */
            *loc,     /* local name specifier */
            *tgt;     /* target name specifier */
    int      o;       /* helper to compute order specifier */
    mvar_t  *step     = new_var (1),         /* the step result variable */
            *map      = new_var (1),         /* mapping helper variable */
            *ret_iter = new_var (p->refctr), /* the `iter' result variable */
            *ret_frag = new_var (p->refctr), /* the `frag' result variable */
            *ret_pre  = new_var (p->refctr); /* the `pre' result variable */

    PFalg_col_t pa_iter     = p->sem.scjoin.iter,
                pa_item     = p->sem.scjoin.item,
                pa_item_res;

    assert (p); assert (L(p)); assert (L(p)->env);

    if (duplicates)
        pa_item_res = pa_iter;
    else {
        pa_item_res = pa_item;
        assert (type_of (L(p), pa_iter) == aat_nat);
    }

    /* collect all information to check *//* fold( */
    /* translate axis information */
    axis = NULL;
    switch (p->sem.scjoin.spec.axis) {
        case alg_anc:    axis = var (PF_MIL_VAR_AXIS_ANC);    break;
        case alg_anc_s:  axis = var (PF_MIL_VAR_AXIS_ANC_S);  break;
        case alg_chld:   axis = var (PF_MIL_VAR_AXIS_CHLD);   break;
        case alg_desc:   axis = var (PF_MIL_VAR_AXIS_DESC);   break;
        case alg_desc_s: axis = var (PF_MIL_VAR_AXIS_DESC_S); break;
        case alg_fol:    axis = var (PF_MIL_VAR_AXIS_FOL);    break;
        case alg_fol_s:  axis = var (PF_MIL_VAR_AXIS_FOL_S);  break;
        case alg_par:    axis = var (PF_MIL_VAR_AXIS_PAR);    break;
        case alg_prec:   axis = var (PF_MIL_VAR_AXIS_PREC);   break;
        case alg_prec_s: axis = var (PF_MIL_VAR_AXIS_PREC_S); break;
        case alg_self:   axis = var (PF_MIL_VAR_AXIS_SELF);   break;
        case alg_attr:   axis = var (PF_MIL_VAR_AXIS_ATTR);   break;
        /* StandOff axes */
        case alg_so_select_narrow:         
                         axis = var (PF_MIL_VAR_AXIS_SELECT_NARROW);   
                                                              break;
        case alg_so_select_wide:   
                         axis = var (PF_MIL_VAR_AXIS_SELECT_WIDE);
                                                              break;
    }

    /*
     * Determine in- and output orderings.
     * MIL functions expect this information encoded in an integer
     * value that we build up here.
     */
    if (duplicates) {
        if (in) /* if there is an order it's item order */
            o = 1;
        else
            o = 0;

        if (out) /* if there is an order it's item order */
            o |= 2;
        else
            o |= 0;
    }
    else {
        if (PFord_implies (in, sortby (pa_iter, pa_item)))
            o = 0;
        else if (PFord_implies (in, sortby (pa_item, pa_iter)))
            o = 1;
        else
            PFoops (OOPS_FATAL, "illegal argument for input ordering");

        if (PFord_implies (out, sortby (pa_iter, pa_item)))
            o |= 0;
        else if (PFord_implies (out, sortby (pa_item, pa_iter)))
            o |= 2;
        else
            PFoops (OOPS_FATAL, "illegal argument for output ordering");
    }

    order = lit_int (o);

    /* initialize the code */
    code = var (PF_MIL_VAR_CODE_KIND);
    /* translate kind information */
    kind = NULL;
    switch (p->sem.scjoin.spec.kind) {
        case node_kind_elem: kind = var (PF_MIL_VAR_KIND_ELEM);    break;
        case node_kind_attr: kind = cast (type (mty_chr), nil ()); break;
        case node_kind_text: kind = var (PF_MIL_VAR_KIND_TEXT);    break;
        case node_kind_pi:   kind = var (PF_MIL_VAR_KIND_PI);      break;
        case node_kind_comm: kind = var (PF_MIL_VAR_KIND_COM);     break;
        case node_kind_doc:  kind = var (PF_MIL_VAR_KIND_DOC);     break;
        case node_kind_node: kind = cast (type (mty_chr), nil ());
        /* overwrite code */ code = var (PF_MIL_VAR_CODE_NONE);
    }

    /* translate name information and extend testing code */
    if (p->sem.scjoin.spec.kind == node_kind_pi && qn_loc) {
        code = var (PF_MIL_VAR_CODE_TARGET);
        uri  = cast (type (mty_str), nil ());
        loc  = cast (type (mty_str), nil ());
        tgt  = lit_str (qn_loc);
    }
    else if (qn_uri && qn_loc) {
        code = var (PF_MIL_VAR_CODE_NSLOC);
        uri  = lit_str (qn_uri);
        loc  = lit_str (qn_loc);
        tgt  = cast (type (mty_str), nil ());
    }
    else if (qn_uri) {
        code = var (PF_MIL_VAR_CODE_NS);
        uri  = lit_str (qn_uri);
        loc  = cast (type (mty_str), nil ());
        tgt  = cast (type (mty_str), nil ());
    }
    else if (qn_loc) {
        code = var (PF_MIL_VAR_CODE_LOC);
        uri  = cast (type (mty_str), nil ());
        loc  = lit_str (qn_loc);
        tgt  = cast (type (mty_str), nil ());
    }
    else {
        uri  = cast (type (mty_str), nil ());
        loc  = cast (type (mty_str), nil ());
        tgt  = cast (type (mty_str), nil ());
    }
    /* end of collect all information to check *//* fold) */

    /*
     * step := step (...);
     * iter := step.fetch (0);
     * frag := step.fetch (1);
     * pre  := step.fetch (2);
     */
    execute (
         assgn (var (step->name),
                step (axis, code,
                      duplicates /* for step_join use head as iter */
                      ? mirror (VAR (L(p)->env, pa_item, aat_pre))
                      : VAR (L(p)->env, pa_iter, type_of (L(p), pa_iter)),
                      VAR (L(p)->env, pa_item, aat_frag),
                      VAR (L(p)->env, pa_item, aat_pre),
                      type_of (L(p), pa_item) & aat_attr
                      ? VAR (L(p)->env, pa_item, aat_attr)
                      : nil (),
                      var (PF_MIL_VAR_WS),
                      order, kind,
                      uri, loc, tgt)),
         assgn (var (ret_pre->name), fetch (var (step->name), lit_int (2))),
         /*
          * Should we actually do materialize at runtime? In most cases
          * we should be able to see at compile time if columns are guaranteed
          * to be constant. We could then avoid carrying around the column at
          * all.
          *
          * Problem is: We do consider a `constant' property in our algebra
          * (not fully, yet, but the ideas are there). This property, however
          * only looks at ``real'' algebra columns. Here, materialize operates
          * on only part of a ``real'' column. The ``real'' column `item' is
          * implemented as `pre|kind' for nodes. And while kind may be constant,
          * pre probably won't.
          */
         assgn (var (ret_frag->name),
                materialize (fetch (var (step->name), lit_int (1)),
                             var (ret_pre->name))),
         assgn (var (ret_iter->name),
                materialize (fetch (var (step->name), lit_int (0)),
                             var (ret_pre->name))));

    /* add the result variables to the environment */
    if (duplicates) {
        env_map (p, L(p)->env, ret_iter);
        unpin (ret_iter, p->refctr);
    }
    else
        env_add (p->env, pa_iter, aat_nat, ret_iter);

    env_add (p->env, pa_item_res, aat_pre, ret_pre);
    env_add (p->env, pa_item_res, aat_frag, ret_frag);

    if (type_of (p, pa_item_res) & aat_attr) {
        mvar_t *ret_attr = new_var (p->refctr);

        execute (
             assgn (var (ret_attr->name),
                    fetch (var (step->name), lit_int (3))));

        env_add (p->env, pa_item_res, aat_attr, ret_attr);
    }

    unpin (step, 1);
    unpin (map, 1);

} /* fold) */

#ifdef HAVE_PFTIJAH /* fold( */

/* PFTIJAH helper functions */

#define PFT_NOT_ORDERED	0
#define PFT_ORDERED	1

static mvar_t *
pft_create_pfop (PFpa_op_t *p, PFalg_simple_type_t t, int ordered)
{
	mvar_t *res;
	if ( p ) {
	    res  = new_var (1);
	    mvar_t *p_iter = env_mvar (p->env, p->schema.items[0].name /* iter */, aat_nat);
	    mvar_t *p_item = env_mvar (p->env, p->schema.items[2].name /* item */, t);
	    mvar_t *p_frag;
	    if ( t == aat_pre ) {
	        p_frag = env_mvar (p->env, p->schema.items[2].name /* item */, aat_frag);
	    } else {
	        p_frag = new_var (1);
		execute(
                    assgn (var (p_frag->name), lit_int(0))
		);
	    }
	    PFmil_t *mil_p_pos;

	    if ( ordered ) {
	        PFalg_simple_type_t postype = p->schema.items[1].type;
	        mvar_t *p_pos  = env_mvar (p->env, p->schema.items[1].name /* pos */, postype);
	        if ( !(p_iter && p_item && p_frag && p_pos) )
		    PFoops(OOPS_FATAL,"pft_create_pfop: missing [iter|item|frag|pos] child");
	    	mil_p_pos  =  var (p_pos->name);
	    } else {
	    	mil_p_pos  =  var (PF_MIL_TIJAH_DUMMYPOS);
	    }
	    execute (
                assgn (var (res->name), 
                          tj_pfop(var (p_iter->name),var(p_item->name),var(p_frag->name),mil_p_pos))
	    );
	    if ( t != aat_pre )
	        unpin(p_frag,1);
	} else {
	    res  = new_var (1);
	    execute (
                assgn (var (res->name), 
                          seqbase (new (type (mty_void), type(mty_bat) ),
                                            lit_oid (0)))
	    );
	}
	return res;
}

static void
pft_unpack_pfop(PFpa_op_t* dest, mvar_t *pack,
		     PFalg_col_t a_iter,
		     PFalg_col_t a_item,
		     PFalg_simple_type_t t_item,
		     PFalg_col_t a_frag,
		     PFalg_col_t a_pos,
		     PFalg_col_t a_score
		    )
{
	mvar_t *v_iter  = new_var (dest->refctr);
	execute (
	    assgn (var (v_iter->name),
		fetch (var (pack->name), lit_int (0))));
	env_add (dest->env, a_iter, aat_nat, v_iter);

	mvar_t *v_item  = new_var (dest->refctr);
	execute (
	    assgn (var (v_item->name),
		fetch (var (pack->name), lit_int (1))));
	env_add (dest->env, a_item, t_item, v_item);


	if ( a_frag ) {
	    mvar_t *v_frag  = new_var (dest->refctr);
	    execute (
	        assgn (var (v_frag->name),
		    fetch (var (pack->name), lit_int (2))));
	    env_add (dest->env, a_frag, aat_frag, v_frag);
	}

	mvar_t *v_pos  = new_var (dest->refctr);
	execute (
	    assgn (var (v_pos->name),
		fetch (var (pack->name), lit_int (3))));
	env_add (dest->env, a_pos, aat_nat, v_pos);

	if ( a_score ) {
	    mvar_t *v_score  = new_var (dest->refctr);
	    execute (
	        assgn (var (v_score->name),
		    fetch (var (pack->name), lit_int (4))));
	    env_add (dest->env, a_score, aat_dbl, v_score);
	}
}

#endif /* fold) */

/***********************************/
/* fold) end reduce helper functions */
/***********************************/

/* fold( reduce*() functions implementing the rec_* operators */
/*
 * Alternative reducer function. Introduces code that is invariant
 * to the recursion before the recursion body is translated.
 */
static void
reduce_rec_border (PFpa_op_t * p, int goalnt, PFarray_t *border_vars)
{ /* fold( */
    int           rule;           /* rule number that matches for this node */
    short        *nts;            /* target non-terminals for the leaf nodes of
                                     the current rule */
    PFpa_op_t    *kids[MAX_KIDS]; /* leaf nodes of this rule */

    assert (p);

    /* determine rule that matches for this non-terminal */
    rule = PFmilgen_rule (STATE_LABEL (p), goalnt);

    /* guard against too dep recursion */
    PFrecursion_fence();

    /* PFinfo (OOPS_NOTICE, "match for rule %i", rule); */
    assert(rule);

    /* initialize the kids[] vector */
    for (unsigned short i = 0; i < MAX_KIDS; i++)
        kids[i] = NULL;

    /*
     * prepare recursive traversal: get information on leaf nodes of
     * this rule
     */
    nts = PFmilgen_nts[rule];
    PFmilgen_kids (p, rule, kids);

    switch (rule) {
        /* Rel:      rec_fix (side_effects (Side, Rec), Rel) */
        case 140:
            /* only follow the parameters */
            reduce_rec_border (kids[1], nts[1], border_vars);
            break;

        /* Rec:      rec_param (rec_arg (Rel, Rel), Rec) */
        case 141:
            /* only follow the seeds */
            reduce_rec_border (kids[0], nts[0], border_vars);
            /* and the rest of the parameter list */
            reduce_rec_border (kids[2], nts[2], border_vars);
            break;

        /* Rec:      rec_param (rec_arg (empty_tbl, Rel), Rec) */
        case 142:
            /* follow the rest of the parameter list */
            reduce_rec_border (kids[1], nts[1], border_vars);
            break;

        /* Rec:      nil */
        case 143:
            /* nothing to be done */
            break;

        /* Rel:      rec_border (Rel) */
        case 145:
            if (!p->env) {
                /* translate sub-DAG starting at the border */
                reduce (p, goalnt);
                assert (p->env);
                /* increase the pin count by one to avoid releasing the
                   variables before the end of the while loop and remember
                   which variables to unpin afterwards */
                for (unsigned int i = 0; i < env_count (p->env); i++) {
                    pin (env_at (p->env, i).mvar, 1);
                    *(mvar_t **) PFarray_add (border_vars)
                        = env_at (p->env, i).mvar;
                }
            }
            break;

        default:
            for (unsigned short i = 0; nts[i]; i++)
                reduce_rec_border (kids[i], nts[i], border_vars);
    }
} /* fold) */

/*
 * Alternative reducer function. Copes with patterns that are
 * larger than the burg patterns (e.g., variable parameter lists
 * required for the recursion operator). It contains the
 * respective action code for some of the above burg patterns.
 */
static void
reduce1 (PFpa_op_t * p, int goalnt, PFarray_t *border_vars)
{ /* fold( */
    int           rule;           /* rule number that matches for this node */
    short        *nts;            /* target non-terminals for the leaf nodes of
                                     the current rule */
    PFpa_op_t    *kids[MAX_KIDS]; /* leaf nodes of this rule */

    assert (p);
    /* reduce1 should be called only once for each pattern */
    if (p->env)
        return;

    /* guard against too dep recursion */
    PFrecursion_fence();

    p->env = new_env ();

    /* determine rule that matches for this non-terminal */
    rule = PFmilgen_rule (STATE_LABEL (p), goalnt);

    /* PFinfo (OOPS_NOTICE, "match for rule %i", rule); */
    assert(rule);

    /* initialize the kids[] vector */
    for (unsigned short i = 0; i < MAX_KIDS; i++)
        kids[i] = NULL;

    /*
     * prepare recursive traversal: get information on leaf nodes of
     * this rule
     */
    nts = PFmilgen_nts[rule];
    PFmilgen_kids (p, rule, kids);

#ifndef NDEBUG
    execute (comment ("Begin rule (reduce1): \"%s\"", PFmilgen_string[rule]));
#endif

    switch (rule) {
        /* Rec:      rec_param (rec_arg (Rel, Rel), Rec) */
        case 141:
            /* only generate MIL code for the seed */
            reduce (kids[0], nts[0]);

            /* relink the enviroment of arg to its base */
            L(p)->sem.rec_arg.base->env = p->env;

            /* Copy the result of the the seed into a new variable.
               This variable is pinned for each call of the base
               (base and paramter both refer to the same environment)
               and additionally for each parameter to avoid that the
               variable is overwritten during generation of the recursion. */
            for (unsigned int i = 0; i < env_count (LL(p)->env); i++) {
                mvar_t *tmp  = new_var (p->refctr +
                                        L(p)->sem.rec_arg.base->refctr);

                /* copy variable */
                execute (
                    assgn (var (tmp->name),
                           var (env_at (LL(p)->env, i).mvar->name)));

                /* add the variable to the current environment
                   (and thus also to the base environment) */
                env_add (p->env,
                         env_at (LL(p)->env, i).col,
                         env_at (LL(p)->env, i).ty,
                         tmp);

                /* unpin the seed once -- the recursion now does not
                   reference it anymore */
                unpin (((env_t *) PFarray_at (kids[0]->env, i))->mvar, 1);
            }

            /* translate all the remaining seeds */
            reduce1 (kids[2], nts[2], border_vars);

            /* translate all expressions that are invariant to
               the recursion body */
            reduce_rec_border (kids[1], nts[1], border_vars);
            break;

        /* Rec:      rec_param (rec_arg (empty_tbl, Rel), Rec) */
        case 142:
        {
            PFalg_simple_type_t ty;

            /* relink the enviroment of arg to its base */
            L(p)->sem.rec_arg.base->env = p->env;

            /* For each column and type in the empty table generate
               a new bat and assign it to the variables used by the
               recursion. */
            for (unsigned int col = 0; col < LL(p)->schema.count; col++) {
                if (!LL(p)->schema.items[col].type)
                    PFoops (OOPS_FATAL,
                            "empty sequence should never "
                            "occur in MIL generation.");

                for (PFalg_simple_type_t t = 1; t; t <<= 1) {
                    ty = TYPE_MASK(LL(p)->schema.items[col].type);
                    if (t & ty) {
                        mvar_t *tmp  = new_var (p->refctr +
                                                L(p)->sem.rec_arg.base->refctr);

                        /* assign an empty BAT to the new variable */
                        execute (
                            assgn (var (tmp->name),
                                   seqbase (new (type (mty_void),
                                                 implty (t, ty)),
                                            lit_oid (0))));

                        /* add the variable to the current environment
                           (and thus also to the base environment) */
                        env_add (p->env,
                                 LL(p)->schema.items[col].name,
                                 t,
                                 tmp);
                    }
                }
            }

            /* translate all the remaining seeds */
            reduce1 (kids[1], nts[1], border_vars);

            /* translate all expressions that are invariant to
               the recursion body */
            reduce_rec_border (kids[0], nts[0], border_vars);
        }   break;

        /* Rec:      nil */
        case 143:
            /* no MIL code needed */
            break;

        default:
            PFoops (OOPS_FATAL,
                    "cannot cope with rule %d in "
                    "alternative reduce function",
                    rule);
    }

#ifndef NDEBUG
    execute (comment ("End rule (reduce1): \"%s\"", PFmilgen_string[rule]));
    for (unsigned int i = 0; i < PFarray_last (p->env); i++)
        assert (((env_t *) PFarray_at (p->env, i))->mvar->pins);
#endif

#ifndef NDEBUG
    /* Debugging only: assign column names to BATs */
    /* switch off debugging information as it triggers errors in MonetDB...
    for (unsigned int i = 0; i < env_count (p->env); i++)
        execute (col_name (var (env_at (p->env, i).mvar->name),
                           lit_str (PFatt_str (env_at (p->env, i).col))));
    */
#endif

} /* fold) */

/*
 * Alternative reducer function. Copes with patterns that are
 * larger than the burg patterns (e.g., variable parameter lists
 * required for the recursion operator). It contains the
 * respective action code for some of the above burg patterns.
 */
static void
reduce2 (PFpa_op_t * p, int goalnt)
{ /* fold( */
    int           rule;           /* rule number that matches for this node */
    short        *nts;            /* target non-terminals for the leaf nodes of
                                     the current rule */
    PFpa_op_t    *kids[MAX_KIDS]; /* leaf nodes of this rule */
    int           pos_body;       /* position of the recursion body in the
                                     list of kids */

    /* reduce2 should be only called after reduce1 */
    if (!p->env)
        PFoops (OOPS_FATAL,
                "cannot cope with function reduce2 "
                "as long as reduce1 was not called.");

    /* guard against too dep recursion */
    PFrecursion_fence();

    /* determine rule that matches for this non-terminal */
    rule = PFmilgen_rule (STATE_LABEL (p), goalnt);

    /* PFinfo (OOPS_NOTICE, "match for rule %i", rule); */
    assert(rule);

    /* initialize the kids[] vector */
    for (unsigned short i = 0; i < MAX_KIDS; i++)
        kids[i] = NULL;

    /*
     * prepare recursive traversal: get information on leaf nodes of
     * this rule
     */
    nts = PFmilgen_nts[rule];
    PFmilgen_kids (p, rule, kids);

#ifndef NDEBUG
    execute (comment ("Begin rule (reduce2): \"%s\"", PFmilgen_string[rule]));
#endif

    pos_body = 0;

    switch (rule) {
        /* Rec:      rec_param (rec_arg (Rel, Rel), Rec) */
        case 141:
            pos_body = 1; /* discard the seed */
        /* Rec:      rec_param (rec_arg (empty_tbl, Rel), Rec) */
        case 142:
            /* only generate MIL code for the body */
            reduce (kids[pos_body], nts[pos_body]);
            /* translate all the remaining parts of the body */
            reduce2 (kids[pos_body + 1], nts[pos_body + 1]);

            /* ensure that we have a 1:1 mapping of the environments */
            assert (PFarray_last (p->env) == PFarray_last (LR(p)->env));

            /* Reassign the variables. Thus the initial seed relations
               are overwritten by the result of the recursion */
            for (unsigned int i = 0; i < PFarray_last (p->env); i++) {
                env_t entry = env_at (p->env, i);

                /* find the corresponding variable in res for
                   the variable in p */
                mvar_t *tmp = env_mvar (LR(p)->env, entry.col, entry.ty);

                execute (
                    assgn (var (entry.mvar->name),
                           var (tmp->name)));

                /* unpin the recursion once -- the recursion now does not
                   reference it anymore */
                unpin (tmp, 1);
            }
            break;

        /* Rec:      nil */
        case 143:
            /* no MIL code needed */
            break;

        default:
            PFoops (OOPS_FATAL,
                    "cannot cope with rule %d in "
                    "alternative reduce function",
                    rule);
    }

#ifndef NDEBUG
    execute (comment ("End rule (reduce2): \"%s\"", PFmilgen_string[rule]));
    for (unsigned int i = 0; i < PFarray_last (p->env); i++)
        assert (((env_t *) PFarray_at (p->env, i))->mvar->pins);
#endif

#ifndef NDEBUG
    /* Debugging only: assign column names to BATs */
    /* switch off debugging information as it triggers errors in MonetDB...
    for (unsigned int i = 0; i < env_count (p->env); i++)
        execute (col_name (var (env_at (p->env, i).mvar->name),
                           lit_str (PFcol_str (env_at (p->env, i).col))));
    */
#endif

} /* fold) */

/*
 * Alternative reducer function. Copes with patterns that are
 * larger than the burg patterns (e.g., variable parameter lists
 * required for the recursion operator). It contains the
 * respective action code for some of the above burg patterns.
 */
static void
reduce3 (PFpa_op_t * p, int goalnt)
{ /* fold( */
    int           rule;           /* rule number that matches for this node */
    short        *nts;            /* target non-terminals for the leaf nodes of
                                     the current rule */
    PFpa_op_t    *kids[MAX_KIDS]; /* leaf nodes of this rule */
    int           pos_list;       /* position of the param list in the
                                     list of kids */

    /* reduce3 should be only called after reduce1 */
    if (!p->env)
        PFoops (OOPS_FATAL,
                "cannot cope with function reduce3 "
                "as long as reduce1 was not called.");

    /* guard against too dep recursion */
    PFrecursion_fence();

    /* determine rule that matches for this non-terminal */
    rule = PFmilgen_rule (STATE_LABEL (p), goalnt);

    /* PFinfo (OOPS_NOTICE, "match for rule %i", rule); */
    assert(rule);

    /* initialize the kids[] vector */
    for (unsigned short i = 0; i < MAX_KIDS; i++)
        kids[i] = NULL;

    /*
     * prepare recursive traversal: get information on leaf nodes of
     * this rule
     */
    nts = PFmilgen_nts[rule];
    PFmilgen_kids (p, rule, kids);

#ifndef NDEBUG
    execute (comment ("Begin rule (reduce3): \"%s\"", PFmilgen_string[rule]));
#endif

    pos_list = 1;

    switch (rule) {
        /* Rec:      rec_param (rec_arg (Rel, Rel), Rec) */
        case 141:
            pos_list = 2; /* discard the seed */
        /* Rec:      rec_param (rec_arg (empty_tbl, Rel), Rec) */
        case 142:
            /* translate all the remaining parts of the list */
            reduce3 (kids[pos_list], nts[pos_list]);

            /* release the remaining pins that ensured that the
               recursion input arguments were not overwritten
               during the recursion. */
            for (unsigned int i = 0; i < PFarray_last (p->env); i++) {
                unpin (env_at (p->env, i).mvar, p->refctr);
            }
            break;

        /* Rec:      nil */
        case 143:
            /* no MIL code needed */
            break;

        default:
            PFoops (OOPS_FATAL,
                    "cannot cope with rule %d in "
                    "alternative reduce function",
                    rule);
    }

#ifndef NDEBUG
    execute (comment ("End rule (reduce3): \"%s\"", PFmilgen_string[rule]));
#endif

#ifndef NDEBUG
    /* Debugging only: assign column names to BATs */
    /* switch off debugging information as it triggers errors in MonetDB...
    for (unsigned int i = 0; i < env_count (p->env); i++)
        execute (col_name (var (env_at (p->env, i).mvar->name),
                           lit_str (PFcol_str (env_at (p->env, i).col))));
    */
#endif

} /* fold) */
/* fold) */

/* fold( reduce_border() function implementing the dep_border operator */
/*
 * Alternative reducer function. Introduces code that is also used
 * outside the branch before the conditional part is translated.
 */
static void
reduce_border (PFpa_op_t * p, int goalnt, int border_rule)
{ /* fold( */
    int           rule;           /* rule number that matches for this node */
    short        *nts;            /* target non-terminals for the leaf nodes of
                                     the current rule */
    PFpa_op_t    *kids[MAX_KIDS]; /* leaf nodes of this rule */

    assert (p);

    /* determine rule that matches for this non-terminal */
    rule = PFmilgen_rule (STATE_LABEL (p), goalnt);

    /* guard against too deep recursion */
    PFrecursion_fence();

    /* PFinfo (OOPS_NOTICE, "match for rule %i", rule); */
    assert(rule);

    /* initialize the kids[] vector */
    for (unsigned short i = 0; i < MAX_KIDS; i++)
        kids[i] = NULL;

    /*
     * prepare recursive traversal: get information on leaf nodes of
     * this rule
     */
    nts = PFmilgen_nts[rule];
    PFmilgen_kids (p, rule, kids);

    /* skip the compilation for all operators until we reach
       the dep_border or cache_border operator */
    if (rule != border_rule)
        for (unsigned short i = 0; nts[i]; i++)
            reduce_border (kids[i], nts[i], border_rule);
    else if (!p->env) {
        /* translate sub-DAG starting at the border */
        reduce (p, goalnt);
        assert (p->env);
    }
} /* fold) */
/* fold) */

/**
 * @brief Reducer function.
 *
 * This is the heart of this source file. It contains all the action code
 * for the above burg patterns.
 */
static void
do_reduce (PFpa_op_t * p, int rule, short *nts, PFpa_op_t *kids[]);

static void
reduce (PFpa_op_t * p, int goalnt)
{ /* fold( */
    int           rule;           /* rule number that matches for this node */
    short        *nts;            /* target non-terminals for the leaf nodes of
                                     the current rule */
    PFpa_op_t    *kids[MAX_KIDS]; /* leaf nodes of this rule */
    bool          topdown;        /* is this a top-down rule? */

    if (p->env)
        return;

    /* determine rule that matches for this non-terminal */
    rule = PFmilgen_rule (STATE_LABEL (p), goalnt);

    /* PFinfo (OOPS_NOTICE, "match for rule %i", rule); */
    assert(rule);

    /* guard against too deep recursion */
    PFrecursion_fence();

    /* initialize the kids[] vector */
    for (unsigned short i = 0; i < MAX_KIDS; i++)
        kids[i] = NULL;

    /*
     * prepare recursive traversal: get information on leaf nodes of
     * this rule
     */
    nts = PFmilgen_nts[rule];
    PFmilgen_kids (p, rule, kids);

    /* PFinfo (OOPS_NOTICE, "in rule %u", rule); */

    switch (rule) {
        /* Query:    serialize (Side, Rel) */
        case 1:
        /* Query:    serialize (Side, empty_tbl) */
        case 2:
        /* Rel:      dep_cross (Rel, Rel) */
        case 12:
        /* Rel:      twig (Twig) */
        case 102:
        /* Fcns:     fcns (Twig, Fcns) */
        case 105:
        /* Twig:     docnode (Rel, Fcns) */
        case 108:
        /* Twig:     element (Rel, Fcns) */
        case 110:
        /* Side:     cache (Side, Rel) */
        case 131:
        /* Rel:      rec_fix (side_effects (Side, Rec), Rel) */
        case 140:
        /* FunRel:   fun_call (Rel, Param) */
        case 151:
        /* Param:    fun_param (Rel, Param) */
        case 152:
            topdown = true;
            break;

        /* Side:     error (Side, Rel) */
        case 129:
        /* Side:     trace (Side, trace_items (Rel, trace_msg (Rel, Map))) */
        case 135:
        /* Side:     trace (Side, trace_items (Rel, trace_msg (Rel, nil))) */
        case 136:
            /* traverse the side effects in pre-order as otherwise
               a cached query might be used before it is defined */
            for (unsigned short i=0; i < MAX_KIDS; i++)
                if (kids[i])
                    reduce (kids[i], nts[i]);
            /* avoid traversing the plan a second time */
            topdown = true;
            break;

        default:
            topdown = false;
    }

    /*
     * Recursively invoke compilation.  This means bottom-up compilation.
     * (ensure that the fragment information is translated after
     *  the value part)
     */
    if (!topdown)
        for (unsigned short i = MAX_KIDS; i > 0; i--)
            if (kids[i - 1])
                reduce (kids[i - 1], nts[i - 1]);

    /* translate every operator only once */
    if (p->env)
        return;

    p->env = new_env ();

#ifndef NDEBUG
    execute (comment ("Begin rule: \"%s\"", PFmilgen_string[rule]));
#endif

    do_reduce (p, rule, nts, kids);
}

static void
do_reduce (PFpa_op_t * p, int rule, short *nts, PFpa_op_t *kids[])
{
    mvar_t *v;

    /* guard against too deep recursion */
    PFrecursion_fence();

    switch (rule) {
        /* Query:   serialize (Side, Rel) */
        case 1: /* fold( */
        {
            PFalg_simple_type_t ty;
            PFmil_create_ws_t create;
            mvar_t *err, *time, *try = NULL;
            PFalg_col_t pa_item = p->sem.serialize.item;
            PFmil_t *oldmilprog, *bodymilprog;

            /* save the current mil program */
            oldmilprog = milprog;

            /* create a new empty milprog */
            milprog = nop ();

            /* decide which type of new_ws should invoke */
            if (aat_update & type_of (R(p), pa_item)) {
                try = new_var(1);
                execute (
                    comment ("volatile variable environment "
                             "for an update query"),
                    assgn (var (PF_MIL_VAR_WS), new_ws (var (try->name))),
                    /* re-assign var(try) to be ready in case of a retry */
                    assgn (var (try->name),
                           add (var (try->name),
                                lit_int(1))));
            }
            else {
                if (aat_docmgmt & type_of (R(p), pa_item))
                    create = CREATE_DOCMGM_WS;
                else
                    create = CREATE_READ_ONLY_WS;

                execute (
                    comment ("volatile variable environment"),
                    assgn (var (PF_MIL_VAR_WS), new_ws (lit_int (create))));
            }
                       
            reduce (kids[0], nts[0]);
            reduce (kids[1], nts[1]);

            /* add timing information */
            time = new_var (1);
            execute (assgn (var (time->name), usec ()));

            /* check if the type of the root node is aat_update
               and if yes play the update tape */
            if (aat_update & type_of (R(p), pa_item)) { /* fold( */
                /* Set up all the value containers for update_tape(). */

                /* UpdateTape (
                       BAT[void,bat] ws,
                       BAT[void,int] kind,
                       BAT[void,oid] pre_tgt,
                       BAT[void,oid] pre_cont_tgt,
                       BAT[void,oid] attr_tgt,
                       BAT[void,oid] attr_cont_tgt,
                       BAT[void,str] replace_strings,
                       BAT[void,str] replace_qn_uristrings,
                       BAT[void,str] replace_qn_loc_strings,
                       BAT[void,oid] pre_ins,
                       BAT[void,oid] pre_cont_ins,
                       BAT[void,oid] attr_ins,
                       BAT[void,oid] attr_cont_ins): void
                */
                mvar_t *upd_kind               = new_var (1),
                       *pre_tgt                = new_var (1),
                       *pre_cont_tgt           = new_var (1),
                       *attr_tgt               = new_var (1),
                       *attr_cont_tgt          = new_var (1),
                       *replace_strings        = new_var (1),
                       *replace_qn_uri         = new_var (1),
                       *replace_qn_prefix      = new_var (1),
                       *replace_qn_locale      = new_var (1),
                       *pre_ins                = new_var (1),
                       *pre_cont_ins           = new_var (1),
                       *attr_ins               = new_var (1),
                       *attr_cont_ins          = new_var (1);

                ty = type_of (R(p), pa_item);

                /* consider update kind */
                execute (
                    assgn (var (upd_kind->name),
                           VAR (R(p)->env, pa_item, aat_update)),
                );

                /* consider node tgt */
                if (ty & aat_pnode1 && !(ty & aat_attr1)) {
                    /* all nodes but not attributes */
                    execute (
                        assgn (var (pre_tgt->name),
                               VAR (R(p)->env, pa_item, aat_pre1)),
                        assgn (var (pre_cont_tgt->name),
                               VAR (R(p)->env, pa_item, aat_frag1)));
                }
                else if (ty & aat_nkind1 && ty & aat_attr1) {
                    /* We have a mixed set of result nodes here
                       and need to use the attr column to find
                       all non-attribute nodes.  */
                    v = new_var (1);
                    execute (
                        assgn (var (v->name),
                               select2 (
                                   VAR (R(p)->env, pa_item, aat_pre1),
                                   cast (type (mty_oid), nil ()),
                                   cast (type (mty_oid), nil ()))),
                        assgn (var (v->name),
                               mirror (
                                   select_ (
                                       misnil (
                                           leftjoin (
                                               mirror (var (v->name)),
                                               VAR (R(p)->env,
                                                    pa_item,
                                                    aat_attr1))),
                                       lit_bit (true)))),
                        assgn (var (pre_tgt->name),
                               outerjoin (
                                   mirror (var (upd_kind->name)),
                                   leftjoin (
                                       var (v->name),
                                       VAR (R(p)->env, pa_item, aat_pre1)))),
                        assgn (var (pre_cont_tgt->name),
                                outerjoin (
                                   mirror (var (upd_kind->name)),
                                   leftjoin (
                                       var (v->name),
                                       VAR (R(p)->env, pa_item, aat_frag1)))));
                    unpin (v, 1);
                }
                else {
                    execute (
                        assgn (var (pre_tgt->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_oid), nil()))),
                        assgn (var (pre_cont_tgt->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_oid), nil()))));
                }

                /* consider attribute tgt */
                if (ty & aat_anode1 && !(ty & aat_nkind1)) {
                    /* only attr and no nkinds */
                    execute (
                        assgn (var (attr_tgt->name),
                               VAR (R(p)->env, pa_item, aat_attr1)),
                        assgn (var (attr_cont_tgt->name),
                               VAR (R(p)->env, pa_item, aat_frag1)));
                }
                else if (ty & aat_attr1) {
                    /* Because frag is shared for all nodes
                       we need the attr column to distinct
                       between attributes and non-attributes. */
                    v = new_var (1);
                    execute (
                        assgn (var (v->name),
                               select2 (
                                   VAR (R(p)->env, pa_item, aat_attr1),
                                   cast (type (mty_oid), nil ()),
                                   cast (type (mty_oid), nil ()))),
                        assgn (var (attr_tgt->name),
                               outerjoin (
                                   mirror (var (upd_kind->name)),
                                   var (v->name))),
                        assgn (var (attr_cont_tgt->name),
                               outerjoin (
                                   mirror (var (upd_kind->name)),
                                   leftjoin (
                                       mirror (var (v->name)),
                                       VAR (R(p)->env, pa_item, aat_frag1)))));
                    unpin (v, 1);
                }
                else {
                    /* no attributes */
                    execute (
                        assgn (var (attr_tgt->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_oid), nil()))),
                        assgn (var (attr_cont_tgt->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_oid), nil()))));
                }


                /* consider strings  (which are arriving as aat_uA...) */
                if (ty & aat_uA)
                    execute (
                        assgn (var (replace_strings->name),
                               VAR (R(p)->env, pa_item, aat_uA)));
                else
                    execute (
                        assgn (var (replace_strings->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_str), nil()))));

                /* consider qnames */ 
                if (ty & aat_qname) {

                    mvar_t *qn_id_no_nil   = new_var(1);
                    mvar_t *qn_cont_no_nil = new_var(1);
                    mvar_t *map            = new_var(1);

                    execute (
                        /* a range select(a,nil,nil) will return all BUNS
                         * that dont have nil on the tail                */
                        assgn (var (qn_id_no_nil->name),
                               select2 (VAR (R(p)->env,
                                             pa_item,
                                             aat_qname_id),
                                        cast (type (mty_oid), nil()),
                                        cast (type (mty_oid), nil()))),
                        assgn (var (qn_cont_no_nil->name),
                               select2 (VAR (R(p)->env,
                                             pa_item,
                                             aat_qname_cont),
                                        cast (type (mty_oid), nil()),
                                        cast (type (mty_oid), nil()))),
                        /* keep a map of the head oids [oid-h,void]*/
                        assgn (var (map->name),
                               mark (var (qn_id_no_nil->name),
                                     lit_oid(0))),
                        /* make the head dense for the mposjoin [void,oid-t]*/
                        assgn (var (qn_id_no_nil->name),
                               tmark (var (qn_id_no_nil->name),
                                      lit_oid(0))),
                        assgn (var (qn_cont_no_nil->name),
                               tmark (var (qn_cont_no_nil->name),
                                      lit_oid(0))),
                        /* finaly is time for the mposjoin */
                        assgn (var (replace_qn_uri->name),
                            mposjoin (var (qn_id_no_nil->name),
                                      var (qn_cont_no_nil->name),
                                      fetch (var (PF_MIL_VAR_WS),
                                             var (PF_MIL_VAR_QN_URI)))),
                        assgn (var (replace_qn_prefix->name),
                            mposjoin (var (qn_id_no_nil->name),
                                      var (qn_cont_no_nil->name),
                                      fetch (var (PF_MIL_VAR_WS),
                                             var (PF_MIL_VAR_QN_PREFIX)))),
                        assgn (var (replace_qn_locale->name),
                            mposjoin (var (qn_id_no_nil->name),
                                      var (qn_cont_no_nil->name),
                                      fetch (var (PF_MIL_VAR_WS),
                                             var (PF_MIL_VAR_QN_LOC)))),
                        /* now he have to map back and restore the nil tails
                         * producing a [oid-h,oid-t]. Then join back with the
                         * upd_kind bat to get the nil values.*/
                        assgn (var (replace_qn_uri->name),
                               outerjoin (mirror (var (upd_kind->name)),
                                          leftjoin (
                                              var (map->name),
                                              var (replace_qn_uri->name)))),
                        assgn (var (replace_qn_prefix->name),
                               outerjoin (mirror (var (upd_kind->name)),
                                          leftjoin (
                                              var (map->name),
                                              var (replace_qn_prefix->name)))),
                        assgn (var (replace_qn_locale->name),
                               outerjoin (mirror (var (upd_kind->name)),
                                          leftjoin (
                                              var (map->name),
                                              var (replace_qn_locale->name))))
                    ); /* end of execute */

                    unpin (qn_id_no_nil, 1);
                    unpin (qn_cont_no_nil, 1);
                    unpin (map, 1);

                } else
                    execute (
                        assgn (var (replace_qn_uri->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_str), nil()))),
                        assgn (var (replace_qn_prefix->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_str), nil()))),
                        assgn (var (replace_qn_locale->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_str), nil()))));

                /* consider node ins */
                if (ty & aat_pnode && !(ty & aat_attr)) {
                    /* all nodes but not attributes */
                    execute (
                        assgn (var (pre_ins->name),
                               VAR (R(p)->env, pa_item, aat_pre)),
                        assgn (var (pre_cont_ins->name),
                               VAR (R(p)->env, pa_item, aat_frag)));
                }
                else if (ty & aat_nkind && ty & aat_attr) {
                    /* We have a mixed set of result nodes here
                       and need to use the attr column to find
                       all non-attribute nodes.  */
                    v = new_var (1);
                    execute (
                        assgn (var (v->name),
                               select2 (
                                   VAR (R(p)->env, pa_item, aat_pre),
                                   cast (type (mty_oid), nil ()),
                                   cast (type (mty_oid), nil ()))),
                        assgn (var (v->name),
                               mirror (
                                   select_ (
                                       misnil (
                                           leftjoin (
                                               mirror (var (v->name)),
                                               VAR (R(p)->env,
                                                    pa_item,
                                                    aat_attr))),
                                       lit_bit (true)))),
                        assgn (var (pre_ins->name),
                               outerjoin (
                                   mirror (var (upd_kind->name)),
                                   leftjoin (
                                       var (v->name),
                                       VAR (R(p)->env, pa_item, aat_pre)))),
                        assgn (var (pre_cont_ins->name),
                               outerjoin (
                                   mirror (var (upd_kind->name)),
                                   leftjoin (
                                       var (v->name),
                                       VAR (R(p)->env, pa_item, aat_frag)))));
                    unpin (v, 1);
                }
                else {
                    execute (
                        assgn (var (pre_ins->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_oid), nil()))),
                        assgn (var (pre_cont_ins->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_oid), nil()))));
                }

                /* consider attribute ins */
                if (ty & aat_anode && !(ty & aat_nkind)) {
                    /* only attr and no nkinds */
                    execute (
                        assgn (var (attr_ins->name),
                               VAR (R(p)->env, pa_item, aat_attr)),
                        assgn (var (attr_cont_ins->name),
                               VAR (R(p)->env, pa_item, aat_frag)));
                }
                else if (ty & aat_attr) {
                    /* Because frag is shared for all nodes
                       we need the attr column to distinct
                       between attributes and non-attributes. */
                    v = new_var (1);
                    execute (
                        assgn (var (v->name),
                               select2 (
                                   VAR (R(p)->env, pa_item, aat_attr),
                                   cast (type (mty_oid), nil ()),
                                   cast (type (mty_oid), nil ()))),
                        assgn (var (attr_ins->name),
                               outerjoin (
                                   mirror (var (upd_kind->name)),
                                   var (v->name))),
                        assgn (var (attr_cont_ins->name),
                               outerjoin (
                                   mirror (var (upd_kind->name)),
                                   leftjoin (
                                       mirror (var (v->name)),
                                       VAR (R(p)->env, pa_item, aat_frag)))));
                    unpin (v, 1);
                }
                else {
                    /* no attributes */
                    execute (
                        assgn (var (attr_ins->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_oid), nil()))),
                        assgn (var (attr_cont_ins->name),
                               project (var (upd_kind->name),
                                        cast (type (mty_oid), nil()))));
                }

                /* execute update_tape */
                execute (
                    use (var (PF_MIL_VAR_XRPC_QID)),
                    update_tape (
                        arg (var (PF_MIL_VAR_WS),
                            arg (var (upd_kind->name),
                                arg (var (pre_tgt->name),
                                    arg (var (pre_cont_tgt->name),
                                        arg (var (attr_tgt->name),
                                            arg (var (attr_cont_tgt->name),
                        arg (var (replace_strings->name),
                            arg (var (replace_qn_uri->name),
                                arg (var (replace_qn_prefix->name),
                                    arg (var (replace_qn_locale->name),
                                        arg (var (pre_ins->name),
                                            arg (var (pre_cont_ins->name),
                                                arg (var (attr_ins->name),
                                                     var (attr_cont_ins->name)
                        )))))))))))))));  /* end of play update tape      */

                unpin (upd_kind, 1);
                unpin (pre_tgt, 1);
                unpin (pre_cont_tgt, 1);
                unpin (attr_tgt, 1);
                unpin (attr_cont_tgt, 1);
                unpin (replace_strings, 1);
                unpin (replace_qn_uri, 1);
                unpin (replace_qn_prefix, 1);
                unpin (replace_qn_locale, 1);
                unpin (pre_ins, 1);
                unpin (pre_cont_ins, 1);
                unpin (attr_ins, 1);
                unpin (attr_cont_ins, 1);

            } /* fold) */
            /* docmgmt query */
            else if (aat_docmgmt & type_of (R(p), pa_item)) { /* fold( */

                mvar_t *docmgmt  = new_var (1),
                       *docname  = new_var (1),
                       *colname  = new_var (1),
                       *filepath = new_var (1);

                ty = type_of (R(p), pa_item);

                /* consider docmgmt kind / percentage */
                execute (
                    assgn (var (docmgmt->name),
                           VAR (R(p)->env, pa_item, aat_docmgmt))
                );

                /* consider file path */
                if (ty & aat_path)
                    execute (
                        assgn (var (filepath->name),
                               VAR (R(p)->env, pa_item, aat_path)));
                else
                    execute (
                        assgn (var (filepath->name),
                               project (var (docmgmt->name),
                                        cast (type (mty_str), nil ()))));

                /* consider document names */
                execute (
                    assgn (var (docname->name),
                           VAR (R(p)->env, pa_item, aat_docnm)));

                /* consider colection names */
                if (ty & aat_colnm)
                    execute (
                        assgn (var (colname->name),
                               VAR (R(p)->env, pa_item, aat_colnm)));
                else
                    execute (
                        assgn (var (colname->name),
                               project (var (docmgmt->name),
                                        cast (type (mty_str), nil ()))));

                execute (
                    docmgmt_tape (
                        arg (var (PF_MIL_VAR_WS),
                            arg (var (filepath->name),
                                arg (var (docname->name),
                                    arg (var (colname->name),
                                         var (docmgmt->name)))))));

#ifdef HAVE_PFTIJAH
                execute (
		   	tj_docmgmt_tape (
			    var(PF_MIL_TIJAH_FTI_TAPE),
                            var (PF_MIL_VAR_WS),
                            var (filepath->name),
                            var (docname->name),
                            var (colname->name),
                            var (docmgmt->name))
		);
#endif
                unpin (docmgmt, 1);
                unpin (docname, 1);
                unpin (colname, 1);
                unpin (filepath, 1);

            } /* fold) */
            /* it is a normal query (neither update nor document management) */
            else { /* fold( */
                mvar_t *intVAL, *dblVAL, *decVAL, *strVAL;
                mvar_t *item, *kind;
                bool sorted = false;

                /* Set up all the value containers for print_result().
                 * (It is actually too much overhead to introduce the value
                 * containers just for printing. But this way we can re-use
                 * Jan F's print_result() and stay compatible with the
                 * ``summer branch''.
                 */

                intVAL = new_var (1);
                dblVAL = new_var (1);
                decVAL = dblVAL;
                strVAL = new_var (1);
                item   = new_var (1);
                kind   = new_var (1);

                execute (
                    assgn (var (intVAL->name),
                           seqbase (
                               reverse (
                                   key (new (type (mty_lng), type (mty_void)),
                                        true)),
                               lit_oid (0))),
                    assgn (var (dblVAL->name),
                           seqbase (
                               reverse (
                                   key (new (type (mty_dbl), type (mty_void)),
                                        true)),
                               lit_oid (0))),
                    /*
                    assgn (var (decVAL->name),
                           seqbase (
                               reverse (
                                   key (new (type (mty_dbl), type (mty_void)),
                                    true)),
                               lit_oid (0))),
                    */
                    assgn (var (strVAL->name),
                           seqbase (
                               reverse (
                                   key (new (type (mty_str), type (mty_void)),
                                        true)),
                               lit_oid (0))),
                    assgn (var (item->name),
                           seqbase (new (type (mty_void), type (mty_oid)),
                                    lit_oid(0))),
                    assgn (var (kind->name),
                           seqbase (new (type (mty_void), type (mty_int)),
                                    lit_oid(0)))
                    );

                ty = type_of (R(p), pa_item);

                /* consider attribute results */
                if (ty == aat_anode) {
                    execute (
                        assgn (var (item->name),
                               VAR (R(p)->env, pa_item, aat_attr)),
                        assgn (var (kind->name),
                               set_kind (VAR (R(p)->env,
                                              pa_item,
                                              aat_frag),
                                         var (PF_MIL_VAR_ATTR))));
                    sorted = true;
                }
                else if (ty & aat_attr) {
                    /* Because frag is shared for all nodes
                       we need the attr column to distinct
                       between attributes and non-attributes. */
                    v = new_var (1);
                    execute (
                        assgn (var (v->name),
                               select2 (
                                   VAR (R(p)->env, pa_item, aat_attr),
                                   cast (type (mty_oid), nil ()),
                                   cast (type (mty_oid), nil ()))),
                        binsert (var (item->name),
                                 var (v->name)),
                        binsert (var (kind->name),
                                 leftjoin (
                                     mirror (var (v->name)),
                                     set_kind (
                                         VAR (R(p)->env, pa_item, aat_frag),
                                         var (PF_MIL_VAR_ATTR)))));
                    unpin (v, 1);
                }

                /* consider node results */
                if (ty == aat_pnode) {
                    execute (
                        assgn (var (item->name),
                               VAR (R(p)->env, pa_item, aat_pre)),
                        assgn (var (kind->name),
                               set_kind (VAR (R(p)->env,
                                              pa_item,
                                              aat_frag),
                                         var (PF_MIL_VAR_ELEM))));
                    sorted = true;
                }
                else if (ty & aat_nkind && ty & aat_attr) {
                    /* We have a mixed set of result nodes here
                       and need to use the attr column to find
                       all non-attribute nodes.  */
                    v = new_var (1);
                    execute (
                        assgn (var (v->name),
                               select2 (
                                   VAR (R(p)->env, pa_item, aat_pre),
                                   cast (type (mty_oid), nil ()),
                                   cast (type (mty_oid), nil ()))),
                        assgn (var (v->name),
                               mirror (
                                   select_ (
                                       misnil (
                                           leftjoin (
                                               mirror (var (v->name)),
                                               VAR (R(p)->env,
                                                    pa_item,
                                                    aat_attr))),
                                       lit_bit (true)))),
                        binsert (var (item->name),
                                 leftjoin (var (v->name),
                                           VAR (R(p)->env, pa_item, aat_pre))),
                        binsert (var (kind->name),
                                 leftjoin (
                                     var (v->name),
                                     set_kind (
                                         VAR (R(p)->env, pa_item, aat_frag),
                                         var (PF_MIL_VAR_ELEM)))));
                    unpin (v, 1);
                }
                else if (ty & aat_nkind)
                    execute (
                        binsert (var (item->name),
                                 select2 (
                                     VAR (R(p)->env, pa_item, aat_pre),
                                     cast (type (mty_oid), nil ()),
                                     cast (type (mty_oid), nil ()))),
                        binsert (var (kind->name),
                                 select2 (
                                     set_kind (VAR (R(p)->env,
                                                    pa_item,
                                                    aat_frag),
                                               var (PF_MIL_VAR_ELEM)),
                                     cast (type (mty_int), nil ()),
                                     cast (type (mty_int), nil ()))));

                /* consider str results */
                if (ty & aat_str) {
                    execute (
                        bappend (var (strVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (VAR (R(p)->env,
                                                           pa_item,
                                                           aat_str),
                                                      cast (type (mty_str),
                                                            nil ()),
                                                      cast (type (mty_str),
                                                            nil ()))
                                             )))));
                    if (ty == aat_str) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (VAR (R(p)->env, pa_item, aat_str),
                                          reverse (var (strVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (VAR (R(p)->env, pa_item, aat_str),
                                         var (PF_MIL_VAR_STR)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (VAR (R(p)->env, pa_item, aat_str),
                                      reverse (var (strVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (VAR (R(p)->env,
                                                       pa_item,
                                                       aat_str),
                                                  cast (type (mty_str),
                                                        nil ()),
                                                  cast (type (mty_str),
                                                        nil ())),
                                         var (PF_MIL_VAR_STR)))
                        );
                    }
                }
#ifdef HAVE_GEOXML
                if (ty & aat_wkb) {
                    execute (
                        bappend (var (strVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (mcast (type (mty_str), VAR (R(p)->env,
                                                           pa_item,
                                                           aat_wkb)),
                                                      cast (type (mty_str),
                                                            nil ()),
                                                      cast (type (mty_str),
                                                            nil ()))
                                             )))));
                    if (ty == aat_str) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (mcast (type (mty_str),VAR (R(p)->env, pa_item, aat_wkb)),
                                          reverse (var (strVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (mcast (type (mty_str),VAR (R(p)->env, pa_item, aat_wkb)),
                                         var (PF_MIL_VAR_STR)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (mcast (type (mty_str),VAR (R(p)->env, pa_item, aat_wkb)),
                                      reverse (var (strVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (mcast (type (mty_str),VAR (R(p)->env,
                                                       pa_item,
                                                       aat_wkb)),
                                                  cast (type (mty_str),
                                                        nil ()),
                                                  cast (type (mty_str),
                                                        nil ())),
                                         var (PF_MIL_VAR_STR)))
                        );
                    }
                }
#endif
                /* consider aat_dtime */
                if (ty & aat_dtime) {
                    execute (
                        bappend (var (strVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (mcast (type (mty_str),
                                                             VAR (R(p)->env,
                                                             pa_item,
                                                             aat_dtime)),
                                                      cast (type (mty_str),
                                                            nil ()),
                                                      cast (type (mty_str),
                                                            nil ()))
                                             )))));
                    if (ty == aat_dtime) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (mcast (type (mty_str),
                                                 VAR (R(p)->env,
                                                 pa_item,
                                                 aat_dtime)),
                                          reverse (var (strVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (mcast (type (mty_str),
                                                VAR (R(p)->env,
                                                pa_item,
                                                aat_dtime)),
                                         var (PF_MIL_VAR_STR)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (mcast (type (mty_str),
                                             VAR (R(p)->env,
                                                  pa_item,
                                                  aat_dtime)),
                                      reverse (var (strVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (mcast (type (mty_str),
                                                         VAR (R(p)->env,
                                                         pa_item,
                                                         aat_dtime)),
                                                  cast (type (mty_str),
                                                        nil ()),
                                                  cast (type (mty_str),
                                                        nil ())),
                                         var (PF_MIL_VAR_STR)))
                        );
                    }
                }

                /* consider aat_date */
                if (ty & aat_date) {
                    execute (
                        bappend (var (strVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (mcast (type (mty_str),
                                                             VAR (R(p)->env,
                                                             pa_item,
                                                             aat_date)),
                                                      cast (type (mty_str),
                                                            nil ()),
                                                      cast (type (mty_str),
                                                            nil ()))
                                             )))));
                    if (ty == aat_date) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (mcast (type (mty_str),
                                                 VAR (R(p)->env,
                                                 pa_item,
                                                 aat_date)),
                                          reverse (var (strVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (mcast (type (mty_str),
                                                VAR (R(p)->env,
                                                pa_item,
                                                aat_date)),
                                         var (PF_MIL_VAR_STR)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (mcast (type (mty_str),
                                             VAR (R(p)->env,
                                                  pa_item,
                                                  aat_date)),
                                      reverse (var (strVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (mcast (type (mty_str),
                                                         VAR (R(p)->env,
                                                         pa_item,
                                                         aat_date)),
                                                  cast (type (mty_str),
                                                        nil ()),
                                                  cast (type (mty_str),
                                                        nil ())),
                                         var (PF_MIL_VAR_STR)))
                        );
                    }
                }

                /* consider aat_time */
                if (ty & aat_time) {
                    execute (
                        bappend (var (strVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (mcast (type (mty_str),
                                                             VAR (R(p)->env,
                                                             pa_item,
                                                             aat_time)),
                                                      cast (type (mty_str),
                                                            nil ()),
                                                      cast (type (mty_str),
                                                            nil ()))
                                             )))));
                    if (ty == aat_time) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (mcast (type (mty_str),
                                                 VAR (R(p)->env,
                                                 pa_item,
                                                 aat_time)),
                                          reverse (var (strVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (mcast (type (mty_str),
                                                VAR (R(p)->env,
                                                pa_item,
                                                aat_time)),
                                         var (PF_MIL_VAR_STR)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (mcast (type (mty_str),
                                             VAR (R(p)->env,
                                                  pa_item,
                                                  aat_time)),
                                      reverse (var (strVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (mcast (type (mty_str),
                                                         VAR (R(p)->env,
                                                         pa_item,
                                                         aat_time)),
                                                  cast (type (mty_str),
                                                        nil ()),
                                                  cast (type (mty_str),
                                                        nil ())),
                                         var (PF_MIL_VAR_STR)))
                        );
                    }
                }

                /* consider aat_ymduration */
                if (ty & aat_ymduration) {
                    execute (
                        bappend (var (strVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (mcast (type (mty_str),
                                                             VAR (R(p)->env,
                                                             pa_item,
                                                             aat_ymduration)),
                                                      cast (type (mty_str),
                                                            nil ()),
                                                      cast (type (mty_str),
                                                            nil ()))
                                             )))));
                    if (ty == aat_ymduration) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (mcast (type (mty_str),
                                                 VAR (R(p)->env,
                                                 pa_item,
                                                 aat_ymduration)),
                                          reverse (var (strVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (mcast (type (mty_str),
                                                VAR (R(p)->env,
                                                pa_item,
                                                aat_ymduration)),
                                         var (PF_MIL_VAR_STR)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (mcast (type (mty_str),
                                             VAR (R(p)->env,
                                                  pa_item,
                                                  aat_ymduration)),
                                      reverse (var (strVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (mcast (type (mty_str),
                                                         VAR (R(p)->env,
                                                         pa_item,
                                                         aat_ymduration)),
                                                  cast (type (mty_str),
                                                        nil ()),
                                                  cast (type (mty_str),
                                                        nil ())),
                                         var (PF_MIL_VAR_STR)))
                        );
                    }
                }

                /* consider aat_dtduration */
                if (ty & aat_dtduration) {
                    execute (
                        bappend (var (strVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (mcast (type (mty_str),
                                                             VAR (R(p)->env,
                                                             pa_item,
                                                             aat_dtduration)),
                                                      cast (type (mty_str),
                                                            nil ()),
                                                      cast (type (mty_str),
                                                            nil ()))
                                             )))));
                    if (ty == aat_dtduration) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (mcast (type (mty_str),
                                                 VAR (R(p)->env,
                                                 pa_item,
                                                 aat_dtduration)),
                                          reverse (var (strVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (mcast (type (mty_str),
                                                VAR (R(p)->env,
                                                pa_item,
                                                aat_dtduration)),
                                         var (PF_MIL_VAR_STR)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (mcast (type (mty_str),
                                             VAR (R(p)->env,
                                                  pa_item,
                                                  aat_dtduration)),
                                      reverse (var (strVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (mcast (type (mty_str),
                                                         VAR (R(p)->env,
                                                         pa_item,
                                                         aat_dtduration)),
                                                  cast (type (mty_str),
                                                        nil ()),
                                                  cast (type (mty_str),
                                                        nil ())),
                                         var (PF_MIL_VAR_STR)))
                        );
                    }
                }

                /* consider untyped results */
                if (ty & aat_uA) {
                    execute (
                        bappend (var (strVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (VAR (R(p)->env,
                                                           pa_item,
                                                           aat_uA),
                                                      cast (type (mty_str),
                                                            nil ()),
                                                      cast (type (mty_str),
                                                            nil ()))
                                             )))));
                    if (ty == aat_uA) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (VAR (R(p)->env, pa_item, aat_uA),
                                          reverse (var (strVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (VAR (R(p)->env, pa_item, aat_uA),
                                         var (PF_MIL_VAR_STR)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (VAR (R(p)->env, pa_item, aat_uA),
                                      reverse (var (strVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (VAR (R(p)->env,
                                                       pa_item,
                                                       aat_uA),
                                                  cast (type (mty_str),
                                                        nil ()),
                                                  cast (type (mty_str),
                                                        nil ())),
                                         var (PF_MIL_VAR_STR)))
                        );
                    }
                }

                /* consider int results */
                if (ty & aat_int) {
                    execute (
                        bappend (var (intVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (VAR (R(p)->env,
                                                           pa_item,
                                                           aat_int),
                                                      cast (type (mty_lng),
                                                            nil ()),
                                                      cast (type (mty_lng),
                                                            nil ()))
                                             )))));
                    if (ty == aat_int) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (VAR (R(p)->env, pa_item, aat_int),
                                          reverse (var (intVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (VAR (R(p)->env, pa_item, aat_int),
                                         var (PF_MIL_VAR_INT)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (VAR (R(p)->env, pa_item, aat_int),
                                      reverse (var (intVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (VAR (R(p)->env,
                                                       pa_item,
                                                       aat_int),
                                                  cast (type (mty_lng),
                                                        nil ()),
                                                  cast (type (mty_lng),
                                                        nil ())),
                                         var (PF_MIL_VAR_INT)))
                        );
                    }
                }

                /* consider dbl results */
                if (ty & aat_dbl) {
                    execute (
                        bappend (var (dblVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (VAR (R(p)->env,
                                                           pa_item,
                                                           aat_dbl),
                                                      cast (type (mty_dbl),
                                                            nil ()),
                                                      cast (type (mty_dbl),
                                                            nil ()))
                                             )))));
                    if (ty == aat_dbl) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (VAR (R(p)->env, pa_item, aat_dbl),
                                          reverse (var (dblVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (VAR (R(p)->env, pa_item, aat_dbl),
                                         var (PF_MIL_VAR_DBL)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (VAR (R(p)->env, pa_item, aat_dbl),
                                      reverse (var (dblVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (VAR (R(p)->env,
                                                       pa_item,
                                                       aat_dbl),
                                                  cast (type (mty_dbl),
                                                        nil ()),
                                                  cast (type (mty_dbl),
                                                        nil ())),
                                         var (PF_MIL_VAR_DBL)))
                        );
                    }
                }

                /* consider dec results */
                if (ty & aat_dec) {
                    execute (
                        bappend (var (decVAL->name),
                                 reverse (
                                     kunique (
                                         reverse (
                                             select2 (VAR (R(p)->env,
                                                           pa_item,
                                                           aat_dec),
                                                      cast (type (mty_dbl),
                                                            nil ()),
                                                      cast (type (mty_dbl),
                                                            nil ()))
                                             )))));
                    if (ty == aat_dec) {
                        execute (
                            assgn (
                                var (item->name),
                                leftjoin (VAR (R(p)->env, pa_item, aat_dec),
                                          reverse (var (decVAL->name)))),
                            assgn (
                                var (kind->name),
                                project (VAR (R(p)->env, pa_item, aat_dec),
                                         var (PF_MIL_VAR_DEC)))
                            );
                        sorted = true;
                    }
                    else {
                        execute (
                            binsert (
                                var (item->name),
                                join (VAR (R(p)->env, pa_item, aat_dec),
                                      reverse (var (decVAL->name)))),
                            binsert (
                                var (kind->name),
                                project (select2 (VAR (R(p)->env,
                                                       pa_item,
                                                       aat_dec),
                                                  cast (type (mty_dbl),
                                                        nil ()),
                                                  cast (type (mty_dbl),
                                                        nil ())),
                                         var (PF_MIL_VAR_DEC)))
                        );
                    }
                }

                /* consider bit results */
                if (ty & aat_bln) {
                    if (ty == aat_bln) {
                        execute (
                            assgn (
                                var (item->name),
                                mcast (type (mty_oid),
                                       VAR (R(p)->env, pa_item, aat_bln))),
                            assgn (
                                var (kind->name),
                                project (VAR (R(p)->env, pa_item, aat_bln),
                                         var (PF_MIL_VAR_BOOL)))
                            );
                        sorted = true;
                    }
                    else {
                        v = new_var (1);
                        execute (
                            assgn (
                                var (v->name),
                                select2 (VAR (R(p)->env, pa_item, aat_bln),
                                         cast (type (mty_bit), nil ()),
                                         cast (type (mty_bit), nil ()))),
                            binsert (
                                var (item->name),
                                mcast (type (mty_oid), var (v->name))),
                            binsert (
                                var (kind->name),
                                project (var (v->name),
                                         var (PF_MIL_VAR_BOOL)))
                        );
                        unpin (v, 1);
                    }
                }

                if (!sorted)
                    execute (
                        assgn (var (item->name),
                               sort (var (item->name), DIR_ASC)),
                        assgn (var (kind->name),
                               leftjoin (mirror (var (item->name)),
                                         var (kind->name))));

                execute (
                    assgn (var (item->name),
                           reverse (mark (reverse (var (item->name)),
                                          lit_oid (0)))),
                    assgn (var (kind->name),
                           reverse (mark (reverse (var (kind->name)),
                                          lit_oid (0)))),

                    serialize (
                        arg (var (PF_MIL_VAR_GENTYPE),
                            arg (var (PF_MIL_VAR_WS),
                                arg (var (item->name),
                                    arg (var (kind->name),
                                        arg (var (intVAL->name),
                                            arg (var (dblVAL->name),
                                                arg (var (decVAL->name),
                                                     var (strVAL->name)))))))))
                        );

                unpin (intVAL, 1);
                unpin (dblVAL, 1);
                unpin (strVAL, 1);
                unpin (item, 1);
                unpin (kind, 1);

            } /* end of printing results */ /* fold) */

            /* add timing information */
            execute (
                assgn (var (PF_MIL_VAR_TIME_PRINT),
                       sub (usec (),
                            var (time->name))));
            unpin (time, 1);

            /* output trace information if available */
            if (global_trace_id != 1)
                execute (
                    trace (
                        arg (var (PF_MIL_VAR_WS),
                        arg (var (PF_MIL_VAR_TRACE_OUTER),
                        arg (var (PF_MIL_VAR_TRACE_INNER),
                        arg (var (PF_MIL_VAR_TRACE_ITER),
                        arg (var (PF_MIL_VAR_TRACE_MSG),
                        arg (var (PF_MIL_VAR_TRACE_ITEM),
                        arg (var (PF_MIL_VAR_TRACE_TYPE),
                             var (PF_MIL_VAR_TRACE_REL))))))))));

            /* make the old mil program the active one */
            bodymilprog = milprog;
            milprog = oldmilprog;

            err = new_var (1);

            /* update queries should loop around until they succeed */
            if (aat_update & type_of (R(p), pa_item)) {

                execute (
                    assgn (var (try->name), lit_int (CREATE_UPDATE_WS)),
                    assgn (var (err->name),
                           lit_str ("!ERROR: conflicting update")),
                    while_ (and (le (var (try->name), lit_int(3)),
                                 not (isnil (var (err->name)))),
                            seq (if_ (not (starts_with (
                                               var (err->name),
                                               lit_str ("!ERROR: conflicting"
                                                        " update"))),
                                      break_(),
                                      nop()),
                                 catch_ (var (err->name), bodymilprog),
                                 if_ (not (isnil (var (PF_MIL_VAR_WS))),
                                      end_ws (var (PF_MIL_VAR_WS),
                                              var (err->name)),
                                      nop ()))),
                    if_ (not (isnil (var (err->name))),
                         error (var (err->name)),
                         nop ()));
                
                unpin (try, 1);
            } else {
                execute (
                    catch_ (var (err->name), bodymilprog),
                    if_ (not (isnil (var (PF_MIL_VAR_WS))),
                         end_ws (var (PF_MIL_VAR_WS), var(err->name)),
                         nop ()),
                    if_ (not (isnil (var (err->name))),
                         error (var (err->name)),
                         nop ()));
            }
            unpin (err, 1);
#ifdef HAVE_PFTIJAH
            execute(
                assgn (var (PF_MIL_TIJAH_SCORE_DB), unused() ),
                assgn (var (PF_MIL_TIJAH_DUMMYPOS), unused() )
            );
#endif
        }   break; /* fold) */

        /* Query:   serialize (Side, empty_tbl) */
        case 2: /* fold( */
        {
            mvar_t *intVAL, *dblVAL, *decVAL, *strVAL;
            mvar_t *item, *kind, *err, *time;
            PFmil_t *oldmilprog, *bodymilprog;

            /* save the current mil program */
            oldmilprog = milprog;

            /* create a new empty milprog */
            milprog = nop ();

            execute (
                comment ("volatile variable environment"),
                assgn (var (PF_MIL_VAR_WS),
                       new_ws (lit_int (CREATE_READ_ONLY_WS))));

            reduce (kids[0], nts[0]);

            /* add timing information */
            time = new_var (1);
            execute (assgn (var (time->name), usec ()));

            /* Set up all the value containers for print_result().
             * (It is actually too much overhead to introduce the value
             * containers just for printing. But this way we can re-use
             * Jan F's print_result() and stay compatible with the
             * ``summer branch''.
             */

            intVAL = new_var (1);
            dblVAL = new_var (1);
            decVAL = new_var (1);
            strVAL = new_var (1);
            item = new_var (1);
            kind = new_var (1);

            execute (
                assgn (
                    var (intVAL->name),
                    seqbase (new (type (mty_void), type (mty_lng)),
                             lit_oid (0))),
                assgn (
                    var (dblVAL->name),
                    seqbase (new (type (mty_void), type (mty_dbl)),
                             lit_oid (0))),
                assgn (
                    var (decVAL->name),
                    seqbase (new (type (mty_void), type (mty_dbl)),
                             lit_oid (0))),
                assgn (
                    var (strVAL->name),
                    seqbase (new (type (mty_void), type (mty_str)),
                             lit_oid (0))),
                assgn (
                    var (item->name),
                    seqbase (new (type (mty_void), type (mty_oid)),
                             lit_oid (0))),
                assgn (
                    var (kind->name),
                    seqbase (new (type (mty_void), type (mty_int)),
                             lit_oid (0))),
                serialize (
                    arg (var (PF_MIL_VAR_GENTYPE),
                        arg (var (PF_MIL_VAR_WS),
                            arg (var (item->name),
                                arg (var (kind->name),
                                    arg (var (intVAL->name),
                                        arg (var (dblVAL->name),
                                            arg (var (decVAL->name),
                                                 var (strVAL->name))))))))));

            unpin (intVAL, 1);
            unpin (dblVAL, 1);
            unpin (decVAL, 1);
            unpin (strVAL, 1);
            unpin (item, 1);
            unpin (kind, 1);

            /* add timing information */
            execute (
                assgn (var (PF_MIL_VAR_TIME_PRINT),
                       sub (usec (),
                            var (time->name))));
            unpin (time, 1);

            /* make the old mil program the active one */
            bodymilprog = milprog;
            milprog = oldmilprog;

            err = new_var (1);

            execute (
                catch_ (var (err->name), bodymilprog),
                if_ (not (isnil (var (PF_MIL_VAR_WS))),
                     end_ws (var (PF_MIL_VAR_WS), var(err->name)),
                     nop ()),
                if_ (not (isnil (var (err->name))),
                     error (var (err->name)),
                     nop ()));

            unpin (err, 1);
#ifdef HAVE_PFTIJAH
	    execute(
                assgn (var (PF_MIL_TIJAH_SCORE_DB), unused() ),
                assgn (var (PF_MIL_TIJAH_FTINAME), unused() )
	    );
#endif
        } break; /* fold) */

        /* Rel:     empty_tbl */
        case 9:
            PFlog ("empty sequence should never occur in MIL generation."
                   " (optimizations disabled?)");
        /* Rel:      lit_tbl */
        case 8: /* fold( */
            /* iterate over table columns */
            for (unsigned int col = 0; col < p->schema.count; col++)
                for (PFalg_simple_type_t t = 1; t; t <<= 1)
                    if (t & TYPE_MASK(p->schema.items[col].type)) {
                        v = new_var (p->refctr);
                        env_add (p->env, p->schema.items[col].name, t, v);

                        execute (
                            assgn (
                                var (v->name),
                                seqbase (
                                    new (type (mty_void), implty_ (t)),
                                    lit_oid (0))));

                        for (unsigned int row = 0;
                                row < p->sem.lit_tbl.count; row++)
                            execute (
                                append (
                                    var (v->name),
                                    t & p->sem.lit_tbl.tuples[row]
                                                      .atoms[col].type
                                    ? literal_ (p->sem.lit_tbl.tuples[row]
                                                              .atoms[col], t)
                                    : cast (implty_ (t), nil ())));

                        execute (access (var (v->name), BAT_READ));
                    }
            break; /* fold) */

        /* Rel:      attach (Rel) */
        case 10: /* fold( */
            /* copy all the existing variables */
            env_copy (p, L(p)->env);

            /* Cope with literal QNames differently
               (as QNames are represented by a id/cont pair). */
            if (p->sem.attach.value.type == aat_qname) {
                mvar_t *id   = new_var (p->refctr);
                mvar_t *cont = new_var (p->refctr);
                env_add (p->env, p->sem.attach.col, aat_qname_id, id);
                env_add (p->env, p->sem.attach.col, aat_qname_cont, cont);

                execute (
                    assgn (var (id->name),
                           project (ANY_VAR(p->env),
                                    literal_ (p->sem.attach.value,
                                              aat_qname_id))),
                    assgn (var (cont->name),
                           project (ANY_VAR(p->env),
                                    literal_ (p->sem.attach.value,
                                              aat_qname_cont))));
            }
            else {
                /* now create the new column */
                v = new_var (p->refctr);
                env_add (p->env, p->sem.attach.col,
                         p->sem.attach.value.type, v);

                execute (
                    assgn (var (v->name),
                           project (ANY_VAR(p->env),
                                    literal (p->sem.attach.value))));
            }
            break; /* fold) */

        /* Rel:      cross (Rel, Rel) */
        case 11: /* fold( */
            cross_worker (p);
            break; /* fold) */

        /* Rel:      dep_cross (Rel, Rel) */
        case 12: /* fold( */
        {
            PFmil_t *oldmilprog, *then_milprog, *else_milprog;

            /* Generate code for left side (and the operators of the right
               side that are also referenced outside the branch. */
            execute (comment ("Evaluate left side of dep_cross."));
            reduce (kids[0], nts[0]);

            execute (comment ("Evaluate the portion of the right side of "
                              "dep_cross that is referenced multiple times."));
            reduce_border (kids[1], nts[1], 13 /* dep_border rule */);

            /* save the current mil program */
            oldmilprog = milprog;

            /* create a new empty milprog for the then-branch */
            milprog = nop ();

            /* translate the independent body expression */
            execute (comment ("Evaluate the independent portion"
                              " of the right side of dep_cross."));
            reduce (kids[1], nts[1]);

            /* generate the code for the cross product */
            execute (comment (" "), comment ("Build the cross product."));
            cross_worker (p);

            /* store the code for the then-branch */
            then_milprog = milprog;

            /* create a new empty milprog for the else-branch */
            milprog = nop ();

            /* For every variable binding the cross product generates
               we also produce an alternative 'empty. translation. */
            execute (comment ("Provide the empty result for all BATs."));
            for (unsigned int col = 0; col < p->schema.count; col++) {
                PFalg_simple_type_t ty = TYPE_MASK(p->schema.items[col].type);
                for (PFalg_simple_type_t t = 1; t; t <<= 1) {
                    if (t & ty) {
                        /* find the variable name used in the then-branch */
                        mvar_t *tmp  = env_mvar (p->env,
                                                 p->schema.items[col].name,
                                                 t & ty);

                        /* assign an empty BAT to the variable */
                        execute (
                            assgn (var (tmp->name),
                                   seqbase (new (type (mty_void),
                                                 implty (t, ty)),
                                            lit_oid (0))));
                    }
                }
            }

            /* store the code for the else-branch */
            else_milprog = milprog;

            /* make the old mil program the active one again */
            milprog = oldmilprog;

            /* Apply the check if the left side of the cross product
               provides a row. */
            execute (
                comment (" "),
                comment ("Don't evaluate the right side of dep_cross"),
                comment ("if the left side already provides the empty"),
                comment ("result."),
                if_ (gt (count (ANY_VAR (L(p)->env)), lit_int (0)),
                     then_milprog,
                     else_milprog));

        }   break; /* fold) */

        /* Rel:      dep_border (Rel) */
        case 13: /* fold( */
            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);
            break; /* fold) */

        /* Rel:      leftjoin (Rel, Rel) */
        case 14:
        /* Rel:      eqjoin (Rel, Rel) */
        case 15:
        /* Rel:      semijoin (Rel, Rel) */
        case 16: /* fold( */
        {
            /*
             * We actually cannot guarantee that MonetDB applies a
             * MergeJoin (tactical optimization may choose other
             * implementations). By using leftjoin(), however, we
             * can guarantee the result to be correctly ordered.
             */
            PFalg_simple_type_t lty = type_of (L(p), p->sem.eqjoin.col1);
            PFalg_simple_type_t rty = type_of (R(p), p->sem.eqjoin.col2);
            mvar_t *l  = NULL;
            mvar_t *r  = NULL;
            mvar_t *v1 = new_var (1);
            mvar_t *v2 = new_var (1);

            v = new_var (1);

            if (type_bit_check (lty)) {
                if (lty != rty)
                    PFoops (OOPS_FATAL, "incompatible types in Join");

                l = env_mvar (L(p)->env, p->sem.eqjoin.col1, lty);
                r = env_mvar (R(p)->env, p->sem.eqjoin.col2, rty);
            }
            else {
                /* If this case is ever triggered this means we have
                   either an erroneous predicate or a join on nodes.
                   In the latter case this join should be replaced
                   by a thetajoin. */
                PFoops (OOPS_FATAL,
                        "multi-predicate joins are not supported yet");
            }

            if (p->kind == pa_semijoin) {
                /* evaluate the semijoin and create the map relation */
                execute (
                    assgn (var (v->name),
                           kintersect (reverse (var (l->name)),
                                       reverse (var (r->name)))),
                    assgn (var (v1->name),
                           tmark (var (v->name), lit_oid (0))));

                /* map all columns from the left argument */
                env_map (p, L(p)->env, v1);
            }
            else {
                /* evaluate the join and create two map relations */
                execute (
                    assgn (var (v->name),
                           leftjoin (var (l->name), reverse (var (r->name)))),
                    assgn (var (v1->name),
                           reverse (mark (var (v->name), lit_oid (0)))),
                    assgn (var (v2->name),
                           reverse (
                               mark (reverse (var (v->name)), lit_oid (0)))));

                /* map all columns from the left and the right argument */
                env_map (p, L(p)->env, v1);
                env_map (p, R(p)->env, v2);
            }

            unpin (v, 1);
            unpin (v1, 1);
            unpin (v2, 1);
        }   break; /* fold) */

        /* Rel:      thetajoin (Rel, Rel) */
        case 17: /* fold( */
        {
            bool                initialized = false;
            PFalg_col_t         lcol,
                                rcol;
            PFalg_simple_type_t lty  = 0,
                                rty  = 0;
            PFmil_t            *(*op) (const PFmil_t *, const PFmil_t *);
            PFmil_t            *comp;
            mvar_t             *l    = new_var (1),
                               *r    = new_var (1),
                               *res  = new_var (1),
                               *lmap = new_var (1),
                               *rmap = new_var (1);
            PFalg_schema_t      left,
                                right;

            /* initialize schemas for equi-join predicates */
            left.count  = 0;
            right.count = 0;
            left.items  = PFmalloc (p->schema.count * sizeof (*(left.items)));
            right.items = PFmalloc (p->schema.count * sizeof (*(right.items)));

            /* first collect all equi-join predicates */
            for (unsigned int i = 0; i < p->sem.thetajoin.count; i++)
                if (p->sem.thetajoin.pred[i].comp == alg_comp_eq) { /* fold( */
                    initialized = true;

                    lcol = p->sem.thetajoin.pred[i].left;
                    rcol = p->sem.thetajoin.pred[i].right;
                    lty  = type_of (L(p), lcol);
                    rty  = type_of (R(p), rcol);

                    left.items[left.count++] =
                        (struct PFalg_schm_item_t)
                            { .name = lcol, .type = lty };
                    right.items[right.count++] =
                        (struct PFalg_schm_item_t)
                            { .name = rcol, .type = rty };

                } /* fold) */

            /* apply the multi-column equi-join */
            if (initialized) {
                /* apply the intersection on all equality predicates */
                intersect (p, left, right, res);

                execute (assgn (var (lmap->name),
                                reverse (mark (var (res->name), lit_oid (0)))),
                         assgn (var (rmap->name),
                                reverse (mark (reverse (var (res->name)),
                                               lit_oid (0)))));
            }

            /* If there was no equality predicate apply a normal inequality
               thetajoin to the first predicate.
               For all remaining predicates (also the ones that appear in
               combination with equi-join predicates we apply a selection
               (post) filter. */
            for (unsigned int i = 0; i < p->sem.thetajoin.count; i++)
                if (p->sem.thetajoin.pred[i].comp != alg_comp_eq) { /* fold( */
                    op   = NULL;
                    comp = NULL;
                    /* find the correct comparison */
                    switch (p->sem.thetajoin.pred[i].comp) {
                        case alg_comp_eq:
                            op   = PFmil_meq;
                            comp = var (PF_MIL_VAR_EQ); break;
                        case alg_comp_gt:
                            op   = PFmil_mgt;
                            comp = var (PF_MIL_VAR_GT); break;
                        case alg_comp_ge:
                            op   = PFmil_mge;
                            comp = var (PF_MIL_VAR_GE); break;
                        case alg_comp_lt:
                            op   = PFmil_mlt;
                            comp = var (PF_MIL_VAR_LT); break;
                        case alg_comp_le:
                            op   = PFmil_mle;
                            comp = var (PF_MIL_VAR_LE); break;
                        case alg_comp_ne:
                            op   = PFmil_mne;
                            if (!initialized) {
                                /* As there was no equi-join condition and
                                   this is the first ne inequality predicate
                                   we evaluate a cross product and apply
                                   a postfilter (by setting initialized to
                                   true). */
                                execute (
                                    assgn (var (res->name),
                                           cross (
                                               ANY_VAR (L(p)->env),
                                               reverse (ANY_VAR (R(p)->env)))),
                                    assgn (var (lmap->name),
                                           reverse (mark (var (res->name),
                                                          lit_oid (0)))),
                                    assgn (var (rmap->name),
                                           reverse (
                                               mark (reverse (var (res->name)),
                                                     lit_oid (0)))));
                                initialized = true;
                            }
                            break;
                        default:
                            PFoops (OOPS_FATAL, "incorrect comparison");
                    }

                    /* prepare the join columns for an inequality
                       predicate (map multiple columns into a single
                       BAT) */
                    prepare_comp (L(p), R(p),
                                  p->sem.thetajoin.pred[i].left,
                                  p->sem.thetajoin.pred[i].right,
                                  l, r);

                    if (!initialized) {
                        /* As there was no equi-join condition and
                           this is the first inequality predicate
                           we evaluate a thetajoin */
                        execute (assgn (var (res->name),
                                        tjoin (
                                            var (l->name),
                                            reverse (var (r->name)),
                                            comp,
                                            PFmil_mmult (
                                                count (var (r->name)),
                                                lit_lng (64)))),
                                 assgn (var (lmap->name),
                                        reverse (mark (var (res->name),
                                                       lit_oid (0)))),
                                 assgn (var (rmap->name),
                                        reverse (
                                            mark (reverse (var (res->name)),
                                                  lit_oid (0)))));
                    } else {
                        /* apply a (post) filter and update
                           the mapping relations lmap and rmap */
                        execute (
                            assgn (
                                var (res->name),
                                op (leftjoin (var (lmap->name), var (l->name)),
                                    leftjoin (var (rmap->name), var (r->name)))),
                            assgn (
                                var (res->name),
                                reverse (
                                    mark (select_ (var (res->name),
                                                   lit_bit (true)),
                                          lit_oid (0)))),
                            assgn (
                                var (lmap->name),
                                leftjoin (var (res->name), var (lmap->name))),
                            assgn (
                                var (rmap->name),
                                leftjoin (var (res->name), var (rmap->name))));
                    }

                    initialized = true;
                } /* fold) */

            /* map all columns from the left and the right argument */
            env_map (p, L(p)->env, lmap);
            env_map (p, R(p)->env, rmap);

            /* release temporary variables */
            unpin (l, 1);
            unpin (r, 1);
            unpin (res, 1);
            unpin (lmap, 1);
            unpin (rmap, 1);
        }   break; /* fold) */

        /* Rel:      unq2_thetajoin (Rel, Rel) */
        case 18: /* fold( */
        {
            PFalg_col_t lcol, rcol, ldist_col, rdist_col;
            PFalg_simple_type_t lty, rty, ldist_ty, rdist_ty;
            PFmil_t *comp;
            mvar_t *l     = NULL,
                   *r     = NULL,
                   *ldist = NULL,
                   *rdist = NULL,
                   *v1    = new_var (p->refctr),
                   *v2    = new_var (p->refctr);
            bool    ldist_node_ty = false,
                    rdist_node_ty = false;

            v = new_var (1);

            lcol      = p->sem.unq_thetajoin.left;
            rcol      = p->sem.unq_thetajoin.right;
            ldist_col = p->sem.unq_thetajoin.ldist;
            rdist_col = p->sem.unq_thetajoin.rdist;

            lty      = type_of (L(p), lcol);
            rty      = type_of (R(p), rcol);
            ldist_ty = type_of (L(p), ldist_col);
            rdist_ty = type_of (R(p), rdist_col);

            if (lty != rty)
                PFoops (OOPS_FATAL, "incompatible types in Theta-Join");
            if (!type_bit_check (lty)) 
                /* If this case is ever triggered this means we have
                   either an erroneous predicate or a join on nodes.
                   In the latter case this join should be replaced
                   by a thetajoin. */
                PFoops (OOPS_FATAL,
                        "multi-predicate theta-joins are not supported yet");

            /* We know that unq2_thetajoin operators with pre nodes are
               guaranteed to come with constant fragment information. We thus
               ignore the fragment information until after the thetajoin. */
            if (ldist_ty == aat_pnode) {
                ldist_node_ty = true;
                ldist_ty = aat_pre;
            }
            else if (ldist_ty != aat_nat)
                PFoops (OOPS_FATAL, "incompatible type in Theta-Join");

            if (rdist_ty == aat_pnode) {
                rdist_node_ty = true;
                rdist_ty = aat_pre;
            }
            else if (rdist_ty != aat_nat)
                PFoops (OOPS_FATAL, "incompatible type in Theta-Join");

            l     = env_mvar (L(p)->env, lcol, lty);
            r     = env_mvar (R(p)->env, rcol, rty);
            ldist = env_mvar (L(p)->env, ldist_col, ldist_ty);
            rdist = env_mvar (R(p)->env, rdist_col, rdist_ty);

            /* find the correct comparison */
            switch (p->sem.unq_thetajoin.comp) {
                case alg_comp_eq: comp = var (PF_MIL_VAR_EQ); break;
                case alg_comp_gt: comp = var (PF_MIL_VAR_GT); break;
                case alg_comp_ge: comp = var (PF_MIL_VAR_GE); break;
                case alg_comp_lt: comp = var (PF_MIL_VAR_LT); break;
                case alg_comp_le: comp = var (PF_MIL_VAR_LE); break;
                default:
                    PFoops (OOPS_FATAL,
                            "cannot cope with inequality comparison");
            }

            /* apply the duplicate removing thetajoin */
            execute (
                assgn (var (v->name),
                       unq2_tjoin (leftjoin (reverse (var (ldist->name)),
                                             var (l->name)),
                                   leftjoin (reverse (var (rdist->name)),
                                             var (r->name)),
                                   comp)),
                assgn (var (v1->name),
                       reverse (mark (var (v->name), lit_oid (0)))),
                assgn (var (v1->name),
                       assert_order (var (v1->name))),
                assgn (var (v2->name),
                       reverse (mark (reverse (var (v->name)),
                                      lit_oid (0)))));

            /* add the two result columns to the environment */
            env_add (p->env, ldist_col, ldist_ty, v1);
            env_add (p->env, rdist_col, rdist_ty, v2);

            /* adjust the fragment information to the result cardinality */
            if (ldist_node_ty) {
                mvar_t *frag = new_var (p->refctr);

                execute (
                    /* make sure to apply the fetch
                       only if there are some result tuples */
                    if_ (gt (count (var (v1->name)), lit_int (0)),
                         assgn (var (frag->name),
                                project (hmark (var (v->name), lit_oid (0)),
                                         fetch (VAR (L(p)->env,
                                                     ldist_col,
                                                     aat_frag),
                                                lit_int (0)))),
                         assgn (var (frag->name), var (v1->name))));

                env_add (p->env, ldist_col, aat_frag, frag);
            }
            if (rdist_node_ty) {
                mvar_t *frag = new_var (p->refctr);

                execute (
                    /* make sure to apply the fetch
                       only if there are some result tuples */
                    if_ (gt (count (var (v2->name)), lit_int (0)),
                         assgn (var (frag->name),
                                project (hmark (var (v->name), lit_oid (0)),
                                         fetch (VAR (R(p)->env,
                                                     rdist_col,
                                                     aat_frag),
                                                lit_int (0)))),
                         assgn (var (frag->name), var (v2->name))));

                env_add (p->env, rdist_col, aat_frag, frag);
            }
            unpin (v, 1);
        }   break; /* fold) */

        /* Rel:      unq1_thetajoin (Rel, Rel) */
        case 19: /* fold( */
        {
            PFalg_col_t lcol, rcol, ldist_col, rdist_col;
            PFalg_simple_type_t lty, rty, ldist_ty, rdist_ty;
            PFmil_t *comp;
            mvar_t *l     = NULL,
                   *r     = NULL,
                   *ldist = NULL,
                   *rdist = NULL,
                   *v1    = new_var (p->refctr);

            v = new_var (1);

            lcol      = p->sem.unq_thetajoin.left;
            rcol      = p->sem.unq_thetajoin.right;
            ldist_col = p->sem.unq_thetajoin.ldist;
            rdist_col = p->sem.unq_thetajoin.rdist;

            lty      = type_of (L(p), lcol);
            rty      = type_of (R(p), rcol);
            ldist_ty = type_of (L(p), ldist_col);
            rdist_ty = type_of (R(p), rdist_col);

            if (type_bit_check (lty) && type_bit_check (ldist_ty)) {
                if (lty != rty || ldist_ty != rdist_ty)
                    PFoops (OOPS_FATAL, "incompatible types in Theta-Join");

                l     = env_mvar (L(p)->env, lcol, lty);
                r     = env_mvar (R(p)->env, rcol, rty);
                ldist = env_mvar (L(p)->env, ldist_col, ldist_ty);
                rdist = env_mvar (R(p)->env, rdist_col, rdist_ty);
            }
            else {
                /* If this case is ever triggered this means we have
                   either an erroneous predicate or a join on nodes.
                   In the latter case this join should be replaced
                   by a thetajoin. */
                PFoops (OOPS_FATAL,
                        "multi-predicate theta-joins are not supported yet");
            }

            /* find the correct comparison */
            switch (p->sem.unq_thetajoin.comp) {
                case alg_comp_eq: comp = var (PF_MIL_VAR_EQ); break;
                case alg_comp_gt: comp = var (PF_MIL_VAR_GT); break;
                case alg_comp_ge: comp = var (PF_MIL_VAR_GE); break;
                case alg_comp_lt: comp = var (PF_MIL_VAR_LT); break;
                case alg_comp_le: comp = var (PF_MIL_VAR_LE); break;
                default:
                    PFoops (OOPS_FATAL,
                            "cannot cope with inequality comparison");
            }

            /* apply the duplicate removing thetajoin */
            execute (
                assgn (var (v->name),
                       unq1_tjoin (
                           leftjoin (reverse (var (ldist->name)),
                                     var (l->name)),
                           leftjoin (reverse (var (rdist->name)),
                                     var (r->name)),
                           var (ldist->name),
                           var (rdist->name),
                           comp)),
                assgn (var (v1->name),
                       reverse( mark (var (v->name), lit_oid (0)))));

            /* add the result column to the environment */
            env_add (p->env, ldist_col, ldist_ty, v1);
            unpin (v, 1);
        }   break; /* fold) */

        /* Rel:      project (Rel) */
        case 20: /* fold( */
            /*
             * Algebra projection is a no-op. We only fill the
             * environment in node p appropriately.
             */
            for (unsigned int i = 0; i < p->sem.proj.count; i++)
                for (PFalg_simple_type_t t = 1; t; t <<= 1)
                    if (t & TYPE_MASK(type_of (L(p),
                                               p->sem.proj.items[i].old))) {
                        v = env_mvar (L(p)->env,
                                              p->sem.proj.items[i].old,
                                              t);
                        env_add (p->env, p->sem.proj.items[i].new, t, v);
                        pin (v, p->refctr);
                    }
            break; /* fold) */

        /* Rel:      slice (Rel) */
        case 21:
            /* apply a slice for all visible BATs */
            for (unsigned int i = 0; i < env_count (L(p)->env); i++) {
                mvar_t *tmp  = new_var (p->refctr);
                /* expand variables */
                execute (
                    assgn (var (tmp->name),
                           slice (var (env_at (L(p)->env, i).mvar->name),
                                  lit_int (p->sem.slice.low),
                                  lit_int (p->sem.slice.high))),
                    /* scary but true -- we need to let the seqbases start
                       with 0@0 as otherwise alignment problems arise */
                    assgn (var (tmp->name),
                           tmark (var (tmp->name), lit_oid (0))));

                env_add (p->env,
                         env_at (L(p)->env, i).col,
                         env_at (L(p)->env, i).ty,
                         tmp);
            }
            break;

        /* Rel:      select (Rel) */
        case 22: /* fold( */
        {
            v = new_var (1);

            /*
             * For the predicate column c do
             *
             *  v := c.uselect (true).mark (0@0).reverse ();
             */
            execute (
                assgn (
                    var (v->name),
                    reverse (
                        mark (
                            select_(VAR (L(p)->env, p->sem.select.col,aat_bln),
                                    lit_bit (true)),
                            lit_oid (0)))));

            /* map all columns from the argument */
            env_map (p, L(p)->env, v);

            /* release v */
            unpin (v, 1);
        }   break; /* fold) */

        /* Rel:      val_select (Rel) */
        case 23: /* fold( */
        {
            v = new_var (1);

            assert (type_of (p, p->sem.attach.col) ==
                    p->sem.attach.value.type);

            if (!type_bit_check (p->sem.attach.value.type))
                /* If this case is ever triggered this means we have
                   either an erroneous predicate or a selection on
                   nodes or qnames. */
                PFoops (OOPS_FATAL,
                        "multi-predicate selections are not supported yet");

            /*
             * For the predicate column c do
             *
             *  v := c.uselect (atom).mark (0@0).reverse ();
             */
            execute (
                assgn (
                    var (v->name),
                    reverse (
                        mark (
                            uselect (VAR (L(p)->env,
                                          p->sem.attach.col,
                                          type_of (p, p->sem.attach.col)),
                                     literal (p->sem.attach.value)),
                            lit_oid (0)))));

            /* map all columns from the argument */
            env_map (p, L(p)->env, v);

            /* release v */
            unpin (v, 1);
        }   break; /* fold) */

        /* Rel:      append_union (Rel, Rel) */
        case 24: /* fold( */
        {
            PFalg_col_t         col;
            PFalg_simple_type_t ty, lty, rty;
            for (unsigned int i = 0; i < p->schema.count; i++) {
                col = p->schema.items[i].name;
                ty  = TYPE_MASK(p->schema.items[i].type);
                lty = type_of (L(p), col);
                rty = type_of (R(p), col);
                for (PFalg_simple_type_t t = 1; t; t <<= 1)
                    if (t & ty) {

                        v = new_var (p->refctr);

                        /*
                         * Type t is in the result relation. See if it
                         * is also in the left operand.
                         */
                        if (t & lty)
                            /* v := l.copy */
                            execute (
                                assgn (
                                    var (v->name),
                                    access (
                                        copy (VAR (L(p)->env, col, t)),
                                        BAT_APPEND)));
                        else
                            /* v := <some BAT of L>.project(nil); */
                            execute (
                                assgn (
                                    var (v->name),
                                    access (
                                        project (
                                            ANY_VAR(L(p)->env),
                                            cast (implty (t, ty), nil ())),
                                        BAT_APPEND)));

                        /*
                         * Is t also in the right operand?
                         */
                        if (t & rty)
                            /* v.append(R); */
                            execute (
                                access (
                                    bappend (
                                        var (v->name),
                                        VAR (R(p)->env, col, t)),
                                    BAT_READ));
                        else
                            /* v.append(<some BAT of L>.project(nil)); */
                            execute (
                                access (
                                    bappend (
                                        var (v->name),
                                        project (
                                            ANY_VAR(R(p)->env),
                                            cast (implty (t, ty), nil ()))),
                                    BAT_READ));

                        env_add (p->env, col, t, v);
                    }
            }
        }   break; /* fold) */

        /* Rel:      merge_union (Rel, Rel) */
        case 25: /* fold( */
        {
            PFalg_col_t         grp_col;
            PFalg_simple_type_t ty,
                                grp_ty;
            PFmil_t            *args;
            v = new_var (1);

            if (PFord_count (p->sem.merge_union.ord) != 1 ||
                PFord_order_dir_at (p->sem.merge_union.ord, 0) != DIR_ASC)
                PFoops (OOPS_FATAL,
                        "MergeUnion for more complex orderings "
                        "is not implemented (got %s)",
                        PFord_str (p->sem.merge_union.ord));

            grp_col = PFord_order_col_at (p->sem.merge_union.ord, 0);
            grp_ty  = type_of (p, grp_col);

            if (!type_bit_check (grp_ty) ||
                type_of (L(p), grp_col) != grp_ty ||
                type_of (R(p), grp_col) != grp_ty)
                PFoops (OOPS_FATAL,
                        "cannot handle polymorphic grouping columns "
                        " in the merge-union translation for MIL");

            /* first two arguments of merged_union() are the grouping cols */
            args = arg (assert_order (VAR (L(p)->env, grp_col, grp_ty)),
                        assert_order (VAR (R(p)->env, grp_col, grp_ty)));

            for (unsigned int i = 0; i < p->schema.count; i++)
                if (p->schema.items[i].name != grp_col) {
                    ty = TYPE_MASK(p->schema.items[i].type);
                    for (PFalg_simple_type_t t = 1; t; t <<= 1)
                        if (t & ty)
                            for (unsigned short j = 0; j <= 1; j++) {
                                /*
                                 * If t is among the operand's types, use the
                                 * corresponding BAT, otherwise substitute a
                                 * BAT with `nil' tail.
                                 */
                                if (t & type_of (p->child[j],
                                                 p->schema.items[i].name))
                                    args = arg (args,
                                                VAR (p->child[j]->env,
                                                     p->schema.items[i].name,
                                                     t));
                                else
                                    args = arg (args,
                                                project (
                                                    ANY_VAR (p->child[j]->env),
                                                    cast (implty(t, ty),
                                                          nil ())));
                            }
                }

            /* execute merged_union() and assign it to v */
            execute (assgn (var (v->name), merged_union (args)));

            /* All BATs are returned in the order they were fed into
               the merged_union operator. This means the grouping
               column comes first and then all columns in the order
               of the above for loops follow. We therefore use the
               same loops to align the column names and types
               with the result columns. */
            unsigned int j = 1;

            /* now extract all the result BATs */
            for (unsigned int i = 0; i < p->schema.count; i++) {
                /* The grouping column is to be found
                   as the first result BAT. */
                if (p->schema.items[i].name == grp_col) {
                    mvar_t *w = new_var (p->refctr);
                    env_add (p->env, p->schema.items[i].name, grp_ty, w);
                    execute (assgn (var (w->name),
                             fetch (var (v->name), lit_int (0))));
                }
                else {
                    for (PFalg_simple_type_t t = 1; t; t <<= 1)
                        if (t & TYPE_MASK(p->schema.items[i].type)) {
                            mvar_t *w = new_var (p->refctr);

                            execute (assgn (var (w->name),
                                     fetch (var (v->name), lit_int (j))));
                            env_add (p->env, p->schema.items[i].name, t, w);
                            j++;
                        }
                }
            }

            /* release our temporary variable v */
            unpin (v, 1);
        }   break; /* fold) */

        /* Rel:      intersect (Rel, Rel) */
        case 26: /* fold( */
        {
            PFalg_col_t         col;
            PFalg_simple_type_t lty,
                                rty;
            PFalg_schema_t      left,
                                right;
            mvar_t             *res = new_var (1);

            /* initialize schemas for equi-join predicates */
            left.count  = 0;
            right.count = 0;
            left.items  = PFmalloc (p->schema.count * sizeof (*(left.items)));
            right.items = PFmalloc (p->schema.count * sizeof (*(right.items)));

            /* collect the aligned list of columns (in preparation for
               the intersect worker) */
            for (unsigned int i = 0; i < p->schema.count; i++) {
                    col = p->schema.items[i].name;
                    lty = type_of (L(p), col);
                    rty = type_of (R(p), col);
                    left.items[left.count++] =
                        (struct PFalg_schm_item_t) { .name = col, .type = lty };
                    right.items[right.count++] =
                        (struct PFalg_schm_item_t) { .name = col, .type = rty };
            }

            /* apply the intersection */
            intersect (p, left, right, res);

            execute (assgn (var (res->name),
                            reverse (
                                mark (tunique (reverse (var (res->name))),
                                      lit_oid (0)))));

            /* map all columns from the argument */
            env_map (p, L(p)->env, res);

            unpin (res, 1);
        }   break; /* fold) */

        /* Rel:      difference (Rel, Rel) */
        case 27: /* fold( */
            /* in most cases we only have a single column (difference based
               on iter) where we can choose a more efficient variant. */
            if (env_count (L(p)->env) == 1 &&
                env_count (R(p)->env) == 1 &&
                L(p)->schema.items[0].type == R(p)->schema.items[0].type) {
                mvar_t *res = new_var (p->refctr);

                execute (
                    assgn (var (res->name),
                           reverse (
                               mark (
                                   kdiff (
                                       reverse (
                                           var (env_at (L(p)->env,
                                                        0).mvar->name)),
                                       reverse (
                                           var (env_at (R(p)->env,
                                                        0).mvar->name))),
                                   lit_oid (0)))));

                env_add (p->env,
                         env_at (L(p)->env, 0).col,
                         env_at (L(p)->env, 0).ty,
                         res);
            }
            else {
                /* First apply the intersection like the intersect operator
                   and then build the difference of the left side and the
                   result of the intersection. */
                PFalg_col_t         col;
                PFalg_simple_type_t lty,
                                    rty;
                PFalg_schema_t      left,
                                    right;
                mvar_t             *res = new_var (1);

                /* initialize schemas for equi-join predicates */
                left.count  = 0;
                right.count = 0;
                left.items  = PFmalloc (p->schema.count *
                                        sizeof (*(left.items)));
                right.items = PFmalloc (p->schema.count *
                                        sizeof (*(right.items)));

                /* collect the aligned list of columns (in preparation for
                   the intersect worker) */
                for (unsigned int i = 0; i < p->schema.count; i++) {
                        col = p->schema.items[i].name;
                        lty = type_of (L(p), col);
                        rty = type_of (R(p), col);
                        left.items[left.count++] =
                            (struct PFalg_schm_item_t)
                                { .name = col, .type = lty };
                        right.items[right.count++] =
                            (struct PFalg_schm_item_t)
                                { .name = col, .type = rty };
                }

                /* apply the intersection */
                intersect (p, left, right, res);

                /* build the difference */
                execute (
                    assgn (var (res->name),
                           reverse (
                               mark (
                                   kdiff (ANY_VAR(L(p)->env),
                                          var (res->name)),
                                   lit_oid (0)))));

                /* map all columns from the argument */
                env_map (p, L(p)->env, res);

                unpin (res, 1);
            }
            break; /* fold) */

        /* Rel:      sort_distinct (Rel) */
        case 30:
        /* Rel:      sort_distinct (std_sort (Rel)) */
        case 31:
        /* Rel:      sort_distinct (refine_sort (Rel)) */
        case 32: /* fold( */
        /* as we have to sort anyway we can also skip the sort operator */
        {
            /*
             * Derive a single BAT from the multi-column grouping
             * (using functions from the xtables module).
             */
            PFord_ordering_t    ord = p->sem.sort_distinct.ord;
            PFpa_op_t          *rel;
            v = new_var (1);

            if (L(p)->kind == pa_std_sort || L(p)->kind == pa_refine_sort)
                rel = LL(p);
            else
                rel = L(p);

            if (!PFord_count (ord))
                /* cope with completely constant relations */
                execute (assgn (var (v->name), ANY_VAR(rel->env)));
            else
                /* create the MIL code that stores
                   the ordered extend in variable v */
                order_extend (rel, ord, v);

            /* apply the duplicate elimination */
            execute (
                assgn (var (v->name),
                       tmark (kunique (reverse (var (v->name))),
                              lit_oid (0))));

            /* map all columns from the argument */
            env_map (p, rel->env, v);

             /* we know that the first sort criterion certainly is sorted
                -- assert_order however only copes with ascending order */
            if (PFord_count (ord) &&
                PFord_order_dir_at (ord, 0) == DIR_ASC) {
                PFalg_col_t col = PFord_order_col_at (ord, 0);
                PFalg_simple_type_t ty = type_of (rel, col);
                if (type_bit_check(ty))
                    execute (
                        assgn (VAR(p->env, col, ty),
                               assert_order (VAR(p->env, col, ty))));
            }

            /* release our temporary variable */
            unpin (v, 1);
        }   break; /* fold) */

        /* Rel:      std_sort (Rel) */
        case 33: /* fold( */
            /* handle the case that a sort does nothing */
            if (!PFord_count (p->sem.sortby.required))
                env_copy (p, L(p)->env);
            else {
                PFord_ordering_t ord = p->sem.sortby.required;

                v = new_var (1);

                /* create the MIL code that stores
                   the ordered extend in variable v */
                order_extend (L(p), ord, v);

                /* prepare the map relation */
                execute (
                    assgn (var (v->name),
                           reverse (mark (var (v->name), lit_oid (0)))));

                /* map all columns from the argument */
                env_map (p, L(p)->env, v);

                 /* we know that the first sort criterion certainly is sorted
                    -- assert_order however only copes with ascending order */
                if (PFord_count (ord) &&
                    PFord_order_dir_at (ord, 0) == DIR_ASC) {
                    PFalg_col_t col = PFord_order_col_at (ord, 0);
                    PFalg_simple_type_t ty = type_of (L(p), col);
                    if (type_bit_check(ty))
                        execute (
                            assgn (VAR(p->env, col, ty),
                                   assert_order (VAR(p->env, col, ty))));
                }

                /* release our temporary variable */
                unpin (v, 1);
            }
            break; /* fold) */

        /* Rel:      refine_sort (Rel) */
        case 34: /* fold( */
        {
            PFord_ordering_t ord = p->sem.sortby.required;
            unsigned int     i,
                             j;
            v = new_var (1);

            /* create the MIL code that stores
               the ordered extend in variable v */
            order_extend (L(p), ord, v);

            /* prepare the map relation */
            execute (
                assgn (var (v->name),
                       reverse (mark (var (v->name), lit_oid (0)))));

            /* map all columns from the argument */
            for (i = 0; i < env_count (L(p)->env); i++) {
                /* all columns that ensure the already existing order
                   stay unchanged. */
                for (j = 0; j < PFord_count (p->sem.sortby.existing); j++)
                    if (PFord_order_col_at (p->sem.sortby.existing, j) ==
                        env_at (L(p)->env, i).col) {
                        env_t entry = env_at (L(p)->env, i);
                        env_add (p->env, entry.col, entry.ty, entry.mvar);
                        pin (entry.mvar, p->refctr);
                        break;
                    }

                /* adjust the ordering for all other columns */
                if (j == PFord_count (p->sem.sortby.existing)) {
                    mvar_t *tmp  = new_var (p->refctr);
                    /* expand variables */
                    execute (
                        assgn (var (tmp->name),
                               leftjoin (var (v->name),
                                         var (env_at (L(p)->env,
                                                      i).mvar->name))),
                        /* because leftjoin does not know that we have
                           exactly one match for each tuple in v,
                           we need to make the heads void ourselves */
                        assgn (var (tmp->name),
                               reverse (mark (reverse (var (tmp->name)),
                                              lit_oid (0)))));

                    env_add (p->env,
                             env_at (L(p)->env, i).col,
                             env_at (L(p)->env, i).ty,
                             tmp);
                }
            }

            /* release our temporary variable */
            unpin (v, 1);
        }   break; /* fold) */

        /* Rel:      fun_1to1 (Rel) */
        case 40: /* fold( */
        {
            /* result variable */
            mvar_t             *res = new_var (p->refctr);
            PFalg_simple_type_t res_type = 0;

            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            switch (p->sem.fun_1to1.kind) {
                case alg_fun_num_add:
                case alg_fun_num_subtract:
                case alg_fun_num_multiply:
                case alg_fun_num_divide:
                case alg_fun_num_modulo:
                case alg_fun_fn_concat: /* fold( */
                {
                    PFmil_t * (*op) (const PFmil_t *, const PFmil_t *) = NULL;
                    PFalg_col_t col1, col2;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    res_type = type_of (L(p), col1);

                    assert (res_type == type_of (L(p), col2));
                    assert (res_type == aat_int || res_type == aat_dec ||
                            res_type == aat_dbl || res_type == aat_str);

                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_fn_concat:
                        case alg_fun_num_add:
                            op = PFmil_madd; break;
                        case alg_fun_num_subtract:
                            op = PFmil_msub; break;
                        case alg_fun_num_multiply:
                            op = PFmil_mmult; break;
                        case alg_fun_num_divide:
                            op = PFmil_mdiv; break;
                        case alg_fun_num_modulo:
                            op = PFmil_mmod; break;
                        default:
                            break;
                    }

                    /* do the arithmetics */
                    execute (
                        assgn (var (res->name),
                               op (VAR (L(p)->env, col1, res_type),
                                   VAR (L(p)->env, col2, res_type))));
                }   break; /* fold) */
                case alg_fun_fn_abs:
                case alg_fun_fn_ceiling:
                case alg_fun_fn_floor:
                case alg_fun_pf_log:
                case alg_fun_pf_sqrt:
                case alg_fun_fn_round: /* fold( */
                {
                    PFmil_t * (*op) (const PFmil_t *) = NULL;
                    PFalg_col_t col;

                    col = clat (p->sem.fun_1to1.refs, 0);
                    res_type = type_of (L(p), col);

                    assert (res_type == aat_int ||
                            res_type == aat_dec ||
                            res_type == aat_dbl);

                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_fn_abs:
                            op = PFmil_mabs; break;
                        case alg_fun_fn_ceiling:
                            op = PFmil_mceil; break;
                        case alg_fun_fn_floor:
                            op = PFmil_mfloor; break;
                        case alg_fun_pf_log:
                            op = PFmil_mlog; break;
                        case alg_fun_pf_sqrt:
                            op = PFmil_msqrt; break;
                        case alg_fun_fn_round:
                            op = PFmil_mround_up; break;
                        default:
                            break;
                    }

                    /* because functions are only allowed for dbl
                       we need to cast before and afterwards:
                       res := `input'.[dbl]().[`op']().[`res_type'](); */
                    if (impl_types (res_type, 0) == mty_dbl)
                        execute (
                            assgn (var (res->name),
                                   op (VAR (L(p)->env, col, res_type))));
                    else
                        execute (
                            assgn (var (res->name),
                                   mcast (implty_ (res_type),
                                          op (mcast (type (mty_dbl),
                                                     VAR (L(p)->env,
                                                          col,
                                                          res_type))))));
                }   break; /* fold) */
                case alg_fun_fn_substring: /* fold( */
                {
                    PFalg_col_t col1, col2;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    res_type = aat_str;

                    execute (
                        assgn (var (res->name),
                               mstring (
                                   VAR (L(p)->env, col1, aat_str),
                                   mmax( msub( mcast (type (mty_int),
                                                      VAR (L(p)->env,
                                                           col2,
                                                           aat_int)),
                                              lit_int(1)),
                                         lit_int(0)))));
                }   break; /* fold) */
                case alg_fun_fn_substring_len: /* fold( */
                {
                    PFalg_col_t col1, col2, col3;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    col3 = clat (p->sem.fun_1to1.refs, 2);
                    res_type = aat_str;

                    execute (
                        assgn (var (res->name),
                               mstring2 (
                                   VAR (L(p)->env, col1, aat_str),
                                   mmax( msub( mcast (type (mty_int),
                                                      VAR (L(p)->env,
                                                           col2,
                                                           aat_int)),
                                              lit_int(1)),
                                         lit_int(0)),
                                   mcast (type (mty_int),
                                          VAR (L(p)->env,
                                               col3,
                                               aat_int)))));
                }   break; /* fold) */

                case alg_fun_fn_string_length: /* fold( */
                {
                    PFalg_col_t col;

                    col = clat (p->sem.fun_1to1.refs, 0);
                    res_type = aat_int;

                    execute (
                        assgn (var (res->name),
                               mcast (implty_ (res_type),
                                      mlength (
                                          VAR (L(p)->env, col, aat_str)))));
                }   break; /* fold) */
                case alg_fun_fn_normalize_space:
                case alg_fun_fn_upper_case:
                case alg_fun_fn_lower_case: /* fold( */
                {
                    PFmil_t * (*op) (const PFmil_t *) = NULL;
                    PFalg_col_t col;

                    col = clat (p->sem.fun_1to1.refs, 0);
                    res_type = aat_str;

                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_fn_upper_case:
                            op = PFmil_mtoUpper; break;
                        case alg_fun_fn_lower_case:
                            op = PFmil_mtoLower; break;
                        case alg_fun_fn_normalize_space:
                            op = PFmil_mnorm_space; break;
                        default: break;
                    }

                    execute (
                        assgn (var (res->name),
                               op (VAR (L(p)->env, col, aat_str))));

                }   break; /* fold) */
                case alg_fun_fn_translate: /* fold( */
                {
                    PFalg_col_t col1, col2, col3;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    col3 = clat (p->sem.fun_1to1.refs, 2);
                    res_type = aat_str;

                    execute (
                        assgn (var (res->name),
                               mtranslate (
                                   VAR (L(p)->env, col1, aat_str),
                                   VAR (L(p)->env, col2, aat_str),
                                   VAR (L(p)->env, col3, aat_str))));
                }   break; /* fold) */
                case alg_fun_fn_like:
                case alg_fun_fn_contains: /* fold( */
                {
                    PFalg_col_t col1, col2;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    res_type = aat_bln;

                    /* do the containment checks:
                       [search](strings,search_strs).[!=](-1).[oid]() */
                    execute (
                        assgn (var (res->name),
                               mnot (meq (msearch (
                                              VAR (L(p)->env, col1, aat_str),
                                              VAR (L(p)->env, col2, aat_str)),
                                          lit_int (-1)))));
                }   break; /* fold) */
                case alg_fun_fn_similar_to:
                        PFoops (OOPS_FATAL,
                                "fn:similar_to not implemented for MIL");
#ifdef HAVE_GEOXML
                case alg_fun_geo_wkb: /* fold( */
                {
                    PFalg_col_t col1;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    res_type = aat_wkb;

                    execute (
                        assgn (var (res->name),
                               mcreate_wkb (VAR (L(p)->env, col1, aat_str))));
                }   break; /* fold) */

                case alg_fun_geo_point: /* fold( */
                {
                    PFalg_col_t col1, col2;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    res_type = aat_wkb;

                    PFmil_t * (*op) (const PFmil_t *, const PFmil_t *) = NULL;
                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_geo_point:
                            op = PFmil_mgeo_point; break;
                        default:
                            break;
                    }
                    execute (
                        assgn (var (res->name),
                               op (VAR (L(p)->env, col1, aat_dec),
                                   VAR (L(p)->env, col2, aat_dec))));
                }   break; /* fold) */
                case alg_fun_geo_distance:
                case alg_fun_geo_intersection: /* fold( */
                {
                    PFalg_col_t col1, col2;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);

                    PFmil_t * (*op) (const PFmil_t *, const PFmil_t *) = NULL;
                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_geo_distance:
                            op = PFmil_mgeo_distance;
                            res_type = aat_dbl;
			    break;
                        case alg_fun_geo_intersection:
                            op = PFmil_mgeo_intersection;
                            res_type = aat_wkb;
			    break;
                        default:
                            res_type = 0;
			    fprintf(stderr,"Oooohps!!!");
                            break;
                    }
                    execute (
                        assgn (var (res->name),
                               op (VAR (L(p)->env, col1, aat_wkb),
                                   VAR (L(p)->env, col2, aat_wkb))));

                }   break; /* fold) */
                case alg_fun_geo_geometry: /* fold( */
                {
                    PFalg_col_t element   = clat (p->sem.fun_1to1.refs, 0);
                    PFmil_t *pre          = VAR (p->env, element, aat_pre),
                            *pre_cont     = VAR (p->env, element, aat_frag);

                    assert (env_count (L(p)->env));

                    res_type = aat_wkb;

                    execute (
                        assgn ( var (res->name),
                                wkb_geometry (var (PF_MIL_VAR_WS),
                                            hmark (pre, lit_oid(0)),
                                            pre,
                                            set_kind (pre_cont,
                                                      var (PF_MIL_VAR_ELEM)))));

                }   break; /* fold) */
                case alg_fun_geo_relate: /* fold( */
                {
                    PFalg_col_t col1, col2, col3;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    col3 = clat (p->sem.fun_1to1.refs, 2);
                    res_type = aat_bln;

                    execute (
                        assgn (var (res->name),
                               mrelate (
                                   VAR (L(p)->env, col2, aat_wkb),
                                   VAR (L(p)->env, col3, aat_wkb),
                                   VAR (L(p)->env, col1, aat_str)
				   )));
                }   break; /* fold) */
#endif
                case alg_fun_fn_starts_with:
                case alg_fun_fn_ends_with:
                case alg_fun_fn_matches: /* fold( */
                {
                    PFmil_t * (*op) (const PFmil_t *, const PFmil_t *) = NULL;
                    PFalg_col_t col1, col2;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    res_type = aat_bln;

                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_fn_starts_with:
                            op = PFmil_mstarts_with; break;
                        case alg_fun_fn_ends_with:
                            op = PFmil_mends_with; break;
                        case alg_fun_fn_matches:
                            op = PFmil_mpcre_match; break;
                        default: break;
                    }

                    execute (
                        assgn (var (res->name),
                               op (VAR (L(p)->env, col1, aat_str),
                                   VAR (L(p)->env, col2, aat_str))));
                }   break; /* fold) */
                case alg_fun_fn_substring_before: /* fold( */
                {
                    PFalg_col_t col1, col2;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    res_type = aat_str;

                    execute (
                        assgn (var (res->name),
                               mstring2 (VAR (L(p)->env, col1, aat_str),
                                         lit_int (0),
                                         msearch (
                                             VAR (L(p)->env, col1, aat_str),
                                             VAR (L(p)->env, col2, aat_str)))));

                }   break; /* fold) */
                case alg_fun_fn_substring_after: /* fold( */
                {
                    PFalg_col_t col1, col2;
                    mvar_t     *search_res;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    res_type = aat_str;
                    search_res = new_var(1);

                    execute (
                        assgn (var (search_res->name),
                               msearch (VAR (L(p)->env, col1, aat_str),
                                        VAR (L(p)->env, col2, aat_str))),
                        assgn (var (res->name),
                               mifthenelse (meq (var (search_res->name),
                                                 lit_int(-1)),
                                            lit_str(""),
                                            mstring (
                                                VAR (L(p)->env, col1, aat_str),
                                                madd (var (search_res->name),
                                                      mlength (VAR (L(p)->env,
                                                                   col2,
                                                                   aat_str))
                                                      )))));
                    unpin(search_res, 1);
                }   break; /* fold) */
                case alg_fun_fn_matches_flag: /* fold( */
                {
                    PFalg_col_t col1, col2, col3;
                    mvar_t *chk = new_var(1),
                           *err = new_var(1);

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    col3 = clat (p->sem.fun_1to1.refs, 2);
                    res_type = aat_bln;

                    /* check flags for validity */
                    execute (
                        catch_ (var (err->name),
                                seq ( assgn (var (chk->name),
                                             mpcre_match (
                                                 VAR (L(p)->env,
                                                      col3,
                                                      aat_str),
                                                 lit_str("[^imsx]"))))),
                        if_ (not (isnil (var (err->name))),
                             error (
                                 arg (lit_str ("Should not happen: "
                                      "error occurred while checking flags: "),
                                      var (err->name))),
                             nop ()),
                        if_ (texist (var (chk->name), lit_bit(true)),
                             error (lit_str ("err:FORX0001: flags of "
                                             "fn:matches containing "
                                             "undefined character(s)")),
                             nop ()));

                    execute (
                        assgn (var (res->name),
                               mpcre_match_flag (
                                   VAR (L(p)->env, col1, aat_str),
                                   VAR (L(p)->env, col2, aat_str),
                                   VAR (L(p)->env, col3, aat_str))));

                    unpin (chk, 1);
                    unpin (err, 1);
                }   break; /* fold) */
                case alg_fun_fn_replace: /* fold( */
                case alg_fun_fn_replace_flag:
                {
                    PFalg_col_t  col1, col2, col3;
                    PFmil_t     *flags = NULL;
                    mvar_t      *chk   = new_var (1);

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    col2 = clat (p->sem.fun_1to1.refs, 1);
                    col3 = clat (p->sem.fun_1to1.refs, 2);
                    res_type = aat_str;

                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_fn_replace:
                            flags = lit_str("");
                            break;
                        case alg_fun_fn_replace_flag:
                            flags = VAR (L(p)->env,
                                         clat (p->sem.fun_1to1.refs, 3),
                                         aat_str);
                            break;
                        default:
                            assert(!"should never reach here"); break;
                    }

                    /* check whether the replacement
                     * string contains variables */
                    execute (
                        assgn (var (chk->name),
                               mpcre_match (VAR (L(p)->env, col3, aat_str),
                                            lit_str("[$][0-9]"))),
                        if_ (texist (var (chk->name), lit_bit(true)),
                             error (lit_str ("Variables in replacements are "
                                             "not supported yet")),
                             nop ()));

                    unpin (chk, 1);

                    execute (
                        assgn (var (res->name),
                               mpcre_replace (
                                   VAR (L(p)->env, col1, aat_str),
                                   VAR (L(p)->env, col2, aat_str),
                                   VAR (L(p)->env, col3, aat_str),
                                   flags)));
                }   break; /* fold) */
                case alg_fun_fn_name: /* fold( */
                {
                    PFalg_col_t col         = clat (p->sem.fun_1to1.refs, 0);
                    mvar_t     *id          = new_var (1),
                               *cont        = new_var (1),
                               *empty_str   = new_var (1),
                               *mu          = new_var (1),
                               *prefix      = new_var (1),
                               *prefix_bool = new_var (1),
                               *true_oid    = new_var (1),
                               *false_oid   = new_var (1);
                    bool        set,
                                names_only;

                    /* check whether we are allowed to remove duplicates */
                    set = PFprop_set (p->prop) &&
                          PFprop_icols_count (p->prop) == 1 &&
                          PFprop_icol (p->prop, p->sem.fun_1to1.res);

                    /* look up the correct QName references */
                    names_only = fn_node_name (L(p), col, id, cont, set);

                    /* get all prefixes */
                    execute (
                        assgn (var (prefix->name),
                               mposjoin (tmark (var (id->name), lit_oid (0)),
                                         tmark (var (cont->name), lit_oid (0)),
                                         fetch (var (PF_MIL_VAR_WS),
                                                var (PF_MIL_VAR_QN_PREFIX)))),
                        /* add ":" only to prefix that are not "" */
                        assgn (var (prefix_bool->name),
                               meq (var (prefix->name), lit_str(""))),
                        assgn (var (true_oid->name),
                               hmark (uselect (var (prefix_bool->name),
                                               lit_bit(true)),
                                      lit_oid(0))),
                        assgn (var (false_oid->name),
                               hmark (uselect (var (prefix_bool->name),
                                               lit_bit(false)),
                                      lit_oid(0))),
                        assgn (var (prefix->name),
                               madd (leftfetchjoin (var (false_oid->name),
                                                    var (prefix->name)),
                                     lit_str(":"))),
                        assgn (var (mu->name),
                               merged_union (
                                   arg (var (true_oid->name),
                                        arg (var (false_oid->name),
                                             arg (lit_str(""),
                                                  var (prefix->name)))))),
                        /* we know that prefix now contains all rows
                           (and thus treat a tmark for a leftjoin) */
                        assgn (var (prefix->name),
                               tmark (
                                   fetch (var (mu->name), lit_int (1)),
                                   lit_oid (0))),
                        assgn (var (res->name),
                               madd (var (prefix->name),
                                     mposjoin (tmark (var (id->name),
                                                      lit_oid (0)),
                                               tmark (var (cont->name),
                                                      lit_oid (0)),
                                               fetch (
                                                   var (PF_MIL_VAR_WS),
                                                   var (PF_MIL_VAR_QN_LOC))))));
                    if (!names_only)
                        execute (
                            /* empty names for nodes that have no QName */
                            assgn (var (empty_str->name),
                                   project (kdiff (ANY_VAR(L(p)->env),
                                                   var (id->name)),
                                            lit_str (""))),
                            assgn (var (mu->name),
                                   merged_union (
                                       arg (hmark (var (id->name), lit_oid (0)),
                                            arg (hmark (var (empty_str->name),
                                                        lit_oid (0)),
                                                 arg (var (res->name),
                                                      tmark (var (empty_str->name),
                                                             lit_oid (0))))))),
                            assgn (var (res->name),
                                   tmark (fetch (var (mu->name), lit_int (1)),
                                          lit_oid (0))));

                    unpin (id, 1);
                    unpin (cont, 1);
                    unpin (empty_str, 1);
                    unpin (mu, 1);
                    unpin (prefix, 1);
                    unpin (prefix_bool, 1);
                    unpin (true_oid, 1);
                    unpin (false_oid, 1);

                    res_type = aat_str;
                }   break; /* fold) */
                case alg_fun_fn_local_name:
                case alg_fun_fn_namespace_uri: /* fold( */
                {
                    PFalg_col_t   col         = clat (p->sem.fun_1to1.refs, 0);
                    mvar_t       *id          = new_var (1),
                                 *cont        = new_var (1),
                                 *empty_str   = new_var (1),
                                 *mu          = new_var (1);
                    PFmil_ident_t uri_loc     = PF_MIL_VAR_UNUSED;
                    bool          set,
                                  names_only;

                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_fn_local_name:
                            uri_loc = PF_MIL_VAR_QN_LOC; break;
                        case alg_fun_fn_namespace_uri:
                            uri_loc = PF_MIL_VAR_QN_URI; break;
                        default:
                            assert(!"should never reach here"); break;
                    }

                    /* check whether we are allowed to remove duplicates */
                    set = PFprop_set (p->prop) &&
                          PFprop_icols_count (p->prop) == 1 &&
                          PFprop_icol (p->prop, p->sem.fun_1to1.res);

                    /* look up the correct QName references */
                    names_only = fn_node_name (L(p), col, id, cont, set);

                    /* get all prefixes */
                    execute (
                        assgn (var (res->name),
                               mposjoin (tmark (var (id->name), lit_oid (0)),
                                         tmark (var (cont->name), lit_oid (0)),
                                         fetch (var (PF_MIL_VAR_WS),
                                                var (uri_loc)))));
                    if (!names_only)
                        execute (
                            /* empty names for nodes that have no QName */
                            assgn (var (empty_str->name),
                                   project (kdiff (ANY_VAR(L(p)->env),
                                                   var (id->name)),
                                            lit_str (""))),
                            assgn (var (mu->name),
                                   merged_union (
                                       arg (hmark (var (id->name), lit_oid (0)),
                                            arg (hmark (var (empty_str->name),
                                                        lit_oid (0)),
                                                 arg (var (res->name),
                                                      tmark (var (empty_str->name),
                                                             lit_oid (0))))))),
                            assgn (var (res->name),
                                   tmark (fetch (var (mu->name), lit_int (1)),
                                          lit_oid (0))));

                    unpin (id, 1);
                    unpin (cont, 1);
                    unpin (empty_str, 1);
                    unpin (mu, 1);

                    res_type = aat_str;
                }   break; /* fold) */
                case alg_fun_fn_number:
                case alg_fun_fn_number_lax: /* fold( */
                {
                    PFalg_col_t         col   = clat (p->sem.fun_1to1.refs, 0);
                    PFalg_simple_type_t ty    = type_of (L(p), col);
                    bool                first = true;

                    res_type = aat_dbl;

                    if (ty & aat_qname)
                        PFoops (OOPS_FATAL,
                                "We do not support the value NaN.");

                    for (PFalg_simple_type_t t = 1; t; t <<= 1)
                        if (t & TYPE_MASK(ty)) {

                            PFmil_t *casted = NULL;

                            if (t == res_type)
                                casted = VAR (L(p)->env, col, t);
                            else
                                casted
                                    = mcast (
                                        implty_ (res_type),
                                        VAR (L(p)->env, col, t));

                            if (first) {
                                execute (assgn (var (res->name), casted));
                                first = false;
                            }
                            else
                                execute (assgn (var (res->name),
                                                mifthenelse (
                                                    misnil (var (res->name)),
                                                    casted,
                                                    var (res->name))));
                        }

                    if (p->sem.fun_1to1.kind == alg_fun_fn_number)
                        /* As we do not support the value NaN we need to generate
                           an error for all tuples that cannot be casted (instead
                           of generating NaN). */
                        execute (
                            if_ (exist (reverse (var (res->name)),
                                        cast (implty_ (res_type), nil ())),
                                 error (
                                     lit_str ("We do not support the value NaN.")),
                                 nop ()));
                }   break; /* fold) */
                case alg_fun_fn_qname: /* fold( */
                {
                    PFalg_col_t uri     = clat (p->sem.fun_1to1.refs, 0),
                                pfx_loc = clat (p->sem.fun_1to1.refs, 1);
                    mvar_t     *cont    = new_var (p->refctr),
                               *offset  = new_var (1),
                               *prefix  = new_var (1),
                               *local   = new_var (1),
                               *err_str = new_var (1),
                               *err_chk = new_var (1);
                    PFmil_t    *v_cast  = VAR (L(p)->env, pfx_loc, aat_str),
                               *v_uri   = VAR (L(p)->env, uri, aat_str);
                    PFmil_t    *str     = NULL;

                    /* split up strings using ``:'' as delimiter */
                    execute (
                        assgn (var (err_str->name),
                               check_qnames (v_cast)),
                        if_ (not (isnil (var (err_str->name))),
                             error (arg (lit_str ("err:FORG0001. "
                                                  "illegal QName '%s'."),
                                         var (err_str->name))),
                             nop ()),
                        assgn (var (offset->name),
                               msearch (v_cast, lit_str (":"))),
                        assgn (var (prefix->name),
                               mstring2 (v_cast,
                                         lit_int (0),
                                         var (offset->name))),
                        assgn (var (local->name),
                               mstring (v_cast,
                                        madd (lit_int (1),
                                              var (offset->name)))));

                    /* Report an error if there is a prefix
                       but no namespace (encoded by the string "|"). */
                    execute (
                        assgn (var (err_chk->name),
                               select_ (
                                   meq (
                                       msearch (
                                           leftfetchjoin (
                                               mirror (
                                                   select_ (
                                                       meq (
                                                           var (prefix->name),
                                                           lit_str ("")),
                                                       lit_bit (false))),
                                               v_uri),
                                           lit_str ("|")),
                                       lit_int (-1)),
                                   lit_bit (false))),
                        if_ (gt (count (var (err_chk->name)), lit_int (0)),
                             error (
                                 lit_str ("err:FOCA0002, "
                                          "Invalid lexical value.")),
                             nop ()));

                    /* add_qnames changes the working set
                       in 'var (PF_MIL_VAR_WS)' as side effect */
                    str = add_qnames (
                              var (prefix->name),
                              v_uri,
                              var (local->name),
                              var (PF_MIL_VAR_WS));

                    execute (assgn (var (res->name), str),
                             assgn (var (cont->name),
                                    project (var (res->name),
                                             var (PF_MIL_VAR_WS_CONT))));

                    unpin (offset, 1);
                    unpin (prefix, 1);
                    unpin (local, 1);
                    unpin (err_str, 1);
                    unpin (err_chk, 1);

                    /* and put the result into p's environment */
                    env_add (p->env, p->sem.fun_1to1.res, aat_qname_cont, cont);

                    res_type = aat_qname_id;
                }   break; /* fold) */
                case alg_fun_fn_doc_available: /* fold( */
                {
                    PFalg_col_t col;

                    col = clat (p->sem.fun_1to1.refs, 0);
                    res_type = aat_bln;

                    execute (
                        assgn (var (res->name),
                               ws_docavailable ( var (PF_MIL_VAR_WS),
                                                 VAR (L(p)->env,
                                                      col,
                                                      aat_str))));

                } break; /* fold) */
                case alg_fun_pf_fragment: /* fold( */
                {
                    res_type = aat_frag;
                    res = env_mvar (L(p)->env,
                                    clat (p->sem.fun_1to1.refs, 0),
                                    aat_frag);
                }   break; /* fold) */
                case alg_fun_pf_supernode: /* fold( */
                    /* FIXME: not implemented yet. */
                    assert (!"no implementation here");
                    break; /* fold) */

                case alg_fun_pf_add_doc_str: /* fold( */
                {
                    PFalg_col_t filepath   = clat (p->sem.fun_1to1.refs, 0),
                                docname    = clat (p->sem.fun_1to1.refs, 1),
                                collection = clat (p->sem.fun_1to1.refs, 2);

                    assert (env_count (L(p)->env));

                    /* relink all filepath strings to the result BATs */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == filepath) {
                            pin (env_at (L(p)->env, i).mvar, p->refctr);
                            env_add (p->env,
                                     p->sem.fun_1to1.res,
                                     aat_path,
                                     env_at (L(p)->env, i).mvar);
                        }

                    /* relink all document name strings to the result BATs */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == docname) {
                            pin (env_at (L(p)->env, i).mvar, p->refctr);
                            env_add (p->env,
                                     p->sem.fun_1to1.res,
                                     aat_docnm,
                                     env_at (L(p)->env, i).mvar);
                        }

                    /* relink all colection name strings to the result BATs */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == collection) {
                            pin (env_at (L(p)->env, i).mvar, p->refctr);
                            env_add (p->env,
                                     p->sem.fun_1to1.res,
                                     aat_colnm,
                                     env_at (L(p)->env, i).mvar);
                        }

                    /* update percentage is the result BAT */
                    res_type = aat_docmgmt;
                    execute (
                        assgn ( var (res->name),
                                project (VAR (L(p)->env, docname, aat_str),
                                         lit_lng(0))));

                }   break; /* fold) */

                case alg_fun_pf_add_doc_str_int: /* fold( */
                {
                    PFalg_col_t filepath   = clat (p->sem.fun_1to1.refs, 0),
                                docname    = clat (p->sem.fun_1to1.refs, 1),
                                collection = clat (p->sem.fun_1to1.refs, 2),
                                percentage = clat (p->sem.fun_1to1.refs, 3);

                    assert (env_count (L(p)->env));

                    /* relink all filepath strings to the result BATs */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == filepath) {
                            pin (env_at (L(p)->env, i).mvar, p->refctr);
                            env_add (p->env,
                                     p->sem.fun_1to1.res,
                                     aat_path,
                                     env_at (L(p)->env, i).mvar);
                        }

                    /* relink all document name strings to the result BATs */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == docname) {
                            pin (env_at (L(p)->env, i).mvar, p->refctr);
                            env_add (p->env,
                                     p->sem.fun_1to1.res,
                                     aat_docnm,
                                     env_at (L(p)->env, i).mvar);
                        }

                    /* relink all colection name strings to the result BATs */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == collection) {
                            pin (env_at (L(p)->env, i).mvar, p->refctr);
                            env_add (p->env,
                                     p->sem.fun_1to1.res,
                                     aat_colnm,
                                     env_at (L(p)->env, i).mvar);
                        }

                    /* update percentage is the result BAT */
                    res_type = aat_docmgmt;
                    execute (
                        assgn ( var (res->name),
                                VAR (L(p)->env, percentage, aat_int)));

                }   break; /* fold) */

                case alg_fun_pf_del_doc: /* fold( */
                {
                    PFalg_col_t docname   = clat (p->sem.fun_1to1.refs, 0);

                    assert (env_count (L(p)->env));

                    /* relink all document name strings to the result BATs */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == docname) {
                            pin (env_at (L(p)->env, i).mvar, p->refctr);
                            env_add (p->env,
                                     p->sem.fun_1to1.res,
                                     aat_docnm,
                                     env_at (L(p)->env, i).mvar);
                        }

                    /* update percentage is the result BAT */
                    res_type = aat_docmgmt;
                    execute (
                        assgn ( var (res->name),
                                project (VAR (L(p)->env, docname, aat_str),
                                         lit_lng(-1))));

                }   break; /* fold) */

                case alg_fun_pf_nid: /* fold( */
                {
                    PFalg_col_t element   = clat (p->sem.fun_1to1.refs, 0);
                    PFmil_t *pre       = VAR (p->env, element, aat_pre),
                            *pre_cont  = VAR (p->env, element, aat_frag);

                    assert (env_count (L(p)->env));

                    res_type = aat_str;

                    execute (
                        assgn ( var (res->name),
                                mcast (type (mty_str),
                                       mcast (type (mty_lng),
                                              mposjoin (
                                                  pre,
                                                  pre_cont,
                                                  fetch (
                                                      var (PF_MIL_VAR_WS),
                                                      var (PF_MIL_VAR_PRE_NID))
                                              )))));

                }   break; /* fold) */
 
                case alg_fun_pf_docname: /* fold( */
                {
                    PFalg_col_t element   = clat (p->sem.fun_1to1.refs, 0);
                    PFmil_t *pre          = VAR (p->env, element, aat_pre),
                            *pre_cont     = VAR (p->env, element, aat_frag);

                    assert (env_count (L(p)->env));

                    res_type = aat_str;

                    execute (
                        assgn ( var (res->name),
                                ws_docname (var (PF_MIL_VAR_WS),
                                            hmark (pre, lit_oid(0)),
                                            pre,
                                            set_kind (pre_cont,
                                                      var (PF_MIL_VAR_ELEM)))));

                }   break; /* fold) */

                case alg_fun_fn_year_from_datetime:
                case alg_fun_fn_month_from_datetime:
                case alg_fun_fn_day_from_datetime:
                case alg_fun_fn_hours_from_datetime:
                case alg_fun_fn_minutes_from_datetime: /* fold( */
                {
                    PFmil_t * (*op1) (const PFmil_t *) = NULL;
                    PFmil_t * (*op2) (const PFmil_t *) = NULL;
                    PFalg_col_t col1;

                    assert (env_count (L(p)->env));

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    res_type = aat_int;

                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_fn_year_from_datetime:
                            op1 = PFmil_mdate;
                            op2 = PFmil_myear;
                            break;
                        case alg_fun_fn_month_from_datetime:
                            op1 = PFmil_mdate;
                            op2 = PFmil_mmonth;
                            break;
                        case alg_fun_fn_day_from_datetime:
                            op1 = PFmil_mdate;
                            op2 = PFmil_mday;
                            break;
                        case alg_fun_fn_hours_from_datetime:
                            op1 = PFmil_mdaytime;
                            op2 = PFmil_mhour;
                            break;
                        case alg_fun_fn_minutes_from_datetime:
                            op1 = PFmil_mdaytime;
                            op2 = PFmil_mminutes;
                            break;
                        default: break;
                    }

                    assert ((op1 != NULL) && (op2 != NULL));

                    execute (
                        assgn (var (res->name),
                               mcast (implty_ (res_type),
                                      op2 (op1 (VAR (L(p)->env,
                                                col1,
                                                aat_dtime))))));

                }   break; /* fold) */

                case alg_fun_fn_seconds_from_datetime: /* fold( */
                {
                    PFalg_col_t col1;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    res_type = aat_dec;

                    execute (
                        assgn (var (res->name),
                               mcast (implty_ (res_type),
                                      msecmsec (mdaytime (VAR (L(p)->env,
                                                               col1,
                                                               aat_dtime))))));
                }   break; /* fold) */

                case alg_fun_fn_year_from_date:
                case alg_fun_fn_month_from_date:
                case alg_fun_fn_day_from_date: /* fold( */
                {
                    PFmil_t * (*op) (const PFmil_t *) = NULL;
                    PFalg_col_t col1;

                    assert (env_count (L(p)->env));

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    res_type = aat_int;

                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_fn_year_from_date:
                            op = PFmil_myear; break;
                        case alg_fun_fn_month_from_date:
                            op = PFmil_mmonth; break;
                        case alg_fun_fn_day_from_date:
                            op = PFmil_mday; break;
                        default: break;
                    }

                    assert (op != NULL);

                    execute (
                        assgn (var (res->name),
                               mcast (implty_ (res_type),
                                      op (VAR (L(p)->env,
                                               col1,
                                               aat_date)))));

                }   break; /* fold) */

                case alg_fun_fn_hours_from_time:
                case alg_fun_fn_minutes_from_time: /* fold( */
                {
                    PFmil_t * (*op) (const PFmil_t *) = NULL;
                    PFalg_col_t col1;

                    assert (env_count (L(p)->env));

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    res_type = aat_int;

                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_fn_hours_from_time:
                            op = PFmil_mhour; break;
                        case alg_fun_fn_minutes_from_time:
                            op = PFmil_mminutes; break;
                        default: break;
                    }

                    assert (op != NULL);

                    execute (
                        assgn (var (res->name),
                               mcast (implty_ (res_type),
                                      op (VAR (L(p)->env,
                                          col1,
                                          aat_time)))));
                }   break; /* fold) */

                case alg_fun_fn_seconds_from_time: /* fold( */
                {
                    PFalg_col_t col1;

                    col1 = clat (p->sem.fun_1to1.refs, 0);
                    res_type = aat_dec;

                    execute (
                        assgn (var (res->name),
                               mcast (implty_ (res_type),
                                      msecmsec (VAR (L(p)->env,
                                                col1,
                                                aat_time)))));
                }   break; /* fold) */

                case alg_fun_add_dur:
                case alg_fun_subtract_dur:
                case alg_fun_multiply_dur:
                case alg_fun_divide_dur:
                {
                }   break;

                case alg_fun_upd_delete: /* fold( */
                {
                    PFalg_col_t tgt = clat (p->sem.fun_1to1.refs, 0);
                    mvar_t *loop = NULL;

                    assert (env_count (L(p)->env));

                    /* relink all target nodes to the result BATs */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == tgt) {
                            pin (env_at (L(p)->env, i).mvar, p->refctr);
                            env_add (p->env,
                                     p->sem.fun_1to1.res,
                                     env_at (L(p)->env, i).ty << 4,
                                     env_at (L(p)->env, i).mvar);
                            loop = env_at (L(p)->env, i).mvar;
                        }

                    res_type = aat_update;

                    /* assign the correct update type to every row */
                    execute (
                        assgn (var (res->name),
                               project (
                                   var (loop->name),
                                   lit_lng(UPDATE_DELETE))));
                }   break; /* fold) */
                case alg_fun_upd_rename:
                case alg_fun_upd_insert_into_as_first:
                case alg_fun_upd_insert_into_as_last:
                case alg_fun_upd_insert_before:
                case alg_fun_upd_insert_after:
                case alg_fun_upd_replace_value_att:
                case alg_fun_upd_replace_value:
                case alg_fun_upd_replace_element:
                case alg_fun_upd_replace_node: /* fold( */
                {
                    PFalg_col_t tgt     = clat (p->sem.fun_1to1.refs, 0),
                                changes = clat (p->sem.fun_1to1.refs, 1);
                    mvar_t *loop = NULL;

                    int update_str;

                    assert (env_count (L(p)->env));

                    /* relink all target nodes to the result BATs */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == tgt) {
                            pin (env_at (L(p)->env, i).mvar, p->refctr);
                            env_add (p->env,
                                     p->sem.fun_1to1.res,
                                     env_at (L(p)->env, i).ty << 4,
                                     env_at (L(p)->env, i).mvar);
                            loop = env_at (L(p)->env, i).mvar;
                        }

                    /* relink all changes to the result BATs */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == changes) {
                            pin (env_at (L(p)->env, i).mvar, p->refctr);
                            env_add (p->env,
                                     p->sem.fun_1to1.res,
                                     env_at (L(p)->env, i).ty,
                                     env_at (L(p)->env, i).mvar);
                        }

                    res_type = aat_update;

                    /* assign the correct update type to every row */
                    switch (p->sem.fun_1to1.kind) {
                        case alg_fun_upd_rename:
                             update_str = UPDATE_RENAME;
                             break;
                        case alg_fun_upd_insert_into_as_first:
                             update_str = UPDATE_INSERT_FIRST;
                             break;
                        case alg_fun_upd_insert_into_as_last:
                             update_str = UPDATE_INSERT_LAST;
                             break;
                        case alg_fun_upd_insert_before:
                             update_str = UPDATE_INSERT_BEFORE;
                             break;
                        case alg_fun_upd_insert_after:
                             update_str = UPDATE_INSERT_AFTER;
                             break;
                        case alg_fun_upd_replace_value_att:
                        case alg_fun_upd_replace_value:
                             update_str = UPDATE_REPLACE;
                             break;
                        case alg_fun_upd_replace_element:
                             update_str = UPDATE_REPLACECONTENT;
                             break;
                        case alg_fun_upd_replace_node:
                             update_str = UPDATE_REPLACENODE;
                             break;
                        default:
                             update_str = 0; /* should never reach here */
                             break;     /* this is just to fool the compiler */
                    }
                    execute (
                        assgn (var (res->name),
                               project (
                                   var (loop->name),
                                   lit_lng(update_str))));

                }   break; /* fold) */
            }

            /* and put the result into p's environment */
            env_add (p->env, p->sem.fun_1to1.res, res_type, res);
        }   break; /* fold) */

        /* Rel:      eq (Rel) */
        case 50:
        /* Rel:      gt (Rel) */
        case 52: /* fold( */
        {
            PFmil_t * (*op) (const PFmil_t *, const PFmil_t *) = NULL;
            mvar_t *l   = new_var (1),
                   *r   = new_var (1),
                   *res = new_var (p->refctr);

            /* choose the correct operator */
            if (p->kind == pa_eq)      op = PFmil_meq;
            else if (p->kind == pa_gt) op = PFmil_mgt;
#ifndef NDEBUG
            else assert (!"unexpected operator in comparison");
#endif
            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            /* transform (possibly) multiple input columns
               into two single BATs (stored in l and r) */
            prepare_comp (
                L(p), L(p), p->sem.binary.col1, p->sem.binary.col2, l, r);

            /* do the comparison */
            execute (
                assgn (var (res->name), op (var (l->name), var (r->name))));

            /* and put the result into p's environment */
            env_add (p->env, p->sem.binary.res, aat_bln, res);

            unpin (l, 1);
            unpin (r, 1);
        }   break; /* fold) */

        /* Rel:      bool_not (Rel) */
        case 60: /* fold( */
        {
            mvar_t *res = new_var (p->refctr);

            assert (aat_bln == type_of (L(p), p->sem.unary.col));

            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            /* do the comparison */
            execute (
                assgn (var (res->name),
                       mnot (VAR (L(p)->env, p->sem.unary.col, aat_bln))));

            /* and put the result into p's environment */
            env_add (p->env, p->sem.unary.res, aat_bln, res);
        }   break; /* fold) */

        /* Rel:      bool_and (Rel) */
        case 61:
        /* Rel:      bool_or (Rel) */
        case 62: /* fold( */
        {
            PFmil_t * (*op) (const PFmil_t *, const PFmil_t *) = NULL;
            mvar_t *res = new_var (p->refctr);

            assert (aat_bln == type_of (L(p), p->sem.binary.col1));
            assert (aat_bln == type_of (L(p), p->sem.binary.col2));

            /* choose the correct operator */
            if (p->kind == pa_bool_and)     op = PFmil_mand;
            else if (p->kind == pa_bool_or) op = PFmil_mor;
#ifndef NDEBUG
            else assert (!"unexpected operator in boolean operator");
#endif
            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            /* do the comparison */
            execute (
                assgn (var (res->name),
                       op (VAR (L(p)->env, p->sem.binary.col1, aat_bln),
                           VAR (L(p)->env, p->sem.binary.col2, aat_bln))));

            /* and put the result into p's environment */
            env_add (p->env, p->sem.binary.res, aat_bln, res);
        }   break; /* fold) */

        /* Rel:      to (Rel) */
        case 64: /* fold( */
        {
            mvar_t *res = new_var (p->refctr);

            v = new_var (1);

            execute (
                /* v := in2.[-](in1).[+](1LL).[max](0LL);
                   v := enumerate(in1, v);
                   res := v.reverse().mark(0@0).reverse();
                   v := v.mark(0@0).reverse();

                   out_n := v.leftjoin(in_n);
                   out_n := out_n.tmark(0@0); */
                assgn (
                    var (v->name),
                    mmax (lit_lng (0),
                          madd (lit_lng (1),
                                msub (VAR (L(p)->env,
                                           p->sem.binary.col2,
                                           aat_int),
                                      VAR (L(p)->env,
                                           p->sem.binary.col1,
                                           aat_int))))),
                assgn (
                    var (v->name),
                    enumerate (VAR (L(p)->env, p->sem.binary.col1, aat_int),
                               var (v->name))),
                assgn (
                    var (res->name),
                    tmark (var (v->name), lit_oid (0))),
                assgn (
                    var (v->name),
                    reverse (mark (var (v->name), lit_oid (0)))));

            env_add (p->env, p->sem.binary.res, aat_int, res);

            /* map all columns from the argument */
            env_map (p, L(p)->env, v);

            unpin (v, 1);
        }   break; /* fold) */

        /* Rel:      count_ext (Rel, Rel) */
        case 65: /* fold( */
        {
            mvar_t *res  = new_var (p->refctr);
            mvar_t *part = new_var (p->refctr);
            PFalg_simple_type_t ty = type_of (p, p->sem.count.part);

            v = new_var (1);

            if (!type_bit_check (ty))
                PFoops (OOPS_FATAL,
                        "Count not implemented for polymorphic groups");

            execute (
                /* v := {count}(p_in.reverse ()) */
                assgn (
                    var (v->name),
                    egcount (
                        reverse (VAR (L(p)->env, p->sem.count.part, ty)),
                        reverse (VAR (R(p)->env, p->sem.count.loop, ty)))),
                /* align with integer representation (lng) */
                assgn (var (v->name),
                       mcast (type (mty_lng), var (v->name))),
                /* res := v.reverse ().mark (0@0).reverse (); */
                assgn (
                    var (res->name),
                    reverse (
                        mark (
                            reverse (var (v->name)),
                            lit_oid (0)))),
                /* part := v.mark (0@0).reverse (); */
                assgn (
                    var (part->name),
                    reverse (
                        mark (var (v->name), lit_oid (0)))));

            env_add (p->env, p->sem.count.res, aat_int, res);
            env_add (p->env, p->sem.count.part, ty, part);

            unpin (v, 1);
        }   break; /* fold) */

        /* Rel:      aggr (Rel) */
        case 66: /* fold( */
            /**
             * We have two completely different implementations:
             *  - a partitioned aggregate (that returns for every group a row
             *    and an empty result for an empty input), and
             *  - an unpartitioned aggregate (that always return a single row).
             */
        
            /* reserve temporary variable */
            v = new_var (1);

            /* Handle partitioned aggregate. */
            if (p->sem.aggr.part != col_NULL) {
                PFalg_col_t         part      = p->sem.aggr.part;
                PFalg_simple_type_t part_ty   = type_of (L(p), part);
                mvar_t             *part_var  = new_var (p->refctr);
                PFmil_t            *PART_VAR  = VAR (L(p)->env, part, part_ty);
                bool                dist      = false;

                if (!type_bit_check (part_ty))
                    PFoops (OOPS_FATAL,
                            "Aggregates not implemented "
                            "for polymorphic columns");

                /* add the part MIL variable to the environment */
                env_add (p->env, part, part_ty, part_var);

                /* 1st run: cope with all non-distinct aggregates */
                for (unsigned int i = 0; i < p->sem.aggr.count; i++) {
                    PFalg_aggr_kind_t   kind    = p->sem.aggr.aggr[i].kind;
                    PFalg_col_t         res     = p->sem.aggr.aggr[i].res,
                                        col     = p->sem.aggr.aggr[i].col;
                    PFalg_simple_type_t col_ty  = type_of (p, res);
                    mvar_t             *res_var;
                    
                    /* skip distinct aggregate for now */
                    if (kind == alg_aggr_dist) {
                        dist = true;
                        continue;
                    }
                   
                    if (!type_bit_check (col_ty))
                        PFoops (OOPS_FATAL,
                                "Aggregates not implemented "
                                "for polymorphic columns");

                    /* create a new result MIL variable
                       and add it to the environment */
                    res_var = new_var (p->refctr);
                    env_add (p->env, res, col_ty, res_var);

                    /* prepare the input for the aggregate */
                    if (col) {
                        assert (type_of (L(p), col) == col_ty);
                        execute (assgn (var (v->name),
                                        leftfetchjoin (
                                            reverse (PART_VAR),
                                            VAR (L(p)->env, col, col_ty))));
                    }
                    else
                        execute (assgn (var (v->name),
                                        reverse (PART_VAR)));

                    switch (kind) {
                        case alg_aggr_dist:
                            assert (0);
                            break;
                        case alg_aggr_min:
                            execute (assgn (var (v->name),
                                            PFmil_gmin (var (v->name))));
                            break;
                        case alg_aggr_max:
                            execute (assgn (var (v->name),
                                            PFmil_gmax (var (v->name))));
                            break;
                        case alg_aggr_all:
                            /* v := [=]({sum}(v),{count}(v)); */
                            execute (assgn (var (v->name),
                                            meq (PFmil_gsum (
                                                     mcast (type (mty_int),
                                                            var (v->name))),
                                                 gcount (var (v->name)))));
                            break;
                        case alg_aggr_count:
                            /* align with integer representation (lng) */
                            execute (assgn (var (v->name),
                                     mcast (type (mty_lng),
                                            gcount (var (v->name)))));
                            break;
                        case alg_aggr_avg:
                            execute (assgn (var (v->name),
                                            PFmil_gavg (var (v->name))));
                            break;
                        case alg_aggr_sum:
                            execute (assgn (var (v->name),
                                            PFmil_gsum (var (v->name))));
                            break;
                        case alg_aggr_seqty1:
                            /* v := [and]([=](1,{sum}(v)),[=](1,{count}(v))); */
                            execute (assgn (var (v->name),
                                            PFmil_mand (
                                                meq (lit_int (1),
                                                     PFmil_gsum (
                                                         mcast (
                                                             type (mty_int),
                                                             var (v->name)))),
                                                meq (lit_int (1),
                                                     gcount (var (v->name))))));
                            break;
                        case alg_aggr_prod:
                            execute (assgn (var (v->name),
                                            PFmil_gprod (var (v->name))));
                            break;
                    }
                    /* bind the aggregate result to the result MIL variable */
                    execute (
                        assgn (var (res_var->name),
                               tmark (var (v->name), lit_oid (0))));
                }

                /* generate a relation that can be used to adjust the
                   distinct aggregate values */
                if (dist)
                    execute (assgn (var (v->name),
                                    PFmil_gmin (reverse (PART_VAR))));

                /* bind the result partition to the partition MIL variable */
                execute (
                    assgn (var (part_var->name),
                           hmark (var (v->name), lit_oid (0))));

                /* 2nd run: cope with all distinct aggregates */
                for (unsigned int i = 0; i < p->sem.aggr.count; i++) {
                    PFalg_aggr_kind_t   kind    = p->sem.aggr.aggr[i].kind;
                    PFalg_col_t         res     = p->sem.aggr.aggr[i].res,
                                        col     = p->sem.aggr.aggr[i].col;
                    PFalg_simple_type_t ty;
                    mvar_t             *col_var,
                                       *res_var;
                    
                    /* only treat distinct aggregate */
                    if (kind != alg_aggr_dist)
                        continue;
                   
                    /* map all variables related with this column */
                    for (unsigned int i = 0; i < env_count (L(p)->env); i++)
                        if (env_at (L(p)->env, i).col == col) {
                            ty      = env_at (L(p)->env, i).ty;
                            col_var = env_at (L(p)->env, i).mvar;
                            res_var = new_var (p->refctr);

                            /* map variables */
                            execute (assgn (var (res_var->name),
                                            tmark (
                                                leftjoin (var (v->name),
                                                          var (col_var->name)),
                                                lit_oid (0))));

                            env_add (p->env, res, ty, res_var);
                        }
                }
            }
            /* Handle unpartitioned aggregate.

               NOTE: The current implementation only generates unpartitioned
               count aggregates. In case other aggregates are also used
               the result for empty input sequences (namely the value nil)
               requires additional care. */
            else {

                for (unsigned int i = 0; i < p->sem.aggr.count; i++) {
                    PFalg_aggr_kind_t   kind    = p->sem.aggr.aggr[i].kind;
                    PFalg_col_t         res     = p->sem.aggr.aggr[i].res,
                                        col     = p->sem.aggr.aggr[i].col;
                    PFalg_simple_type_t col_ty  = type_of (p, res);
                    mvar_t             *res_var;
                    
                    if (!type_bit_check (col_ty))
                        PFoops (OOPS_FATAL,
                                "Aggregates not implemented "
                                "for polymorphic columns");

                    /* create a new result MIL variable
                       and add it to the environment */
                    res_var = new_var (p->refctr);
                    env_add (p->env, res, col_ty, res_var);

                    /* prepare the input for the aggregate */
                    if (col) {
                        assert (type_of (L(p), col) == col_ty);
                        execute (assgn (var (v->name), 
                                        VAR (L(p)->env, col, col_ty)));
                    }
                    else
                        execute (assgn (var (v->name), 
                                        ANY_VAR (L(p)->env)));

                    switch (kind) {
                        case alg_aggr_dist:
                            /* This case doesn't make sense -- so we bail out */
                            PFoops (OOPS_FATAL,
                                    "Unpartitioned distinct aggregate"
                                    " is not implemented");
                            break;
                        case alg_aggr_min:
                            execute (assgn (var (v->name),
                                            PFmil_min (var (v->name))));
                            break;
                        case alg_aggr_max:
                            execute (assgn (var (v->name),
                                            PFmil_max (var (v->name))));
                            break;
                        case alg_aggr_all:
                            execute (assgn (var (v->name),
                                            eq (PFmil_sum (
                                                    mcast (type (mty_int),
                                                           var (v->name))),
                                                count (var (v->name)))));
                            break;
                        case alg_aggr_count:
                            /* align with integer representation (lng) */
                            execute (assgn (var (v->name),
                                     cast (type (mty_lng),
                                           count (var (v->name)))));
                            break;
                        case alg_aggr_avg:
                            execute (assgn (var (v->name),
                                            PFmil_avg (var (v->name))));
                            break;
                        case alg_aggr_sum:
                            execute (assgn (var (v->name),
                                            PFmil_sum (var (v->name))));
                            break;
                        case alg_aggr_seqty1:
                            execute (assgn (var (v->name),
                                            PFmil_and (
                                                eq (lit_int (1),
                                                    PFmil_sum (
                                                        mcast (
                                                            type (mty_int),
                                                            var (v->name)))),
                                                eq (lit_int (1),
                                                    count (var (v->name))))));
                            break;
                        case alg_aggr_prod:
                            execute (assgn (var (v->name),
                                            PFmil_prod (var (v->name))));
                            break;
                    }
                    /* bind the aggregate result to the result MIL variable */
                    execute (
                        assgn (var (res_var->name),
                               append (
                                   seqbase (
                                       new (type (mty_void), implty_ (col_ty)),
                                       lit_oid (0)),
                                   var (v->name))));
                }
            }
            /* release temporary variable */
            unpin (v, 1);
            break; /* fold) */

        /* Rel:      mark (Rel) */
        case 71: /* fold( */
        {
            mvar_t *res = new_var (p->refctr);

            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            if (env_at (L(p)->env, 0).ty == aat_frag)
                /* As in many cases two adjacent path steps are separated
                   by a mark operator and the fragment is constant we
                   try to avoid an additional dependency on the fragment
                   to ease 'materialize' operator removal. */
                execute (
                    assgn (var (res->name),
                           mark (VAR (L(p)->env,
                                      env_at (L(p)->env, 0).col,
                                      aat_pre),
                                 lit_oid (1))));
            else
                execute (assgn (var (res->name),
                                mark (ANY_VAR (L(p)->env), lit_oid (1))));

            /* put the result into p's environment */
            env_add (p->env, p->sem.mark.res, aat_nat, res);
        } break; /* fold) */

        /* Rel:      rank (Rel) */
        case 72:
        /* Rel:      rank (std_sort (Rel)) */
        case 73:
        /* Rel:      rank (refine_sort (Rel)) */
        case 74: /* fold( */
            /* as we have to sort anyway we can also skip the sort operator */
        {
            /*
             * Derive a single BAT from the multi-column grouping
             * (using functions from the xtables module).
             */
            PFord_ordering_t    ord = p->sem.rank.ord;
            PFpa_op_t          *rel;
            mvar_t             *res = new_var (p->refctr);

            v = new_var (1);

            if (L(p)->kind == pa_std_sort || L(p)->kind == pa_refine_sort)
                rel = LL(p);
            else
                rel = L(p);

            assert (PFord_count (ord));

            /* create the MIL code that stores
               the ordered extend in variable v */
            order_extend (rel, ord, v);

            execute (
                /* Extend the sorting with a dummy sort criterion to
                   ensure that the result column @a res consists of oids. */
                assgn (var (res->name),
                       reverse (mark (reverse (
                                          ctrefine (var (v->name),
                                                    project (var (v->name),
                                                             lit_oid (1)),
                                                    false)),
                                      lit_oid (0)))),
                 /* We know that the extent certainly is sorted. */
                assgn (var (res->name),
                       assert_order (var (res->name))),
                /* Create a new mapping relation. */
                assgn (var (v->name),
                       reverse (mark (var (v->name), lit_oid (0)))));

            /* put the result into p's environment */
            env_add (p->env, p->sem.rank.res, aat_nat, res);

            /* map all columns from the argument */
            env_map (p, rel->env, v);

             /* we know that the first sort criterion certainly is sorted
                -- assert_order however only copes with ascending order */
            if (PFord_count (ord) &&
                PFord_order_dir_at (ord, 0) == DIR_ASC) {
                PFalg_col_t col = PFord_order_col_at (ord, 0);
                PFalg_simple_type_t ty = type_of (rel, col);
                if (type_bit_check (ty))
                    execute (
                        assgn (VAR(p->env, col, ty),
                               assert_order (VAR(p->env, col, ty))));
            }

            /* release our temporary variable */
            unpin (v, 1);
        }   break; /* fold) */

        /* Rel:      mark_grp (Rel) */
        case 75: /* fold( */
        {
            mvar_t *res = new_var (p->refctr);

            assert (env_count (L(p)->env));
            assert (p->sem.mark.part);

            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            execute (
                assgn (var (res->name),
                       mark_grp (
                           VAR (p->env,
                                p->sem.mark.part,
                                type_of (p, p->sem.mark.part)),
                           project (
                               kunique (
                                   reverse (
                                       VAR (p->env,
                                            p->sem.mark.part,
                                            type_of (p, p->sem.mark.part)))),
                               lit_oid (1)))));

            /* put the result into p's environment */
            env_add (p->env, p->sem.mark.res, aat_nat, res);
        } break; /* fold) */

        /* Rel:      type (Rel) */
        case 76: /* fold( */
        {
            mvar_t             *res      = new_var (p->refctr);
            PFalg_col_t         col      = p->sem.type.col;
            PFalg_simple_type_t input_ty = type_of (L(p), col),
                                req_ty   = p->sem.type.ty;
            PFmil_t            *type     = NULL;

            /* and put the result into p's environment */
            env_add (p->env, p->sem.type.res, aat_bln, res);

            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            if (!(req_ty & input_ty))
                /* cope with the case that our schema does not provide
                   the type represented by req_ty */
                type = project (ANY_VAR (L(p)->env), lit_bit (false));
            else if (req_ty == aat_node)
                /* both pre values and attributes are available and allowed */
                type = mnot (misnil (VAR (L(p)->env, col, aat_frag)));
            else if (req_ty == aat_pnode && input_ty & aat_attr)
                /* attr values are available and not allowed */
                type = mand (mnot (misnil (VAR (L(p)->env, col, aat_frag))),
                             misnil (VAR (L(p)->env, col, aat_attr)));
            else if (req_ty == aat_pnode)
                /* pre values are available and allowed */
               type = mnot (misnil (VAR (L(p)->env, col, aat_pre)));
            else if (req_ty == aat_anode)
                /* attributes are available and allowed */
                type = mnot (misnil (VAR (L(p)->env, col, aat_attr)));
            else if (req_ty == aat_qname)
                /* attributes are available and allowed */
                type = mnot (misnil (VAR (L(p)->env, col, aat_qname_id)));
            else
                /* we have one simple type */
                type = mnot (misnil (VAR (L(p)->env, col, req_ty)));

            execute (assgn (var (res->name), type));
        }   break; /* fold) */

        /* Rel:      type_assert (Rel) */
        case 77: /* fold( */
            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);
            break; /* fold) */

        /* Rel:      cast (Rel) */
        case 78: /* fold( */
        {
            PFalg_col_t         col      = p->sem.cast.col;
            PFalg_simple_type_t input_ty = type_of (L(p), col),
                                req_ty   = p->sem.cast.ty;

            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            /* cast as qname requires additional document access */
            if (req_ty == aat_qname) {
                if (input_ty & ~(aat_str | aat_uA | aat_qname))
                    PFoops (OOPS_FATAL,
                            "cast to type QName is only possible "
                            "for values of type QName or string.");

                if (input_ty == aat_qname) {
                    env_add (p->env, p->sem.cast.res, aat_qname_id,
                             env_mvar (L(p)->env, col, aat_qname_id));
                    env_add (p->env, p->sem.cast.res, aat_qname_cont,
                             env_mvar (L(p)->env, col, aat_qname_cont));
                }
                else if (input_ty == aat_str || input_ty == aat_uA) {
                    mvar_t *res_id   = new_var (p->refctr),
                           *res_cont = new_var (p->refctr),
                           *in       = env_mvar (L(p)->env, col, input_ty);

                    transform_QName (in, res_id);
                    execute (
                        assgn (var (res_cont->name),
                               project (var (res_id->name),
                                        var (PF_MIL_VAR_WS_CONT))));

                    /* and put the result into p's environment */
                    env_add (p->env, p->sem.cast.res, aat_qname_id, res_id);
                    env_add (p->env, p->sem.cast.res, aat_qname_cont, res_cont);
                }
                else {
                    PFalg_simple_type_t ty[2]    = { aat_str, aat_uA };
                    mvar_t             *res_id   = new_var (p->refctr),
                                       *res_cont = new_var (p->refctr);

                    if (input_ty & aat_qname)
                        execute (
                            assgn (var (res_id->name),
                                   VAR (L(p)->env, col, aat_qname_id)),
                            assgn (var (res_cont->name),
                                   VAR (L(p)->env, col, aat_qname_cont)));
                    else
                        execute (
                            assgn (var (res_id->name),
                                   project (ANY_VAR (L(p)->env),
                                            mcast (type (mty_oid), nil ()))),
                            assgn (var (res_cont->name),
                                   project (ANY_VAR (L(p)->env),
                                            mcast (type (mty_oid), nil ()))));

                    for (unsigned short i = 0; i < 2; i++)
                        if (input_ty & ty[i]) {
                            mvar_t *str_id   = new_var (1),
                                   *str_cont = new_var (1),
                                   *in       = env_mvar (L(p)->env, col, ty[i]);

                            transform_QName (in, str_id);
                            execute (
                                assgn (var (str_cont->name),
                                       project (var (res_id->name),
                                                var (PF_MIL_VAR_WS_CONT))),
                                assgn (var (res_id->name),
                                       mifthenelse (
                                           misnil (var (res_id->name)),
                                           var (str_id->name),
                                           var (res_id->name))),
                                assgn (var (res_cont->name),
                                       mifthenelse (
                                           misnil (var (res_cont->name)),
                                           var (str_cont->name),
                                           var (res_cont->name))));

                            unpin (str_id, 1);
                            unpin (str_cont, 1);
                        }

                    /* and put the result into p's environment */
                    env_add (p->env, p->sem.cast.res, aat_qname_id, res_id);
                    env_add (p->env, p->sem.cast.res, aat_qname_cont, res_cont);
                }
            }
            else if (type_bit_check (req_ty)) {
                unsigned int parts = 0;
                mvar_t      *res   = new_var (p->refctr),
                            *tmp   = new_var (1);

                /* and put the result into p's environment */
                env_add (p->env, p->sem.cast.res, req_ty, res);

                if (input_ty & aat_qname) {
                    if (req_ty == aat_str || req_ty == aat_uA) {
                        mvar_t *id,
                               *cont,
                               *mu          = new_var (1),
                               *prefix      = new_var (1),
                               *prefix_bool = new_var (1),
                               *true_oid    = new_var (1),
                               *false_oid   = new_var (1);

                        id   = env_mvar (L(p)->env, col, aat_qname_id);
                        cont = env_mvar (L(p)->env, col, aat_qname_cont);

                        execute (
                            assgn (var (prefix->name),
                                   mposjoin (
                                       var (id->name),
                                       var (cont->name),
                                       fetch (var (PF_MIL_VAR_WS),
                                              var (PF_MIL_VAR_QN_PREFIX)))),
                            /* add ":" only to prefix that are not "" */
                            assgn (var (prefix_bool->name),
                                   meq (var (prefix->name), lit_str(""))),
                            assgn (var (true_oid->name),
                                   hmark (uselect (var (prefix_bool->name),
                                                   lit_bit(true)),
                                          lit_oid(0))),
                            assgn (var (false_oid->name),
                                   hmark (uselect (var (prefix_bool->name),
                                                   lit_bit(false)),
                                          lit_oid(0))),
                            assgn (var (prefix->name),
                                   madd (leftfetchjoin (var (false_oid->name),
                                                        var (prefix->name)),
                                         lit_str(":"))),
                            assgn (var (mu->name),
                                   merged_union (
                                       arg (var (true_oid->name),
                                            arg (var (false_oid->name),
                                                 arg (lit_str(""),
                                                      var (prefix->name)))))),
                            assgn (var (prefix->name),
                                   leftfetchjoin (
                                       reverse (
                                           fetch (var (mu->name), lit_int (0))),
                                       fetch (var (mu->name), lit_int (1)))),
                            assgn (var (res->name),
                                   madd (var (prefix->name),
                                         mposjoin (
                                             var (id->name),
                                             var (cont->name),
                                             fetch (
                                                 var (PF_MIL_VAR_WS),
                                                 var (PF_MIL_VAR_QN_LOC))))));
                        unpin (mu, 1);
                        unpin (prefix, 1);
                        unpin (prefix_bool, 1);
                        unpin (true_oid, 1);
                        unpin (false_oid, 1);
                    }
                    else
                        PFoops (OOPS_FATAL,
                                "err:XPTY0004: cannot cast QName to %s",
                                PFalg_simple_type_str (req_ty));

                    /* remove QNames */
                    input_ty = input_ty & ~aat_qname;
                    parts++;
                }
                for (PFalg_simple_type_t t = 1; t; t <<= 1)
                    if (t & TYPE_MASK(input_ty)) {
                        PFmil_t *casted = NULL;

                        if (t == p->sem.cast.ty)
                            casted = VAR (L(p)->env, p->sem.cast.col, t);
                        else if ((t == aat_str || t == aat_uA) &&
                                 req_ty == aat_bln) {
                            /* The cast from string or untypedAtomic
                               to boolean is only allowed for a few
                               values. Here the values are checked and
                               the respective result is returned. */
                            mvar_t *false_values = new_var (1),
                                   *true_values  = tmp;

                            /* collect all strings that map to 'true' */
                            execute (assgn (var (true_values->name),
                                            meq (VAR (L(p)->env,
                                                      p->sem.cast.col,
                                                      t),
                                                 lit_str("true"))),
                                     assgn (var (true_values->name),
                                            mor (var (true_values->name),
                                                 meq (VAR (L(p)->env,
                                                           p->sem.cast.col,
                                                           t),
                                                      lit_str("1")))),
                            /* collect all strings that map to 'false' */
                                     assgn (var (false_values->name),
                                            meq (VAR (L(p)->env,
                                                      p->sem.cast.col,
                                                      t),
                                                 lit_str("false"))),
                                     assgn (var (false_values->name),
                                            mor (var (false_values->name),
                                                 meq (VAR (L(p)->env,
                                                           p->sem.cast.col,
                                                           t),
                                                      lit_str("0")))),
                            /* generate an error message for all other
                               strings */
                                     if_ (
                                         exist (
                                             reverse (
                                                 mor (
                                                     var (
                                                         true_values->name),
                                                     var (
                                                         false_values->name)
                                                     )),
                                             lit_bit (false)),

                                         error (
                                             t == aat_uA
                                             ? lit_str ("err:FORG0001. "
                                                        "casting from "
                                                        "untypedAtomic "
                                                        "to boolean "
                                                        "failed.")
                                             : lit_str ("err:FORG0001. "
                                                        "casting from "
                                                        "string to "
                                                        "boolean failed.")
                                             ),
                                         nop ()));

                            casted = var (true_values->name);
                            /* note: casted == tmp */
                            unpin (false_values, 1);
                        }
                        else
                            casted
                                = mcast (
                                    implty_ (p->sem.cast.ty),
                                    VAR (L(p)->env, p->sem.cast.col, t));

                        if (parts)
                            execute (assgn (var (res->name),
                                            mifthenelse (
                                                misnil (var (res->name)),
                                                casted,
                                                var (res->name))));
                        else
                            execute (assgn (var (res->name), casted));

                        parts++;
                    }
                execute (
                    if_ (exist (reverse (var (res->name)),
                                cast (implty_ (p->sem.cast.ty), nil ())),
                         error (lit_str ("err:FORG0001.")),
                         nop ()));
                unpin (tmp, 1);
            }
            else
                PFoops (OOPS_FATAL,
                        "cast to polymorphic type not allowed.");
        }   break; /* fold) */

        /* Rel:      llscjoin (Rel) */
        case 90: /* fold( */
            llscj (p);
            break; /* fold) */

        /* Rel:      llscjoin_dup (Rel) */
        case 91: /* fold( */
            llscj_dup (p);
            break; /* fold) */

        /* Rel:      doc_tbl (Rel) */
        case 100: /* fold( */
        {
            PFalg_doc_tbl_kind_t kind = p->sem.doc_tbl.kind;

            /* temporary variables */
            mvar_t *time = new_var (1),
                   /* result BATs */
                   *frag = new_var (p->refctr),
                   *pre  = new_var (p->refctr);

            v = new_var (1);

            env_add (p->env, p->sem.doc_tbl.res, aat_pre, pre);
            env_add (p->env, p->sem.doc_tbl.res, aat_frag, frag);

            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            /* add timing information */
            execute (assgn (var (time->name), usec ()));

            /* fn:doc */
            if (kind == alg_dt_doc) {
                execute (
                    assgn (var (v->name),
                           doc_tbl (var (PF_MIL_VAR_WS),
                                    VAR (L(p)->env,
                                         p->sem.doc_tbl.col,
                                         aat_str))),
                    assgn (var (pre->name),
                           fetch (var (v->name),
                           lit_int (1))),
                    assgn (var (frag->name),
                           fetch (var (v->name),
                           lit_int (2))),
                    assgn (var (PF_MIL_VAR_WS),
                           fetch (var (v->name),
                           lit_int (0))));
            /* pf:collection */
            } else if (kind == alg_dt_col) {
                execute (
                    assgn (var (v->name),
                           ws_collection_root (var (PF_MIL_VAR_WS),
                                               VAR (L(p)->env,
                                                    p->sem.doc_tbl.col,
                                                    aat_str))),
                    assgn (var (pre->name),
                           tmark (var(v->name),
                                  lit_oid(0))),
                    assgn (var (frag->name),
                           hmark (var(v->name),
                                  lit_oid(0))));
            } else {
                assert(!"should never reach here");
            }

            unpin (v, 1);

            /* add timing information */
            execute (
                assgn (var (PF_MIL_VAR_TIME_LOAD),
                       add (var (PF_MIL_VAR_TIME_LOAD),
                            sub (usec (),
                                 var (time->name)))));
            unpin (time, 1);
        }   break; /* fold) */

        /* Rel:      doc_access (Rel) */
        case 101: /* fold( */
        {
            PFalg_col_t         col = p->sem.doc_access.col;
#ifndef NDEBUG
            /* only used in assertions */
            PFalg_simple_type_t ty  = type_of (L(p), p->sem.doc_access.col);
#endif
            mvar_t             *str = NULL,
                               *qname_id = NULL,
                               *qname_cont = NULL;

            PFmil_t *frag = VAR (L(p)->env, col, aat_frag),
                    *pre  = VAR (L(p)->env, col, aat_pre),
                    *attr,
                    *prop = mposjoin (
                                pre, frag, fetch (var (PF_MIL_VAR_WS),
                                                  var (PF_MIL_VAR_PRE_PROP))),
                    *cont = mposjoin (
                                pre, frag, fetch (var (PF_MIL_VAR_WS),
                                                  var (PF_MIL_VAR_PRE_CONT)));

            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            if (p->sem.doc_access.doc_col != doc_qname) {
                str = new_var (p->refctr);
                env_add (p->env, p->sem.doc_access.res, aat_str, str);
            }
            else {
                qname_id   = new_var (p->refctr);
                qname_cont = new_var (p->refctr);
                env_add (p->env, p->sem.doc_access.res,
                         aat_qname_id, qname_id);
                env_add (p->env, p->sem.doc_access.res,
                         aat_qname_cont, qname_cont);
            }

            /* lookup the values in the documents using mposjoin */
            switch (p->sem.doc_access.doc_col) {
                case (doc_atext):
                    assert (ty == aat_anode);
                    attr = VAR (L(p)->env, col, aat_attr);

                    execute (
                        assgn (var (str->name),
                               mposjoin (
                                   mposjoin (
                                       attr,
                                       frag,
                                       fetch (var (PF_MIL_VAR_WS),
                                              var (PF_MIL_VAR_ATTR_PROP))),
                                   mposjoin (
                                       attr,
                                       frag,
                                       fetch (var (PF_MIL_VAR_WS),
                                              var (PF_MIL_VAR_ATTR_CONT))),
                                   fetch (var (PF_MIL_VAR_WS),
                                          var (PF_MIL_VAR_PROP_VAL)))));
                    break;
                case (doc_text):
                    assert (ty == aat_pnode);
                    execute (
                        assgn (var (str->name),
                               mposjoin (
                                   prop,
                                   cont,
                                   fetch (var (PF_MIL_VAR_WS),
                                          var (PF_MIL_VAR_PROP_TEXT)))));
                    break;
                case (doc_comm):
                    assert (ty == aat_pnode);
                    execute (
                        assgn (var (str->name),
                               mposjoin (
                                   prop,
                                   cont,
                                   fetch (var (PF_MIL_VAR_WS),
                                          var (PF_MIL_VAR_PROP_COM)))));
                    break;
                case (doc_pi_text):
                    assert (ty == aat_pnode);
                    execute (
                        assgn (var (str->name),
                               mposjoin (
                                   prop,
                                   cont,
                                   fetch (var (PF_MIL_VAR_WS),
                                          var (PF_MIL_VAR_PROP_INS)))));
                    break;
                case (doc_atomize):
                {
                    assert (ty == aat_pnode);
                    /* Implement atomize (or string-value) semantic
                       by applying a descendant-or-self::text()
                       step_join, followed by a text-value lookup
                       (doc_access(doc_text)) and string_join aggregate
                       to get a single string for each input node. */

                    mvar_t  *iter     = new_var (1),
                            *scj_res  = new_var (1),
                            *iter_res = new_var (1),
                            *item_res = new_var (1),
                            *cont_res = new_var (1),
                            *item_str = new_var (1);

                    /* evaluate descendant-or-self::text() step:
                       iter := pre.mark(1@0);
                       scj_res := step (AXIS_descendant_or_self,
                                        TEST_kind,
                                        iter, pre, frag, nil, ws, 0,
                                        TEXT, str(nil), str(nil), str(nil));
                       iter_res := scj_res.fetch(0);
                       item_res := scj_res.fetch(2);
                       # cont is probably a fake project
                       cont_res := scj_res.fetch(1);
                       # avoid iter being a fake project
                       iter_res := materialize(iter_res, item_res); */
                    execute (
                        assgn (var (iter->name), mirror (pre)),
                        assgn (
                            var (scj_res->name),
                            step (var (PF_MIL_VAR_AXIS_DESC_S),
                                  var (PF_MIL_VAR_CODE_KIND),
                                  var (iter->name),
                                  frag,
                                  pre,
                                  nil (),
                                  var (PF_MIL_VAR_WS),
                                  lit_int (0),
                                  var (PF_MIL_VAR_KIND_TEXT),
                                  cast (type (mty_str), nil ()),
                                  cast (type (mty_str), nil ()),
                                  cast (type (mty_str), nil ()))),
                        assgn (
                            var (iter_res->name),
                            fetch(var (scj_res->name), lit_int (0))),
                        assgn (
                            var (item_res->name),
                            fetch(var (scj_res->name), lit_int (2))),
                        assgn (
                            var (cont_res->name),
                            fetch(var (scj_res->name), lit_int (1))),
                        assgn (
                            var (iter_res->name),
                            materialize (
                                var (iter_res->name),
                                var (item_res->name))));

                    /* lookup the text-value of the resulting text nodes */
                    execute (
                        assgn (var (item_str->name),
                               mposjoin (
                                   mposjoin (
                                       var (item_res->name),
                                       var (cont_res->name),
                                       fetch (var (PF_MIL_VAR_WS),
                                              var (PF_MIL_VAR_PRE_PROP))),
                                   mposjoin (
                                       var (item_res->name),
                                       var (cont_res->name),
                                       fetch (var (PF_MIL_VAR_WS),
                                              var (PF_MIL_VAR_PRE_CONT))),
                                   fetch (var (PF_MIL_VAR_WS),
                                          var (PF_MIL_VAR_PROP_TEXT)))));

                    /* apply string-join aggregate */
                    execute (
                        assgn (var (str->name),
                               string_join (
                                   leftjoin (
                                       reverse (var (iter_res->name)),
                                       var (item_str->name)),
                                   project (var (iter->name), lit_str ("")))),
                        assgn (var (str->name),
                               tmark(var (str->name), lit_oid (0))));
                    /* (In the beginning of this rule we used the head values
                        as iter values. This allows to ignore the back-mapping
                        after the string-join operator (see rule
                        string_join (Rel, Rel)). */

                    unpin (iter, 1);
                    unpin (scj_res, 1);
                    unpin (iter_res, 1);
                    unpin (item_res, 1);
                    unpin (cont_res, 1);
                    unpin (item_str, 1);
                }   break;
                case (doc_qname):
                    /* look up the correct QName references */
                    fn_node_name (L(p), col, qname_id, qname_cont, false);
                    break;
                default:
                    PFoops (OOPS_FATAL,
                            "unexpected document column in doc_access (%i)",
                            p->sem.doc_access.doc_col);
            }
        }   break; /* fold) */

        /* Rel:      twig (Twig) */
        case 102: /* fold( */
        { /* top-down */
            unsigned int i;
            mvar_t *root_pre, *root_frag, *root_iter,
                   *mmu_res, *seqb, *newPre, *tmp;

            /* backup old twig state before traversing the children... */
            twig_state_t *old_twig_state = twig_state;

            /* ... and create a new one */
            twig_state = PFmalloc (sizeof (twig_state_t));
            twig_state->pre          = 0;
            twig_state->parent       = 0;
            twig_state->size         = 0;
            twig_state->level        = 0;
            twig_state->elem_vars    = PFarray (sizeof (mvar_t *), 10);
            twig_state->attr_vars    = PFarray (sizeof (mvar_t *), 10);
            twig_state->loop         = NULL;
            twig_state->elem_content = false;

            /* translate the child operators */
            reduce(kids[0], nts[0]);

            root_iter = new_var (p->refctr);
            root_pre  = new_var (p->refctr);
            root_frag = new_var (p->refctr);
            mmu_res   = new_var (1);
            seqb      = new_var (1);
            newPre    = new_var (1);

            /* the result of the twig construction will be stored
               in the variables root_iter, root_pre, and root_frag */
            env_add (p->env, p->sem.ii.iter, aat_nat, root_iter);
            env_add (p->env, p->sem.ii.item, aat_pre, root_pre);
            env_add (p->env, p->sem.ii.item, aat_frag, root_frag);

            /* FIXME: We cannot cope with a single content operator
               that provides only attribute nodes */

            /* merge all input node constructors
               (in the correct order -- the one stored
                in twig_state->elem_vars) */
            if (PFarray_last (twig_state->elem_vars) > 1) {
                mvar_t *mmu_input = new_var (1);

                /* create relation to hold all the input relations
                   for the merged_union operation */
                execute (
                    assgn (var (mmu_input->name),
                           seqbase (new (type (mty_void), type (mty_bat)),
                                    lit_oid (0))));

                /* fill in all input relations (in the correct order) */
                for (i = 0; i < PFarray_last (twig_state->elem_vars); i++) {
                    tmp = *(mvar_t **) PFarray_at (twig_state->elem_vars, i);
                    execute (bappend (var (mmu_input->name), var (tmp->name)));
                    unpin (tmp, 1);
                }

                /* apply merged union operation over multiple inputs */
                execute (
                    assgn (var (mmu_res->name),
                           multi_merged_union (var (mmu_input->name))));
                unpin (mmu_input, 1);

            } else {
                /* no merged_union needed in case we only have a single
                   constructor (with possibly multiple attributes) */
                assert (PFarray_last (twig_state->elem_vars) == 1);
                tmp = *(mvar_t **) PFarray_at (twig_state->elem_vars, 0);

                execute (assgn (var (mmu_res->name), var (tmp->name)));
                unpin (tmp, 1);
            }

            /* Generate the MIL code necessary for document, element,
               textnodes, comments, and processing-instructions */
            execute (

                /* get the offset for the first free node id:
                   seqb := oid (ws.fetch(PRE_SIZE).fetch(WS).count() +
                                ws.fetch(PRE_SIZE).fetch(WS).seqbase().int());
                */
                assgn (var (seqb->name),
                       cast (
                           type (mty_oid),
                           add (
                               count (
                                   fetch (
                                       fetch (
                                           var (PF_MIL_VAR_WS),
                                           var (PF_MIL_VAR_PRE_SIZE)),
                                       var (PF_MIL_VAR_WS_CONT))),
                               cast (
                                   type (mty_int),
                                   seqbase_lookup (
                                       fetch (
                                           fetch (
                                               var (PF_MIL_VAR_WS),
                                               var (PF_MIL_VAR_PRE_SIZE)),
                                           var (PF_MIL_VAR_WS_CONT))))))),
                /* create a column with the new pre numbers:
                   newPre := mmu_res.fetch(0).mark(seqb); */
                assgn (var (newPre->name),
                       mark (
                           fetch (var (mmu_res->name), lit_int (0)),
                           var (seqb->name))),


                /* fill the constructed nodes into the ws */

                /* size:
                   ws.fetch(PRE_SIZE).fetch(WS).append (mmu_res.fetch(2)); */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_SIZE)),
                             var (PF_MIL_VAR_WS_CONT)),
                         fetch (var (mmu_res->name), lit_int (2))),
                /* level:
                   ws.fetch(PRE_LEVEL).fetch(WS).append (mmu_res.fetch(3)); */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_LEVEL)),
                             var (PF_MIL_VAR_WS_CONT)),
                         fetch (var (mmu_res->name), lit_int (3))),
                /* kind:
                   ws.fetch(PRE_KIND).fetch(WS).append (mmu_res.fetch(4)); */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_KIND)),
                             var (PF_MIL_VAR_WS_CONT)),
                         fetch (var (mmu_res->name), lit_int (4))),
                /* prop:
                   ws.fetch(PRE_PROP).fetch(WS).append (mmu_res.fetch(5)); */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_PROP)),
                             var (PF_MIL_VAR_WS_CONT)),
                         fetch (var (mmu_res->name), lit_int (5))),
                /* cont:
                   ws.fetch(PRE_CONT).fetch(WS).append (mmu_res.fetch(6)); */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_CONT)),
                             var (PF_MIL_VAR_WS_CONT)),
                         fetch (var (mmu_res->name), lit_int (6))),
                /* pre_nid:
                   ws.fetch(PRE_NID).fetch(WS).append (newPre); */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_NID)),
                             var (PF_MIL_VAR_WS_CONT)),
                         var (newPre->name)),
                /* nid_rid:
                   ws.fetch(NID_RID).fetch(WS).append (newPre); */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_NID_RID)),
                             var (PF_MIL_VAR_WS_CONT)),
                         var (newPre->name)),

                /* select roots and fill environment */

                /* collect new pre values of the root nodes:
                   root_pre := mmu_res.fetch(1).reverse().mark(seqb).reverse()
                                      .ord_uselect(0@0).mark(0@0).reverse(); */
                assgn (var (root_pre->name),
                       reverse (
                           mark (
                               uselect (
                                   reverse (
                                       mark (
                                           reverse (
                                               fetch (
                                                   var (mmu_res->name),
                                                   lit_int (1))),
                                           var (seqb->name))),
                                   lit_oid (0)),
                               lit_oid (0)))),

                /* prepare new iter column:
                   root_iter := root_pre.leftjoin (mmu_res.fetch(0)
                                                          .reverse.mark(seqb)
                                                          .reverse()); */
                assgn (var (root_iter->name),
                       leftjoin (
                           var (root_pre->name),
                           reverse (
                               mark (
                                   reverse (
                                       fetch (
                                           var (mmu_res->name),
                                           lit_int (0))),
                                   var (seqb->name))))),
                /* prepare the new fragment column:
                   root_frag := root_pre.leftjoin (mmu_res.fetch(6)
                                                          .reverse.mark(seqb)
                                                          .reverse()); */
                assgn (var (root_frag->name),
                       leftjoin (
                           var (root_pre->name),
                           reverse (
                               mark (
                                   reverse (
                                       fetch (
                                           var (mmu_res->name),
                                           lit_int (6))),
                                   var (seqb->name))))),

                /* make the fragment boundaries known:
                   ws.fetch(FRAG_ROOT)
                     .fetch(WS)
                     .insert(root_pre.reverse().project(oid_nil).reverse()); */
                binsert (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_FRAG_ROOT)),
                             var (PF_MIL_VAR_WS_CONT)),
                         reverse (
                             project (
                                 reverse (var (root_pre->name)),
                                 lit_oid (0)))) );

            unpin (seqb, 1);

            /* map root attributes (dslink (iter, pre))
               and add them to the ws */
            if (PFarray_last (twig_state->attr_vars)) {
                PFmil_t *bodymilprog, *oldmilprog;
                mvar_t  *a_iter  = new_var (1);
                mvar_t  *a_pre   = new_var (1);
                mvar_t  *a_qn    = new_var (1);
                mvar_t  *a_val   = new_var (1);
                mvar_t  *a_cont  = new_var (1);
                mvar_t  *count   = new_var (1);
                mvar_t  *mapping = new_var (1);
                mvar_t  *sorting = new_var (1);

                /* first collect the overall size */
                execute (assgn (var (count->name), lit_int (0)));
                for (i = 0; i < PFarray_last (twig_state->attr_vars); i++) {
                    tmp = *(mvar_t **) PFarray_at (twig_state->attr_vars, i);
                    execute (assgn (var (count->name),
                                    add (var (count->name),
                                         count (var (tmp->name)))));
                }

                oldmilprog = milprog;
                /* start new milprog for the nesting:
                   'if (...) {...} else {}' */
                milprog = nop ();

                /* create relation to hold all the input relations
                   for the append operation */
                execute (
                    assgn (var (a_iter->name),
                           seqbase (new (type (mty_void), type (mty_oid)),
                                    lit_oid (0))),
                    assgn (var (a_pre->name),
                           seqbase (new (type (mty_void), type (mty_oid)),
                                    lit_oid (0))),
                    assgn (var (a_qn->name),
                           seqbase (new (type (mty_void), type (mty_oid)),
                                    lit_oid (0))),
                    assgn (var (a_val->name),
                           seqbase (new (type (mty_void), type (mty_oid)),
                                    lit_oid (0))),
                    assgn (var (a_cont->name),
                           seqbase (new (type (mty_void), type (mty_oid)),
                                    lit_oid (0))));

                /* add all possible root attributes
                   (references stored in twig_state->attr_vars) */
                for (i = 0; i < PFarray_last (twig_state->attr_vars); i++) {
                    tmp = *(mvar_t **) PFarray_at (twig_state->attr_vars, i);
                    execute (
                        bappend (var (a_iter->name),
                                 fetch (var (tmp->name), lit_int (0))),
                        bappend (var (a_pre->name),
                                 fetch (var (tmp->name), lit_int (1))),
                        bappend (var (a_qn->name),
                                 fetch (var (tmp->name), lit_int (2))),
                        bappend (var (a_val->name),
                                 fetch (var (tmp->name), lit_int (3))),
                        bappend (var (a_cont->name),
                                 fetch (var (tmp->name), lit_int (4))));
                    unpin (tmp, 1);
                }

                execute (
                    /* collect the references to the parent element nodes:
                       mapping := ds_link (a_iter, mmu_res.fetch(0),
                                           a_pre, mmu_res.fetch(1)); */
                    assgn (var (mapping->name),
                           mc_intersect (
                               arg (
                                   arg (
                                       var (a_iter->name),
                                       fetch (var (mmu_res->name),
                                              lit_int (0))),
                                   arg (
                                       var (a_pre->name),
                                       fetch (var (mmu_res->name),
                                              lit_int (1)))))),

                    /* get the pre values and align them
                       with the attribute values:
                       mapping := a_iter.mirror()
                                        .leftjoin(mapping.join(newPre)); */
                    assgn (var (mapping->name),
                           leftjoin (mirror (var (a_iter->name)),
                                     join (var (mapping->name),
                                           var (newPre->name)))),

                    /* fill the constructed attributes into the ws */

                    /* own:
                       ws.fetch(ATTR_OWN).fetch(WS).append(mapping); */
                    bappend (fetch (
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_OWN)),
                                 var (PF_MIL_VAR_WS_CONT)),
                             var (mapping->name)),
                    /* qn:
                       ws.fetch(ATTR_QN).fetch(WS).append(a_qn); */
                    bappend (fetch (
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_QN)),
                                 var (PF_MIL_VAR_WS_CONT)),
                             var (a_qn->name)),
                    /* prop:
                       ws.fetch(ATTR_PROP).fetch(WS).append(a_val); */
                    bappend (fetch (
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_PROP)),
                                 var (PF_MIL_VAR_WS_CONT)),
                             var (a_val->name)),
                    /* cont:
                       ws.fetch(ATTR_CONT).fetch(WS).append(a_cont); */
                    bappend (fetch (
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_CONT)),
                                 var (PF_MIL_VAR_WS_CONT)),
                             var (a_cont->name)));
                unpin (mapping, 1);

                /* check for duplicate attributes and generate
                   a runtime error if duplicates have been found. */
                execute (
                    /* sorting := a_iter.reverse().sort().reverse(); */
                    assgn (
                        var (sorting->name),
                        reverse (sort (reverse (var (a_iter->name)), DIR_ASC))),
                    /* sorting := sorting.CTrefine (a_pre); */
                    assgn (
                        var (sorting->name),
                        ctrefine (
                            var (sorting->name),
                            var (a_pre->name),
                            DIR_ASC)),
                    /* sorting := sorting.CTrefine (
                                              mposjoin (a_qn,
                                                        a_cont,
                                                        ws.fetch(QN_URI))); */
                    assgn (
                        var (sorting->name),
                        ctrefine (
                            var (sorting->name),
                            mposjoin (
                                var (a_qn->name),
                                var (a_cont->name),
                                fetch (
                                    var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_QN_URI))),
                            DIR_ASC)),
                    /* sorting := sorting.CTrefine (
                                              mposjoin (a_qn,
                                                        a_cont,
                                                        ws.fetch(QN_LOC))); */
                    assgn (
                        var (sorting->name),
                        ctrefine (
                            var (sorting->name),
                            mposjoin (
                                var (a_qn->name),
                                var (a_cont->name),
                                fetch (
                                    var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_QN_LOC))),
                            DIR_ASC)),
                    /* if (sorting.count() != sorting.tunique().count())
                       { ERROR ("..."); } else {} */
                    if_ (not (eq (count (var (sorting->name)),
                              count (tunique (var (sorting->name))))),
                         error (lit_str ("err:XQDY0025: attribute names are not"
                                         " unique in constructed element.")),
                         nop ()));
                unpin (sorting, 1);

                unpin (a_iter, 1);
                unpin (a_pre, 1);
                unpin (a_qn, 1);
                unpin (a_val, 1);
                unpin (a_cont, 1);

                /* store nested MIL code */
                bodymilprog = milprog;
                /* activate old mil program */
                milprog = oldmilprog;

                /* fill in the MIL code for root attributes:
                   if (count > 0) { ... } else { } */
                execute (
                    if_ (gt (var (count->name), lit_int (0)),
                    /* then */ bodymilprog,
                    /* else */ nop ()));

                unpin (count, 1);
            }

            /* collect and update content attributes (mvaljoin) */
            if (twig_state->elem_content) {
                mvar_t *oldPre = new_var (1);
                mvar_t *oldCont=new_var (1);
                mvar_t *oldNid = new_var (1);
                mvar_t *attr = new_var (1);
                mvar_t *item = new_var (1);
                mvar_t *cont = new_var (1);

                execute (
                    /* lookup attribute NIDs for all subtree nodes:
                       oldPre  := select (mmu_res.fetch (7), oid_nil, oid_nil);
                       # align all additional information to the selected list
                       # (otherwise the head values are not in sync anymore)
                       newPre  := oldPre.hmark(0@0).leftfetchjoin(newPre);
                       oldCont := oldPre.hmark(0@0).leftfetchjoin(mmu_res.fetch (8));
                       oldNid  := mposjoin (oldPre.tmark(0@0), oldCont, ws.fetch (PRE_NID));
                       attr    := get_attr_own (ws, oldNid, oldCont);
                     */
                    assgn (
                        var (oldPre->name),
                        select2 (fetch (var (mmu_res->name), lit_int (7)),
                                 cast (type (mty_oid), nil ()),
                                 cast (type (mty_oid), nil ()))),
                    assgn (
                        var (newPre->name),
                        leftfetchjoin (hmark (var (oldPre->name), lit_oid (0)),
                                       var (newPre->name))),
                    assgn (
                        var (oldCont->name),
                        leftfetchjoin (hmark (var (oldPre->name), lit_oid (0)),
                                       fetch (var (mmu_res->name), lit_int (8)))),
                    assgn (
                        var (oldNid->name),
                        mposjoin (tmark (var (oldPre->name), lit_oid (0)),
                                  var (oldCont->name),
                                  fetch (var (PF_MIL_VAR_WS),
                                         var (PF_MIL_VAR_PRE_NID)))),
                    assgn (
                        var (attr->name),
                        get_attr_own (var (PF_MIL_VAR_WS),
                                      var (oldNid->name),
                                      var (oldCont->name))),

                    /* align the resulting attribute ids and the fragment
                       information:
                       item := attr.reverse().mark(0@0).reverse();
                       cont := attr.mark(0@0).reverse()
                                   .leftjoin(oldCont); */
                    assgn (var (item->name),
                           reverse (
                               mark (
                                   reverse (
                                       var (attr->name)),
                                   lit_oid (0)))),
                    assgn (var (cont->name),
                           leftjoin (
                               reverse (
                                   mark (
                                       var (attr->name),
                                       lit_oid (0))),
                               var (oldCont->name))),

                    /* fill the constructed attributes into the ws */

                    /* own:
                       ws.fetch(ATTR_OWN).fetch(WS)
                         .append(attr.mark(0@0).reverse().leftjoin(newPre)); */
                    bappend (fetch (
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_OWN)),
                                 var (PF_MIL_VAR_WS_CONT)),
                             leftjoin (
                                 reverse (
                                     mark (
                                         var (attr->name),
                                         lit_oid (0))),
                                 var (newPre->name))),
                    /* qn:
                       ws.fetch(ATTR_QN).fetch(WS)
                         .append(mposjoin(item,cont,ws.fetch(ATTR_QN))); */
                    bappend (fetch (
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_QN)),
                                 var (PF_MIL_VAR_WS_CONT)),
                             mposjoin (
                                 var (item->name),
                                 var (cont->name),
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_QN)))),
                    /* prop:
                       ws.fetch(ATTR_PROP).fetch(WS)
                         .append(mposjoin(item,cont,ws.fetch(ATTR_PROP))); */
                    bappend (fetch (
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_PROP)),
                                 var (PF_MIL_VAR_WS_CONT)),
                             mposjoin (
                                 var (item->name),
                                 var (cont->name),
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_PROP)))),
                    /* cont:
                       ws.fetch(ATTR_CONT).fetch(WS)
                         .append(mposjoin(item,cont,ws.fetch(ATTR_CONT))); */
                    bappend (fetch (
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_CONT)),
                                 var (PF_MIL_VAR_WS_CONT)),
                             mposjoin (
                                 var (item->name),
                                 var (cont->name),
                                 fetch (
                                     var (PF_MIL_VAR_WS),
                                     var (PF_MIL_VAR_ATTR_CONT)))),
                    );
                unpin (oldPre, 1);
                unpin (oldCont, 1);
                unpin (oldNid, 1);
                unpin (attr, 1);
                unpin (item, 1);
                unpin (cont, 1);
            }

            unpin (mmu_res, 1);
            unpin (newPre, 1);

            /* reset old twig state */
            twig_state = old_twig_state;
        }
            break; /* fold) */

        /* Rel:      twig (attribute (Rel)) */
        case 103: /* fold( */
            assert (type_of (LL(p), L(p)->sem.iter_item1_item2.iter)
                    == aat_nat);
            assert (type_of (LL(p), L(p)->sem.iter_item1_item2.item1)
                    == aat_qname);
            assert (type_of (LL(p), L(p)->sem.iter_item1_item2.item2)
                    == aat_str);
        {
            PFalg_col_t iter_col  = L(p)->sem.iter_item1_item2.iter,
                        qn_col    = L(p)->sem.iter_item1_item2.item1,
                        val_col   = L(p)->sem.iter_item1_item2.item2;
            mvar_t     *seqb      = new_var (1),
                       *qn_id     = new_var (1),
                       *root_pre  = new_var (p->refctr),
                       *root_attr = new_var (p->refctr),
                       *root_frag = new_var (p->refctr),
                       *iter      = env_mvar (LL(p)->env, iter_col, aat_nat);
            /* Lookup the input value column ... */
            PFmil_t    *val       = VAR (LL(p)->env, val_col, aat_str);

            /* and the QName columns. (Furthermore ensure that the QNames
               are stored in the WS container and copy them if they reside
               in a different container.) */
            copy_QName (
                env_mvar (LL(p)->env, qn_col, aat_qname_id),
                env_mvar (LL(p)->env, qn_col, aat_qname_cont),
                qn_id);

            execute (
                /* get first free pre value */
                assgn (var (seqb->name),
                       cast (
                           type (mty_oid),
                           add (
                               count (
                                   fetch (
                                       fetch (
                                           var (PF_MIL_VAR_WS),
                                           var (PF_MIL_VAR_ATTR_OWN)),
                                       var (PF_MIL_VAR_WS_CONT))),
                               cast (
                                   type (mty_int),
                                   seqbase_lookup (
                                       fetch (
                                           fetch (
                                               var (PF_MIL_VAR_WS),
                                               var (PF_MIL_VAR_ATTR_OWN)),
                                           var (PF_MIL_VAR_WS_CONT))))))),
                /* own */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_ATTR_OWN)),
                             var (PF_MIL_VAR_WS_CONT)),
                         project (val, cast (type (mty_oid), nil ()))),
                /* qn */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_ATTR_QN)),
                             var (PF_MIL_VAR_WS_CONT)),
                         var (qn_id->name)),
                /* prop */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_ATTR_PROP)),
                             var (PF_MIL_VAR_WS_CONT)),
                         add_content (val,
                                      var (PF_MIL_VAR_WS),
                                      var (PF_MIL_VAR_PROP_VAL))),
                /* cont */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_ATTR_CONT)),
                             var (PF_MIL_VAR_WS_CONT)),
                         project (val, var (PF_MIL_VAR_WS_CONT))),

                /* new root pre values */
                assgn (var (root_pre->name),
                       project (val, cast (type (mty_oid), nil ()))),
                /* new root attr values */
                assgn (var (root_attr->name),
                       mark (val, var (seqb->name))),
                /* fragment information */
                assgn (var (root_frag->name),
                       project (val, var (PF_MIL_VAR_WS_CONT))));

            unpin (seqb, 1);
            unpin (qn_id, 1);

            pin (iter, p->refctr);
            env_add (p->env, p->sem.ii.iter, aat_nat, iter);
            env_add (p->env, p->sem.ii.item, aat_pre, root_pre);
            env_add (p->env, p->sem.ii.item, aat_attr, root_attr);
            env_add (p->env, p->sem.ii.item, aat_frag, root_frag);
        }
            break; /* fold) */

        /* Rel:      twig (textnode (Rel)) */
        case 104: /* fold( */
            assert (type_of (LL(p), L(p)->sem.ii.iter) == aat_nat);
            assert (type_of (LL(p), L(p)->sem.ii.item) == aat_str);
        {
            mvar_t *seqb      = new_var (1),
                   *root_pre  = new_var (p->refctr),
                   *root_frag = new_var (p->refctr),
                   *iter      = new_var (p->refctr),
                   *item      = new_var (1),
                   *map       = new_var (1);

            /* prune all empty textnodes */
            execute (
                assgn (var (map->name),
                       hmark (
                           select_ (
                               PFmil_mne (VAR (LL(p)->env,
                                               L(p)->sem.ii.item,
                                               aat_str),
                                          lit_str ("")),
                               lit_bit (true)),
                           lit_oid (0))),
                assgn (var (iter->name),
                       leftjoin (var (map->name),
                                 VAR (LL(p)->env,
                                      L(p)->sem.ii.iter,
                                      aat_nat))),
                assgn (var (item->name),
                       leftjoin (var (map->name),
                                 VAR (LL(p)->env,
                                      L(p)->sem.ii.item,
                                      aat_str))));
            unpin (map, 1);

            execute (
                /* get first free pre value */
                assgn (var (seqb->name),
                       cast (
                           type (mty_oid),
                           add (
                               count (
                                   fetch (
                                       fetch (
                                           var (PF_MIL_VAR_WS),
                                           var (PF_MIL_VAR_PRE_SIZE)),
                                       var (PF_MIL_VAR_WS_CONT))),
                               cast (
                                   type (mty_int),
                                   seqbase_lookup (
                                       fetch (
                                           fetch (
                                               var (PF_MIL_VAR_WS),
                                               var (PF_MIL_VAR_PRE_SIZE)),
                                           var (PF_MIL_VAR_WS_CONT))))))),
                /* size */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_SIZE)),
                             var (PF_MIL_VAR_WS_CONT)),
                         project (var (item->name), lit_int (0))),
                /* level */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_LEVEL)),
                             var (PF_MIL_VAR_WS_CONT)),
                         project (var (item->name),
                                  cast (type (mty_chr), lit_int (0)))),
                /* kind */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_KIND)),
                             var (PF_MIL_VAR_WS_CONT)),
                         project (var (item->name),
                                  var (PF_MIL_VAR_KIND_TEXT))),
                /* prop */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_PROP)),
                             var (PF_MIL_VAR_WS_CONT)),
                         add_content (var (item->name),
                                      var (PF_MIL_VAR_WS),
                                      var (PF_MIL_VAR_PROP_TEXT))),
                /* cont */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_CONT)),
                             var (PF_MIL_VAR_WS_CONT)),
                         project (var (item->name),
                                  var (PF_MIL_VAR_WS_CONT))),
                /* pre_nid */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_PRE_NID)),
                             var (PF_MIL_VAR_WS_CONT)),
                         mark (var (item->name), var (seqb->name))),
                /* nid_rid */
                bappend (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_NID_RID)),
                             var (PF_MIL_VAR_WS_CONT)),
                         mark (var (item->name), var (seqb->name))),

                /* new root pre values */
                assgn (var (root_pre->name),
                       mark (var (item->name), var (seqb->name))),
                /* fragment information */
                assgn (var (root_frag->name),
                       project (var (item->name), var (PF_MIL_VAR_WS_CONT))),

                /* make the fragment boundaries known */
                binsert (fetch (
                             fetch (
                                 var (PF_MIL_VAR_WS),
                                 var (PF_MIL_VAR_FRAG_ROOT)),
                             var (PF_MIL_VAR_WS_CONT)),
                         reverse (
                             project (
                                 reverse (var (root_pre->name)),
                                 lit_oid (0)))));

            unpin (seqb, 1);
            unpin (item, 1);
            env_add (p->env, p->sem.ii.iter, aat_nat,  iter);
            env_add (p->env, p->sem.ii.item, aat_pre,  root_pre);
            env_add (p->env, p->sem.ii.item, aat_frag, root_frag);
        }
            break; /* fold) */

        /* Fcns:     fcns (Twig, Fcns) */
        case 105: /* fold( */
        { /* top-down */

            /* traverse the DAG in sequence order */
            reduce(kids[0], nts[0]);
            reduce(kids[1], nts[1]);

            /* propagate the size information of the content
               operators underneath */
            if (env_count (L(p)->env) &&
                env_count (R(p)->env)) {
                mvar_t *l = env_at (L(p)->env, 0).mvar;
                mvar_t *r = env_at (R(p)->env, 0).mvar;
                v = new_var (1);

                assert (env_count (L(p)->env) == 1);
                assert (env_count (R(p)->env) == 1);

                execute (
                    assgn (var (v->name),
                           madd (var (l->name), var (r->name))));

                env_add (p->env,
                         env_at (L(p)->env, 0).col,
                         env_at (L(p)->env, 0).ty,
                         v);

            } else if (env_count (L(p)->env)) {

                assert (env_count (L(p)->env) == 1);
                env_add (p->env,
                         env_at (L(p)->env, 0).col,
                         env_at (L(p)->env, 0).ty,
                         env_at (L(p)->env, 0).mvar);
                pin (env_at (p->env, 0).mvar, 1);

            } else if (env_count (R(p)->env)) {

                assert (env_count (R(p)->env) == 1);
                env_add (p->env,
                         env_at (R(p)->env, 0).col,
                         env_at (R(p)->env, 0).ty,
                         env_at (R(p)->env, 0).mvar);
                pin (env_at (p->env, 0).mvar, 1);
            }
        }
            break; /* fold) */

        /* Fcns:     fcns (Twig, nil) */
        case 106: /* fold( */
            /* propagate the size information of the content
               operators underneath */
            if (env_count (L(p)->env)) {
                assert (env_count (L(p)->env) == 1);
                env_add (p->env,
                         env_at (L(p)->env, 0).col,
                         env_at (L(p)->env, 0).ty,
                         env_at (L(p)->env, 0).mvar);
                pin (env_at (p->env, 0).mvar, 1);
            }
            break; /* fold) */

        /* Twig:     docnode (Rel, nil) */
        case 107: /* fold( */
            assert (type_of (L(p), p->sem.ii.iter) == aat_nat);
        {
            PFmil_t *iter = VAR (L(p)->env, p->sem.ii.iter, aat_nat);
            v = new_var (1);

            execute (
                assgn (var (v->name),
                       seqbase (new (type (mty_void), type (mty_bat)),
                                lit_oid (0))),
                /* iter */
                bappend (var (v->name), iter),
                /* pre */
                bappend (var (v->name),
                         project (iter, lit_oid (twig_state->pre))),
                /* size */
                bappend (var (v->name),
                         project (iter, lit_int (0))),
                /* level */
                bappend (var (v->name),
                         project (iter,
                                  cast (type (mty_chr),
                                        lit_int (twig_state->level)))),
                /* kind */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_KIND_DOC))),
                /* prop */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))),
                /* cont */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_WS_CONT))),
                /* old_pre */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))),
                /* old_cont */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))));

            *(mvar_t **) PFarray_add (twig_state->elem_vars) = v;
            twig_state->pre++;
            twig_state->size++;
        }
            break; /* fold) */

        /* Twig:     docnode (Rel, Fcns) */
        case 108: /* fold( */
            assert (type_of (L(p), p->sem.ii.iter) == aat_nat);
        { /* top-down */
            unsigned int old_twig_state_pre,
                         old_twig_state_parent,
                         old_twig_state_size;
            mvar_t  *size = new_var (1);
            PFmil_t *iter;
            v = new_var (1);

            /* translate the qnames */
            reduce(kids[0], nts[0]);

            iter = VAR (L(p)->env, p->sem.ii.iter, aat_nat);

            /* add the element representation into the ordered
               twig state list to ensure that the constructed node
               appears before all children */
            *(mvar_t **) PFarray_add (twig_state->elem_vars) = v;

            /* store the twig state information
               and prepare for the translation of the children */
            old_twig_state_pre    = twig_state->pre;
            old_twig_state_parent = twig_state->parent;
            old_twig_state_size   = twig_state->size;

            twig_state->parent = twig_state->pre;
            twig_state->pre++;
            twig_state->size = 0;
            twig_state->level++;
            /* Use the iter column of the root twig operator
               as loop relation for the content operator.

               NOTE: We have to use the root twig operator
               (the one the content operator is nested in)
               as otherwise the variable stored in twig_state->loop
               might not be pinned anymore before the content operator
               can use it. */
            if (!twig_state->loop)
                twig_state->loop = iter;

            /* translate the children */
            reduce(kids[1], nts[1]);

            /* reset the level information */
            twig_state->level--;

            /* calculate the sizes */
            if (env_count (R(p)->env) && twig_state->size) {
                mvar_t *content_size = env_at (R(p)->env, 0).mvar;

                assert (env_count (R(p)->env) == 1);

                execute (
                    assgn (var (size->name),
                           madd (var (content_size->name),
                                 lit_int (twig_state->size))));

                env_add (p->env,
                         env_at (R(p)->env, 0).col,
                         env_at (R(p)->env, 0).ty,
                         env_at (R(p)->env, 0).mvar);
                pin (env_at (p->env, 0).mvar, 1);

            } else if (env_count (R(p)->env)) {
                mvar_t *content_size = env_at (R(p)->env, 0).mvar;

                assert (env_count (R(p)->env) == 1);

                execute (
                    assgn (var (size->name),
                           var (content_size->name)));

                env_add (p->env,
                         env_at (R(p)->env, 0).col,
                         env_at (R(p)->env, 0).ty,
                         env_at (R(p)->env, 0).mvar);
                pin (env_at (p->env, 0).mvar, 1);

            } else {
                execute (
                    assgn (var (size->name),
                           project (iter, lit_int (twig_state->size))));
            }

            execute (
                assgn (var (v->name),
                       seqbase (new (type (mty_void), type (mty_bat)),
                                lit_oid (0))),
                /* iter */
                bappend (var (v->name), iter),
                /* pre */
                bappend (var (v->name),
                         project (iter, lit_oid (old_twig_state_pre))),
                /* size */
                bappend (var (v->name), var (size->name)),
                /* level */
                bappend (var (v->name),
                         project (iter,
                                  cast (type (mty_chr),
                                        lit_int (twig_state->level)))),
                /* kind */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_KIND_DOC))),
                /* prop */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))),
                /* cont */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_WS_CONT))),
                /* old_pre */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))),
                /* old_cont */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))));

            unpin (size, 1);

            twig_state->size = twig_state->size + old_twig_state_size + 1;
            twig_state->parent = old_twig_state_parent;
        }
            break; /* fold) */

        /* Twig:     element (Rel, nil) */
        case 109: /* fold( */
            assert (type_of (L(p), p->sem.ii.iter) == aat_nat);
            assert (type_of (L(p), p->sem.ii.item) == aat_qname);
        {
            mvar_t  *qn_id = new_var (1);
            PFmil_t *iter  = VAR (L(p)->env, p->sem.ii.iter, aat_nat);

            v = new_var (1);

            /* Ensure that the QNames are stored in the WS container
               and copy them if they reside in a different container. */
            copy_QName (
                env_mvar (L(p)->env, p->sem.ii.item, aat_qname_id),
                env_mvar (L(p)->env, p->sem.ii.item, aat_qname_cont),
                qn_id);

            execute (
                assgn (var (v->name),
                       seqbase (new (type (mty_void), type (mty_bat)),
                                lit_oid (0))),
                /* iter */
                bappend (var (v->name), iter),
                /* pre */
                bappend (var (v->name),
                         project (iter, lit_oid (twig_state->pre))),
                /* size */
                bappend (var (v->name),
                         project (iter, lit_int (0))),
                /* level */
                bappend (var (v->name),
                         project (iter,
                                  cast (type (mty_chr),
                                        lit_int (twig_state->level)))),
                /* kind */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_KIND_ELEM))),
                /* prop */
                bappend (var (v->name), var (qn_id->name)),
                /* cont */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_WS_CONT))),
                /* old_pre */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))),
                /* old_cont */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))));

            unpin (qn_id, 1);

            *(mvar_t **) PFarray_add (twig_state->elem_vars) = v;
            twig_state->pre++;
            twig_state->size++;
        }
            break; /* fold) */

        /* Twig:     element (Rel, Fcns) */
        case  110: /* fold( */
            assert (type_of (L(p), p->sem.ii.iter) == aat_nat);
            assert (type_of (L(p), p->sem.ii.item) == aat_qname);
        { /* top-down */
            unsigned int old_twig_state_pre,
                         old_twig_state_parent,
                         old_twig_state_size;
            mvar_t  *qn_id = new_var (1),
                    *size  = new_var (1);
            PFmil_t *iter;

            v = new_var (1);

            /* translate the qnames */
            reduce(kids[0], nts[0]);

            iter = VAR (L(p)->env, p->sem.ii.iter, aat_nat);

            /* Ensure that the QNames are stored in the WS container
               and copy them if they reside in a different container. */
            copy_QName (
                env_mvar (L(p)->env, p->sem.ii.item, aat_qname_id),
                env_mvar (L(p)->env, p->sem.ii.item, aat_qname_cont),
                qn_id);

            /* add the element representation into the ordered
               twig state list to ensure that the constructed node
               appears before all children */
            *(mvar_t **) PFarray_add (twig_state->elem_vars) = v;

            /* store the twig state information
               and prepare for the translation of the children */
            old_twig_state_pre    = twig_state->pre;
            old_twig_state_parent = twig_state->parent;
            old_twig_state_size   = twig_state->size;

            twig_state->parent = twig_state->pre;
            twig_state->pre++;
            twig_state->size = 0;
            twig_state->level++;
            /* Use the iter column of the root twig operator
               as loop relation for the content operator.

               NOTE: We have to use the root twig operator
               (the one the content operator is nested in)
               as otherwise the variable stored in twig_state->loop
               might not be pinned anymore before the content operator
               can use it. */
            if (!twig_state->loop)
                twig_state->loop = iter;

            /* translate the children */
            reduce(kids[1], nts[1]);

            /* reset the level information */
            twig_state->level--;

            /* calculate the sizes */
            if (env_count (R(p)->env) && twig_state->size) {
                mvar_t *content_size = env_at (R(p)->env, 0).mvar;

                assert (env_count (R(p)->env) == 1);

                execute (
                    assgn (var (size->name),
                           madd (var (content_size->name),
                                 lit_int (twig_state->size))));

                env_add (p->env,
                         env_at (R(p)->env, 0).col,
                         env_at (R(p)->env, 0).ty,
                         env_at (R(p)->env, 0).mvar);
                pin (env_at (p->env, 0).mvar, 1);

            } else if (env_count (R(p)->env)) {
                mvar_t *content_size = env_at (R(p)->env, 0).mvar;

                assert (env_count (R(p)->env) == 1);

                execute (
                    assgn (var (size->name),
                           var (content_size->name)));

                env_add (p->env,
                         env_at (R(p)->env, 0).col,
                         env_at (R(p)->env, 0).ty,
                         env_at (R(p)->env, 0).mvar);
                pin (env_at (p->env, 0).mvar, 1);

            } else {
                execute (
                    assgn (var (size->name),
                           project (iter, lit_int (twig_state->size))));
            }

            execute (
                assgn (var (v->name),
                       seqbase (new (type (mty_void), type (mty_bat)),
                                lit_oid (0))),
                /* iter */
                bappend (var (v->name), iter),
                /* pre */
                bappend (var (v->name),
                         project (iter, lit_oid (old_twig_state_pre))),
                /* size */
                bappend (var (v->name), var (size->name)),
                /* level */
                bappend (var (v->name),
                         project (iter,
                                  cast (type (mty_chr),
                                        lit_int (twig_state->level)))),
                /* kind */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_KIND_ELEM))),
                /* prop */
                bappend (var (v->name), var (qn_id->name)),
                /* cont */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_WS_CONT))),
                /* old_pre */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))),
                /* old_cont */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))));

            unpin (qn_id, 1);
            unpin (size, 1);

            twig_state->size = twig_state->size + old_twig_state_size + 1;
            twig_state->parent = old_twig_state_parent;
        }
            break; /* fold) */

        /* Twig:     attribute (Rel) */
        case 111: /* fold( */
            assert (type_of (L(p), p->sem.iter_item1_item2.iter) == aat_nat);
            assert (type_of (L(p), p->sem.iter_item1_item2.item1) == aat_qname);
            assert (type_of (L(p), p->sem.iter_item1_item2.item2) == aat_str);
        {
            mvar_t     *qn_id  = new_var (1),
                       *prop   = new_var (1);
            PFmil_t    *iter   = VAR (L(p)->env,
                                      p->sem.iter_item1_item2.iter,
                                      aat_nat);
            PFalg_col_t qn_col = p->sem.iter_item1_item2.item1;
            PFmil_t    *val    = VAR (L(p)->env,
                                      p->sem.iter_item1_item2.item2,
                                      aat_str);

            v = new_var (1);

            /* Ensure that the QNames are stored in the WS container
               and copy them if they reside in a different container. */
            copy_QName (
                env_mvar (L(p)->env, qn_col, aat_qname_id),
                env_mvar (L(p)->env, qn_col, aat_qname_cont),
                qn_id);

            execute (
                assgn (var (prop->name),
                       add_content (val,
                                    var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_PROP_VAL))),
                assgn (var (v->name),
                       seqbase (new (type (mty_void), type (mty_bat)),
                                lit_oid (0))),
                /* iter */
                bappend (var (v->name), iter),
                /* pre (parent) */
                bappend (var (v->name),
                         project (iter, lit_oid (twig_state->parent))),
                /* qname */
                bappend (var (v->name), var (qn_id->name)),
                /* value */
                bappend (var (v->name), var (prop->name)),
                /* cont */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_WS_CONT))));

            unpin (qn_id, 1);
            unpin (prop, 1);

            *(mvar_t **) PFarray_add (twig_state->attr_vars) = v;
        }
            break; /* fold) */

        /* Twig:     textnode (Rel) */
        case 112: /* fold( */
            assert (type_of (L(p), p->sem.ii.iter) == aat_nat);
            assert (type_of (L(p), p->sem.ii.item) == aat_str);
        {
            mvar_t  *prop = new_var (1),
                    *iter = new_var (1),
                    *item = new_var (1);

            v = new_var (1);

            /* check for constant non-empty string */
            if (PFprop_const (p->prop, p->sem.ii.item) &&
                strcmp (PFprop_const_val (p->prop, p->sem.ii.item).val.str, "")) {
                execute (
                    assgn (var (iter->name),
                           VAR (L(p)->env, p->sem.ii.iter, aat_nat)),
                    assgn (var (item->name),
                           VAR (L(p)->env, p->sem.ii.item, aat_str)));

                /* stable size + 1 */
                twig_state->size++;
            }
            /* we need to prune empty textnodes and calculate the
               resulting sizes for the consuming parents */
            else {
                mvar_t *bool_list = new_var (1),
                       *map       = new_var (1),
                       *size      = new_var (1);
                
                /* prune all empty textnodes */
                execute (
                    assgn (var (bool_list->name),
                           PFmil_mne (VAR (L(p)->env,
                                           p->sem.ii.item,
                                           aat_str),
                                      lit_str (""))),
                    assgn (var (map->name),
                           hmark (
                               select_ (var (bool_list->name),
                                        lit_bit (true)),
                               lit_oid (0))),
                    assgn (var (iter->name),
                           leftjoin (var (map->name),
                                     VAR (L(p)->env,
                                          p->sem.ii.iter,
                                          aat_nat))),
                    assgn (var (item->name),
                           leftjoin (var (map->name),
                                     VAR (L(p)->env,
                                          p->sem.ii.item,
                                          aat_str))));
                unpin (map, 1);

                assert (twig_state->loop);

                /* calculate the sizes and map them to the head
                   of the loop relation */
                execute (
                    assgn (var (size->name),
                           leftjoin (
                               twig_state->loop,
                               leftjoin (
                                   reverse (VAR (L(p)->env,
                                                 p->sem.ii.iter,
                                                 aat_nat)),
                                   mcast (type (mty_int),
                                          var (bool_list->name))))));
                unpin (bool_list, 1);
                
                /* add the correct sizes to the variable environment */
                env_add (p->env, col_NULL, aat_int, size);
            }
            
            execute (
                assgn (var (prop->name),
                       add_content (var (item->name),
                                    var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_PROP_TEXT))),
                assgn (var (v->name),
                       seqbase (new (type (mty_void), type (mty_bat)),
                                lit_oid (0))),
                /* iter */
                bappend (var (v->name), var (iter->name)),
                /* pre */
                bappend (var (v->name),
                         project (var (iter->name),
                                  lit_oid (twig_state->pre))),
                /* size */
                bappend (var (v->name),
                         project (var (iter->name), lit_int (0))),
                /* level */
                bappend (var (v->name),
                         project (var (iter->name),
                                  cast (type (mty_chr),
                                        lit_int (twig_state->level)))),
                /* kind */
                bappend (var (v->name),
                         project (var (iter->name),
                                  var (PF_MIL_VAR_KIND_TEXT))),
                /* prop */
                bappend (var (v->name), var (prop->name)),
                /* cont */
                bappend (var (v->name),
                         project (var (iter->name),
                                  var (PF_MIL_VAR_WS_CONT))),
                /* old_pre */
                bappend (var (v->name),
                         project (var (iter->name),
                                  cast (type (mty_oid), nil ()))),
                /* old_cont */
                bappend (var (v->name),
                         project (var (iter->name),
                                  cast (type (mty_oid), nil ()))));

            unpin (iter, 1);
            unpin (item, 1);
            unpin (prop, 1);

            *(mvar_t **) PFarray_add (twig_state->elem_vars) = v;
            twig_state->pre++;
        }
            break; /* fold) */

        /* Twig:     comment (Rel) */
        case 113: /* fold( */
            assert (type_of (L(p), p->sem.ii.iter) == aat_nat);
            assert (type_of (L(p), p->sem.ii.item) == aat_str);
        {
            mvar_t  *prop = new_var (1);
            PFmil_t *iter = VAR (L(p)->env, p->sem.ii.iter, aat_nat);
            PFmil_t *item = VAR (L(p)->env, p->sem.ii.item, aat_str);
            v = new_var (1);

            execute (
                assgn (var (prop->name),
                       add_content (item,
                                    var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_PROP_COM))),
                assgn (var (v->name),
                       seqbase (new (type (mty_void), type (mty_bat)),
                                lit_oid (0))),
                /* iter */
                bappend (var (v->name), iter),
                /* pre */
                bappend (var (v->name),
                         project (iter, lit_oid (twig_state->pre))),
                /* size */
                bappend (var (v->name),
                         project (iter, lit_int (0))),
                /* level */
                bappend (var (v->name),
                         project (iter,
                                  cast (type (mty_chr),
                                        lit_int (twig_state->level)))),
                /* kind */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_KIND_COM))),
                /* prop */
                bappend (var (v->name), var (prop->name)),
                /* cont */
                bappend (var (v->name),
                         project (iter, var (PF_MIL_VAR_WS_CONT))),
                /* old_pre */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))),
                /* old_cont */
                bappend (var (v->name),
                         project (iter, cast (type (mty_oid), nil ()))));

            unpin (prop, 1);

            *(mvar_t **) PFarray_add (twig_state->elem_vars) = v;
            twig_state->pre++;
            twig_state->size++;
        }
            break; /* fold) */

        /* Twig:     processi (Rel) */
        case 114: /* fold( */
            assert (!"not implemented yet");
            break; /* fold) */

        /* Twig:     content (Rel) */
        case 115:
        /* Twig:     slim_content (Rel) */
        case 116: /* fold( */
            /* ignore content if it contains an error */
            if (type_of (L(p), p->sem.ii.item) == aat_error)
                break;
            
            assert (type_of (L(p), p->sem.ii.iter) == aat_nat);
            assert (!(type_of (L(p), p->sem.ii.item) & ~aat_node));
        {
            PFalg_simple_type_t item_ty    = type_of (L(p), p->sem.ii.item);
            mvar_t             *a_iter     = NULL,
                               *a_item     = NULL,
                               *a_cont     = NULL,
                               *p_iter     = NULL,
                               *p_item     = NULL,
                               *p_cont     = NULL;
            bool                treat_attr = false,
                                treat_pre  = false;

            /* based on the item type treat only attributes or other nodes */
            if (item_ty == aat_pnode) {
                treat_pre = true;
                p_iter = env_mvar (L(p)->env, p->sem.ii.iter, aat_nat);
                p_item = env_mvar (L(p)->env, p->sem.ii.item, aat_pre);
                p_cont = env_mvar (L(p)->env, p->sem.ii.item, aat_frag);
            } else if (item_ty == aat_anode) {
                treat_attr = true;
                a_iter = env_mvar (L(p)->env, p->sem.ii.iter, aat_nat);
                a_item = env_mvar (L(p)->env, p->sem.ii.item, aat_attr);
                a_cont = env_mvar (L(p)->env, p->sem.ii.item, aat_frag);
            } else /* mixed content */ {
                mvar_t *attr = new_var (1),
                       *sel  = new_var (1),
                       *iter = env_mvar (L(p)->env, p->sem.ii.iter, aat_nat),
                       *frag = env_mvar (L(p)->env, p->sem.ii.item, aat_frag),
                       *tmp;

                treat_pre  = true;
                treat_attr = true;

                p_iter = new_var (1);
                p_item = new_var (1);
                p_cont = new_var (1);
                a_iter = new_var (1);
                a_item = new_var (1);
                a_cont = new_var (1);

                /* create a boolean BAT that distinct attributes
                   and other nodes */

                /* attr := [isnil](attr); */
                execute (
                    assgn (
                        var (attr->name),
                        misnil (VAR (L(p)->env, p->sem.ii.item, aat_attr))));

                /* split up by nodes... */

                /* sel    := attr.uselect(true).hmark(0@0);
                   p_item := leftfetchjoin (sel, pre);
                   p_iter := leftfetchjoin (sel, iter);
                   p_cont := leftfetchjoin (sel, frag); */
                tmp = env_mvar (L(p)->env, p->sem.ii.item, aat_pre);
                execute (
                    assgn (var (sel->name),
                           hmark (select_ (var (attr->name), lit_bit (true)),
                                  lit_oid (0))),
                    assgn (var (p_item->name),
                           leftfetchjoin (var (sel->name), var (tmp->name))),
                    assgn (var (p_iter->name),
                           leftfetchjoin (var (sel->name), var (iter->name))),
                    assgn (var (p_cont->name),
                           leftfetchjoin (var (sel->name), var (frag->name))));

                /* ... and attributes */

                /* sel    := attr.uselect(false).hmark(0@0);
                   a_item := leftfetchjoin (sel, pre);
                   a_iter := leftfetchjoin (sel, iter);
                   a_cont := leftfetchjoin (sel, frag); */
                tmp = env_mvar (L(p)->env, p->sem.ii.item, aat_attr);
                execute (
                    assgn (var (sel->name),
                           hmark (select_ (var (attr->name), lit_bit (false)),
                                  lit_oid (0))),
                    assgn (var (a_item->name),
                           leftfetchjoin (var (sel->name), var (tmp->name))),
                    assgn (var (a_iter->name),
                           leftfetchjoin (var (sel->name), var (iter->name))),
                    assgn (var (a_cont->name),
                           leftfetchjoin (var (sel->name), var (frag->name))));

                unpin (attr, 1);
                unpin (sel, 1);
            }

            /* first handle root attributes */
            if (treat_attr) {
                v = new_var (1);

                /* collect attribute names, values, and container... */
                execute (
                    assgn (var (v->name),
                           seqbase (new (type (mty_void), type (mty_bat)),
                                    lit_oid (0))),
                    /* iter */
                    bappend (var (v->name), var (a_iter->name)),
                    /* pre (parent) */
                    bappend (var (v->name),
                             project (var (a_iter->name),
                                      lit_oid (twig_state->parent))),
                    /* qname */
                    bappend (var (v->name),
                             mposjoin (
                                 var (a_item->name),
                                 var (a_cont->name),
                                 fetch (var (PF_MIL_VAR_WS),
                                        var (PF_MIL_VAR_ATTR_QN)))),
                    /* value */
                    bappend (var (v->name),
                             mposjoin (
                                 var (a_item->name),
                                 var (a_cont->name),
                                 fetch (var (PF_MIL_VAR_WS),
                                        var (PF_MIL_VAR_ATTR_PROP)))),
                    /* cont */
                    bappend (var (v->name),
                             mposjoin (
                                 var (a_item->name),
                                 var (a_cont->name),
                                 fetch (var (PF_MIL_VAR_WS),
                                        var (PF_MIL_VAR_ATTR_CONT)))));

                /* ... and add them to list of root attributes */
                *(mvar_t **) PFarray_add (twig_state->attr_vars) = v;
            }

            if (treat_pre && p->kind == pa_content) {
                mvar_t  *unq_iter, *scj_res, *root_level, *content_level;
                mvar_t  *iter = new_var (1);
                mvar_t  *item = new_var (1);
                mvar_t  *cont = new_var (1);

                v = new_var (1);

                unq_iter = new_var (1);
                scj_res  = new_var (1);
                /* evaluate descendant-or-self::node() step:
                   unq_iter := p_iter.mirror();
                   scj_res := step (AXIS_descendant_or_self,
                                    TEST_none,
                                    p_iter, p_cont, p_item, nil, ws, 0,
                                    chr(nil), str(nil), str(nil), str(nil));
                   iter := scj_res.fetch(0);
                   item := scj_res.fetch(2);
                   # cont is probably a fake project
                   cont := scj_res.fetch(1);
                   # avoid iter being a fake project
                   iter := materialize(iter, item); */
                execute (
                    assgn (
                        var (unq_iter->name),
                        mirror (var (p_iter->name))),
                    assgn (
                        var (scj_res->name),
                        step (var (PF_MIL_VAR_AXIS_DESC_S),
                              var (PF_MIL_VAR_CODE_NONE),
                              var (unq_iter->name),
                              var (p_cont->name),
                              var (p_item->name),
                              nil (),
                              var (PF_MIL_VAR_WS),
                              lit_int (0),
                              cast (type (mty_chr), nil ()),
                              cast (type (mty_str), nil ()),
                              cast (type (mty_str), nil ()),
                              cast (type (mty_str), nil ()))),
                    assgn (
                        var (iter->name),
                        fetch(var (scj_res->name), lit_int (0))),
                    assgn (
                        var (item->name),
                        fetch(var (scj_res->name), lit_int (2))),
                    assgn (
                        var (cont->name),
                        fetch(var (scj_res->name), lit_int (1))),
                    assgn (
                        var (iter->name),
                        materialize (
                            var (iter->name),
                            var (item->name))));
                unpin (unq_iter, 1);
                unpin (scj_res, 1);

                root_level    = new_var (1);
                content_level = new_var (1);
                /* collect node values and insert them into
                   list of twig constructors:
                   v := new(void, bat).seqbase(0@0);
                   v.append(iter.leftjoin(p_iter).chk_order());
                   v.append(item.project(%twig_state->pre%));
                   v.append(mposjoin(item,cont,ws.fetch(PRE_SIZE)));
                   root_level := mposjoin(p_item,p_cont,ws.fetch(PRE_LEVEL));
                   # map root_level to the correct cardinality
                   root_level := iter.leftjoin(root_level);
                   content_level := mposjoin(item,cont,ws.fetch(PRE_LEVEL));
                   content_level := [-](content_level, root_level);
                   content_level := [+](content_level, %twig_state->level%);
                   v.append(content_level);
                   v.append(mposjoin(item,cont,ws.fetch(PRE_KIND)));
                   v.append(mposjoin(item,cont,ws.fetch(PRE_PROP)));
                   v.append(mposjoin(item,cont,ws.fetch(PRE_CONT)));
                   v.append(item);
                   # avoid cont being a fake project
                   v.append(materialize (cont, item));
                   */
                execute (
                    assgn (var (v->name),
                           seqbase (new (type (mty_void), type (mty_bat)),
                                    lit_oid (0))),
                    /* iter */
                    bappend (var (v->name),
                             chk_order (
                                 leftjoin (
                                     var (iter->name),
                                     var (p_iter->name)))),
                    /* pre */
                    bappend (var (v->name),
                             project (
                                 var (item->name),
                                 lit_oid (twig_state->pre))),
                    /* size */
                    bappend (var (v->name),
                             mposjoin (
                                 var (item->name),
                                 var (cont->name),
                                 fetch (var (PF_MIL_VAR_WS),
                                        var (PF_MIL_VAR_PRE_SIZE)))),
                    /* level */
                    assgn (
                        var (root_level->name),
                         mposjoin (
                             var (p_item->name),
                             var (p_cont->name),
                             fetch (var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_PRE_LEVEL)))),
                    assgn (
                        var (root_level->name),
                        leftjoin (
                            var (iter->name),
                            var (root_level->name))),
                    assgn (
                        var (content_level->name),
                         mposjoin (
                             var (item->name),
                             var (cont->name),
                             fetch (var (PF_MIL_VAR_WS),
                                    var (PF_MIL_VAR_PRE_LEVEL)))),
                    assgn (
                        var (content_level->name),
                        msub (
                            var (content_level->name),
                            var (root_level->name))),
                    assgn (
                        var (content_level->name),
                        madd (
                            var (content_level->name),
                            cast (
                                type (mty_chr),
                                lit_int (twig_state->level)))),
                    bappend (var (v->name),
                             var (content_level->name)),
                    /* kind */
                    bappend (var (v->name),
                             mposjoin (
                                 var (item->name),
                                 var (cont->name),
                                 fetch (var (PF_MIL_VAR_WS),
                                        var (PF_MIL_VAR_PRE_KIND)))),
                    /* prop */
                    bappend (var (v->name),
                             mposjoin (
                                 var (item->name),
                                 var (cont->name),
                                 fetch (var (PF_MIL_VAR_WS),
                                        var (PF_MIL_VAR_PRE_PROP)))),
                    /* cont */
                    bappend (var (v->name),
                             mposjoin (
                                 var (item->name),
                                 var (cont->name),
                                 fetch (var (PF_MIL_VAR_WS),
                                        var (PF_MIL_VAR_PRE_CONT)))),
                    /* old_pre */
                    bappend (var (v->name),
                             var (item->name)),
                    /* old_cont */
                    bappend (var (v->name),
                             materialize (
                                 var (cont->name),
                                 var (item->name))));
                unpin (root_level, 1);
                unpin (content_level, 1);
                unpin (iter, 1);
                unpin (item, 1);
                unpin (cont, 1);

                *(mvar_t **) PFarray_add (twig_state->elem_vars) = v;
                twig_state->pre++;
                /* tell the twig constructor to handle
                   subtree attribute copies */
                twig_state->elem_content = true;

                /* add summed sizes to the environment */
                if (twig_state->loop) {
                    mvar_t *sizes = new_var (1);
                    mvar_t *gsize = new_var (1);

                    /* sizes := mposjoin(p_item,p_cont,ws.fetch(PRE_SIZE);
                       # don't forget the node itself
                       sizes := [+](sizes, 1);
                       sizes := p_iter.reverse().leftjoin(sizes);
                       gsize := {sum}(sizes,%twig_state->loop%.reverse());
                       # map back to head values
                       sizes := %twig_state->loop%.leftjoin(gsize); */
                    execute (
                        assgn (
                            var (sizes->name),
                            mposjoin (
                                var (p_item->name),
                                var (p_cont->name),
                                fetch (var (PF_MIL_VAR_WS),
                                       var (PF_MIL_VAR_PRE_SIZE)))),
                        assgn (
                            var (sizes->name),
                            madd (var (sizes->name), lit_int (1))),
                        assgn (
                            var (sizes->name),
                            leftjoin (
                                reverse (var (p_iter->name)),
                                var (sizes->name))),
                        assgn (
                            var (gsize->name),
                            egsum (
                                var (sizes->name),
                                reverse (twig_state->loop))),
                        assgn (
                            var (gsize->name),
                            mifthenelse (
                               misnil (var (gsize->name)),
                               project (var (gsize->name),
                                        lit_int (0)),
                               var (gsize->name))),
                        assgn (
                            var (gsize->name),
                            leftjoin (
                                twig_state->loop,
                                var (gsize->name))));
                    unpin (sizes, 1);
                    /* add the grouped sizes to the variable environment */
                    env_add (p->env, col_NULL, aat_int, gsize);
                }
            }
            else if (treat_pre && p->kind == pa_slim_content) {
                v = new_var (1);

                /* add the node references into list of twig constructors
                   (size = 0, kind = REFERENCE, prop = p_prop, cont = p_cont):
                   v := new(void, bat).seqbase(0@0);
                   v.append(p_iter.chk_order());
                   v.append(p_iter.project(%twig_state->pre%));
                   v.append(p_iter.project(0));
                   v.append(p_iter.project(%twig_state->level%));
                   v.append(p_iter.project(REFERENCE));
                   # store the references to look up the reference
                   # in the PRE_PROP column
                   v.append(p_item);
                   # store the node container to look up the reference
                   # in the PRE_CONT column
                   v.append(p_cont);
                   v.append(p_iter.project(oid(nil)));
                   v.append(p_iter.project(oid(nil)));
                   */
                execute (
                    assgn (var (v->name),
                           seqbase (new (type (mty_void), type (mty_bat)),
                                    lit_oid (0))),
                    /* iter */
                    bappend (var (v->name),
                             chk_order (var (p_iter->name))),
                    /* pre */
                    bappend (var (v->name),
                             project (
                                 var (p_iter->name),
                                 lit_oid (twig_state->pre))),
                    /* size */
                    bappend (var (v->name),
                             project (
                                 var (p_iter->name),
                                 lit_int (0))),
                    /* level */
                    bappend (var (v->name),
                             project (
                                 var (p_iter->name),
                                 cast (
                                     type (mty_chr),
                                     lit_int (twig_state->level)))),
                    /* kind */
                    bappend (var (v->name),
                             project (
                                 var (p_iter->name),
                                 var (PF_MIL_VAR_KIND_REF))),
                    /* prop */
                    bappend (var (v->name),
                             var (p_item->name)),
                    /* cont */
                    bappend (var (v->name),
                             var (p_cont->name)),
                    /* old_pre */
                    bappend (var (v->name),
                             project (
                                 var (p_iter->name),
                                 cast (type (mty_oid), nil ()))),
                    /* old_cont */
                    bappend (var (v->name),
                             project (
                                 var (p_iter->name),
                                 cast (type (mty_oid), nil ()))));

                *(mvar_t **) PFarray_add (twig_state->elem_vars) = v;
                twig_state->pre++;
                /* do not tell the twig constructor to handle
                   subtree attribute copies */
                /* twig_state->elem_content = false; */

                /* add count of the references to the environment */
                if (twig_state->loop) {
                    mvar_t *gsize = new_var (1);

                    /* gsize := {count}(p_iter.reverse(),
                                        %twig_state->loop%.reverse());
                       # map back to head values
                       gsize := %twig_state->loop%.leftjoin(gsize); */
                    execute (
                        assgn (
                            var (gsize->name),
                            egcount (
                                reverse (var (p_iter->name)),
                                reverse (twig_state->loop))),
                        assgn (
                            var (gsize->name),
                            leftjoin (
                                twig_state->loop,
                                var (gsize->name))));

                    /* add the grouped sizes to the variable environment */
                    env_add (p->env, col_NULL, aat_int, gsize);
                }
            }

            if (treat_pre && treat_attr) {
                unpin (p_iter, 1);
                unpin (p_item, 1);
                unpin (p_cont, 1);
                unpin (a_iter, 1);
                unpin (a_item, 1);
                unpin (a_cont, 1);
            }
        }
            break; /* fold) */

        /* Rel:      merge_adjacent (Rel) */
        case 117: /* fold( */
        {
            PFalg_col_t         iter_att   = p->sem.iter_pos_item.iter,
                                pos_att    = p->sem.iter_pos_item.pos,
                                item_att   = p->sem.iter_pos_item.item;
            PFalg_simple_type_t item_ty    = type_of (L(p), item_att);
            mvar_t             *iter       = new_var (p->refctr),
                               *pos        = new_var (p->refctr),
                               *pre        = new_var (p->refctr),
                               *frag       = new_var (p->refctr),
                               *a_iter     = NULL,
                               *a_pos      = NULL,
                               *a_pre      = NULL,
                               *a_attr     = NULL,
                               *a_cont     = NULL,
                               *p_iter     = NULL,
                               *p_pos      = NULL,
                               *p_pre      = NULL,
                               *p_cont     = NULL,
                               *ma;
            bool                treat_attr = false;

            env_add (p->env, iter_att, aat_nat, iter);
            env_add (p->env, pos_att,  aat_nat, pos);
            env_add (p->env, item_att, aat_pre, pre);
            env_add (p->env, item_att, aat_frag, frag);

            /* if we have attributes and other nodes we need to
               split them up first */
            if (item_ty & aat_attr) {
                mvar_t *attr    = new_var (1),
                       *sel     = new_var (1),
                       *in_iter = env_mvar (L(p)->env, iter_att, aat_nat),
                       *in_pos  = env_mvar (L(p)->env, pos_att,  aat_nat),
                       *in_frag = env_mvar (L(p)->env, item_att, aat_frag),
                       *in_pre  = env_mvar (L(p)->env, item_att, aat_pre),
                       *in_attr = env_mvar (L(p)->env, item_att, aat_attr);

                treat_attr = true;

                p_iter = new_var (1);
                p_pos  = new_var (1);
                p_pre  = new_var (1);
                p_cont = new_var (1);
                a_iter = new_var (1);
                a_pos  = new_var (1);
                a_pre  = new_var (1);
                a_attr = new_var (1);
                a_cont = new_var (1);

                /* create a boolean BAT that distinct attributes
                   and other nodes */

                /* attr := [isnil](attr); */
                execute (
                    assgn (
                        var (attr->name),
                        misnil (var (in_attr->name))));

                /* split up by nodes... */

                /* sel    := attr.uselect(true).hmark(0@0);
                   p_pre  := leftfetchjoin (sel, pre);
                   p_iter := leftfetchjoin (sel, iter);
                   p_pos  := leftfetchjoin (sel, pos);
                   p_cont := leftfetchjoin (sel, frag); */
                execute (
                    assgn (var (sel->name),
                           hmark (select_ (var (attr->name), lit_bit (true)),
                                  lit_oid (0))),
                    assgn (var (p_pre->name),
                           leftfetchjoin (var (sel->name),
                                          var (in_pre->name))),
                    assgn (var (p_iter->name),
                           leftfetchjoin (var (sel->name),
                                          var (in_iter->name))),
                    assgn (var (p_pos->name),
                           leftfetchjoin (var (sel->name),
                                          var (in_pos->name))),
                    assgn (var (p_cont->name),
                           leftfetchjoin (var (sel->name),
                                          var (in_frag->name))));

                /* ... and attributes */

                /* sel    := attr.uselect(false).hmark(0@0);
                   a_pre  := leftfetchjoin (sel, pre);
                   a_attr := leftfetchjoin (sel, attr);
                   a_iter := leftfetchjoin (sel, iter);
                   a_pos  := leftfetchjoin (sel, pos);
                   a_cont := leftfetchjoin (sel, frag); */
                execute (
                    assgn (var (sel->name),
                           hmark (select_ (var (attr->name), lit_bit (false)),
                                  lit_oid (0))),
                    assgn (var (a_pre->name),
                           leftfetchjoin (var (sel->name),
                                          var (in_pre->name))),
                    assgn (var (a_attr->name),
                           leftfetchjoin (var (sel->name),
                                          var (in_attr->name))),
                    assgn (var (a_iter->name),
                           leftfetchjoin (var (sel->name),
                                          var (in_iter->name))),
                    assgn (var (a_pos->name),
                           leftfetchjoin (var (sel->name),
                                          var (in_pos->name))),
                    assgn (var (a_cont->name),
                           leftfetchjoin (var (sel->name),
                                          var (in_frag->name))));

                unpin (attr, 1);
                unpin (sel, 1);
            }
            else {
                p_iter = env_mvar (L(p)->env, iter_att, aat_nat);
                p_pos  = env_mvar (L(p)->env, pos_att, aat_nat);
                p_pre  = env_mvar (L(p)->env, item_att, aat_pre);
                p_cont = env_mvar (L(p)->env, item_att, aat_frag);
            }

            /* apply the merge_adjacent operation */
            ma = new_var (1);

            execute (
                assgn (var (ma->name),
                       merge_adjacent (var (p_iter->name),
                                       var (p_pre->name),
                                       var (p_cont->name),
                                       var (PF_MIL_VAR_WS))),
                assgn (var (iter->name),
                       leftfetchjoin (
                           hmark (fetch (var (ma->name), lit_int (1)),
                                  lit_oid (0)),
                           VAR (L(p)->env, iter_att, aat_nat))),
                assgn (var (pos->name),
                       leftfetchjoin (
                           hmark (fetch (var (ma->name), lit_int (1)),
                                  lit_oid (0)),
                           VAR (L(p)->env, pos_att, aat_nat))),
                assgn (var (pre->name),
                       tmark (fetch (var (ma->name), lit_int (1)),
                              lit_oid (0))),
                assgn (var (frag->name),
                       tmark (fetch (var (ma->name), lit_int (2)),
                              lit_oid (0))),
                assgn (var (PF_MIL_VAR_WS),
                       fetch (var (ma->name), lit_int (0))));

            unpin (ma, 1);

            /* if we have attributes and other nodes we need to
               merge them back again */
            if (treat_attr) {
                mvar_t *mu   = new_var (1),
                       *attr = new_var (p->refctr);

                env_add (p->env, item_att, aat_attr, attr);

                /* Attributes have to appear before the other nodes.
                   Otherwise the node constructors may fail.
                   (In our scenario it however doesn't matteri
                    as we split them up anyway.) */
                execute (
                    assgn (var (mu->name),
                           merged_union (
                               arg (var (a_iter->name),
                               arg (var (iter->name),
                               arg (var (a_pos->name),
                               arg (var (pos->name),
                               arg (var (a_pre->name),
                               arg (var (pre->name),
                               arg (var (a_attr->name),
                               arg (project (var (iter->name),
                                             cast (type (mty_oid), nil ())),
                               arg (var (a_cont->name),
                                    var (frag->name)))))))))))),
                    assgn (var (iter->name),
                           fetch (var (mu->name), lit_int (0))),
                    assgn (var (pos->name),
                           fetch (var (mu->name), lit_int (1))),
                    assgn (var (pre->name),
                           fetch (var (mu->name), lit_int (2))),
                    assgn (var (attr->name),
                           fetch (var (mu->name), lit_int (3))),
                    assgn (var (frag->name),
                           fetch (var (mu->name), lit_int (4))));

                unpin (mu, 1);

                unpin (p_iter, 1);
                unpin (p_pos, 1);
                unpin (p_pre, 1);
                unpin (p_cont, 1);
                unpin (a_iter, 1);
                unpin (a_pos, 1);
                unpin (a_pre, 1);
                unpin (a_attr, 1);
                unpin (a_cont, 1);
            }
        }   break; /* fold) */

        /* Side:     error (Side, Rel) */
        case 129: /* fold( */
            execute (
                if_ (eq (count (VAR (R(p)->env, p->sem.err.col, aat_str)),
                         lit_int (0)),
                     nop(),
                     error (fetch (VAR (R(p)->env, p->sem.err.col, aat_str),
                                   lit_int (0)))));
            break; /* fold) */

        /* Side:     nil */
        case 130: /* fold( */
            /* end of parameter list */
            break; /* fold) */

        /* Side:     cache (Side, Rel) */
        case 131: /* fold( */
        {
            char       *id   = p->sem.cache.id;
            PFalg_col_t item = p->sem.cache.item;
            mvar_t     *res_bat,
                       *item_bat;
            PFmil_t    *oldmilprog,
                       *then_milprog;

            /* Generate code for left side (and the operators of the right
               side that are also referenced outside the branch. */
            reduce (kids[0], nts[0]);

            execute (comment ("Evaluate the portion of the to-be-cached query "
                              "that is referenced multiple times."));
            reduce_border (kids[1], nts[1], 132 /* cache_border rule */);

            /* save the current mil program */
            oldmilprog = milprog;

            /* create a new empty milprog for the then-branch */
            milprog = nop ();

            /* translate the independent body expression */
            execute (comment ("Evaluate the independent portion"
                              " of the right side of the cache operator."));
            reduce (kids[1], nts[1]);

            /* store the result in FIXME */
            res_bat = new_var (1);
            execute (
                comment (" "),
                comment ("Storing the query result under id '%s'.", id),
                assgn (
                    var (res_bat->name),
                    seqbase (new (type (mty_void), type(mty_bat)),
                             lit_oid (0))));

            /* Add all item columns in the same order as rule 151
               ('fun_call (Rel, Param)'; case alg_fun_call_cache)
               retrieves them from the container. */
            for (PFalg_simple_type_t t = 1; t; t <<= 1)
                if (t & TYPE_MASK(type_of (p, item))) {
                    item_bat = env_mvar (R(p)->env, item, t);
                    execute (
                        append (
                            var (res_bat->name),
                            var (item_bat->name)));
                }

            /* Add the cache id and the item container BAT
               to the query cache. */
            execute (
                cache_put (var (PF_MIL_VAR_WS), lit_str (id), var (res_bat->name)));
            unpin (res_bat, 1);

            /* store the code for the then-branch */
            then_milprog = milprog;

            /* make the old mil program the active one again */
            milprog = oldmilprog;

            /* Apply the check that tests if the query is already cached. */
            execute (
                comment ("Caching Query %s...", id),
                if_ (cache_expr(var (PF_MIL_VAR_WS), lit_str (id)),
                     then_milprog,
                     nop ()));

        }   break; /* fold) */

        /* Rel:      cache_border (Rel) */
        case 132: /* fold( */
            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);
            break; /* fold) */

        /* Side:     trace (Side, trace_items (Rel, trace_msg (Rel, Map))) */
        case 135:
        /* Side:     trace (Side, trace_items (Rel, trace_msg (Rel, nil))) */
        case 136: /* fold( */
        {
            unsigned trace_id = new_trace_id ();
            PFmil_t *iter = NULL,
                    *item = NULL;

            /* copy all the columns */
            for (unsigned int i = 0; i < env_count (RL(p)->env); i++) {
                /* as a side effect fill in the trace information */
                if (env_at (RL(p)->env, i).col == R(p)->sem.ii.iter) {
                    /* fill in the iter information */
                    execute (
                        insert (var (PF_MIL_VAR_TRACE_ITER),
                                lit_oid (trace_id),
                                var (env_at (RL(p)->env, i).mvar->name)));
                }
                else if (env_at (RL(p)->env, i).col == R(p)->sem.ii.item) {
                    /* fill in the item information */
                    execute (
                        insert (var (PF_MIL_VAR_TRACE_ITEM),
                                lit_oid (trace_id),
                                var (env_at (RL(p)->env, i).mvar->name)),
                        insert (var (PF_MIL_VAR_TRACE_TYPE),
                                lit_oid (trace_id),
                                lit_int (env_at (RL(p)->env, i).ty)));
                }
            }

            /* collect the message information */
            iter = VAR (RRL(p)->env, RR(p)->sem.ii.iter, aat_nat);
            assert (iter);
            item = VAR (RRL(p)->env, RR(p)->sem.ii.item, aat_str);
            assert (item);

            execute (
                insert (var (PF_MIL_VAR_TRACE_MSG),
                        lit_oid (trace_id),
                        leftjoin (reverse (iter), item)));

            /* fill in the relationship between the trace and the
               last map relation */
            if (RRR(p)->kind == pa_nil)
                execute (
                    insert (var (PF_MIL_VAR_TRACE_REL),
                            lit_oid (0),
                            lit_oid (trace_id)));
            else
                execute (
                    insert (var (PF_MIL_VAR_TRACE_REL),
                            lit_oid (RRR(p)->sem.trace_map.trace_id),
                            lit_oid (trace_id)));
        }   break; /* fold) */

        /* Map:      trace_map (Rel, Map) */
        case 137:
        /* Map:      trace_map (Rel, nil) */
        case 138: /* fold( */
        {
            unsigned trace_id = new_trace_id ();
            /* store the trace_id */
            p->sem.trace_map.trace_id = trace_id;

            for (unsigned int i = 0; i < env_count (L(p)->env); i++) {
                if (env_at (L(p)->env, i).col == p->sem.trace_map.outer) {
                    /* fill in the iter information */
                    execute (
                        insert (var (PF_MIL_VAR_TRACE_OUTER),
                                lit_oid (trace_id),
                                var (env_at (L(p)->env, i).mvar->name)));
                }
                else if (env_at (L(p)->env, i).col == p->sem.trace_map.inner) {
                    /* fill in the item information */
                    execute (
                        insert (var (PF_MIL_VAR_TRACE_INNER),
                                lit_oid (trace_id),
                                var (env_at (L(p)->env, i).mvar->name)));
                }
            }

            /* fill in the relationship between the map relations */
            if (R(p)->kind == pa_nil)
                execute (
                    insert (var (PF_MIL_VAR_TRACE_REL),
                            lit_oid (0),
                            lit_oid (trace_id)));
            else
                execute (
                    insert (var (PF_MIL_VAR_TRACE_REL),
                            lit_oid (R(p)->sem.trace_map.trace_id),
                            lit_oid (trace_id)));
        }   break; /* fold) */

        /* Rel:      rec_fix (side_effects (Side, Rec), Rel) */
        case 140: /* fold( */
        {
            PFmil_t *oldmilprog, *bodymilprog;
            PFarray_t *res_env;
            mvar_t *old_count, *new_count;
            PFarray_t *border_vars = PFarray (sizeof (mvar_t *), 10);

            /* Generate code for the seeds and bind them to the new variables.
               In addition generate code for all expressions that are
               invariant to the recursion body (all expressions underneath
               a rec_border operator) and pin the variables holding the
               results once more such they are not released in the recursion
               body (references stored in border_vars). */
            reduce_rec_border(kids[0], nts[0], border_vars);
            reduce1(kids[1], nts[1], border_vars);

            old_count = new_var (1);
            new_count = new_var (1);

            /* initialize the result counters */
            execute (
                assgn (var (old_count->name),
                       lit_int (-1)),
                assgn (var (new_count->name),
                       lit_int (0)));

            /* save the current mil program */
            oldmilprog = milprog;

            /* create a new empty milprog */
            milprog = nop ();

            /* translate the recursion body and
               reassign the recursion variables */
            reduce(kids[0], nts[0]);
            reduce2(kids[1], nts[1]);

            /* get the result environment */
            reduce(kids[2], nts[2]);
            res_env = R(p)->env;

            /* update the result counters */
            execute (
                assgn (var (old_count->name),
                       var (new_count->name)),
                assgn (var (new_count->name),
                       count (var (env_at (res_env, 0).mvar->name))));

            /* make the old mil program the active one */
            bodymilprog = milprog;
            milprog = oldmilprog;

            /* apply the while statement */
            execute (
                while_ (
                  gt (var (new_count->name),
                      var (old_count->name)),
                  bodymilprog));

            /* the condition variables are not needed anymore */
            unpin (new_count, 1);
            unpin (old_count, 1);

            /* copy all the result columns */
            for (unsigned int i = 0; i < env_count (res_env); i++) {
                pin (env_at (res_env, i).mvar,
                     p->refctr);

                env_add (p->env,
                         env_at (res_env, i).col,
                         env_at (res_env, i).ty,
                         env_at (res_env, i).mvar);
            }

            /* release the additional pins of the variables
               representing the recursion invariant expressions */
            for (unsigned int i = 0; i < PFarray_last (border_vars); i++)
                unpin (*(mvar_t **) PFarray_at (border_vars, i), 1);

            /* release all the pins of the while loop arguments */
            reduce3(kids[1], nts[1]);

            /* ensure that the child of p (the first argument) still
               has one pin left to release (see bottom of function reduce) */
            for (unsigned int i = 0; i < PFarray_last (LR(p)->env); i++)
                pin (env_at (LR(p)->env, i).mvar, 1);
        }   break; /* fold) */

        /* Rec:      rec_param (rec_arg (Rel, Rel), Rec) */
        case 141:
        /* Rec:      rec_param (rec_arg (empty_tbl, Rel), Rec) */
        case 142:
        /* Rec:      nil */
        case 143:
            /* the rules are called via reduce1, reduce2, and reduce3 */
            break;

        /* Rel:      rec_base */
        case 144:
            /* no MIL code needed */

            /* The environment already contains the bindings.
               See rules:
                  rec_param (rec_arg (Rel, Rel), Rec)
                and
                  rec_param (rec_arg (empty_tbl, Rel), Rec))
                in function reduce1 */
            break;

        /* Rel:      rec_border (Rel) */
        case 145: /* fold( */
            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);
            break; /* fold) */

        /* Rel:      FunRel */
        case 150:
            /* no operator -- nothing to do */
            break;

        /* FunRel:   fun_call (Rel, Param) */
        case 151: /* fold( */
        {   /* TOPDOWN */
            PFarray_t *old_fun_params;
            PFpa_op_t *param;

            /* Collect the destinations */
            reduce (kids[0], nts[0]);

            old_fun_params = fun_params;

            /* We will collect the parameters here */
            fun_params = PFarray (sizeof (PFpa_op_t **), 10);

            /* Top-down processing puts all parameters into this array */
            reduce (kids[1], nts[1]);

            /* All function parameters are now in the array `fun_params'. */

            /***********************************/
            /*                                 */
            /* DO FUNCTION TRANSFORMATION HERE */
            /*                                 */
            /***********************************/

            /* PFalg_col_t funcall_loop = p->sem.fun_call.iter; */

            switch (p->sem.fun_call.kind) { /* fold( */
                
                /* Simple NtoN functions */
                case alg_fun_call_pf_documents:
                case alg_fun_call_pf_documents_unsafe:
                {
                    bool safe = true;
                    mvar_t *nodes    = new_var(1);
                    mvar_t *res_item = new_var (p->refctr);
                    mvar_t *res_iter = new_var (p->refctr);
                    mvar_t *res_frag = new_var (p->refctr);
	            PFalg_col_t iter = p->schema.items[0].name;
	            PFalg_col_t item = p->schema.items[1].name;
                    mvar_t *loop = env_mvar (L(p)->env,
                                             p->sem.fun_call.iter,
                                             aat_nat);

                    /* decide if it is safe or unsafe */
                    switch (p->sem.fun_call.kind) {
                        case alg_fun_call_pf_documents:
                            safe = true; break;
                        case alg_fun_call_pf_documents_unsafe:
                            safe = false; break;
                        default:
                            assert(!"should never reach here");
                    }

                    execute (assgn (var (nodes->name),
                                 cross (reverse (var (loop->name)),
                                        ws_documents (var (PF_MIL_VAR_WS), 
                                                      lit_bit(safe)))));

                    execute (
                             assgn (var (res_item->name),
                                    tmark (var(nodes->name),
                                           lit_oid(0))),
                             assgn (var (res_iter->name),
                                    hmark (var(nodes->name),
                                           lit_oid(0))),
                             assgn (var (res_frag->name),
                                    project (var (res_item->name),
                                             var (PF_MIL_VAR_WS_CONT))));

                    env_add (p->env, item, aat_pre, res_item);
                    env_add (p->env, item, aat_frag, res_frag);
                    env_add (p->env, iter, aat_nat, res_iter);

                    unpin(nodes, 1);
                }   break;

                case alg_fun_call_pf_documents_str:
                case alg_fun_call_pf_documents_str_unsafe:
                {
                    bool safe = true;
                    mvar_t *nodes    = new_var(1);
                    mvar_t *res_item = new_var (p->refctr);
                    mvar_t *res_iter = new_var (p->refctr);
                    mvar_t *res_frag = new_var (p->refctr);
	            PFalg_col_t iter = p->schema.items[0].name;
	            PFalg_col_t item = p->schema.items[1].name;
                    mvar_t *loop = env_mvar (L(p)->env,
                                             p->sem.fun_call.iter,
                                             aat_nat);
                    PFpa_op_t *param_1 = *(PFpa_op_t **)
                                         PFarray_at (fun_params, 0);

                    /* decide if it is safe or unsafe */
                    switch (p->sem.fun_call.kind) {
                        case alg_fun_call_pf_documents_str:
                            safe = true; break;
                        case alg_fun_call_pf_documents_str_unsafe:
                            safe = false; break;
                        default:
                            assert(!"should never reach here");
                    }

                    execute (assgn (var (nodes->name),
                             leftjoin (reverse (var (loop->name)),
                                    ws_documents_str (
                                         var (PF_MIL_VAR_WS), 
                                         VAR (param_1->env,
                                   /* item */ param_1->schema.items[2].name,
                                              aat_str),
                                         lit_bit(safe)))));

                    execute (
                             assgn (var (res_item->name),
                                    tmark (var(nodes->name),
                                           lit_oid(0))),
                             assgn (var (res_iter->name),
                                    hmark (var(nodes->name),
                                           lit_oid(0))),
                             assgn (var (res_frag->name),
                                    project (var (res_item->name),
                                             var (PF_MIL_VAR_WS_CONT))));

                    env_add (p->env, item, aat_pre, res_item);
                    env_add (p->env, item, aat_frag, res_frag);
                    env_add (p->env, iter, aat_nat, res_iter);

                    unpin(nodes, 1);
                }   break;

                case alg_fun_call_pf_collections:
                case alg_fun_call_pf_collections_unsafe:
                {
                    bool safe = true;
                    mvar_t *nodes    = new_var(1);
                    mvar_t *res_item = new_var (p->refctr);
                    mvar_t *res_iter = new_var (p->refctr);
                    mvar_t *res_frag = new_var (p->refctr);
	            PFalg_col_t iter = p->schema.items[0].name;
	            PFalg_col_t item = p->schema.items[1].name;
                    mvar_t *loop = env_mvar (L(p)->env,
                                             p->sem.fun_call.iter,
                                             aat_nat);

                    /* decide if it is safe or unsafe */
                    switch (p->sem.fun_call.kind) {
                        case alg_fun_call_pf_collections:
                            safe = true; break;
                        case alg_fun_call_pf_collections_unsafe:
                            safe = false; break;
                        default:
                            assert(!"should never reach here");
                    }

                    execute (assgn (var (nodes->name),
                             cross (reverse (var (loop->name)),
                                    ws_collections (var (PF_MIL_VAR_WS), 
                                                    lit_bit(safe)))));

                    execute (
                             assgn (var (res_item->name),
                                    tmark (var(nodes->name),
                                           lit_oid(0))),
                             assgn (var (res_iter->name),
                                    hmark (var(nodes->name),
                                           lit_oid(0))),
                             assgn (var (res_frag->name),
                                    project (var (res_item->name),
                                             var (PF_MIL_VAR_WS_CONT))));

                    env_add (p->env, item, aat_pre, res_item);
                    env_add (p->env, item, aat_frag, res_frag);
                    env_add (p->env, iter, aat_nat, res_iter);

                    unpin(nodes, 1);
                }   break;

                /* XRPC function */
                case alg_fun_call_xrpc: /* fold( */
                {
                    PFcnode_t *core_apply = (PFcnode_t *) p->sem.fun_call.ctx;

                    /* do XRPC stuff here */
                    (void)* core_apply;

                    /* dummy stub to fill the environment */

                    /* create dummy temp variable */
                    v = new_var (1);
                    /* add more references to v */
                    pin (v, 1);
                    /* release all pins */
                    unpin (v, 2);

                    /* fill the environment for all columns */
                    for (unsigned int i = 0; i < p->schema.count; i++) {
                        for (PFalg_simple_type_t t = 1; t; t <<= 1)
                            if (t & TYPE_MASK(p->schema.items[i].type)) {
                                /* create new variable */
                                v = new_var (p->refctr);
                                /* dummy assignment */
                                execute (
                                    assgn (var (v->name),
                                           nil ()));
                                env_add (p->env, p->schema.items[i].name, t, v);
                            }
                        }
                }   break; /* fold) */

                /* XRPC helpers function */
                case alg_fun_call_xrpc_helpers:
                {
                }   break;

                /* Tijah function */
                case alg_fun_call_tijah: /* fold( */ 
                {
#ifdef HAVE_PFTIJAH
	    const char* fcname = PFqname_loc(p->sem.fun_call.qname);

	    PFalg_col_t fc_iter_a = p->schema.items[0].name; /* fixed */
	    PFalg_col_t fc_pos_a  = p->schema.items[1].name; /* fixed */
	    PFalg_col_t fc_item_a = p->schema.items[2].name; /* fixed */


	    if ( PFT_FUN(fcname) ) {

	        /* handle pftijah functions here */

	        mvar_t *fc_loop = env_mvar (L(p)->env,
                                            p->sem.fun_call.iter,
                                            aat_nat);

		if ( PFT_FUN_QUERY(fcname) ) {
		    int fcci = 0;
		    PFalg_simple_type_t restype;
		    int returnNodes = PTF_QUERY_NODES(fcname);

		    mvar_t *retNodes    = new_var (1);
		    if ( returnNodes ) {
		        execute (assgn(var(retNodes->name),lit_bit(false)));
			restype = aat_pre;
		    } else {
		        execute (assgn(var(retNodes->name),lit_bit(true)));
			restype = aat_int;
		    }

		    mvar_t *pfop_sn, *pfop_query, *pfop_opt;

		    if ( PTF_QUERY_STARTNODES(fcname) ) {
		        pfop_sn    = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,fcci),aat_pre,PFT_NOT_ORDERED);
			fcci++;
		    } else {
		        pfop_sn    = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }

		    pfop_query = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,fcci),aat_str,PFT_NOT_ORDERED);
		    fcci++;

		    if ( PTF_QUERY_OPTIONS(fcname) ) {
		        pfop_opt   = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,fcci),aat_pre,PFT_NOT_ORDERED);
		    } else {
		        pfop_opt   = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }

		    mvar_t *tjqres = new_var(1);
		    execute(
		        assgn(var(tjqres->name),
			    tj_query_handler(
			    	var(retNodes->name),
				var(pfop_sn->name),
				var(pfop_query->name),
				var(pfop_opt->name),
				var(fc_loop->name),
				var (PF_MIL_VAR_WS),
				var (PF_MIL_TIJAH_SCORE_DB)
			    )
			)
		    );
		    unpin(retNodes,1);

		    unpin(pfop_sn,1);
		    unpin(pfop_query,1);
		    unpin(pfop_opt,1);

		    pft_unpack_pfop(p,tjqres,fc_iter_a,fc_item_a,restype,fc_item_a,fc_pos_a,0);

		    unpin(tjqres,1);
		} else if ( PFT_FUN_FTFUN(fcname) ) {
		    int fcci = 0;
	            PFalg_col_t fc_score_a = p->schema.items[3].name;

		    PFalg_simple_type_t restype;
		    /* function returns nodes OR booleans */
		    int returnNodes = PTF_QUERY_NODES(fcname);

		    mvar_t *retNodes    = new_var (1);
		    if ( returnNodes ) {
		        execute (assgn(var(retNodes->name),lit_bit(false)));
			restype = aat_pre;
		    } else {
		        execute (assgn(var(retNodes->name),lit_bit(true)));
			restype = aat_bln;
		    }

		    mvar_t *pfop_sn, *pfop_terms, *pfop_opt, *pfop_ign;

		    if ( PTF_FTFUN_STARTNODES(fcname) ) {
		        pfop_sn    = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,fcci),aat_pre,PFT_NOT_ORDERED);
			fcci++;
		    } else {
		        pfop_sn    = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }

		    pfop_terms = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,fcci),aat_str,PFT_NOT_ORDERED);
		    fcci++;

		    if ( PTF_FTFUN_OPTIONS(fcname) ) {
		        pfop_opt   = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,fcci),aat_pre,PFT_NOT_ORDERED);
			fcci++;
		    } else {
		        pfop_opt   = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }

		    if ( PTF_FTFUN_IGNORES(fcname) ) {
		        pfop_ign   = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,fcci),aat_pre,PFT_NOT_ORDERED);
			fcci++;
		    } else {
		        pfop_ign   = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }

		    mvar_t *tjqres = new_var(1);
		    execute(
		        assgn(var(tjqres->name),
			    tj_ftfun_handler(
			    	var(retNodes->name),
				var(pfop_sn->name),
				var(pfop_terms->name),
				var(pfop_opt->name),
				var(pfop_ign->name),
				var(fc_loop->name),
				var (PF_MIL_VAR_WS),
				var (PF_MIL_TIJAH_SCORE_DB)
			    )
			)
		    );
		    unpin(retNodes,1);

		    unpin(pfop_sn,1);
		    unpin(pfop_terms,1);
		    unpin(pfop_opt,1);
		    unpin(pfop_ign,1);

		    if ( restype == aat_bln )
		        pft_unpack_pfop(p,tjqres,fc_iter_a,fc_item_a,restype,0,fc_pos_a,fc_score_a);
		    else
		        pft_unpack_pfop(p,tjqres,fc_iter_a,fc_item_a,restype,fc_item_a,fc_pos_a,fc_score_a);

		    unpin(tjqres,1);
		} else if ( PFT_FUN_MANAGE(fcname) ) {
		    int fcci = 0;

		    char* opkind;
		    
		    switch (PFT_FUN_MANAGE_KIND(fcname) ) {
		     case 'c':	opkind = "create";
		     		break;
		     case 'e':	opkind = "extend";
		     		break;
		     case 'r':	opkind = "remove";
		     		break;
		     default:   opkind = "error";
		    }

		    mvar_t *pfop_coll, *pfop_opt;

		    if ( PFT_FUN_MANAGE_COLL(fcname) ) {
		        pfop_coll    = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,fcci),aat_str,PFT_NOT_ORDERED);
			fcci++;
		    } else {
		        pfop_coll    = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }
		    if ( PFT_FUN_MANAGE_OPT(fcname) ) {
		        pfop_opt    = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,fcci),aat_pre,PFT_NOT_ORDERED);
			fcci++;
		    } else {
		        pfop_opt    = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }

                    execute (
                        assgn (var (PF_MIL_TIJAH_FTI_TAPE),
		 	       tj_add_fti_tape(
			           lit_str(opkind),
				   var(pfop_coll->name),
				   var(pfop_opt->name),
				   var(fc_loop->name),
				   var(PF_MIL_VAR_WS),
			           var(PF_MIL_TIJAH_FTI_TAPE)
			       )));

		    unpin(pfop_coll,1);
		    unpin(pfop_opt,1);

                    mvar_t *p_iter  = new_var (p->refctr);
                    execute (
                       assgn (var (p_iter->name),
                          seqbase (new (type (mty_void), type(mty_oid) ),
                                            lit_oid (0))));
                    env_add (p->env, fc_iter_a, aat_nat, p_iter);

                    mvar_t *p_item1 = new_var (p->refctr);
                    execute (
                       assgn (var (p_item1->name),
                          seqbase (new (type (mty_void), type(mty_lng) ),
                                            lit_oid (0))));
                    env_add (p->env, fc_item_a, aat_docmgmt, p_item1);

                    mvar_t *p_item2 = new_var (p->refctr);
                    execute (
                       assgn (var (p_item2->name),
                          seqbase (new (type (mty_void), type(mty_str) ),
                                            lit_oid (0))));
                    env_add (p->env, fc_item_a, aat_docnm, p_item2);

                    mvar_t *p_pos  = new_var (p->refctr);
                    execute (
                       assgn (var (p_pos->name),
                          seqbase (new (type (mty_void), type(mty_oid) ),
                                            lit_oid (0))));
                    env_add (p->env, fc_pos_a, aat_nat, p_pos);


		} else if ( (strcmp(fcname,PFT_TERMS) == 0) ||
			    (strcmp(fcname,PFT_TERMS_O) == 0) ) {
		    mvar_t *pfop_terms;
		    mvar_t *pfop_term_opt;

		    pfop_terms = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,0),aat_pre,PFT_NOT_ORDERED);

		    if ( strcmp(fcname,PFT_TERMS_O) == 0 ) {
		        pfop_term_opt   = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,1),aat_pre,PFT_NOT_ORDERED);
		    } else {
		        pfop_term_opt   = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }

		    mvar_t *tjsres = new_var(1);
		    execute(
		        assgn(var(tjsres->name),
			    tj_terms(
				var(fc_loop->name),
				var (PF_MIL_VAR_WS),
				var(pfop_terms->name),
				var(pfop_term_opt->name)
			    )
			)
		    );
		    unpin(pfop_terms,1);
		    unpin(pfop_term_opt,1);

		    pft_unpack_pfop(p,tjsres,fc_iter_a,fc_item_a,aat_str,0,fc_pos_a,0);
		    unpin(tjsres,1);
		} else if ( (strcmp(fcname,PFT_TFALL) == 0) ||
			    (strcmp(fcname,PFT_TFALL_O) == 0) ) {
		    mvar_t *pfop_term;
		    mvar_t *pfop_term_opt;

		    pfop_term = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,0),aat_str,PFT_NOT_ORDERED);

		    if ( strcmp(fcname,PFT_TFALL_O) == 0 ) {
		        pfop_term_opt   = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,1),aat_pre,PFT_NOT_ORDERED);
		    } else {
		        pfop_term_opt   = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }

		    mvar_t *tjsres = new_var(1);
		    execute(
		        assgn(var(tjsres->name),
			    tj_tfall(
				var(fc_loop->name),
				var (PF_MIL_VAR_WS),
				var(pfop_term->name),
				var(pfop_term_opt->name)
			    )
			)
		    );
		    unpin(pfop_term,1);
		    unpin(pfop_term_opt,1);

		    pft_unpack_pfop(p,tjsres,fc_iter_a,fc_item_a,aat_int,0,fc_pos_a,0);
		    unpin(tjsres,1);
		} else if ( (strcmp(fcname,PFT_TF) == 0) ||
			    (strcmp(fcname,PFT_TF_O) == 0) ) {
		    mvar_t *pfop_el;
		    mvar_t *pfop_str;
		    mvar_t *pfop_opt;

		    pfop_el = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,0),aat_pre,PFT_NOT_ORDERED);
		    pfop_str = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,1),aat_str,PFT_NOT_ORDERED);

		    if ( strcmp(fcname,PFT_TF_O) == 0 ) {
		        pfop_opt   = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,2),aat_pre,PFT_NOT_ORDERED);
		    } else {
		        pfop_opt   = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }

		    mvar_t *tjsres = new_var(1);
		    execute(
		        assgn(var(tjsres->name),
			    tj_tf(
				var(fc_loop->name),
				var (PF_MIL_VAR_WS),
				var(pfop_el->name),
				var(pfop_str->name),
				var(pfop_opt->name)
			    )
			)
		    );
		    unpin(pfop_el,1);
		    unpin(pfop_str,1);
		    unpin(pfop_opt,1);

		    pft_unpack_pfop(p,tjsres,fc_iter_a,fc_item_a,aat_int,0,fc_pos_a,0);
		    unpin(tjsres,1);
		} else if ( (strcmp(fcname,PFT_FBTERMS) == 0) ||
			    (strcmp(fcname,PFT_FBTERMS_O) == 0) ) {
		    mvar_t *pfop_terms;
		    mvar_t *pfop_term_opt;

		    pfop_terms = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,0),aat_pre,PFT_NOT_ORDERED);

		    if ( strcmp(fcname,PFT_FBTERMS_O) == 0 ) {
		        pfop_term_opt   = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,1),aat_pre,PFT_NOT_ORDERED);
		    } else {
		        pfop_term_opt   = pft_create_pfop(NULL,aat_pre,PFT_NOT_ORDERED);
		    }

		    mvar_t *tjsres = new_var(1);
		    execute(
		        assgn(var(tjsres->name),
			    tj_fbterms(
				var(fc_loop->name),
				var (PF_MIL_VAR_WS),
				var(pfop_terms->name),
				var(pfop_term_opt->name)
			    )
			)
		    );
		    unpin(pfop_terms,1);
		    unpin(pfop_term_opt,1);

		    pft_unpack_pfop(p,tjsres,fc_iter_a,fc_item_a,aat_str,0,fc_pos_a,0);
		    unpin(tjsres,1);
		} else if (strcmp(fcname,PFT_SCORE) == 0 ) {
		    mvar_t *pfop_id;
		    mvar_t *pfop_nodes;

		    pfop_id = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,0),aat_int,PFT_NOT_ORDERED);
		    pfop_nodes = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,1),aat_pre,PFT_NOT_ORDERED);

		    mvar_t *tjsres = new_var(1);
		    execute(
		        assgn(var(tjsres->name),
			    tj_query_score(
				var(fc_loop->name),
				var(pfop_id->name),
				var(pfop_nodes->name),
				var (PF_MIL_TIJAH_SCORE_DB)
			    )
			)
		    );
		    unpin(pfop_id,1);
		    unpin(pfop_nodes,1);

		    pft_unpack_pfop(p,tjsres,fc_iter_a,fc_item_a,aat_dbl,0,fc_pos_a,0);

		    unpin(tjsres,1);
		} else if (strcmp(fcname,PFT_NODES) == 0 ) {
		    mvar_t *pfop_id;

		    pfop_id = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,0),aat_int,PFT_NOT_ORDERED);

		    mvar_t *tjnres = new_var(1);
		    execute(
		        assgn(var(tjnres->name),
			    tj_query_nodes(
				var(fc_loop->name),
				var(pfop_id->name),
				var (PF_MIL_TIJAH_SCORE_DB)
			    )
			)
		    );
		    unpin(pfop_id,1);

		    pft_unpack_pfop(p,tjnres,fc_iter_a,fc_item_a,aat_pre,fc_item_a,fc_pos_a,0);

		    unpin(tjnres,1);
		} else if ( (strcmp(fcname,PFT_TOKENIZE) == 0) ||
			    (strcmp(fcname,PFT_RESSIZE) == 0) ) {
		    PFpa_op_t* op1 = *(PFpa_op_t **)PFarray_at(fun_params,0);

		    /* copy the iter bat */
	            mvar_t *p_iter = env_mvar (
                                         op1->env,
                                         op1->schema.items[0].name /* iter */,
                                         aat_nat);
		    pin(p_iter,p->refctr);
                    env_add (p->env, fc_iter_a, aat_nat, p_iter);

                    mvar_t *new_item  = new_var (p->refctr);
		    if ( strcmp(fcname,PFT_TOKENIZE) == 0 ) {
	                mvar_t *p_item = env_mvar (
                                             op1->env,
                                             op1->schema.items[2].name /* item */,
                                             aat_str);
                        execute (
                           assgn (var (new_item->name),
		               tj_tokenize( var(p_item->name) ) ) );
                        env_add (p->env, fc_item_a, aat_str, new_item);
		    } else {
		        /* must be RESSIZE */
	                mvar_t *p_item = env_mvar (
                                             op1->env,
                                             op1->schema.items[2].name /* item */,
                                             aat_int);
			/* "var res := item%s.join(tijah_scoreDB.fetch(4@0));\n" */
                        execute (
                           assgn (var (new_item->name),
		               tmark (join( var(p_item->name), 
			       	     fetch( var(PF_MIL_TIJAH_SCORE_DB),
				         lit_int(4)) ), lit_oid (0)) ) );
                        env_add (p->env, fc_item_a, aat_int, new_item);
		    }
		    PFalg_simple_type_t postype = op1->schema.items[1].type;
		    /* now copy the pos bat */
	            mvar_t *p_pos  = env_mvar_unsafe (
                                         op1->env,
                                         op1->schema.items[1].name /* pos */,
                                         postype);
		    if ( !p_pos && (postype & aat_pre) ) {
		        /* it must be a polymorpic pos, try it with only aat_pre as type */
	               	p_pos  = env_mvar (
                                         op1->env,
                                         op1->schema.items[1].name /* pos */,
                                         aat_pre);
		    } else {
		        /* make it generate the original error */
	                p_pos  = env_mvar(
                                         op1->env,
                                         op1->schema.items[1].name /* pos */,
                                         postype);
		    }
		    pin(p_pos,p->refctr);
                    env_add (p->env, fc_pos_a, aat_nat, p_pos);
		} else if (strcmp(fcname,PFT_INFO) == 0 ) {
		    mvar_t *pfop_names;

		    int fpsz = PFarray_last (fun_params);

		    if ( fpsz == 0 ) {
		        pfop_names = pft_create_pfop(NULL,aat_str,PFT_NOT_ORDERED);
		    } else {
		        pfop_names = pft_create_pfop(*(PFpa_op_t **)PFarray_at (fun_params,0),aat_str,PFT_NOT_ORDERED);
		    }

		    mvar_t *tjires = new_var(1);
		    execute(
		        assgn(var(tjires->name),
			    tj_ft_index_info(
				var (PF_MIL_VAR_WS),
				var(fc_loop->name),
				var(pfop_names->name)
			    )
			)
		    );
		    unpin(pfop_names,1);

		    pft_unpack_pfop(p,tjires,fc_iter_a,fc_item_a,aat_pre,fc_item_a,fc_pos_a,0);

		    unpin(tjires,1);
		} else {
	    	    PFoops (OOPS_FATAL,"milgen.brg: PFTIJAH fun_call() bad function[%s]!!!\n",fcname);
		}
	    } else {
	    	    PFoops (OOPS_FATAL,"milgen.brg: PFTIJAH fun_call() bad function[%s]!!!\n",fcname);
	    }
#endif /* PFTIJAH */
                }   break; /* fold) */

                /* Query caching */
                case alg_fun_call_cache:
                {
                    mvar_t     *res_bat  = new_var (1);
                    mvar_t     *res_iter = new_var (p->refctr);
                    mvar_t     *res_pos  = new_var (p->refctr);
	            PFalg_col_t iter     = p->schema.items[0].name;
	            PFalg_col_t pos      = p->schema.items[1].name;
	            PFalg_col_t item     = p->schema.items[2].name;

                    mvar_t     *loop = env_mvar (L(p)->env,
                                                 p->sem.fun_call.iter,
                                                 aat_nat);

                    PFpa_op_t  *param    = *(PFpa_op_t **)
                                               PFarray_at (fun_params, 0);
                    PFalg_col_t id_col   = param->schema.items[2].name;
                    char       *id;

                    /* use the function call argument to extract the cache id */
                    assert (PFprop_const (param->prop, id_col));
                    id = PFprop_const_val (param->prop, id_col).val.str;

                    /* find the BAT that corresponds to a cache id */
                    execute (
                        assgn (var (res_bat->name),
                        cache_get(var (PF_MIL_VAR_WS),
                              lit_str (id))));

                    /* Lookup all item columns in the same order as
                       rule 131 ('cache (Side, Rel)') puts them into
                       the container. */
                    int counter = 0;
                    for (PFalg_simple_type_t t = 1; t; t <<= 1)
                        if (t & TYPE_MASK(type_of (p, item))) {
                            mvar_t *tmp = new_var (p->refctr);
                            execute (
                                assgn (
                                    var (tmp->name),
                                    fetch (var (res_bat->name),
                                           lit_int (counter++))));
                            env_add (p->env, item, t, tmp);
                        }
                    unpin(res_bat, 1);

                    /* Cope with a singleton loop relation
                       and fill in the iter and position
                       information. */
                    if (PFprop_card (L(p)->prop) == 1) {
                        execute (
                            assgn (
                                var (res_iter->name),
                                project (
                                    ANY_VAR(p->env),
                                    fetch (var (loop->name),
                                           lit_int(0)))),
                            assgn (
                                var (res_pos->name),
                                mark (
                                    ANY_VAR(p->env),
                                    lit_oid (0))));
                    }
                    /* Allow the loop lifting of the cached query
                       by multiplying the output with the cardinality
                       of the loop relation. */
                    else {
                        mvar_t *map = new_var (1);
                        /* map the result to the current loop cardinality */
                        execute (
                            assgn (
                                var (map->name),
                                cross (ANY_VAR(p->env),
                                       var (loop->name))),
                            assgn (
                                var (res_iter->name),
                                tmark (var (map->name), lit_oid (0))),
                            /* Use old head values of the item sequence
                               to get a partitioned position column. */
                            assgn (
                                var (res_pos->name),
                                hmark (var (map->name), lit_oid (0))),
                            assgn (
                                var (map->name),
                                hmark (var (map->name), lit_oid (0))));

                        /* Update all item columns in the environment.
                           (Columns pos and iter are only added after
                           the mapping.) */
                        for (unsigned int i = 0; i < env_count (p->env); i++)
                            execute (
                                assgn (
                                    var (env_at (p->env, i).mvar->name),
                                    leftfetchjoin (
                                        var (map->name),
                                        var (env_at (p->env, i).mvar->name))));
                        unpin(map, 1);
                    }

                    /* add the iter and pos columns to ensure that
                       the output matches the schema */
                    env_add (p->env, iter, aat_nat, res_iter);
                    env_add (p->env, pos, aat_nat, res_pos);

                }   break;
            } /* fold) */

            /* Unpin all MIL variables that represent the function parameters.
               (They have 1 additional pin (see rule fun_param) to ensure
                their visibility in this operator.) */
            for (unsigned int i = 0; i < PFarray_last (fun_params); i++) {
                param = *((PFpa_op_t **) PFarray_at (fun_params, i));
                for (unsigned int j = 0; j < PFarray_last (param->env); j++)
                    unpin (((env_t *) PFarray_at (param->env, j))->mvar, 1);
            }

            /* restore the function arguments */
            fun_params = old_fun_params;
        }   break; /* fold) */

        /* Param:    fun_param (Rel, Param) */
        case 152: /* fold( */
        {   /* TOPDOWN */

            /* translate the argument itself */
            reduce (kids[0], nts[0]);

            /* copy the complete environment of the argument */
            env_copy (p, L(p)->env);

            /* Add an extra pin to every function argument to ensure
               that they are only free'ed AFTER the fun_call operator. */
            for (unsigned int i = 0; i < PFarray_last (p->env); i++)
                pin (((env_t *) PFarray_at (p->env, i))->mvar, 1);
            
            /* Append the new parameter to function parameter list */
            *((PFpa_op_t **) PFarray_add (fun_params)) = p;

            /* go on to next arguments */
            reduce (kids[1], nts[1]);
        }   break; /* fold) */
        /* Param:    nil */
        case 154:
            /* end of parameter list */
            break;

        /* Rel:      string_join (Rel, Rel) */
        case 160: /* fold( */
        {
            mvar_t *str  = new_var (1);
            mvar_t *iter = new_var (p->refctr);
            mvar_t *item = new_var (p->refctr);

            execute (
                assgn (var (str->name),
                       string_join (
                           leftjoin (
                               reverse (VAR(L(p)->env,
                                            p->sem.ii.iter,
                                            aat_nat)),
                               VAR(L(p)->env, p->sem.ii.item, aat_str)),
                           leftjoin (
                               reverse (VAR(R(p)->env,
                                            p->sem.ii.iter,
                                            aat_nat)),
                               VAR(R(p)->env, p->sem.ii.item, aat_str)))),
                assgn (var (iter->name),
                       reverse (mark (var (str->name), lit_oid (0)))),
                assgn (var (item->name),
                       reverse (
                           mark (reverse (var (str->name)), lit_oid (0)))));

            unpin (str, 1);
            env_add (p->env, p->sem.ii.iter, aat_nat, iter);
            env_add (p->env, p->sem.ii.item, aat_str, item);
        }   break; /* fold) */

        /* Rel:      findnodes (Rel) */
        case 170: /* fold( */
        {
            mvar_t *nodes     = new_var (1);
            mvar_t *iter      = new_var (p->refctr);
            mvar_t *item_res  = new_var (p->refctr);
            mvar_t *frag_res  = new_var (p->refctr);
            PFmil_t *pre      = VAR (L(p)->env,
                                     p->sem.findnodes.item_doc,
                                     aat_pre),
                    *pre_cont = VAR (L(p)->env,
                                     p->sem.findnodes.item_doc,
                                     aat_frag);

            execute (
                assgn (var (nodes->name),
                       ws_findnodes (
                           var (PF_MIL_VAR_WS),
                           VAR (L(p)->env, p->sem.findnodes.iter, aat_nat),
                           pre,
                           set_kind (pre_cont, var (PF_MIL_VAR_ELEM)),
                           pre_cont,
                           VAR (L(p)->env, p->sem.findnodes.item, aat_str),
                           p->sem.findnodes.id == la_dj_id ? lit_bit (true) :
                                                             lit_bit (false))));

            execute (
                assgn (var (iter->name),
                       leftfetchjoin (hmark (var (nodes->name), lit_oid(0)),
                                      VAR (L(p)->env,
                                           p->sem.findnodes.iter,
                                           aat_nat))),
                assgn (var (item_res->name),
                       tmark ( var (nodes->name), lit_oid(0))),
                assgn (var (frag_res->name),
                       leftfetchjoin (hmark (var (nodes->name), lit_oid(0)),
                                      pre_cont)));

            env_add (p->env, p->sem.findnodes.iter, aat_nat, iter);
            env_add (p->env, p->sem.findnodes.item_res, aat_pre, item_res);
            env_add (p->env, p->sem.findnodes.item_res, aat_frag, frag_res);

            unpin (nodes, 1);

        }   break; /* fold) */

        /* Rel:      vx_lookup (Rel) */
        case 171: /* fold( */
        {
            mvar_t *nodes     = new_var (1);
            mvar_t *iter      = new_var (p->refctr);
            mvar_t *item_res  = new_var (p->refctr);
            mvar_t *frag_res  = new_var (p->refctr);
            PFmil_t *pre      = VAR (L(p)->env,
                                     p->sem.vx_lookup.item_doc,
                                     aat_pre),
                    *pre_cont = VAR (L(p)->env,
                                     p->sem.vx_lookup.item_doc,
                                     aat_frag);

            execute (
                assgn (var (nodes->name),
                       m_vx_lookup (
                           var (PF_MIL_VAR_WS),
                           VAR (L(p)->env, p->sem.vx_lookup.iter, aat_nat),
                           pre,
                           p->sem.vx_lookup.id ? 
                                set_kind (pre_cont, var (PF_MIL_VAR_ELEM)):
                                set_kind (pre_cont, var (PF_MIL_VAR_ATTR)),
                           VAR (L(p)->env, p->sem.vx_lookup.item, aat_str),
                           lit_str(p->sem.vx_lookup.ns1),
                           lit_str(p->sem.vx_lookup.loc1),
                           lit_str(p->sem.vx_lookup.ns2),
                           lit_str(p->sem.vx_lookup.loc2),
                           p->sem.vx_lookup.id ? lit_bit (false) : lit_bit (true))));

            execute (
                assgn (var (iter->name),
                       leftfetchjoin (hmark (var (nodes->name), lit_oid(0)),
                                      VAR (L(p)->env,
                                           p->sem.vx_lookup.iter,
                                           aat_nat))),
                assgn (var (item_res->name),
                       tmark ( var (nodes->name), lit_oid(0))),
                assgn (var (frag_res->name),
                       leftfetchjoin (hmark (var (nodes->name), lit_oid(0)),
                                      pre_cont)));

            env_add (p->env, p->sem.vx_lookup.iter, aat_nat, iter);
            env_add (p->env, p->sem.vx_lookup.item_res, aat_pre, item_res);
            env_add (p->env, p->sem.vx_lookup.item_res, aat_frag, frag_res);

            unpin (nodes, 1);

        }   break; /* fold) */

        default:
            PFoops (OOPS_FATAL, "unknown rule %u", rule);
            break;
    }

    for (unsigned short c = 0; nts[c]; c++)
        for (unsigned int i = 0; i < PFarray_last (kids[c]->env); i++)
            unpin (((env_t *) PFarray_at (kids[c]->env, i))->mvar, 1);

#ifndef NDEBUG
    execute (comment ("End rule: \"%s\"", PFmilgen_string[rule]));

    for (unsigned int i = 0; i < PFarray_last (p->env); i++)
        assert (((env_t *) PFarray_at (p->env, i))->mvar->pins);
#endif

#ifndef NDEBUG
    /* Debugging only: assign column names to BATs */
    /* switch off debugging information as it triggers errors in MonetDB...
    for (unsigned int i = 0; i < env_count (p->env); i++)
        execute (col_name (var (env_at (p->env, i).mvar->name),
                           lit_str (PFcol_str (env_at (p->env, i).col))));
    */
#endif

} /* fold) */

/**
 * @brief Collect the number of references
 *        for each physical algebra operator @a n.
 */
static void
inc_refctr (PFpa_op_t *n)
{ /* fold( */
    assert (n);

    /* count number of incoming edges */
    n->refctr++;

    /* only descend once */
    if (SEEN(n))
        return;
    else
        SEEN(n) = true;

    for (unsigned int i = 0; i < PFPA_OP_MAXCHILD && n->child[i]; i++)
        inc_refctr (n->child[i]);
} /* fold) */

/** @brief Assign the brg state labels to the physical algebra tree */
static void
label (PFpa_op_t *p)
{ /* fold( */
    if (!L(p) && !R(p)) {
        STATE_LABEL(p) = PFmilgen_state (OP_LABEL(p), 0, 0);
    }
    else if (L(p) && !R(p)) {
        if (!SEEN(L(p))) label (L(p));
        STATE_LABEL(p) = PFmilgen_state (OP_LABEL(p),
                                         STATE_LABEL(L(p)),
                                         0);
    }
    else if (!L(p) && R(p)) {
        if (!SEEN(R(p))) label (R(p));
        STATE_LABEL(p) = PFmilgen_state (OP_LABEL(p),
                                         STATE_LABEL(R(p)),
                                         0);
    }
    else {
        if (!SEEN(L(p))) label (L(p));
        if (!SEEN(R(p))) label (R(p));
        STATE_LABEL(p) = PFmilgen_state (OP_LABEL(p),
                                         STATE_LABEL(L(p)),
                                         STATE_LABEL(R(p)));
    }
    SEEN(p) = true;
} /* fold) */

/** @brief Compile physical algebra tree into a MIL program. */
PFmil_t *
PFmilgen (PFpa_op_t *n, char *genType)
{
    PFmil_t   *bodymilprog;
    PFarray_t *opt;
    bool       nocache = false;
    long long  timeout = 0;
    char      *qid     = NULL;

    /* Retrieve session information from the global option list. */
    opt = PFenv_lookup (PFoptions, PFqname(PFns_lib, "session-id"));
    if (opt) {
        qid = *((char **) PFarray_at (opt, 0));
        if (PFarray_last(opt) > 1)
            PFlog ("Multiple session IDs -- "
                   "Choosing pf:session-id \"%s\".",
                   qid);
    }
    opt = PFenv_lookup (PFoptions, PFqname(PFns_lib, "session-timeout"));
    if (opt) {
        timeout = strtoll (*((char **) PFarray_at (opt, 0)), NULL, 10);
        if (timeout <= 0)
            PFoops (OOPS_FATAL, "Invalid session timeout: \"%s\".",
                    *((char **) PFarray_at (opt, 0)));
        if (PFarray_last(opt) > 1)
            PFlog ("Multiple session timeouts -- "
                   "Choosing pf:session-timeout \"%s\".",
                   *((char **) PFarray_at (opt, 0)));
    }
    opt = PFenv_lookup (PFoptions, PFqname(PFns_lib, "session-nocache"));
    if (opt) {
        char *mode = *((char **) PFarray_at (opt, 0));
        if (PFarray_last(opt) > 1)
            PFlog ("Multiple session modes -- "
                   "Choosing pf:session-nocache \"%s\".", mode);
        nocache = strcmp(mode, "true") == 0 || strcmp(mode, "yes") == 0;
    }

    assert (n);

    /* set counters in algebra tree nodes */
    inc_refctr (n);
    PFpa_dag_reset (n);

    /* enrich algebra tree with state labels for subsequent reduce() call */
    label (n);
    PFpa_dag_reset (n);

    /* we start with an empty MIL program */
    milprog = declare (unused ());

    execute (declare (var (PF_MIL_VAR_WS)),
             comment ("variable controlling the output format"),
             declare (var (PF_MIL_VAR_GENTYPE)),
             assgn (var (PF_MIL_VAR_GENTYPE), lit_str (genType)),
             assgn (unused (), nil ()));

    /* prepare the storage structure for the side
       effect of a trace operator: the trace output */
    execute (comment ("trace structure"),
             declare (var (PF_MIL_VAR_TRACE_OUTER)),
             declare (var (PF_MIL_VAR_TRACE_INNER)),
             declare (var (PF_MIL_VAR_TRACE_ITER )),
             declare (var (PF_MIL_VAR_TRACE_MSG  )),
             declare (var (PF_MIL_VAR_TRACE_ITEM )),
             declare (var (PF_MIL_VAR_TRACE_TYPE )),
             declare (var (PF_MIL_VAR_TRACE_REL  )),
             assgn (var (PF_MIL_VAR_TRACE_OUTER),
                    new (type (mty_oid), type (mty_bat))),
             assgn (var (PF_MIL_VAR_TRACE_INNER),
                    new (type (mty_oid), type (mty_bat))),
             assgn (var (PF_MIL_VAR_TRACE_ITER ),
                    new (type (mty_oid), type (mty_bat))),
             assgn (var (PF_MIL_VAR_TRACE_MSG  ),
                    new (type (mty_oid), type (mty_bat))),
             assgn (var (PF_MIL_VAR_TRACE_ITEM ),
                    new (type (mty_oid), type (mty_bat))),
             assgn (var (PF_MIL_VAR_TRACE_TYPE ),
                    new (type (mty_oid), type (mty_int))),
             assgn (var (PF_MIL_VAR_TRACE_REL  ),
                    new (type (mty_oid), type (mty_oid))));

    /* initialize list of variables we use */
    mvars = PFarray (sizeof (mvar_t *), 100);

    /* initialize the variable name counter
       with the first free variable number */
    varno = PF_MIL_RES_VAR_COUNT;
    
    /* dummy initializations */
    twig_state      = NULL;
    fun_params      = NULL;

    /* initialize tracing counter */
    global_trace_id = 1;

    /* start compilation */
    reduce (n, 1);

#ifndef NDEBUG
    mvar_t *var = NULL;
    for (unsigned int i = 0; i < PFarray_last (mvars); i++)
        if ((var = *(mvar_t **) PFarray_at (mvars, i))->pins) {
            if (var->pins == 1)
                PFinfo (OOPS_WARNING,
                        "variable %s stilled pinned once.",
                        PFmil_var_str (var->name));
            else
                PFinfo (OOPS_WARNING,
                        "variable %s stilled pinned %i times.",
                        PFmil_var_str (var->name), var->pins);
        }
#endif

    bodymilprog = milprog;

    milprog = seq (
#ifdef HAVE_PFTIJAH
		   /* create pftijah score db */
    		   declare (var (PF_MIL_TIJAH_SCORE_DB)),
    		   declare (var (PF_MIL_TIJAH_FTINAME)),
                   assgn (var (PF_MIL_TIJAH_SCORE_DB), 
                          seqbase (new (type (mty_void), type(mty_bat) ),
                                            lit_oid (0))),
    		   declare (var (PF_MIL_TIJAH_DUMMYPOS)),
                   assgn (var (PF_MIL_TIJAH_DUMMYPOS), 
                          new (type (mty_oid), type(mty_oid) ) ),
		   append (var (PF_MIL_TIJAH_SCORE_DB),
		          seqbase (new (type (mty_void), type(mty_oid) ),
			           lit_oid (0))),
		   append (var (PF_MIL_TIJAH_SCORE_DB),
		          seqbase (new (type (mty_void), type(mty_oid) ),
			           lit_oid (0))),
		   append (var (PF_MIL_TIJAH_SCORE_DB),
		          seqbase (new (type (mty_void), type(mty_oid) ),
			           lit_oid (0))),
		   append (var (PF_MIL_TIJAH_SCORE_DB),
		          seqbase (new (type (mty_void), type(mty_dbl) ),
			           lit_oid (0))),
		   append (var (PF_MIL_TIJAH_SCORE_DB),
		          new (type (mty_lng), type(mty_lng) ) ),
    		   declare (var (PF_MIL_TIJAH_FTI_TAPE)),
                   assgn (var (PF_MIL_TIJAH_FTI_TAPE), 
                          (new (type (mty_str), type(mty_bat) ))),
#endif

                   /* add xrpc_* vars */
                   declare (var (PF_MIL_VAR_XRPC_QID)),
                   declare (var (PF_MIL_VAR_XRPC_CALLER)),
                   declare (var (PF_MIL_VAR_XRPC_HDL)),
                   declare (var (PF_MIL_VAR_XRPC_SEQNR)),
                   declare (var (PF_MIL_VAR_XRPC_TIMEOUT)),
                   declare (var (PF_MIL_VAR_XRPC_MODE)),
                   declare (var (PF_MIL_VAR_XRPC_MODULE)),
                   declare (var (PF_MIL_VAR_XRPC_METHOD)),
                   declare (var (PF_MIL_VAR_XRPC_COORD)),

                   assgn (var (PF_MIL_VAR_XRPC_QID), lit_str(qid?qid:"")),
                   assgn (var (PF_MIL_VAR_XRPC_CALLER), lit_str("")),
                   assgn (var (PF_MIL_VAR_XRPC_HDL), lit_int(0)),
                   assgn (var (PF_MIL_VAR_XRPC_SEQNR), lit_lng(0)),
                   assgn (var (PF_MIL_VAR_XRPC_TIMEOUT), lit_lng(timeout)),
                   assgn (var (PF_MIL_VAR_XRPC_MODE),
                          lit_str (qid ? nocache
                                         ? "use-cache-repeatable"
                                         : "cache-repeatable"
                                       : "none")),
                   assgn (var (PF_MIL_VAR_XRPC_MODULE), lit_str("")),
                   assgn (var (PF_MIL_VAR_XRPC_METHOD), lit_str("")),
                   assgn (var (PF_MIL_VAR_XRPC_COORD), lit_str("")),

                   /* add timing information */
                   declare (var (PF_MIL_VAR_TIME_LOAD)),
                   declare (var (PF_MIL_VAR_TIME_QUERY)),
                   declare (var (PF_MIL_VAR_TIME_PRINT)),
                   assgn (var (PF_MIL_VAR_TIME_LOAD), lit_int (0)),
                   assgn (var (PF_MIL_VAR_TIME_PRINT), lit_int (0)),
                   assgn (var (PF_MIL_VAR_TIME_QUERY), usec ()),
                 );
                   
    /* prepend variable declarations before the actual program */
    for (unsigned int i = 0; i < PFarray_last (mvars); i++)
        milprog = seq (milprog,
                       declare (
                           var ((*(mvar_t **) PFarray_at (mvars, i))->name)));

    milprog = seq (milprog,
                   bodymilprog,
                   /* add timing information */
                   assgn (var (PF_MIL_VAR_TIME_QUERY),
                          sub (usec (),
                               var (PF_MIL_VAR_TIME_QUERY))),
                   assgn (var (PF_MIL_VAR_TIME_QUERY),
                          sub (var (PF_MIL_VAR_TIME_QUERY),
                               var (PF_MIL_VAR_TIME_LOAD))),
                   assgn (var (PF_MIL_VAR_TIME_QUERY),
                          sub (var (PF_MIL_VAR_TIME_QUERY),
                               var (PF_MIL_VAR_TIME_PRINT))),
                   assgn (var (PF_MIL_VAR_TIME_LOAD),
                          div_ (
                              cast (type (mty_dbl),
                                    var (PF_MIL_VAR_TIME_LOAD)),
                              lit_dbl (1000.0))),
                   assgn (var (PF_MIL_VAR_TIME_QUERY),
                          div_ (
                              cast (type (mty_dbl),
                                    var (PF_MIL_VAR_TIME_QUERY)),
                              lit_dbl (1000.0))),
                   assgn (var (PF_MIL_VAR_TIME_PRINT),
                          div_ (
                              cast (type (mty_dbl),
                                    var (PF_MIL_VAR_TIME_PRINT)),
                              lit_dbl (1000.0))));

    return milprog;
}

/* vim:set shiftwidth=4 expandtab filetype=c foldmarker=fold(,fold) foldmethod=marker foldopen-=search: */
