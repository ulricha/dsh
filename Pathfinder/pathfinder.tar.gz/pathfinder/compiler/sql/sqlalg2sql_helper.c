/**
 * @file
 *
 * Implementation of helper functions for translation of SQL algebra to SQL.
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * $Id$
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"

/** assert() */
#include <assert.h>
/** fprintf() */
#include <stdio.h>

#include "oops.h"             /* PFoops() */
#include "mem.h"

#include "sqlalg2sql_helper.h"
#include "sqlalg2sql_mnemonic.h"

/* Helper struct for function substitute_aliases */
struct sql_alias_map_t
{
    PFsql_aident_t new;
    PFsql_aident_t old;
};
typedef struct sql_alias_map_t sql_alias_map_t;

/* Helper function that constructs a sql_collist_item */
collist_item_t
PFsqlalg2sql_new_sql_collist_item (PFalg_col_t col,
                                   PFalg_simple_type_t type,
                                   PFsql_t *expr)
{
    return (collist_item_t) {
        .type = type,
        .col = col,
        .expression = expr
    };
}

/* Helper function that constructs a sql_fromlist_item */
fromlist_item_t
PFsqlalg2sql_new_sql_fromlist_item (PFsql_t *tbl, PFsql_t *al)
{
    return (fromlist_item_t) {
        .table = tbl,
        .alias = al
    };
}

/* static variable that holds the current col-number
   (used by function new_sql_col) */
static unsigned int col_varno = PF_SQL_RES_COLUMN_COUNT;

/* static variable that holds the actual alias-number
   (used by function new_alias) */
static unsigned int alias_varno = PF_SQL_RES_ALIAS_COUNT;

/* Variable that holds the actual table-number
   (used by function new_table_name) */
static unsigned int table_varno = PF_SQL_RES_TABLE_COUNT;

/* Returns a new table name. */
PFsql_tident_t
PFsqlalg2sql_new_table_name (void)
{
    return table_varno++;
}

/** Returns a new alias. */
PFsql_aident_t
PFsqlalg2sql_new_alias (void)
{
    return alias_varno++;
}

/* Returns a new column name
   (also storing its logical algebra name and its type). */
PFsql_col_t *
PFsqlalg2sql_new_sql_col (PFalg_col_t col, PFalg_simple_type_t ty)
{
    PFsql_col_t *ret = (PFsql_col_t *) PFmalloc (sizeof (PFsql_col_t));
    ret->spec = -1;
    ret->col = col;
    ret->ty  = ty;
    ret->id  = col_varno++;
    return ret;
}

/* Helper function to reset name and alias variables so that the
   names and aliases in each query start from scratch */
void
PFsqlalg2sql_reset_names_aliases_varnos ()
{
    col_varno = PF_SQL_RES_COLUMN_COUNT;
    alias_varno = PF_SQL_RES_ALIAS_COUNT;
    table_varno = PF_SQL_RES_TABLE_COUNT;
}

/* Helper function that copies the col, from and where
   lists from one SQL algebra operater to another */
void
PFsqlalg2sql_copy_lists_from_to (PFsa_op_t *from, PFsa_op_t *to)
{
    COLLIST(to) = column_l_copy(COLLIST(from));
    FROMLIST(to) = from_l_copy(FROMLIST(from));
    WHERELIST(to) = where_l_copy(WHERELIST(from));
}

/* Construct a SQL literal from a given algebra atom. */
PFsql_t *
PFsqlalg2sql_new_sql_literal (PFalg_atom_t atom)
{
    if (atom.is_null)
        return PFsql_null ();

    switch (atom.type) {
        case aat_nat: return PFsql_lit_int (atom.val.nat_);
        case aat_int: return PFsql_lit_int (atom.val.int_);
        case aat_str: return PFsql_lit_str (atom.val.str);
        case aat_bln: return PFsql_lit_int (atom.val.bln?1:0);
        case aat_dbl: return PFsql_lit_dec (atom.val.dbl);
        case aat_dec: return PFsql_lit_dec (atom.val.dec_);
        default:
            break;
    }

    PFoops (OOPS_FATAL,
            "SQLgen: a relational algebra type (0x%X) has not "
            "been implemented yet.",
            atom.type);

    /* satisfy picky compilers */
    return NULL;
}

/* Transform the fromlist of a SQL algebra operator into a list of
   SQL alias binds needed for construction of SQL operators. */
PFsql_t *
PFsqlalg2sql_transform_frommap (PFsa_op_t *p)
{
    PFsql_t        *fromlist = NULL;
    fromlist_item_t from_clause;

    assert (from_l_size(FROMLIST(p)));

    for (int i = from_l_size(FROMLIST(p)) - 1; i >= 0; i--) {
        from_clause = from_l_at(FROMLIST(p), i);
        fromlist = PFsql_from_list (fromlist,
                                    PFsql_alias_bind (
                                        from_clause.table,
                                        from_clause.alias));
    }

    return fromlist;
}

/* Transform a wherelist of a SQL algebra operator into a list of
   SQL predicates needed for construction of SQL operators. */
PFsql_t *
PFsqlalg2sql_transform_wheremap (PFsa_op_t *n)
{
    PFsql_t *wherelist = NULL;
    PFsql_t *where_clause;

    for (int i = where_l_size(WHERELIST(n)) - 1; i >= 0; i--) {
        where_clause = where_l_at (WHERELIST(n), i);
        wherelist = PFsql_where_list (wherelist, where_clause);
    }

    return wherelist;
}

/* Transform a SQL expression @a n into another SQL expression that
   can be put in a selectlist to represent @a col: If @a n already represents
   the desired @a col return it. Otherwise put @a n in a column assign
   operator ('@a n AS @a col'). In case @a col is a bool we have to build a case
   statement. */
PFsql_t *
PFsqlalg2sql_transform_expression (PFsql_t *n, PFsql_t *col)
{
    assert (col->kind == sql_column_name);

    /* we have a different strategy when our item is boolean */
    if (col->sem.column.name->ty == aat_bln) {
        n = (n->kind == sql_column_name || n->kind == sql_lit_int)
            ? n
            : PFsql_case (PFsql_when (n, PFsql_lit_int (1)),
                          PFsql_else (PFsql_lit_int (0)));
    }

    if (n->kind == sql_column_name) {
        if (n->sem.column.name->col == col->sem.column.name->col &&
            n->sem.column.name->ty == col->sem.column.name->ty)
            return n;
        else
            return PFsql_column_assign (n, col);
    }
    else
        return PFsql_column_assign (n, col);
}

/* Helper function that searches in a list @a col_list for an item
   with column col */
collist_item_t
PFsqlalg2sql_col_env_lookup (PFsqlalg2sql_collist_t *col_list, PFalg_col_t col)
{
    collist_item_t coll_item;

    for (unsigned int i = 0; i < column_l_size(col_list); i++) {
        coll_item = column_l_at (col_list, i);
        if (coll_item.col == col) {
             return coll_item;
        }
    }

    PFoops (OOPS_FATAL, "Column %s not found in column list.", PFcol_str (col));

    /* Pacify picky compilers */
    return (collist_item_t) { .type       = 0,
                              .col        = col_NULL,
                              .expression = NULL };
}

/* Helper function for substitute_aliases:
   It recursively replaces all "old" table aliases (map[].old)
   in the SQL operator sqlnode by "new" ones (map[].new). */
static void
substitute_aliases_helper (PFsql_t *sqlnode,
                           sql_alias_map_t map[],
                           unsigned int map_count)
{
    unsigned int i;

    /* Descend the tree */
    for (i = 0; i < PFSQL_OP_MAXCHILD && sqlnode->child[i]; i++)
        substitute_aliases_helper (sqlnode->child[i], map, map_count);

    /* Replace the aliases in either a column name...  */
    if ((sqlnode->kind == sql_column_name &&
        sqlnode->sem.column.alias != PF_SQL_ALIAS_UNBOUND)) {
            for (i = 0; i < map_count; i++)
                if (map[i].old == sqlnode->sem.column.alias) {
                    sqlnode->sem.column.alias = map[i].new;
                    break;
                }
    /* ...or a ref column name */
    } else if (sqlnode->kind == sql_ref_column_name) {
        for (i = 0; i < map_count; i++)
            if (map[i].old == sqlnode->sem.ref_column_name.alias) {
                sqlnode->sem.ref_column_name.alias = map[i].new;
                break;
            }
    }

}

/* Substitue all table aliases in the col, from and where list
   of SQL algebra operator n by new ones. */
void
PFsqlalg2sql_substitute_aliases (PFsa_op_t *n)
{
    unsigned int       i,
                       mapsize = from_l_size(FROMLIST(n));
    sql_alias_map_t    map[mapsize];
    PFsql_t           *whl_item;
    collist_item_t     coll_item;

    /* Create new aliases and store them togther with the old ones in map */
    for (i = 0; i < from_l_size(FROMLIST(n)); i++) {
        map[i].new = new_alias ();
        map[i].old = (from_l_at(FROMLIST(n), i)).alias->sem.alias.name;

        (from_l_at(FROMLIST(n), i)).alias
            = PFsql_op_duplicate ((from_l_at(FROMLIST(n), i)).alias);
        (from_l_at(FROMLIST(n), i)).table
            = PFsql_op_duplicate ((from_l_at(FROMLIST(n), i)).table);

        (from_l_at(FROMLIST(n), i)).alias->sem.alias.name = map[i].new;
    }

    /* Substitute the old alias for the new one in the COLLIST */
    for (i = 0; i < column_l_size(COLLIST(n)); i++) {
        coll_item = column_l_at(COLLIST(n), i);
        coll_item.expression = PFsql_op_duplicate (coll_item.expression);
        substitute_aliases_helper (coll_item.expression, map, mapsize);
        column_l_at(COLLIST(n), i) = coll_item;
    }

    /* Substitute the old alias for the new one in the WHERELIST.
       Although for now we substitute aliases only on bound
       operators (i.e. operators with empty WHERELIST) we keep
       this code block to support later uses  */
    for (i = 0; i < where_l_size(WHERELIST(n)); i++) {
        whl_item = PFsql_op_duplicate (where_l_at(WHERELIST(n), i));
        substitute_aliases_helper (whl_item, map, mapsize);
        where_l_at(WHERELIST(n), i) = whl_item;
    }
}

/* vim:set shiftwidth=4 expandtab filetype=c: */
