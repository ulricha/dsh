/**
 * @file
 *
 * Transforms the SQL algebra tree into a tree that represents
 * SQL statements.
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * $Id$
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"

/** assert() */
#include <assert.h>
/** fprintf() */
#include <stdio.h>
/** strcpy, strlen, ... */
#include <string.h>

#include "oops.h"             /* PFoops() */
#include "mem.h"
#include "array.h"
#include "string_utils.h"

#include "sqlalg2sql.h"

/* Easily access subtree-parts */
#include "child_mnemonic.h"

#include "sqlalg.h"
#include "sql.h"
#include "sqlalg_dag.h"
#include "sqlalg_mnemonic.h"
#include "sqlalg_opt.h"
#include "sqlalg2sql_helper.h"
#include "sqlalg2sql_mnemonic.h"

#include "alg_cl_mnemonic.h"

/* Collect the SQL statements during compilation here */
static PFsql_t *sql_stmts;

/* ---- Auxilliary functions used during translation  ---- */

/* Append a SQL algebra operator to the sequence of common table expressions */
#define append_cte(c) sql_stmts = (sql_stmts == NULL)                          \
                                  ? PFsql_common_table_expr (PFsql_nil(), (c)) \
                                  : PFsql_common_table_expr (sql_stmts, (c));

/**
 * FIXME This is for test purposes! (Building same select lists
 * in 'old' and 'new' translation in order to compare results with
 * vimdiff)
 * Check if a column @a b appears in list @a a.
 */
static bool
clin (PFalg_collist_t *a, PFalg_col_t b)
{
    if (!a) return false;

    for (unsigned int i = 0; i < clsize (a); i++)
        if (b == clat (a, i))
            return true;

    return false;
}

/* Bind operator @a n: Create a new SELECT-FROM-WHERE statement either as new
   common table expression (if @a n is referenced by more than one operator)
   or as a nested subquery (if @a n is referenced by just one operator) */
static void
bind_operator (PFsa_op_t *n, bool distinct)
{
    /* Only bind the operator if it is not already bound */
    if (BOUND(n)) return;

    unsigned int       i;
    PFsql_t           *bind       = NULL;
    PFsql_t           *sfw_block  = NULL;
    PFsql_t           *selectlist = NULL;
    PFsql_t           *columnlist = NULL;
    collist_item_t     coll_item;
    PFsql_col_t       *newcol     = NULL;
    PFsql_tident_t     newtable;
    PFsql_aident_t     newalias   = new_alias ();

    /* Prepare the selection lists, the column list, and fill in
       the new bindings for the column environment */
    for (i = 0; i < column_l_size(COLLIST(n)); i++) {
        coll_item = column_l_at(COLLIST(n), i);
        newcol = new_sql_col (coll_item.col, coll_item.type);

        /* Create columnlist for the table name */
        columnlist = PFsql_column_list (columnlist,
                                        PFsql_column_name (
                                            PF_SQL_ALIAS_UNBOUND,
                                            newcol));

        /* Add the sql operation to the select list */
        selectlist = PFsql_select_list (
                         selectlist,
                         transform_expression (
                             coll_item.expression,
                             PFsql_column_name (PF_SQL_ALIAS_UNBOUND,
                                                newcol)));

        /* Override expression with columnname */
        coll_item.expression = PFsql_column_name (newalias, newcol);

        /* Override column map entry */
        column_l_at(COLLIST(n), i) = coll_item;
    }

    /* Build the SELECT-FROM-WHERE statement */
    sfw_block = PFsql_select (distinct,
                              selectlist,
                              transform_frommap (n),
                              transform_wheremap (n),
                              NULL,
                              NULL);

    /* Clear the from and the where list */
    FROMLIST(n) = from_l(1);
    WHERELIST(n) = where_l(1);

    /* If the operator is referred to more than once, we bind
       it as new CTE, otherwise, we add it as a nested subquery
       to the frommap */
    if (n->refctr > 1) {
        newtable = new_table_name ();
        bind = PFsql_bind (PFsql_table_def (newtable, columnlist),
                           sfw_block);

        /* Append new bind operator to the CTE sequence */
        append_cte(bind);

        /* add the new binding to the from list */
        from_l_add(FROMLIST(n)) = new_sql_fromlist_item (
                                      PFsql_table_name (newtable),
                                      PFsql_alias (newalias));
    }
    else {
        /* Add the SFW block to the from list as nested subquery */
        from_l_add (FROMLIST(n)) = new_sql_fromlist_item (
                                       sfw_block,
                                       PFsql_alias_def (
                                           newalias,
                                           columnlist));
    }

    /* Mark node n as bound */
    BOUND(n) = true;
}

/* ----- Translate the SQL algebra into SQL algebra ----- */

/* Translate SQL algebra expressions into SQL algebra operators */
static PFsql_t *
sqlalg_expr2sql (PFsa_expr_t *expr, PFsqlalg2sql_collist_t *col_list)
{
    switch (expr->kind) {

        case sa_expr_column:
            return (col_env_lookup (col_list, expr->sem.col.old)).expression;

        case sa_expr_atom:
            return new_sql_literal (expr->sem.atom.atom);

        case sa_expr_comp:
        {
            PFsql_t *l = sqlalg_expr2sql (L(expr), col_list),
                    *r = sqlalg_expr2sql (R(expr), col_list);

            switch (expr->sem.comp.kind) {
                case sa_comp_equal:    return PFsql_eq (l, r);
                case sa_comp_gt:       return PFsql_gt (l, r);
                case sa_comp_gte:      return PFsql_gteq (l, r);
                case sa_comp_lt:       return PFsql_gt (r, l);
                case sa_comp_lte:      return PFsql_gteq (r, l);
                case sa_comp_notequal: return PFsql_not (PFsql_eq (l, r));
            }
        }
            break;

        case sa_expr_func:
        {
           PFsql_t *l  = sqlalg_expr2sql (L(expr), col_list),
                   *r  = R(expr) ?
                         sqlalg_expr2sql (R(expr), col_list) :
                         NULL;

            switch (expr->sem.func.name) {
                case sa_func_add:             return PFsql_add (l, r);
                case sa_func_sub:             return PFsql_sub (l, r);
                case sa_func_mult:            return PFsql_mul (l, r);
                case sa_func_div:             return PFsql_div (l, r);
                case sa_func_mod:             return PFsql_modulo (l, r);
                case sa_func_and:             return PFsql_and (l, r);
                case sa_func_or:              return PFsql_or (l, r);
                case sa_func_like:            return PFsql_like (l, r);
                case sa_func_not:             return PFsql_not (l);
                case sa_func_year_from_date:  return PFsql_year (l);
                case sa_func_month_from_date: return PFsql_month (l);
                case sa_func_day_from_date:   return PFsql_day (l);
                case sa_func_substring:       return PFsql_substring (l, r);
                /* substring-len has 3 children */
                case sa_func_substring_len:   return PFsql_substring_length (
                                                         l, r, sqlalg_expr2sql (
                                                                   expr->child[2],
                                                                   col_list));
            }
         }
            break;

        case sa_expr_aggr:
        {
           PFsql_t *l = L(expr) ?
                        sqlalg_expr2sql (L(expr), col_list) :
                        NULL;

            switch (expr->sem.aggr.kind) {
                case sa_aggr_sum:   return PFsql_sum (l);
                case sa_aggr_avg:   return PFsql_avg (l);
                case sa_aggr_max:   return PFsql_max (l);
                case sa_aggr_min:   return PFsql_min (l);
                case sa_aggr_count: return L(expr) ? PFsql_count (l)
                                                   : PFsql_count (PFsql_star());
            }
        }
            break;

        case sa_expr_convert:
        {
            PFalg_simple_type_t type        = L(expr)->type;
            PFalg_simple_type_t result_type = expr->type;

            #define DEC_TYPE(t)    ((t == aat_dec) || \
                                    (t == aat_dbl))
            #define INT_TYPE(t)    ((t == aat_int) || \
                                    (t == aat_nat))
            #define CHAR_TYPE(t)   ((t == aat_str) || \
                                    (t == aat_uA))
            #define DATE_TYPE(t)    (t == aat_date)

            /* Don't cast if not necessary */
            if ((type == result_type) ||
                (DEC_TYPE(type) && DEC_TYPE(result_type))  ||
                (INT_TYPE(type) && INT_TYPE(result_type))  ||
                (CHAR_TYPE(type) && CHAR_TYPE(result_type)) ||
                (DATE_TYPE(type) && DATE_TYPE(result_type)) )
                return sqlalg_expr2sql (L(expr), col_list);

            if (!CHAR_TYPE(type) && DATE_TYPE(result_type))
                PFoops (OOPS_FATAL, "Cast to date expects string as input");

            return PFsql_cast (sqlalg_expr2sql (L(expr), col_list),
                               PFsql_type (result_type));
        }
            break;

        case sa_expr_num_gen:
        {
            unsigned int i;
            PFsa_exprlist_t *sort_exprs    = NULL;
            PFsa_exprlist_t *part_exprs    = NULL;
            PFsql_t         *sql_part_list = NULL;
            PFsql_t         *sql_sort_list = NULL;
            PFsa_expr_t     *curr_expr     = NULL;
            PFsql_t         *expr_in_sql   = NULL;
            PFsql_t         *(*op) (void);

            if (expr->sem.num_gen.kind == sa_num_gen_rowid ||
                expr->sem.num_gen.kind == sa_num_gen_rownum)
                op = PFsql_row_number;
            else
                op = PFsql_dense_rank;

            /* Build (possibly empty) partition list */
            part_exprs = expr->sem.num_gen.part_cols;
            for (i = 0; i < elsize(part_exprs); i++) {
                curr_expr = elat (part_exprs, i);
                expr_in_sql = sqlalg_expr2sql (curr_expr, col_list);

                sql_part_list = PFsql_column_list (
                        sql_part_list,
                        expr_in_sql);
            }

            /* Build (possibly empty) sort list */
            sort_exprs = expr->sem.num_gen.sort_cols;
            for (i = 0; i < elsize(sort_exprs); i++) {
                curr_expr = elat (sort_exprs, i);
                expr_in_sql = sqlalg_expr2sql (curr_expr, col_list);

                /* The PFsql_sortkey_item constructor
                   interprets 'true' as ASC while SQL algebra
                   interprets 'false' as ASC (following
                   the definition in algebra.h), so
                   negate sortorder */
                sql_sort_list = PFsql_sortkey_list (
                                    sql_sort_list,
                                    PFsql_sortkey_item (
                                        expr_in_sql,
                                        !curr_expr->sortorder));
            }

            return PFsql_over (op (),
                               PFsql_window_clause (
                                   sql_part_list ?
                                       PFsql_partition (sql_part_list) :
                                       NULL,
                                   sql_sort_list ?
                                       PFsql_order_by (sql_sort_list) :
                                       NULL));
        }
            break;

        case sa_expr_in:
        {
            unsigned int i;
            PFsql_t          *col            = col_env_lookup (
                                                   col_list,
                                                   expr->sem.in.col).expression;
            unsigned int      in_list_size   = elsize(expr->sem.in.in_list);
            PFsa_expr_t      *curr_expr      = NULL;
            PFsql_t         **item           = NULL;
            PFsql_t          *list_of_items  = NULL;

            item = PFmalloc (in_list_size * sizeof (PFsql_t *));
            list_of_items = PFmalloc (in_list_size * sizeof (PFsql_t *));

            /* expr->sem.in.in_list contains only  */
            for (i = 0; i < in_list_size; i++) {
                curr_expr = elat(expr->sem.in.in_list, i);
                
                if (curr_expr->kind == sa_expr_atom)
                    item[i] = new_sql_literal (curr_expr->sem.atom.atom);
                else if (curr_expr->kind == sa_expr_column)
                    item[i] = (col_env_lookup (
                                   col_list,
                                   curr_expr->sem.col.old)).expression;
            }
            list_of_items = PFsql_stmt_list_ (
                                    in_list_size,
                                    (const PFsql_t **) item);

            return PFsql_in (col, list_of_items);
        }

            break;
    }
    return NULL;
}

/* Translate SQL algebra operators into SQL algebra operators */
static void
sqlalg_op2sql (PFsa_op_t *n)
{
    unsigned int i;

    /* traverse child operators recursively */
    for (i = 0; i < PFSA_OP_MAXCHILD && n->child[i]; i++)
        if (!n->child[i]->bit_dag)
            /* If child was not seen before, translate it */
            sqlalg_op2sql (n->child[i]);
        else
            /* Child already seen, so this is another reference to it
               and we have to substitute the aliases */
            substitute_aliases (n->child[i]);

    /* Initialize sql annotation */
    n->sql_ann = PFmalloc (sizeof (PFsqlalg2sql_ann_t));
    BOUND(n)   = false;
    /* Mark node vistited */
    n->bit_dag = true;

    switch (n->kind) {

        case sa_op_nil_node:
            COLLIST(n) = column_l(1);
            FROMLIST(n) = from_l(1);
            WHERELIST(n) = where_l(1);
            break;

        case sa_op_serialize_rel:
        {
            /* Builds a final SQL SELECT-FROM-WHERE-ORDERBY
               construct on top of the plan to get some output */
            unsigned int    i;
            PFsa_expr_t    *curr_expr       = NULL;
            PFalg_col_t     curr_item;
            collist_item_t  item_as_sql;
            collist_item_t  pos_coll_item;
            collist_item_t  iter_coll_item;
            PFsql_t        *selectlist       = NULL;
            PFsql_t        *orderby          = NULL;
            PFsql_t        *final_query      = NULL;

            copy_lists_from_to (R(n), n);

            /* Translation from logical algebra operator 'serialize sequence'
               to SQL algebra operator 'serialize relation' leaves iter column
               NULL, so check for existence */
            if (n->sem.ser_rel.iter) {
                iter_coll_item = col_env_lookup (COLLIST(R(n)),
                                                 n->sem.ser_rel.iter);

                /* Add iter column to selection and order by list */
                selectlist = PFsql_select_list (
                                 selectlist,
                                 transform_expression (
                                     iter_coll_item.expression,
                                     PFsql_column_name (
                                         PF_SQL_ALIAS_UNBOUND,
                                         new_sql_col (iter_coll_item.col,
                                                      iter_coll_item.type))));

               orderby = PFsql_sortkey_list (
                              orderby,
                              PFsql_sortkey_item (
                                  iter_coll_item.expression,
                                  true));
            }

            for (i = 0; i < elsize(n->sem.ser_rel.order_list); i++) {
                curr_expr = elat(n->sem.ser_rel.order_list, i);
                pos_coll_item = col_env_lookup (COLLIST(R(n)),
                                                curr_expr->col);

                /* Add pos column to selection and order by list */
                selectlist = PFsql_select_list (
                                 selectlist,
                                 transform_expression (
                                     pos_coll_item.expression,
                                     PFsql_column_name (
                                         PF_SQL_ALIAS_UNBOUND,
                                         new_sql_col (pos_coll_item.col,
                                                      pos_coll_item.type))));

                /* The PFsql_sortkey_item constructor
                   interprets 'true' as ASC while SQL algebra
                   interprets 'false' as ASC (following
                   the definition in algebra.h), so
                   negate sortorder */
                orderby = PFsql_sortkey_list (
                              orderby,
                              PFsql_sortkey_item (
                                  pos_coll_item.expression,
                                  !curr_expr->sortorder));
            }

            /* Put the items in item list of ser_rel into selectlist */
            for (i = 0; i < clsize(n->sem.ser_rel.items); i++) {
                curr_item = clat(n->sem.ser_rel.items, i);
                item_as_sql = col_env_lookup (COLLIST(R(n)), curr_item);

                selectlist = PFsql_select_list (
                                 selectlist,
                                 transform_expression (
                                     item_as_sql.expression,
                                     PFsql_column_name (
                                         PF_SQL_ALIAS_UNBOUND,
                                         new_sql_col (item_as_sql.col,
                                                      item_as_sql.type))));
            }

            /* FIXME This is for test purposes! (Building same select lists
               in 'old' and 'new' translation in order to compare results with
               vimdiff) */
            PFsql_t        *sel2       = NULL;
            int j;
            for (j = (column_l_size (COLLIST(R(n))) - 1); j >= 0; j--) {
                collist_item_t coll_item = column_l_at (COLLIST(R(n)), j);
                if (clin (n->sem.ser_rel.items, coll_item.col) ||
                    n->sem.ser_rel.iter == coll_item.col)
                    sel2 = PFsql_select_list (
                               sel2,
                               transform_expression (
                                   coll_item.expression,
                                   PFsql_column_name (
                                       PF_SQL_ALIAS_UNBOUND,
                                       new_sql_col (coll_item.col,
                                                    coll_item.type))));
            }

            /* Build the final SELECT-FROM-WHERE-ORDERBY block */
            final_query = PFsql_select (false,
                                        /* selectlist, */
                                        sel2,
                                        transform_frommap (R(n)),
                                        transform_wheremap (R(n)),
                                        orderby,
                                        NULL);

            /* Check if there are already common-table expressions
               or if we have a standalone query */
            sql_stmts = (sql_stmts) ?
                        PFsql_root (PFsql_nil (),
                                    PFsql_with (sql_stmts, 
                                                final_query)) :
                        PFsql_root (PFsql_nil (),
                                    final_query);
        }
            break;

        case sa_op_literal_table:
        {
            unsigned int      i,
                              row,
                              col,
                              tuples_count;
            PFsql_aident_t    newalias       = new_alias ();
            PFalg_schm_item_t schm_item;
            PFalg_tuple_t    *tuples         = n->sem.literal_table.tuples;
            PFsql_t          *expr           = NULL;
            PFsql_t          *values         = NULL;
            PFsql_t          *columnlist     = NULL;
            PFsql_col_t      *newcol         = NULL;
            PFalg_atom_t      atom;
            PFsql_t         **tuple          = NULL;
            PFsql_t         **list_of_tuples = NULL;

            tuples_count = n->sem.literal_table.tuples_count;

            /* List to collect the values of one row of
               the literal table (i.e.: a tuple). */
            tuple = PFmalloc (n->schema.count * sizeof (PFsql_t *));

            /* List to collect the tuples of the literal table */
            list_of_tuples = PFmalloc (tuples_count * sizeof (PFsql_t *));

            /* Init lists for sql annotation */
            COLLIST(n)   = column_l(1);
            FROMLIST(n)  = from_l(1);
            WHERELIST(n) = where_l(1);

            /* Add columns of the literal table to col_list */
            for (i = 0; i < n->schema.count; i++) {
                schm_item = n->schema.items[i];
                newcol = new_sql_col (schm_item.name, schm_item.type);

                expr = PFsql_column_name (newalias, newcol);

                column_l_add(COLLIST(n)) = new_sql_collist_item (
                                               schm_item.name,
                                               schm_item.type,
                                               expr);

                /* Put cols in another list for construction
                   of VALUES(...) expression */
                columnlist = PFsql_column_list (columnlist,
                                                PFsql_column_name (
                                                    PF_SQL_ALIAS_UNBOUND,
                                                    newcol));
            }

            /* Build list of tuples for VALUES(...) expression */
            for (row = 0; row < tuples_count; row++) {
                for (col = 0; col < tuples[row].count; col++) {
                    atom = tuples[row].atoms[col];
                    /* Add atom to tuple */
                    tuple[col] = new_sql_literal (atom);
                }
                /* Add tuple to list of tuples */
                list_of_tuples[row] = PFsql_stmt_list_ (
                                          n->schema.count,
                                          (const PFsql_t **) tuple);
            }

            /* Construct VALUES(...) expression */
            values = PFsql_values (
                         PFsql_list_list_ (
                             tuples_count,
                             (const PFsql_t **) list_of_tuples));

            /* Add VALUES(...) expression to from_list */
            from_l_add(FROMLIST(n)) = new_sql_fromlist_item (values,
                                                             PFsql_alias_def (
                                                                 newalias,
                                                                 columnlist));
        }
            break;

        case sa_op_table:
        {
            unsigned int  i;
            PFsql_t       *tbl_ref     = PFsql_ref_table_name (n->sem.table.name);
            PFsql_aident_t newalias    = new_alias ();
            PFsql_t       *tbl_alias   = PFsql_alias (newalias);
            PFsa_expr_t   *expr        = NULL;
            PFsa_expr_t   *orgname     = NULL;
            PFsql_t       *tbl_col_ref = NULL;

            /* Init lists for sql annotation */
            COLLIST(n)   = column_l(1);
            FROMLIST(n)  = from_l(1);
            WHERELIST(n) = where_l(1);

            /* Add new table alias to from list */
            from_l_add(FROMLIST(n)) = new_sql_fromlist_item (tbl_ref,
                                                             tbl_alias);
            /* Put SQL algebra column exprs in column list together with a
               reference to their original name in the table */
            for (i = 0; i < elsize(n->sem.table.expr_list); i++) {
                expr = elat(n->sem.table.expr_list, i);
                orgname = elat(n->sem.table.col_names, i);

                tbl_col_ref = PFsql_ref_column_name (
                                  newalias,
                                  orgname->sem.atom.atom.val.str);

                column_l_add(COLLIST(n)) = new_sql_collist_item (
                                               expr->col,
                                               expr->type,
                                               tbl_col_ref);
            }
        }
            break;

        case sa_op_select:
        {
            unsigned int i;
            PFsa_expr_t *expr        = NULL;

            copy_lists_from_to (L(n), n);

            /* Add exprs to where list */
            for (i = 0; i < elsize(n->sem.select.expr_list); i++) {
                expr = elat(n->sem.select.expr_list, i);
                
                where_l_add(WHERELIST(n)) = sqlalg_expr2sql (expr, COLLIST(n));
            }
        }
            break;

        case sa_op_project:
        {
            unsigned int i;
            PFsa_expr_t  *expr        = NULL;
            PFsql_t      *expr_in_sql = NULL;

            copy_lists_from_to (L(n), n);
            /* Immediately overwrite copied COLLIST(n) and ... */
            COLLIST(n) = column_l(1);

            /* ... build a new one with the SQL algebra expressions */
            for (i = 0; i < elsize(n->sem.proj.expr_list); i++) {
                expr = elat(n->sem.proj.expr_list, i);
                expr_in_sql = sqlalg_expr2sql (expr, COLLIST(L(n)));

                column_l_add(COLLIST(n)) = new_sql_collist_item (
                                               expr->col,
                                               expr->type,
                                               expr_in_sql);
            }

            /* We assume that the optimization whatever they could to
               combine projections and we need to bind here definitely. */
            /* TODO Check another optimizetion */
            bind_operator (n, n->distinct);
            return;
        }
            break;

        case sa_op_union:
        case sa_op_except:
        {
            unsigned int i;
            PFsql_tident_t      newtable;
            PFsql_aident_t      newalias     = new_alias ();
            PFsql_t            *(*op) (const PFsql_t *, const PFsql_t *);
            PFsql_t            *set_query    = NULL;
            PFsql_t            *selectlist_l = NULL;
            PFsql_t            *selectlist_r = NULL;
            PFsql_t            *columnlist   = NULL;
            PFsql_t            *bind         = NULL;
            PFsql_col_t        *newcol       = NULL;
            PFalg_col_t         col;
            PFalg_simple_type_t ty;

            COLLIST(n)   = column_l(1);
            FROMLIST(n)  = from_l(1);
            WHERELIST(n) = where_l(1);

            if (n->kind == sa_op_except)
                op = PFsql_difference;
            else
                op = PFsql_union;

            /* Add columns from schema to column list and also to
               lists needed for construction of SQL algebra operators */
            for (i = 0; i < n->schema.count; i++) {
                col = n->schema.items[i].name;
                ty  = n->schema.items[i].type;
                newcol = new_sql_col (col, ty);

                column_l_add(COLLIST(n)) = new_sql_collist_item (
                                               col,
                                               ty,
                                               PFsql_column_name (
                                                   newalias,
                                                   newcol));

                columnlist = PFsql_column_list (columnlist,
                                                PFsql_column_name (
                                                    PF_SQL_ALIAS_UNBOUND,
                                                    newcol));

                selectlist_l = PFsql_select_list (
                                   selectlist_l,
                                   transform_expression (
                                       col_env_lookup (
                                           COLLIST(L(n)), col).expression,
                                       PFsql_column_name (
                                           PF_SQL_ALIAS_UNBOUND,
                                           newcol)));

                selectlist_r = PFsql_select_list (
                                   selectlist_r,
                                   transform_expression (
                                       col_env_lookup (
                                           COLLIST(R(n)), col).expression,
                                       PFsql_column_name (
                                           PF_SQL_ALIAS_UNBOUND,
                                           newcol)));
            }


            /* Build new UNION / EXCEPT query */
            set_query = op(PFsql_select (
                               false,
                               selectlist_l,
                               transform_frommap (L(n)),
                               transform_wheremap (L(n)),
                               NULL,
                               NULL),
                           PFsql_select (
                               false,
                               selectlist_r,
                               transform_frommap (R(n)),
                               transform_wheremap (R(n)),
                               NULL,
                               NULL));

             /* If this operator is referred to more than once, we bind
                it as new CTE, otherwise, we add it as a nested subquery in the
                frommap */
            if (n->refctr > 1) {
                newtable = new_table_name ();

                /* Bind new SQL algebra select operator to new table alias  */
                bind = PFsql_bind (PFsql_table_def (newtable, columnlist),
                                   set_query);

                /* Since we're about to bind, add new table alias to from list */
                from_l_add(FROMLIST(n)) = new_sql_fromlist_item (
                                              PFsql_table_name (newtable),
                                              PFsql_alias (newalias));

                /* Append new bind operator to the CTE sequence */
                append_cte(bind);
            } else {
                 from_l_add (FROMLIST(n)) = new_sql_fromlist_item (
                                                set_query,
                                                PFsql_alias_def (
                                                    newalias,
                                                    columnlist));
            }

            /* Mark node n as bound */
            BOUND(n) = true;
            return;
        }
            break;

        case sa_op_groupby:
        {
            unsigned int        i;
            PFsql_tident_t      newtable;
            PFsql_aident_t      newalias      = new_alias ();
            PFsql_t            *selectlist    = NULL;
            PFsql_t            *groupbylist   = NULL;
            PFsql_t            *columnlist    = NULL;
            PFsql_t            *bind          = NULL;
            PFsql_t            *groupby_query = NULL;
            PFsa_expr_t        *curr_expr     = NULL;
            PFsql_t            *expr_as_sql   = NULL;
            PFsql_col_t        *newcol        = NULL;
            PFalg_col_t         col;
            PFalg_simple_type_t ty;

            COLLIST(n)   = column_l(1);
            FROMLIST(n)  = from_l(1);
            WHERELIST(n) = where_l(1);

            /* Add columns from prj_list to column list and build
               up two other lists needed for construction of SQL
               algebra operators */
            for (i = 0; i < elsize(n->sem.groupby.prj_list); i++) {
                curr_expr = elat(n->sem.groupby.prj_list, i);
                col = curr_expr->col;
                ty  = curr_expr->type;
                newcol = new_sql_col (col, ty);

                column_l_add(COLLIST(n)) = new_sql_collist_item (
                                               col,
                                               ty,
                                               PFsql_column_name (newalias,
                                                                  newcol));

                columnlist = PFsql_column_list (columnlist,
                                                PFsql_column_name (
                                                    PF_SQL_ALIAS_UNBOUND,
                                                    newcol));

                selectlist = PFsql_select_list (selectlist,
                                                transform_expression (
                                                    sqlalg_expr2sql (curr_expr,
                                                                     COLLIST(L(n))),
                                                    PFsql_column_name (
                                                        PF_SQL_ALIAS_UNBOUND,
                                                        newcol)));
            }

            /* Add columns of grp_list to a list 'groupby' needed
               for construction of SQL algebra operator */
            for (i = 0; i < elsize(n->sem.groupby.grp_list); i++) {
                curr_expr = elat(n->sem.groupby.grp_list, i);
                col = curr_expr->col;
                ty  = curr_expr->type;
                
                expr_as_sql = sqlalg_expr2sql (curr_expr, COLLIST(L(n)));

                groupbylist = PFsql_column_list (groupbylist,
                                                 expr_as_sql);
            }

            /* Build new SQL algebra select operator  */
            groupby_query = PFsql_select (false,
                                          selectlist,
                                          transform_frommap (L(n)),
                                          transform_wheremap (L(n)),
                                          NULL,
                                          groupbylist);

             /* If this groupby operator is referred to more than once, we bind
                it as new CTE, otherwise, we add it as a nested subquery in the
                frommap */
             if (n->refctr > 1) {
                 newtable = new_table_name ();
                 bind = PFsql_bind (PFsql_table_def (newtable, columnlist),
                                    groupby_query);

                 /* Since we're about to bind, add new table alias to from list */
                 from_l_add(FROMLIST(n)) = new_sql_fromlist_item (
                                               PFsql_table_name (newtable),
                                               PFsql_alias (newalias));

                 /* Append new bind operator to the CTE sequence */
                 append_cte(bind);
             } else {
                 from_l_add (FROMLIST(n)) = new_sql_fromlist_item (
                                                groupby_query,
                                                PFsql_alias_def (
                                                    newalias,
                                                    columnlist));
             }

             /* Mark node n as bound */
             BOUND(n) = true;
             return;
        }
            break;

        case sa_op_cross:
        case sa_op_join:
        case sa_op_semijoin:
        {
            unsigned int i;
            PFsa_expr_t *curr_expr = NULL;

            /* Copy lists from left child */
            copy_lists_from_to (L(n), n);
            /* and from the right child ... */

            if (n->kind == sa_op_join || n->kind == sa_op_cross)
                column_l_append(COLLIST(n), column_l_copy(COLLIST(R(n))));

            from_l_append(FROMLIST(n), from_l_copy(FROMLIST(R(n))));
            where_l_append(WHERELIST(n), where_l_copy(WHERELIST(R(n))));

            /* Append join predicates to where list */
            if (n->kind == sa_op_join || n->kind == sa_op_semijoin) {
                for (i = 0; i < elsize(n->sem.join.expr_list); i++) {
                    curr_expr = elat(n->sem.join.expr_list, i);
                    where_l_add(WHERELIST(n)) = sqlalg_expr2sql (curr_expr,
                                                                 COLLIST(n));
                }
            }

            /* To translate the semijoin we have to bind with DISTINCT flag */
            if (n->kind == sa_op_semijoin) {
                bind_operator (n, true);
                return;
            }
        }
            break;

        case sa_op_antisemijoin:
        {
            unsigned int i;
            PFsa_expr_t *curr_expr    = NULL;
            bool not_in_flag          = true;
            PFsa_exprlist_t *lhs      = el(1);
            PFsa_exprlist_t *rhs      = el(1);
            PFsql_t *columnlist       = NULL;
            PFsql_t *selectlist_subq  = NULL;
            PFsql_col_t *newcol       = NULL;
            PFalg_col_t col;
            PFalg_simple_type_t ty;
            PFsql_t *subquery         = NULL;
            PFsql_t *not_in           = NULL;
            PFsql_t *not_exists       = NULL;
           
            copy_lists_from_to (L(n), n);

            /* Check if predicates are just equal expressions (then
               translate to NOT IN) or if the also contain other
               expressions (then translate to NOT EXISTS) */
            for (i = 0; i < elsize(n->sem.join.expr_list); i++) {
                curr_expr = elat(n->sem.join.expr_list, i);

                /* Save the left/right hand side of curr_expr
                   for the case we translate to NOT IN */
                eladd(lhs) = L(curr_expr);
                eladd(rhs) = R(curr_expr);
                
                /* If we find at least one expression that is not
                   an equal comparison, translate to NOT EXISTS */
                if (!(curr_expr->kind == sa_expr_comp &&
                      curr_expr->sem.comp.kind == sa_comp_equal))
                    not_in_flag = not_in_flag && false;
            }

            /* Translate to NOT IN */
            if (not_in_flag) {

                /* Build lhs column list, i.e. the list left of
                   the NOT IN statement */
                for (i = 0; i < elsize(lhs); i++) {
                    curr_expr = elat(lhs, i);
                    col = curr_expr->col;
                    ty = curr_expr->type;
                    newcol = new_sql_col (col, ty);

                    columnlist = PFsql_column_list (
                                       columnlist,
                                       transform_expression (
                                           col_env_lookup (
                                               COLLIST(L(n)), col).expression,
                                           PFsql_column_name (
                                               PF_SQL_ALIAS_UNBOUND,
                                               newcol)));
                }

                /* Build select list of subquery in the NOT IN
                   statement */
                for (i = 0; i < elsize(rhs); i++) {
                    curr_expr = elat(rhs, i);
                    col = curr_expr->col;
                    ty = curr_expr->type;
                    newcol = new_sql_col (col, ty);

                    selectlist_subq = PFsql_select_list (
                                          selectlist_subq,
                                          transform_expression (
                                              col_env_lookup (
                                                  COLLIST(R(n)), col).expression,
                                              PFsql_column_name (
                                                  PF_SQL_ALIAS_UNBOUND,
                                                  newcol)));
                }

                /* Build subquery */
                subquery = PFsql_select (
                               false,
                               selectlist_subq,
                               transform_frommap (R(n)),
                               transform_wheremap (R(n)),
                               NULL,
                               NULL);

                /* Build NOT IN sql operator */
                not_in = PFsql_not_in (
                             columnlist, 
                             subquery);

                /* Add NOT IN to where list */
                where_l_add(WHERELIST(n)) = not_in;

                /* Bind operator */
                bind_operator (n, false);
                return;

            } else {
            /* Translate to NOT EXISTS */

                /* Build select list for subquery, TODO: 'SELECT *' or
                   'SELECT foo' is also possible because of the existencial
                   semantics. Would that be understood by all DBMSs? */
                for (i = 0; i < R(n)->schema.count; i++) {
                    col = R(n)->schema.items[i].name;
                    ty  = R(n)->schema.items[i].type;
                    newcol = new_sql_col (col, ty);

                    selectlist_subq = PFsql_select_list (
                                          selectlist_subq,
                                          transform_expression (
                                              col_env_lookup (
                                                  COLLIST(R(n)), col).expression,
                                              PFsql_column_name (
                                                  PF_SQL_ALIAS_UNBOUND,
                                                  newcol)));
                }

                /* Put the join predicates into R(n)'s where list.
                   This introduces correlation */
                for (i = 0; i < elsize(n->sem.join.expr_list); i++) {
                    curr_expr = elat(n->sem.join.expr_list, i);
                    /* FIXME Better solution than appending collists? */
                    where_l_add(WHERELIST(R(n))) = sqlalg_expr2sql (curr_expr,
                                                                    column_l_append (
                                                                        COLLIST(L(n)),
                                                                        COLLIST(R(n))));
                }

                /* Build subquery */ 
                subquery = PFsql_select (
                               false,
                               selectlist_subq,
                               transform_frommap (R(n)),
                               transform_wheremap (R(n)),
                               NULL,
                               NULL);

                /* Build NOT EXISTS sql operator */
                not_exists = PFsql_not_exists (
                             subquery);

                /* Add NOT EXISTS into wherelist */
                where_l_add(WHERELIST(n)) = not_exists;

                /* Bind operator */
                bind_operator (n, false);
                return;
            }

        }
            break;
    }

   /* Bind if there is more than one reference */
   if (n->refctr > 1)
       bind_operator (n, false);
}

/* Translate the SQL algebra into SQL algebra */
PFsql_t *
PFsqlalg2sql (PFsa_op_t *n)
{
    /* reset return variable */
    sql_stmts = NULL;

    /* reset name and alias variables */
    reset_names_aliases_varnos ();

    /* start worker to fill sql_ann fields in n */
    PFsqlalg_dag_reset (n);
    PFsqlalg_infer_refctr (n);
    sqlalg_op2sql (n);
    PFsqlalg_dag_reset (n);

    return sql_stmts;
}

/* vim:set shiftwidth=4 expandtab filetype=c: */
