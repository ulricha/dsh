#line 1 "lalg2sql.brg"


/**
 * @file
 *
 * Transforms the logical algebra tree into a tree that represents
 * SQL statements.
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * $Id$
 */

/* always include pathfinder first */
#include "pf_config.h"
#include "pathfinder.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <algebra.h>

#include "lalg2sql.h"
#include "alg_dag.h"
#include "string_utils.h"
#include "mem.h"
#include "oops.h"             /* PFoops() */

/* mnemonic column list accessors */
#include "alg_cl_mnemonic.h"

/* Easily access subtree-parts */
#include "child_mnemonic.h"

/**
 * Annotations to logical algebra tree nodes. Used during
 * SQL code generation. (typedef resides in logical.h.)
 */
struct PFsql_alg_ann_t {
    unsigned        bound:1;       /**< indicates if the operator has been bound */

    PFarray_t       *colmap;       /**< Mapping table that maps (logical)
                                        column/type  pairs to their
                                        SQL expression or in case of
                                        a binding to their column names.
                                        (select list) */
    PFarray_t       *frommap;      /**< table--alias mappings */
    PFarray_t       *wheremap;     /**< contains references to the boolean
                                        in colmap */

    /* annotations needed to translate twig constructors (and path steps) */
    PFsql_t         *fragment;     /**< a fragment reference */
    PFsql_t         *content_size; /**< a reference to a content-size binding */

    unsigned int     twig_pre;     /**< local pre value for constructions
                                        with the twig-constructor */
    int              twig_size;    /**< local size value for constructions
                                        with the twig-constructor */
    unsigned int     twig_level;   /**< local level value for constructions
                                        with the twig-constructor */

    /* annotations needed to improve the query-part that provides the
       result relation for the serialization */
    ser_report_t     ser_report;   /**< serialization report */
    PFalg_collist_t *ser_list1;    /**< a list of columns to check further
                                        constraints */
    bool             bind;         /**< a boolean indicating if a numbering
                                        operator needs to be bound */
};

/**
 * Accessors for the burg pattern matcher
 */
typedef struct PFla_op_t *NODEPTR_TYPE;

/* accessor to the node kind */
#define OP_LABEL(p)     ((p)->kind)

/* accessors to left and right child node */
#define LEFT_CHILD(p)   ((p)->child[0])
#define RIGHT_CHILD(p)  ((p)->child[1])

/* the state, burg determines during the bottom up graph
 * traversal
 */
#define STATE_LABEL(p) ((p)->state_label)

/* the state of the children determined during
   bottom-up labeling is backed up here */
#define CHILD_STATE_LABEL(p,i) ((p)->child_state_label[i])

/* if an error occurs, call PFoops */
#define PANIC(...) PFoops (OOPS_BURG, __VA_ARGS__)

#ifndef PFlalg2sql_PANIC
#define PFlalg2sql_PANIC	PANIC
#endif /* PFlalg2sql_PANIC */
#include <stdlib.h> /* for abort() */
#ifdef NDEBUG
#define PFlalg2sql_assert(x,y)	;
#else
#define PFlalg2sql_assert(x,y)	if(!(x)) {y; abort();}
#endif
static short PFlalg2sql_r1_nts[] ={ 7, 3, 2, 0 };
static short PFlalg2sql_r5_nts[] ={ 7, 6, 6, 0 };
static short PFlalg2sql_r6_nts[] ={ 7, 3, 0 };
static short PFlalg2sql_r7_nts[] ={ 7, 2, 0 };
static short PFlalg2sql_r8_nts[] ={ 0 };
static short PFlalg2sql_r11_nts[] ={ 2, 0 };
static short PFlalg2sql_r12_nts[] ={ 2, 2, 0 };
static short PFlalg2sql_r40_nts[] ={ 2, 2, 2, 0 };
static short PFlalg2sql_r55_nts[] ={ 3, 2, 0 };
static short PFlalg2sql_r61_nts[] ={ 4, 0 };
static short PFlalg2sql_r64_nts[] ={ 3, 3, 0 };
static short PFlalg2sql_r65_nts[] ={ 3, 0 };
static short PFlalg2sql_r71_nts[] ={ 6, 0 };
static short PFlalg2sql_r78_nts[] ={ 6, 5, 0 };
static short PFlalg2sql_r80_nts[] ={ 2, 5, 0 };
static short PFlalg2sql_r100_nts[] ={ 7, 8, 0 };
static short PFlalg2sql_r101_nts[] ={ 2, 9, 0 };
static short PFlalg2sql_r102_nts[] ={ 2, 10, 0 };
static short PFlalg2sql_r109_nts[] ={ 2, 2, 12, 2, 0 };
static short PFlalg2sql_r110_nts[] ={ 12, 2, 0 };
static short PFlalg2sql_r118_nts[] ={ 2, 13, 0 };
static short PFlalg2sql_r120_nts[] ={ 3, 13, 0 };
short *PFlalg2sql_nts[] = {
	0,
	PFlalg2sql_r1_nts,
	PFlalg2sql_r1_nts,
	PFlalg2sql_r1_nts,
	PFlalg2sql_r1_nts,
	PFlalg2sql_r5_nts,
	PFlalg2sql_r6_nts,
	PFlalg2sql_r7_nts,
	PFlalg2sql_r8_nts,
	PFlalg2sql_r8_nts,
	PFlalg2sql_r8_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r12_nts,
	PFlalg2sql_r12_nts,
	PFlalg2sql_r12_nts,
	PFlalg2sql_r12_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r12_nts,
	PFlalg2sql_r12_nts,
	PFlalg2sql_r12_nts,
	PFlalg2sql_r11_nts,
	0,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	0,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	0,
	0,
	0,
	PFlalg2sql_r40_nts,
	0,
	0,
	PFlalg2sql_r12_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	0,
	PFlalg2sql_r55_nts,
	PFlalg2sql_r55_nts,
	PFlalg2sql_r55_nts,
	PFlalg2sql_r55_nts,
	PFlalg2sql_r55_nts,
	PFlalg2sql_r55_nts,
	PFlalg2sql_r61_nts,
	PFlalg2sql_r61_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r64_nts,
	PFlalg2sql_r65_nts,
	PFlalg2sql_r8_nts,
	0,
	0,
	0,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r71_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r78_nts,
	PFlalg2sql_r71_nts,
	PFlalg2sql_r80_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r80_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r55_nts,
	PFlalg2sql_r55_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFlalg2sql_r7_nts,
	PFlalg2sql_r8_nts,
	PFlalg2sql_r7_nts,
	PFlalg2sql_r100_nts,
	PFlalg2sql_r101_nts,
	PFlalg2sql_r102_nts,
	PFlalg2sql_r102_nts,
	PFlalg2sql_r8_nts,
	PFlalg2sql_r8_nts,
	PFlalg2sql_r8_nts,
	PFlalg2sql_r12_nts,
	PFlalg2sql_r12_nts,
	PFlalg2sql_r109_nts,
	PFlalg2sql_r110_nts,
	0,
	0,
	0,
	0,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r11_nts,
	PFlalg2sql_r118_nts,
	PFlalg2sql_r118_nts,
	PFlalg2sql_r120_nts,
	PFlalg2sql_r8_nts,
};
static unsigned char PFlalg2sql_serialize_seq_transition[4][8] = {
{    0,    0,    0,    0,    0,    0,    0,    0}	/* row 0 */,
{    0,    2,    3,    4,    5,    1,    2,    2}	/* row 1 */,
{    0,    2,    3,    4,    5,    1,    6,    6}	/* row 2 */,
{    0,    2,    3,    4,    5,    1,    6,    6}	/* row 3 */
};
static unsigned char PFlalg2sql_serialize_rel_transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */,
{    0,    1,    0}	/* row 2 */
};
static unsigned char PFlalg2sql_side_effects_transition[3][6] = {
{    0,    0,    0,    0,    0,    0}	/* row 0 */,
{    0,    4,    5,    2,    1,    3}	/* row 1 */,
{    0,    4,    0,    0,    1,    3}	/* row 2 */
};
static unsigned char PFlalg2sql_cross_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_eqjoin_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_semijoin_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_thetajoin_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_disjunion_transition[4][4] = {
{    0,    0,    0,    0}	/* row 0 */,
{    0,    2,    2,    2}	/* row 1 */,
{    0,    2,    1,    1}	/* row 2 */,
{    0,    2,    1,    1}	/* row 3 */
};
static unsigned char PFlalg2sql_intersect_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_difference_transition[2][4] = {
{    0,    0,    0,    0}	/* row 0 */,
{    0,    1,    3,    2}	/* row 1 */
};
static unsigned char PFlalg2sql_step_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_step_join_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_guide_step_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_guide_step_join_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_doc_index_join_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_doc_access_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_fcns_transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    0}	/* row 1 */,
{    0,    3,    2}	/* row 2 */
};
static unsigned char PFlalg2sql_docnode_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_element_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFlalg2sql_content_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_merge_adjacent_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_frag_union_transition[3][4] = {
{    0,    0,    0,    0}	/* row 0 */,
{    0,    2,    1,    3}	/* row 1 */,
{    0,    4,    4,    4}	/* row 2 */
};
static unsigned char PFlalg2sql_error_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_cache_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_trace_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_trace_items_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_trace_msg_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_trace_map_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_rec_fix_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    2}	/* row 1 */,
{    0,    1}	/* row 2 */
};
static unsigned char PFlalg2sql_rec_param_transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */,
{    0,    2,    1}	/* row 2 */
};
static unsigned char PFlalg2sql_rec_arg_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFlalg2sql_fun_call_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_fun_param_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_fun_frag_param_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFlalg2sql_string_join_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static struct {
	unsigned int f31:2;
	unsigned int f32:2;
	unsigned int f33:2;
	unsigned int f34:3;
	unsigned int f35:4;
	unsigned int f36:2;
	unsigned int f37:4;
	unsigned int f38:3;
	unsigned int f39:6;
	unsigned int f40:4;
} PFlalg2sql_plank_0[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  36,   0,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  37,   0,},	/* row 2 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  20,   0,},	/* row 3 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  20,   0,},	/* row 4 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  20,   0,},	/* row 5 */
	{   0,   0,   0,   0,   9,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  43,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  41,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  42,   0,},	/* row 9 */
	{   0,   0,   0,   4,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  38,   0,},	/* row 11 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   3,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 14 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  10,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  10,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  10,   0,},	/* row 17 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  35,   0,},	/* row 18 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  12,   0,},	/* row 19 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   9,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  24,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  25,   0,},	/* row 22 */
	{   0,   0,   0,   0,   0,   0,   6,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   4,   0,   0,   0,   0,   0,},	/* row 24 */
	{   0,   0,   0,   0,   6,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,},	/* row 26 */
	{   0,   0,   0,   0,   8,   0,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   7,   0,   0,   0,   0,   0,},	/* row 28 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  19,   0,},	/* row 31 */
	{   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 32 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 33 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 34 */
	{   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 35 */
	{   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 36 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 37 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 38 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 39 */
	{   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 40 */
	{   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 41 */
	{   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 42 */
	{   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 43 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  46,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  28,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  26,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  11,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  22,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   8,   0,   0,   0,},	/* row 52 */
	{   0,   1,   2,   3,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  45,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  44,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  14,   0,},	/* row 56 */
	{   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  16,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  16,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  16,   0,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  16,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  16,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  31,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  31,   0,},	/* row 66 */
	{   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   8,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   7,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   6,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  21,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  23,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  23,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  23,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  30,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  33,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  32,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  15,   0,},	/* row 81 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  18,   0,},	/* row 82 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   7,},	/* row 83 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 84 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,},	/* row 85 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   5,},	/* row 86 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   6,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,},	/* row 88 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   8,},	/* row 89 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   4,},	/* row 90 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  29,   0,},	/* row 96 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  27,   0,},	/* row 97 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  34,   0,},	/* row 98 */
	{   0,   0,   0,   0,   5,   0,   0,   0,   0,   0,},	/* row 99 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  17,   0,},	/* row 100 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  13,   0,},	/* row 101 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 102 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 103 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 104 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 105 */
	{   0,   0,   0,   0,   0,   0,   9,   0,   0,   0,},	/* row 106 */
	{   0,   0,   0,   0,   0,   0,   5,   0,   0,   0,},	/* row 107 */
	{   0,   0,   0,   0,   0,   0,   4,   0,   0,   0,},	/* row 108 */
	{   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,},	/* row 109 */
	{   0,   0,   0,   0,   0,   0,   7,   0,   0,   0,},	/* row 110 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 111 */
	{   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  40,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  39,   0,},	/* row 114 */
};
static struct {
	unsigned int f16:2;
	unsigned int f17:2;
	unsigned int f18:2;
	unsigned int f19:2;
	unsigned int f20:2;
	unsigned int f21:3;
	unsigned int f22:2;
	unsigned int f23:2;
	unsigned int f24:2;
	unsigned int f25:2;
	unsigned int f26:2;
	unsigned int f27:2;
	unsigned int f28:2;
	unsigned int f29:2;
	unsigned int f30:3;
} PFlalg2sql_plank_1[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 3 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 4 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 18 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 19 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   0,   0,   3,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 28 */
	{   0,   0,   0,   0,   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 31 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 32 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 33 */
	{   2,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 34 */
	{   2,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 35 */
	{   0,   0,   0,   0,   2,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 36 */
	{   0,   0,   0,   0,   2,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 37 */
	{   0,   0,   0,   0,   2,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 38 */
	{   0,   0,   0,   0,   2,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 39 */
	{   0,   0,   0,   0,   2,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 40 */
	{   0,   0,   0,   0,   2,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 41 */
	{   0,   0,   0,   0,   2,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 42 */
	{   0,   0,   0,   0,   2,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 43 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   2,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   3,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   0,   0,   3,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   1,   0,   0,   0,   0,   0,   1,   0,   0,   1,   0,   0,   1,   1,   1,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 81 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 82 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 83 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 84 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 85 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 86 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 89 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 90 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 95 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 96 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 97 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 98 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 99 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 100 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 101 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 102 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 103 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 104 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 105 */
	{   0,   0,   2,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 106 */
	{   0,   0,   1,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 107 */
	{   0,   0,   2,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 108 */
	{   0,   0,   2,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 109 */
	{   0,   0,   2,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 110 */
	{   0,   0,   2,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 111 */
	{   0,   0,   2,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 114 */
};
static struct {
	unsigned int f3:2;
	unsigned int f4:3;
	unsigned int f5:2;
	unsigned int f6:2;
	unsigned int f7:3;
	unsigned int f8:3;
	unsigned int f9:3;
	unsigned int f10:3;
	unsigned int f11:2;
	unsigned int f12:2;
	unsigned int f13:2;
	unsigned int f14:3;
	unsigned int f15:2;
} PFlalg2sql_plank_2[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   1,   0,   1,   1,   2,   3,   1,   1,   2,   1,   0,   0,   0,},	/* row 1 */
	{   1,   0,   1,   1,   3,   2,   1,   1,   2,   1,   0,   0,   0,},	/* row 2 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 3 */
	{   1,   0,   1,   1,   1,   1,   3,   1,   2,   1,   0,   0,   0,},	/* row 4 */
	{   1,   0,   1,   1,   1,   1,   2,   1,   2,   1,   0,   0,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   7,   2,},	/* row 6 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 7 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 8 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   2,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   2,},	/* row 13 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 14 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 15 */
	{   1,   0,   2,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 16 */
	{   1,   0,   3,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 17 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 18 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 19 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   2,   0,   0,   0,},	/* row 20 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 21 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 22 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   2,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   2,},	/* row 25 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   4,   2,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   2,},	/* row 28 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 29 */
	{   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 31 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 32 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 33 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 34 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 35 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 36 */
	{   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 37 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 38 */
	{   0,   5,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 39 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 40 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 41 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 42 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 43 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 44 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 48 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 49 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 50 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 53 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 54 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 55 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,},	/* row 57 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 58 */
	{   1,   0,   1,   1,   1,   1,   1,   3,   2,   1,   0,   0,   0,},	/* row 59 */
	{   1,   0,   1,   1,   1,   1,   1,   2,   2,   1,   0,   0,   0,},	/* row 60 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 61 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 62 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 63 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 64 */
	{   1,   0,   1,   1,   4,   1,   1,   1,   1,   1,   0,   0,   0,},	/* row 65 */
	{   1,   0,   1,   1,   5,   1,   1,   1,   1,   1,   0,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 69 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 70 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 71 */
	{   0,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 74 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 75 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 76 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 77 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 78 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 79 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 80 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 81 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 82 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 83 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 84 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 85 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 86 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 89 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 90 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 96 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 97 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 98 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   6,   2,},	/* row 99 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 100 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 101 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 102 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 103 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 104 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 105 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 106 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 107 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 108 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 109 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 110 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 111 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 112 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 113 */
	{   1,   0,   1,   1,   1,   1,   1,   1,   2,   1,   0,   0,   0,},	/* row 114 */
};
static struct {
	unsigned int f0:3;
	unsigned int f1:4;
	unsigned int f2:2;
} PFlalg2sql_plank_3[] = {
	{   0,   0,   0,},	/* row 0 */
	{   0,   1,   0,},	/* row 1 */
	{   0,   1,   0,},	/* row 2 */
	{   0,   1,   0,},	/* row 3 */
	{   0,   1,   0,},	/* row 4 */
	{   0,   1,   0,},	/* row 5 */
	{   0,   0,   0,},	/* row 6 */
	{   0,   1,   0,},	/* row 7 */
	{   0,   1,   0,},	/* row 8 */
	{   0,   1,   0,},	/* row 9 */
	{   0,   0,   2,},	/* row 10 */
	{   0,   1,   0,},	/* row 11 */
	{   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,},	/* row 13 */
	{   0,   1,   0,},	/* row 14 */
	{   0,   1,   0,},	/* row 15 */
	{   0,   1,   0,},	/* row 16 */
	{   0,   1,   0,},	/* row 17 */
	{   0,   1,   0,},	/* row 18 */
	{   0,   1,   0,},	/* row 19 */
	{   0,   3,   0,},	/* row 20 */
	{   0,   1,   0,},	/* row 21 */
	{   0,   1,   0,},	/* row 22 */
	{   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,},	/* row 24 */
	{   0,   0,   0,},	/* row 25 */
	{   0,   1,   0,},	/* row 26 */
	{   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,},	/* row 28 */
	{   0,   0,   0,},	/* row 29 */
	{   0,   2,   0,},	/* row 30 */
	{   0,   1,   0,},	/* row 31 */
	{   0,   0,   2,},	/* row 32 */
	{   0,   0,   0,},	/* row 33 */
	{   0,   0,   0,},	/* row 34 */
	{   0,   0,   0,},	/* row 35 */
	{   0,   0,   0,},	/* row 36 */
	{   0,   0,   0,},	/* row 37 */
	{   0,   0,   0,},	/* row 38 */
	{   0,   0,   0,},	/* row 39 */
	{   0,   0,   0,},	/* row 40 */
	{   0,   0,   0,},	/* row 41 */
	{   0,   0,   0,},	/* row 42 */
	{   0,   0,   0,},	/* row 43 */
	{   0,   1,   0,},	/* row 44 */
	{   0,   1,   0,},	/* row 45 */
	{   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,},	/* row 47 */
	{   0,   1,   0,},	/* row 48 */
	{   0,   1,   0,},	/* row 49 */
	{   0,   1,   0,},	/* row 50 */
	{   0,   1,   0,},	/* row 51 */
	{   0,   0,   0,},	/* row 52 */
	{   0,   0,   1,},	/* row 53 */
	{   0,   1,   0,},	/* row 54 */
	{   0,   1,   0,},	/* row 55 */
	{   0,   1,   0,},	/* row 56 */
	{   0,   0,   0,},	/* row 57 */
	{   0,   1,   0,},	/* row 58 */
	{   0,   1,   0,},	/* row 59 */
	{   0,   1,   0,},	/* row 60 */
	{   0,   4,   0,},	/* row 61 */
	{   0,   5,   0,},	/* row 62 */
	{   0,   1,   0,},	/* row 63 */
	{   0,   1,   0,},	/* row 64 */
	{   0,   1,   0,},	/* row 65 */
	{   0,   1,   0,},	/* row 66 */
	{   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,},	/* row 68 */
	{   0,   1,   0,},	/* row 69 */
	{   0,   1,   0,},	/* row 70 */
	{   0,   1,   0,},	/* row 71 */
	{   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,},	/* row 73 */
	{   0,   1,   0,},	/* row 74 */
	{   0,   7,   0,},	/* row 75 */
	{   0,   6,   0,},	/* row 76 */
	{   0,   1,   0,},	/* row 77 */
	{   0,   1,   0,},	/* row 78 */
	{   0,   1,   0,},	/* row 79 */
	{   0,   1,   0,},	/* row 80 */
	{   0,   1,   0,},	/* row 81 */
	{   0,   1,   0,},	/* row 82 */
	{   0,   0,   0,},	/* row 83 */
	{   0,   0,   0,},	/* row 84 */
	{   0,   0,   0,},	/* row 85 */
	{   0,   0,   0,},	/* row 86 */
	{   0,   0,   0,},	/* row 87 */
	{   0,   0,   0,},	/* row 88 */
	{   0,   0,   0,},	/* row 89 */
	{   0,   0,   0,},	/* row 90 */
	{   2,   0,   0,},	/* row 91 */
	{   0,   0,   0,},	/* row 92 */
	{   3,   0,   0,},	/* row 93 */
	{   1,   0,   0,},	/* row 94 */
	{   0,   0,   0,},	/* row 95 */
	{   0,   1,   0,},	/* row 96 */
	{   0,   1,   0,},	/* row 97 */
	{   0,   1,   0,},	/* row 98 */
	{   0,   0,   0,},	/* row 99 */
	{   0,   1,   0,},	/* row 100 */
	{   0,   1,   0,},	/* row 101 */
	{   0,   0,   2,},	/* row 102 */
	{   0,   0,   0,},	/* row 103 */
	{   0,   0,   0,},	/* row 104 */
	{   0,   0,   0,},	/* row 105 */
	{   0,   0,   0,},	/* row 106 */
	{   0,   0,   0,},	/* row 107 */
	{   0,   0,   0,},	/* row 108 */
	{   0,   0,   0,},	/* row 109 */
	{   0,   0,   0,},	/* row 110 */
	{   0,   0,   0,},	/* row 111 */
	{   0,   0,   0,},	/* row 112 */
	{   0,   1,   0,},	/* row 113 */
	{   0,   1,   0,},	/* row 114 */
};
static short PFlalg2sql_eruleMap[] = {
    0,  108,  107,    0,   75,   74,   73,   72,   71,   70,	/* 0-9 */
   77,   89,   76,    0,   66,   65,   64,   63,   62,    0,	/* 10-19 */
   78,   79,    0,  103,  104,    0,  102,    0,  121,  120,	/* 20-29 */
  119,    0,    8,    2,    4,    5,    1,    6,    7,    3,	/* 30-39 */
    0,  106,    0,   12,  118,  117,  116,  115,  110,  109,	/* 40-49 */
  105,   23,   22,   21,   20,   19,   18,   17,   16,   15,	/* 50-59 */
   14,   13,   11,   10,    9,   61,   60,   59,   58,   57,	/* 60-69 */
   56,   55,   53,   52,   51,   50,   43,   40,   36,   35,	/* 70-79 */
   33,   32,   31,   30,   29,   28,   27,   26,   25,    0,	/* 80-89 */
  100,   97,   98,   99,    0,  101,    0,   86,   87,   88,	/* 90-99 */
   80,   85,   81,   82,   83,   84
};
#define PFlalg2sql_Query_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_0[state].f40 +31]
#define PFlalg2sql_Rel_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_0[state].f39 +42]
#define PFlalg2sql_Frag_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_0[state].f38 +13]
#define PFlalg2sql_Constr_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_0[state].f37 +3]
#define PFlalg2sql_List_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_0[state].f36 +19]
#define PFlalg2sql_Twig_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_0[state].f35 +96]
#define PFlalg2sql_Side_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_0[state].f34 +89]
#define PFlalg2sql_Trc_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_1[state].f23 +94]
#define PFlalg2sql_Msg_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_1[state].f24 +25]
#define PFlalg2sql_Map_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_0[state].f33 +22]
#define PFlalg2sql_Rec_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_0[state].f32 +40]
#define PFlalg2sql_Arg_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_0[state].f31 +0]
#define PFlalg2sql_Param_rule(state)	PFlalg2sql_eruleMap[PFlalg2sql_plank_1[state].f30 +27]

#ifdef __STDC__
int PFlalg2sql_rule(int state, int goalnt) {
#else
int PFlalg2sql_rule(state, goalnt) int state; int goalnt; {
#endif
	PFlalg2sql_assert(state >= 0 && state < 115, PFlalg2sql_PANIC("Bad state %d passed to PFlalg2sql_rule\n", state));
	switch(goalnt) {
	case 1:
		return PFlalg2sql_Query_rule(state);
	case 2:
		return PFlalg2sql_Rel_rule(state);
	case 3:
		return PFlalg2sql_Frag_rule(state);
	case 4:
		return PFlalg2sql_Constr_rule(state);
	case 5:
		return PFlalg2sql_List_rule(state);
	case 6:
		return PFlalg2sql_Twig_rule(state);
	case 7:
		return PFlalg2sql_Side_rule(state);
	case 8:
		return PFlalg2sql_Trc_rule(state);
	case 9:
		return PFlalg2sql_Msg_rule(state);
	case 10:
		return PFlalg2sql_Map_rule(state);
	case 11:
		return PFlalg2sql_Rec_rule(state);
	case 12:
		return PFlalg2sql_Arg_rule(state);
	case 13:
		return PFlalg2sql_Param_rule(state);
	default:
		PFlalg2sql_PANIC("Unknown nonterminal %d in PFlalg2sql_rule;\n", goalnt);
		abort();
		return 0;
	}
}

int PFlalg2sql_TEMP;
#define PFlalg2sql_serialize_seq_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_serialize_seq_transition[PFlalg2sql_plank_3[l].f0][PFlalg2sql_plank_3[r].f1]) ? PFlalg2sql_TEMP + 84 : 0 )
#define PFlalg2sql_serialize_rel_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_serialize_rel_transition[PFlalg2sql_plank_3[l].f2][PFlalg2sql_plank_2[r].f3]) ? PFlalg2sql_TEMP + 82 : 0 )
#define PFlalg2sql_side_effects_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_side_effects_transition[PFlalg2sql_plank_3[l].f2][PFlalg2sql_plank_2[r].f4]) ? PFlalg2sql_TEMP + 90 : 0 )
#define PFlalg2sql_lit_tbl_state	51
#define PFlalg2sql_empty_tbl_state	30
#define PFlalg2sql_ref_tbl_state	74
#define PFlalg2sql_attach_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f5) ? PFlalg2sql_TEMP + 2 : 0 )
#define PFlalg2sql_cross_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_cross_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 13 : 0 )
#define PFlalg2sql_eqjoin_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_eqjoin_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 30 : 0 )
#define PFlalg2sql_semijoin_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_semijoin_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 81 : 0 )
#define PFlalg2sql_thetajoin_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_thetajoin_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 99 : 0 )
#define PFlalg2sql_project_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f7) ? PFlalg2sql_TEMP + 57 : 0 )
#define PFlalg2sql_select__state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 80 : 0 )
#define PFlalg2sql_pos_select_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 55 : 0 )
#define PFlalg2sql_disjunion_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_disjunion_transition[PFlalg2sql_plank_2[l].f8][PFlalg2sql_plank_2[r].f9]) ? PFlalg2sql_TEMP + 17 : 0 )
#define PFlalg2sql_intersect_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_intersect_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 49 : 0 )
#define PFlalg2sql_difference_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_difference_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_2[r].f10]) ? PFlalg2sql_TEMP + 14 : 0 )
#define PFlalg2sql_distinct_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 19 : 0 )
#define PFlalg2sql_fun_1to1_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 43 : 0 )
#define PFlalg2sql_num_eq_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 53 : 0 )
#define PFlalg2sql_num_gt_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 54 : 0 )
#define PFlalg2sql_bool_and_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 6 : 0 )
#define PFlalg2sql_bool_or_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 8 : 0 )
#define PFlalg2sql_bool_not_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 7 : 0 )
#define PFlalg2sql_to_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 100 : 0 )
#define PFlalg2sql_aggr_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f11) ? PFlalg2sql_TEMP + 0 : 0 )
#define PFlalg2sql_rownum_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 78 : 0 )
#define PFlalg2sql_rowrank_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 79 : 0 )
#define PFlalg2sql_rank_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f12) ? PFlalg2sql_TEMP + 64 : 0 )
#define PFlalg2sql_rowid_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 77 : 0 )
#define PFlalg2sql_type_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 112 : 0 )
#define PFlalg2sql_type_assert_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 113 : 0 )
#define PFlalg2sql_cast_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 10 : 0 )
#define PFlalg2sql_step_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_step_transition[PFlalg2sql_plank_2[l].f13][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 95 : 0 )
#define PFlalg2sql_step_join_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_step_join_transition[PFlalg2sql_plank_2[l].f13][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 96 : 0 )
#define PFlalg2sql_guide_step_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_guide_step_transition[PFlalg2sql_plank_2[l].f13][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 47 : 0 )
#define PFlalg2sql_guide_step_join_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_guide_step_join_transition[PFlalg2sql_plank_2[l].f13][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 48 : 0 )
#define PFlalg2sql_doc_index_join_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_doc_index_join_transition[PFlalg2sql_plank_2[l].f13][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 21 : 0 )
#define PFlalg2sql_doc_tbl_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 22 : 0 )
#define PFlalg2sql_doc_access_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_doc_access_transition[PFlalg2sql_plank_2[l].f13][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 20 : 0 )
#define PFlalg2sql_twig_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f14) ? PFlalg2sql_TEMP + 105 : 0 )
#define PFlalg2sql_fcns_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_fcns_transition[PFlalg2sql_plank_2[l].f15][PFlalg2sql_plank_1[r].f16]) ? PFlalg2sql_TEMP + 32 : 0 )
#define PFlalg2sql_docnode_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_docnode_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_1[r].f17]) ? PFlalg2sql_TEMP + 23 : 0 )
#define PFlalg2sql_element_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_element_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_1[r].f17]) ? PFlalg2sql_TEMP + 26 : 0 )
#define PFlalg2sql_attribute_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 5 : 0 )
#define PFlalg2sql_textnode_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 98 : 0 )
#define PFlalg2sql_comment_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 11 : 0 )
#define PFlalg2sql_processi_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 56 : 0 )
#define PFlalg2sql_content_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_content_transition[PFlalg2sql_plank_2[l].f13][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 12 : 0 )
#define PFlalg2sql_merge_adjacent_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_merge_adjacent_transition[PFlalg2sql_plank_2[l].f13][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 51 : 0 )
#define PFlalg2sql_roots__state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_1[l].f18) ? PFlalg2sql_TEMP + 74 : 0 )
#define PFlalg2sql_fragment_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_1[l].f19) ? PFlalg2sql_TEMP + 40 : 0 )
#define PFlalg2sql_frag_extract_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 35 : 0 )
#define PFlalg2sql_frag_union_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_frag_union_transition[PFlalg2sql_plank_1[l].f20][PFlalg2sql_plank_1[r].f21]) ? PFlalg2sql_TEMP + 36 : 0 )
#define PFlalg2sql_empty_frag_state	29
#define PFlalg2sql_error_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_error_transition[PFlalg2sql_plank_1[l].f22][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 31 : 0 )
#define PFlalg2sql_nil_state	53
#define PFlalg2sql_cache_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_cache_transition[PFlalg2sql_plank_1[l].f22][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 9 : 0 )
#define PFlalg2sql_trace_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_trace_transition[PFlalg2sql_plank_1[l].f22][PFlalg2sql_plank_1[r].f23]) ? PFlalg2sql_TEMP + 101 : 0 )
#define PFlalg2sql_trace_items_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_trace_items_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_1[r].f24]) ? PFlalg2sql_TEMP + 102 : 0 )
#define PFlalg2sql_trace_msg_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_trace_msg_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_1[r].f25]) ? PFlalg2sql_TEMP + 104 : 0 )
#define PFlalg2sql_trace_map_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_trace_map_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_1[r].f25]) ? PFlalg2sql_TEMP + 103 : 0 )
#define PFlalg2sql_rec_fix_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_rec_fix_transition[PFlalg2sql_plank_1[l].f26][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 69 : 0 )
#define PFlalg2sql_rec_param_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_rec_param_transition[PFlalg2sql_plank_1[l].f27][PFlalg2sql_plank_1[r].f28]) ? PFlalg2sql_TEMP + 71 : 0 )
#define PFlalg2sql_rec_arg_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_rec_arg_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_2[r].f12]) ? PFlalg2sql_TEMP + 66 : 0 )
#define PFlalg2sql_rec_base_state	69
#define PFlalg2sql_fun_call_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_fun_call_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_1[r].f29]) ? PFlalg2sql_TEMP + 44 : 0 )
#define PFlalg2sql_fun_param_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_fun_param_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_1[r].f29]) ? PFlalg2sql_TEMP + 46 : 0 )
#define PFlalg2sql_fun_frag_param_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_fun_frag_param_transition[PFlalg2sql_plank_2[l].f13][PFlalg2sql_plank_1[r].f29]) ? PFlalg2sql_TEMP + 45 : 0 )
#define PFlalg2sql_proxy_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 62 : 0 )
#define PFlalg2sql_proxy_base_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 63 : 0 )
#define PFlalg2sql_string_join_state(l,r)	( (PFlalg2sql_TEMP = PFlalg2sql_string_join_transition[PFlalg2sql_plank_2[l].f6][PFlalg2sql_plank_2[r].f6]) ? PFlalg2sql_TEMP + 97 : 0 )
#define PFlalg2sql_dummy_state(l)	( (PFlalg2sql_TEMP = PFlalg2sql_plank_2[l].f6) ? PFlalg2sql_TEMP + 25 : 0 )

#ifdef __STDC__
int PFlalg2sql_state(int op, int l, int r) {
#else
int PFlalg2sql_state(op, l, r) int op; int l; int r; {
#endif
	register int PFlalg2sql_TEMP;
#ifndef NDEBUG
	switch (op) {
	case 1:
	case 2:
	case 3:
	case 8:
	case 9:
	case 10:
	case 11:
	case 16:
	case 17:
	case 18:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 56:
	case 61:
	case 62:
	case 63:
	case 68:
	case 69:
	case 73:
	case 78:
	case 80:
	case 81:
	case 82:
	case 83:
	case 84:
	case 85:
	case 86:
	case 87:
	case 90:
	case 91:
	case 92:
	case 102:
		PFlalg2sql_assert(r >= 0 && r < 115, PFlalg2sql_PANIC("Bad state %d passed to PFlalg2sql_state\n", r));
		/*FALLTHROUGH*/
	case 7:
	case 12:
	case 13:
	case 14:
	case 19:
	case 20:
	case 25:
	case 26:
	case 28:
	case 29:
	case 30:
	case 31:
	case 32:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
	case 55:
	case 60:
	case 64:
	case 65:
	case 66:
	case 67:
	case 70:
	case 71:
	case 72:
	case 96:
	case 97:
	case 120:
		PFlalg2sql_assert(l >= 0 && l < 115, PFlalg2sql_PANIC("Bad state %d passed to PFlalg2sql_state\n", l));
		/*FALLTHROUGH*/
	case 4:
	case 5:
	case 6:
	case 74:
	case 79:
	case 88:
		break;
	}
#endif
	switch (op) {
	default: PFlalg2sql_PANIC("Unknown op %d in PFlalg2sql_state\n", op); abort(); return 0;
	case 1:
		return PFlalg2sql_serialize_seq_state(l,r);
	case 2:
		return PFlalg2sql_serialize_rel_state(l,r);
	case 3:
		return PFlalg2sql_side_effects_state(l,r);
	case 4:
		return PFlalg2sql_lit_tbl_state;
	case 5:
		return PFlalg2sql_empty_tbl_state;
	case 6:
		return PFlalg2sql_ref_tbl_state;
	case 7:
		return PFlalg2sql_attach_state(l);
	case 8:
		return PFlalg2sql_cross_state(l,r);
	case 9:
		return PFlalg2sql_eqjoin_state(l,r);
	case 10:
		return PFlalg2sql_semijoin_state(l,r);
	case 11:
		return PFlalg2sql_thetajoin_state(l,r);
	case 12:
		return PFlalg2sql_project_state(l);
	case 13:
		return PFlalg2sql_select__state(l);
	case 14:
		return PFlalg2sql_pos_select_state(l);
	case 16:
		return PFlalg2sql_disjunion_state(l,r);
	case 17:
		return PFlalg2sql_intersect_state(l,r);
	case 18:
		return PFlalg2sql_difference_state(l,r);
	case 19:
		return PFlalg2sql_distinct_state(l);
	case 20:
		return PFlalg2sql_fun_1to1_state(l);
	case 25:
		return PFlalg2sql_num_eq_state(l);
	case 26:
		return PFlalg2sql_num_gt_state(l);
	case 28:
		return PFlalg2sql_bool_and_state(l);
	case 29:
		return PFlalg2sql_bool_or_state(l);
	case 30:
		return PFlalg2sql_bool_not_state(l);
	case 31:
		return PFlalg2sql_to_state(l);
	case 32:
		return PFlalg2sql_aggr_state(l);
	case 37:
		return PFlalg2sql_rownum_state(l);
	case 38:
		return PFlalg2sql_rowrank_state(l);
	case 39:
		return PFlalg2sql_rank_state(l);
	case 40:
		return PFlalg2sql_rowid_state(l);
	case 41:
		return PFlalg2sql_type_state(l);
	case 42:
		return PFlalg2sql_type_assert_state(l);
	case 43:
		return PFlalg2sql_cast_state(l);
	case 50:
		return PFlalg2sql_step_state(l,r);
	case 51:
		return PFlalg2sql_step_join_state(l,r);
	case 52:
		return PFlalg2sql_guide_step_state(l,r);
	case 53:
		return PFlalg2sql_guide_step_join_state(l,r);
	case 54:
		return PFlalg2sql_doc_index_join_state(l,r);
	case 55:
		return PFlalg2sql_doc_tbl_state(l);
	case 56:
		return PFlalg2sql_doc_access_state(l,r);
	case 60:
		return PFlalg2sql_twig_state(l);
	case 61:
		return PFlalg2sql_fcns_state(l,r);
	case 62:
		return PFlalg2sql_docnode_state(l,r);
	case 63:
		return PFlalg2sql_element_state(l,r);
	case 64:
		return PFlalg2sql_attribute_state(l);
	case 65:
		return PFlalg2sql_textnode_state(l);
	case 66:
		return PFlalg2sql_comment_state(l);
	case 67:
		return PFlalg2sql_processi_state(l);
	case 68:
		return PFlalg2sql_content_state(l,r);
	case 69:
		return PFlalg2sql_merge_adjacent_state(l,r);
	case 70:
		return PFlalg2sql_roots__state(l);
	case 71:
		return PFlalg2sql_fragment_state(l);
	case 72:
		return PFlalg2sql_frag_extract_state(l);
	case 73:
		return PFlalg2sql_frag_union_state(l,r);
	case 74:
		return PFlalg2sql_empty_frag_state;
	case 78:
		return PFlalg2sql_error_state(l,r);
	case 79:
		return PFlalg2sql_nil_state;
	case 80:
		return PFlalg2sql_cache_state(l,r);
	case 81:
		return PFlalg2sql_trace_state(l,r);
	case 82:
		return PFlalg2sql_trace_items_state(l,r);
	case 83:
		return PFlalg2sql_trace_msg_state(l,r);
	case 84:
		return PFlalg2sql_trace_map_state(l,r);
	case 85:
		return PFlalg2sql_rec_fix_state(l,r);
	case 86:
		return PFlalg2sql_rec_param_state(l,r);
	case 87:
		return PFlalg2sql_rec_arg_state(l,r);
	case 88:
		return PFlalg2sql_rec_base_state;
	case 90:
		return PFlalg2sql_fun_call_state(l,r);
	case 91:
		return PFlalg2sql_fun_param_state(l,r);
	case 92:
		return PFlalg2sql_fun_frag_param_state(l,r);
	case 96:
		return PFlalg2sql_proxy_state(l);
	case 97:
		return PFlalg2sql_proxy_base_state(l);
	case 102:
		return PFlalg2sql_string_join_state(l,r);
	case 120:
		return PFlalg2sql_dummy_state(l);
	}
}
#ifdef PFlalg2sql_STATE_LABEL
#define PFlalg2sql_INCLUDE_EXTRA
#else
#ifdef STATE_LABEL
#define PFlalg2sql_INCLUDE_EXTRA
#define PFlalg2sql_STATE_LABEL 	STATE_LABEL
#define PFlalg2sql_NODEPTR_TYPE	NODEPTR_TYPE
#define PFlalg2sql_LEFT_CHILD  	LEFT_CHILD
#define PFlalg2sql_OP_LABEL    	OP_LABEL
#define PFlalg2sql_RIGHT_CHILD 	RIGHT_CHILD
#endif /* STATE_LABEL */
#endif /* PFlalg2sql_STATE_LABEL */

#ifdef PFlalg2sql_INCLUDE_EXTRA

#ifdef __STDC__
int PFlalg2sql_label(PFlalg2sql_NODEPTR_TYPE n) {
#else
int PFlalg2sql_label(n) PFlalg2sql_NODEPTR_TYPE n; {
#endif
	PFlalg2sql_assert(n, PFlalg2sql_PANIC("NULL pointer passed to PFlalg2sql_label\n"));
	switch (PFlalg2sql_OP_LABEL(n)) {
	default: PFlalg2sql_PANIC("Bad op %d in PFlalg2sql_label\n", PFlalg2sql_OP_LABEL(n)); abort(); return 0;
	case 4:
	case 5:
	case 6:
	case 74:
	case 79:
	case 88:
		return PFlalg2sql_STATE_LABEL(n) = PFlalg2sql_state(PFlalg2sql_OP_LABEL(n), 0, 0);
	case 7:
	case 12:
	case 13:
	case 14:
	case 19:
	case 20:
	case 25:
	case 26:
	case 28:
	case 29:
	case 30:
	case 31:
	case 32:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
	case 55:
	case 60:
	case 64:
	case 65:
	case 66:
	case 67:
	case 70:
	case 71:
	case 72:
	case 96:
	case 97:
	case 120:
		return PFlalg2sql_STATE_LABEL(n) = PFlalg2sql_state(PFlalg2sql_OP_LABEL(n), PFlalg2sql_label(PFlalg2sql_LEFT_CHILD(n)), 0);
	case 1:
	case 2:
	case 3:
	case 8:
	case 9:
	case 10:
	case 11:
	case 16:
	case 17:
	case 18:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 56:
	case 61:
	case 62:
	case 63:
	case 68:
	case 69:
	case 73:
	case 78:
	case 80:
	case 81:
	case 82:
	case 83:
	case 84:
	case 85:
	case 86:
	case 87:
	case 90:
	case 91:
	case 92:
	case 102:
		return PFlalg2sql_STATE_LABEL(n) = PFlalg2sql_state(PFlalg2sql_OP_LABEL(n), PFlalg2sql_label(PFlalg2sql_LEFT_CHILD(n)), PFlalg2sql_label(PFlalg2sql_RIGHT_CHILD(n)));
	}
}
#ifdef __STDC__
PFlalg2sql_NODEPTR_TYPE * PFlalg2sql_kids(PFlalg2sql_NODEPTR_TYPE p, int rulenumber, PFlalg2sql_NODEPTR_TYPE *kids) {
#else
PFlalg2sql_NODEPTR_TYPE * PFlalg2sql_kids(p, rulenumber, kids) PFlalg2sql_NODEPTR_TYPE p; int rulenumber; PFlalg2sql_NODEPTR_TYPE *kids; {
#endif
	PFlalg2sql_assert(p, PFlalg2sql_PANIC("NULL node pointer passed to PFlalg2sql_kids\n"));
	PFlalg2sql_assert(kids, PFlalg2sql_PANIC("NULL kids pointer passed to PFlalg2sql_kids\n"));
	switch (rulenumber) {
	default:
		PFlalg2sql_PANIC("Unknown Rule %d in PFlalg2sql_kids;\n", rulenumber);
		abort();
		/* NOTREACHED */
	case 1:
		kids[0] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[1] = PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[2] = PFlalg2sql_RIGHT_CHILD(p);
		break;
	case 2:
		kids[0] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[1] = PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[2] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(p));
		break;
	case 3:
		kids[0] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[1] = PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[2] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(p)));
		break;
	case 4:
		kids[0] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[1] = PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[2] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(p))));
		break;
	case 5:
		kids[0] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[1] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(p)))));
		kids[2] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(p)));
		break;
	case 6:
		kids[0] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[1] = PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		break;
	case 40:
		kids[0] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		kids[1] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(p)));
		kids[2] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(p)))));
		break;
	case 65:
		kids[0] = PFlalg2sql_RIGHT_CHILD(p);
		break;
	case 36:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
	case 77:
		kids[0] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(p));
		break;
	case 108:
		kids[0] = PFlalg2sql_LEFT_CHILD(p);
		kids[1] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(p));
		break;
	case 109:
		kids[0] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(p))));
		kids[1] = PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(p))));
		kids[2] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(p))));
		kids[3] = PFlalg2sql_RIGHT_CHILD(p);
		break;
	case 110:
		kids[0] = PFlalg2sql_LEFT_CHILD(PFlalg2sql_RIGHT_CHILD(PFlalg2sql_LEFT_CHILD(p)));
		kids[1] = PFlalg2sql_RIGHT_CHILD(p);
		break;
	case 11:
	case 16:
	case 17:
	case 18:
	case 19:
	case 23:
	case 25:
	case 26:
	case 27:
	case 28:
	case 29:
	case 30:
	case 31:
	case 32:
	case 33:
	case 35:
	case 50:
	case 51:
	case 52:
	case 53:
	case 61:
	case 62:
	case 63:
	case 70:
	case 71:
	case 79:
	case 81:
	case 83:
	case 84:
	case 85:
	case 86:
	case 87:
	case 115:
	case 116:
	case 117:
		kids[0] = PFlalg2sql_LEFT_CHILD(p);
		break;
	case 7:
	case 12:
	case 13:
	case 14:
	case 15:
	case 20:
	case 21:
	case 22:
	case 43:
	case 55:
	case 56:
	case 57:
	case 58:
	case 59:
	case 60:
	case 64:
	case 78:
	case 80:
	case 82:
	case 88:
	case 89:
	case 97:
	case 99:
	case 100:
	case 101:
	case 102:
	case 103:
	case 107:
	case 118:
	case 119:
	case 120:
		kids[0] = PFlalg2sql_LEFT_CHILD(p);
		kids[1] = PFlalg2sql_RIGHT_CHILD(p);
		break;
	case 8:
	case 9:
	case 10:
	case 66:
	case 98:
	case 104:
	case 105:
	case 106:
	case 121:
		break;
	}
	return kids;
}
#ifdef __STDC__
PFlalg2sql_NODEPTR_TYPE PFlalg2sql_child(PFlalg2sql_NODEPTR_TYPE p, int index) {
#else
PFlalg2sql_NODEPTR_TYPE PFlalg2sql_child(p, index) PFlalg2sql_NODEPTR_TYPE p; int index; {
#endif
	PFlalg2sql_assert(p, PFlalg2sql_PANIC("NULL pointer passed to PFlalg2sql_child\n"));
	switch (index) {
	case 0:
		return PFlalg2sql_LEFT_CHILD(p);
	case 1:
		return PFlalg2sql_RIGHT_CHILD(p);
	}
	PFlalg2sql_PANIC("Bad index %d in PFlalg2sql_child;\n", index);
	abort();
	return 0;
}
#ifdef __STDC__
int PFlalg2sql_op_label(PFlalg2sql_NODEPTR_TYPE p) {
#else
int PFlalg2sql_op_label(p) PFlalg2sql_NODEPTR_TYPE p; {
#endif
	PFlalg2sql_assert(p, PFlalg2sql_PANIC("NULL pointer passed to PFlalg2sql_op_label\n"));
	return PFlalg2sql_OP_LABEL(p);
}
#ifdef __STDC__
int PFlalg2sql_state_label(PFlalg2sql_NODEPTR_TYPE p) {
#else
int PFlalg2sql_state_label(p) PFlalg2sql_NODEPTR_TYPE p; {
#endif
	PFlalg2sql_assert(p, PFlalg2sql_PANIC("NULL pointer passed to PFlalg2sql_state_label\n"));
	return PFlalg2sql_STATE_LABEL(p);
}
#endif /* PFlalg2sql_INCLUDE_EXTRA */
#define PFlalg2sql_Param_NT 13
#define PFlalg2sql_Arg_NT 12
#define PFlalg2sql_Rec_NT 11
#define PFlalg2sql_Map_NT 10
#define PFlalg2sql_Msg_NT 9
#define PFlalg2sql_Trc_NT 8
#define PFlalg2sql_Side_NT 7
#define PFlalg2sql_Twig_NT 6
#define PFlalg2sql_List_NT 5
#define PFlalg2sql_Constr_NT 4
#define PFlalg2sql_Frag_NT 3
#define PFlalg2sql_Rel_NT 2
#define PFlalg2sql_Query_NT 1
#define PFlalg2sql_NT 13
char * PFlalg2sql_opname[] = {
	0, /* 0 */
	"serialize_seq", /* 1 */
	"serialize_rel", /* 2 */
	"side_effects", /* 3 */
	"lit_tbl", /* 4 */
	"empty_tbl", /* 5 */
	"ref_tbl", /* 6 */
	"attach", /* 7 */
	"cross", /* 8 */
	"eqjoin", /* 9 */
	"semijoin", /* 10 */
	"thetajoin", /* 11 */
	"project", /* 12 */
	"select_", /* 13 */
	"pos_select", /* 14 */
	0, /* 15 */
	"disjunion", /* 16 */
	"intersect", /* 17 */
	"difference", /* 18 */
	"distinct", /* 19 */
	"fun_1to1", /* 20 */
	0, /* 21 */
	0, /* 22 */
	0, /* 23 */
	0, /* 24 */
	"num_eq", /* 25 */
	"num_gt", /* 26 */
	0, /* 27 */
	"bool_and", /* 28 */
	"bool_or", /* 29 */
	"bool_not", /* 30 */
	"to", /* 31 */
	"aggr", /* 32 */
	0, /* 33 */
	0, /* 34 */
	0, /* 35 */
	0, /* 36 */
	"rownum", /* 37 */
	"rowrank", /* 38 */
	"rank", /* 39 */
	"rowid", /* 40 */
	"type", /* 41 */
	"type_assert", /* 42 */
	"cast", /* 43 */
	0, /* 44 */
	0, /* 45 */
	0, /* 46 */
	0, /* 47 */
	0, /* 48 */
	0, /* 49 */
	"step", /* 50 */
	"step_join", /* 51 */
	"guide_step", /* 52 */
	"guide_step_join", /* 53 */
	"doc_index_join", /* 54 */
	"doc_tbl", /* 55 */
	"doc_access", /* 56 */
	0, /* 57 */
	0, /* 58 */
	0, /* 59 */
	"twig", /* 60 */
	"fcns", /* 61 */
	"docnode", /* 62 */
	"element", /* 63 */
	"attribute", /* 64 */
	"textnode", /* 65 */
	"comment", /* 66 */
	"processi", /* 67 */
	"content", /* 68 */
	"merge_adjacent", /* 69 */
	"roots_", /* 70 */
	"fragment", /* 71 */
	"frag_extract", /* 72 */
	"frag_union", /* 73 */
	"empty_frag", /* 74 */
	0, /* 75 */
	0, /* 76 */
	0, /* 77 */
	"error", /* 78 */
	"nil", /* 79 */
	"cache", /* 80 */
	"trace", /* 81 */
	"trace_items", /* 82 */
	"trace_msg", /* 83 */
	"trace_map", /* 84 */
	"rec_fix", /* 85 */
	"rec_param", /* 86 */
	"rec_arg", /* 87 */
	"rec_base", /* 88 */
	0, /* 89 */
	"fun_call", /* 90 */
	"fun_param", /* 91 */
	"fun_frag_param", /* 92 */
	0, /* 93 */
	0, /* 94 */
	0, /* 95 */
	"proxy", /* 96 */
	"proxy_base", /* 97 */
	0, /* 98 */
	0, /* 99 */
	0, /* 100 */
	0, /* 101 */
	"string_join", /* 102 */
	0, /* 103 */
	0, /* 104 */
	0, /* 105 */
	0, /* 106 */
	0, /* 107 */
	0, /* 108 */
	0, /* 109 */
	0, /* 110 */
	0, /* 111 */
	0, /* 112 */
	0, /* 113 */
	0, /* 114 */
	0, /* 115 */
	0, /* 116 */
	0, /* 117 */
	0, /* 118 */
	0, /* 119 */
	"dummy"
};
char PFlalg2sql_arity[] = {
	-1, /* 0 */
	2, /* 1 */
	2, /* 2 */
	2, /* 3 */
	0, /* 4 */
	0, /* 5 */
	0, /* 6 */
	1, /* 7 */
	2, /* 8 */
	2, /* 9 */
	2, /* 10 */
	2, /* 11 */
	1, /* 12 */
	1, /* 13 */
	1, /* 14 */
	-1, /* 15 */
	2, /* 16 */
	2, /* 17 */
	2, /* 18 */
	1, /* 19 */
	1, /* 20 */
	-1, /* 21 */
	-1, /* 22 */
	-1, /* 23 */
	-1, /* 24 */
	1, /* 25 */
	1, /* 26 */
	-1, /* 27 */
	1, /* 28 */
	1, /* 29 */
	1, /* 30 */
	1, /* 31 */
	1, /* 32 */
	-1, /* 33 */
	-1, /* 34 */
	-1, /* 35 */
	-1, /* 36 */
	1, /* 37 */
	1, /* 38 */
	1, /* 39 */
	1, /* 40 */
	1, /* 41 */
	1, /* 42 */
	1, /* 43 */
	-1, /* 44 */
	-1, /* 45 */
	-1, /* 46 */
	-1, /* 47 */
	-1, /* 48 */
	-1, /* 49 */
	2, /* 50 */
	2, /* 51 */
	2, /* 52 */
	2, /* 53 */
	2, /* 54 */
	1, /* 55 */
	2, /* 56 */
	-1, /* 57 */
	-1, /* 58 */
	-1, /* 59 */
	1, /* 60 */
	2, /* 61 */
	2, /* 62 */
	2, /* 63 */
	1, /* 64 */
	1, /* 65 */
	1, /* 66 */
	1, /* 67 */
	2, /* 68 */
	2, /* 69 */
	1, /* 70 */
	1, /* 71 */
	1, /* 72 */
	2, /* 73 */
	0, /* 74 */
	-1, /* 75 */
	-1, /* 76 */
	-1, /* 77 */
	2, /* 78 */
	0, /* 79 */
	2, /* 80 */
	2, /* 81 */
	2, /* 82 */
	2, /* 83 */
	2, /* 84 */
	2, /* 85 */
	2, /* 86 */
	2, /* 87 */
	0, /* 88 */
	-1, /* 89 */
	2, /* 90 */
	2, /* 91 */
	2, /* 92 */
	-1, /* 93 */
	-1, /* 94 */
	-1, /* 95 */
	1, /* 96 */
	1, /* 97 */
	-1, /* 98 */
	-1, /* 99 */
	-1, /* 100 */
	-1, /* 101 */
	2, /* 102 */
	-1, /* 103 */
	-1, /* 104 */
	-1, /* 105 */
	-1, /* 106 */
	-1, /* 107 */
	-1, /* 108 */
	-1, /* 109 */
	-1, /* 110 */
	-1, /* 111 */
	-1, /* 112 */
	-1, /* 113 */
	-1, /* 114 */
	-1, /* 115 */
	-1, /* 116 */
	-1, /* 117 */
	-1, /* 118 */
	-1, /* 119 */
	1
};
int PFlalg2sql_max_op = 120;
int PFlalg2sql_max_state = 114;
#define PFlalg2sql_Max_state 114
char *PFlalg2sql_string[] = {
	0,
	"Query: serialize_seq(side_effects(Side, Frag), Rel)",
	"Query: serialize_seq(side_effects(Side, Frag), distinct(Rel))",
	"Query: serialize_seq(side_effects(Side, Frag), project(rank(Rel)))",
	"Query: serialize_seq(side_effects(Side, Frag), project(rank(distinct(Rel))))",
	"Query: serialize_seq(side_effects(Side, frag_union(empty_frag, fragment(twig(Twig)))), roots_(twig(Twig)))",
	"Query: serialize_seq(side_effects(Side, Frag), empty_tbl)",
	"Query: serialize_rel(Side, Rel)",
	"Query: serialize_rel(nil, empty_tbl)",
	"Rel: lit_tbl",
	"Rel: ref_tbl",
	"Rel: attach(Rel)",
	"Rel: cross(Rel, Rel)",
	"Rel: eqjoin(Rel, Rel)",
	"Rel: semijoin(Rel, Rel)",
	"Rel: thetajoin(Rel, Rel)",
	"Rel: project(Rel)",
	"Rel: select_(Rel)",
	"Rel: pos_select(Rel)",
	"Rel: to(Rel)",
	"Rel: disjunion(Rel, Rel)",
	"Rel: intersect(Rel, Rel)",
	"Rel: difference(Rel, Rel)",
	"Rel: distinct(Rel)",
	0,
	"Rel: fun_1to1(Rel)",
	"Rel: num_eq(Rel)",
	"Rel: num_gt(Rel)",
	"Rel: bool_and(Rel)",
	"Rel: bool_or(Rel)",
	"Rel: bool_not(Rel)",
	"Rel: type(Rel)",
	"Rel: type_assert(Rel)",
	"Rel: cast(Rel)",
	0,
	"Rel: aggr(Rel)",
	"Rel: aggr(rank(Rel))",
	0,
	0,
	0,
	"Rel: disjunion(aggr(Rel), attach(difference(Rel, project(aggr(Rel)))))",
	0,
	0,
	"Rel: string_join(Rel, Rel)",
	0,
	0,
	0,
	0,
	0,
	0,
	"Rel: rownum(Rel)",
	"Rel: rowrank(Rel)",
	"Rel: rank(Rel)",
	"Rel: rowid(Rel)",
	0,
	"Rel: step(Frag, Rel)",
	"Rel: guide_step(Frag, Rel)",
	"Rel: step_join(Frag, Rel)",
	"Rel: guide_step_join(Frag, Rel)",
	"Rel: doc_index_join(Frag, Rel)",
	"Rel: doc_access(Frag, Rel)",
	"Rel: roots_(Constr)",
	"Frag: fragment(Constr)",
	"Frag: frag_extract(Rel)",
	"Frag: frag_union(Frag, Frag)",
	"Frag: frag_union(empty_frag, Frag)",
	"Frag: empty_frag",
	0,
	0,
	0,
	"Constr: doc_tbl(Rel)",
	"Constr: twig(Twig)",
	"Constr: twig(docnode(Rel, fcns(nil, nil)))",
	"Constr: twig(element(Rel, fcns(nil, nil)))",
	"Constr: twig(attribute(Rel))",
	"Constr: twig(textnode(Rel))",
	"Constr: twig(comment(Rel))",
	"Constr: twig(processi(Rel))",
	"List: fcns(Twig, List)",
	"List: fcns(Twig, nil)",
	"Twig: docnode(Rel, List)",
	"Twig: docnode(Rel, fcns(nil, nil))",
	"Twig: element(Rel, List)",
	"Twig: element(Rel, fcns(nil, nil))",
	"Twig: attribute(Rel)",
	"Twig: textnode(Rel)",
	"Twig: comment(Rel)",
	"Twig: processi(Rel)",
	"Twig: content(Frag, Rel)",
	"Constr: merge_adjacent(Frag, Rel)",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"Side: error(Side, Rel)",
	"Side: nil",
	"Side: cache(Side, Rel)",
	"Side: trace(Side, Trc)",
	"Trc: trace_items(Rel, Msg)",
	"Msg: trace_msg(Rel, Map)",
	"Map: trace_map(Rel, Map)",
	"Map: nil",
	"Rel: rec_base",
	"Rec: nil",
	"Arg: rec_arg(Rel, Rel)",
	"Arg: rec_arg(Rel, distinct(Rel))",
	"Rel: rec_fix(side_effects(nil, rec_param(rec_arg(Rel, Rel), rec_param(Arg, nil))), Rel)",
	"Rel: rec_fix(side_effects(nil, rec_param(Arg, nil)), Rel)",
	0,
	0,
	0,
	0,
	"Rel: dummy(Rel)",
	"Rel: proxy(Rel)",
	"Rel: proxy_base(Rel)",
	"Rel: fun_call(Rel, Param)",
	"Param: fun_param(Rel, Param)",
	"Param: fun_frag_param(Frag, Param)",
	"Param: nil",
};
int PFlalg2sql_max_rule = 121;
#define PFlalg2sql_Max_rule 121
short PFlalg2sql_rule_descriptor_0[] = { 0, 0 };
short PFlalg2sql_rule_descriptor_1[] = {   -1,    1,    3,   -7,   -3,   -2, };
short PFlalg2sql_rule_descriptor_2[] = {   -1,    1,    3,   -7,   -3,   19,   -2, };
short PFlalg2sql_rule_descriptor_3[] = {   -1,    1,    3,   -7,   -3,   12,   39,   -2, };
short PFlalg2sql_rule_descriptor_4[] = {   -1,    1,    3,   -7,   -3,   12,   39,   19,   -2, };
short PFlalg2sql_rule_descriptor_5[] = {   -1,    1,    3,   -7,   73,   74,   71,   60,   -6,   70,   60,   -6, };
short PFlalg2sql_rule_descriptor_6[] = {   -1,    1,    3,   -7,   -3,    5, };
short PFlalg2sql_rule_descriptor_7[] = {   -1,    2,   -7,   -2, };
short PFlalg2sql_rule_descriptor_8[] = {   -1,    2,   79,    5, };
short PFlalg2sql_rule_descriptor_9[] = {   -2,    4, };
short PFlalg2sql_rule_descriptor_10[] = {   -2,    6, };
short PFlalg2sql_rule_descriptor_11[] = {   -2,    7,   -2, };
short PFlalg2sql_rule_descriptor_12[] = {   -2,    8,   -2,   -2, };
short PFlalg2sql_rule_descriptor_13[] = {   -2,    9,   -2,   -2, };
short PFlalg2sql_rule_descriptor_14[] = {   -2,   10,   -2,   -2, };
short PFlalg2sql_rule_descriptor_15[] = {   -2,   11,   -2,   -2, };
short PFlalg2sql_rule_descriptor_16[] = {   -2,   12,   -2, };
short PFlalg2sql_rule_descriptor_17[] = {   -2,   13,   -2, };
short PFlalg2sql_rule_descriptor_18[] = {   -2,   14,   -2, };
short PFlalg2sql_rule_descriptor_19[] = {   -2,   31,   -2, };
short PFlalg2sql_rule_descriptor_20[] = {   -2,   16,   -2,   -2, };
short PFlalg2sql_rule_descriptor_21[] = {   -2,   17,   -2,   -2, };
short PFlalg2sql_rule_descriptor_22[] = {   -2,   18,   -2,   -2, };
short PFlalg2sql_rule_descriptor_23[] = {   -2,   19,   -2, };
short PFlalg2sql_rule_descriptor_25[] = {   -2,   20,   -2, };
short PFlalg2sql_rule_descriptor_26[] = {   -2,   25,   -2, };
short PFlalg2sql_rule_descriptor_27[] = {   -2,   26,   -2, };
short PFlalg2sql_rule_descriptor_28[] = {   -2,   28,   -2, };
short PFlalg2sql_rule_descriptor_29[] = {   -2,   29,   -2, };
short PFlalg2sql_rule_descriptor_30[] = {   -2,   30,   -2, };
short PFlalg2sql_rule_descriptor_31[] = {   -2,   41,   -2, };
short PFlalg2sql_rule_descriptor_32[] = {   -2,   42,   -2, };
short PFlalg2sql_rule_descriptor_33[] = {   -2,   43,   -2, };
short PFlalg2sql_rule_descriptor_35[] = {   -2,   32,   -2, };
short PFlalg2sql_rule_descriptor_36[] = {   -2,   32,   39,   -2, };
short PFlalg2sql_rule_descriptor_40[] = {   -2,   16,   32,   -2,    7,   18,   -2,   12,   32,   -2, };
short PFlalg2sql_rule_descriptor_43[] = {   -2,  102,   -2,   -2, };
short PFlalg2sql_rule_descriptor_50[] = {   -2,   37,   -2, };
short PFlalg2sql_rule_descriptor_51[] = {   -2,   38,   -2, };
short PFlalg2sql_rule_descriptor_52[] = {   -2,   39,   -2, };
short PFlalg2sql_rule_descriptor_53[] = {   -2,   40,   -2, };
short PFlalg2sql_rule_descriptor_55[] = {   -2,   50,   -3,   -2, };
short PFlalg2sql_rule_descriptor_56[] = {   -2,   52,   -3,   -2, };
short PFlalg2sql_rule_descriptor_57[] = {   -2,   51,   -3,   -2, };
short PFlalg2sql_rule_descriptor_58[] = {   -2,   53,   -3,   -2, };
short PFlalg2sql_rule_descriptor_59[] = {   -2,   54,   -3,   -2, };
short PFlalg2sql_rule_descriptor_60[] = {   -2,   56,   -3,   -2, };
short PFlalg2sql_rule_descriptor_61[] = {   -2,   70,   -4, };
short PFlalg2sql_rule_descriptor_62[] = {   -3,   71,   -4, };
short PFlalg2sql_rule_descriptor_63[] = {   -3,   72,   -2, };
short PFlalg2sql_rule_descriptor_64[] = {   -3,   73,   -3,   -3, };
short PFlalg2sql_rule_descriptor_65[] = {   -3,   73,   74,   -3, };
short PFlalg2sql_rule_descriptor_66[] = {   -3,   74, };
short PFlalg2sql_rule_descriptor_70[] = {   -4,   55,   -2, };
short PFlalg2sql_rule_descriptor_71[] = {   -4,   60,   -6, };
short PFlalg2sql_rule_descriptor_72[] = {   -4,   60,   62,   -2,   61,   79,   79, };
short PFlalg2sql_rule_descriptor_73[] = {   -4,   60,   63,   -2,   61,   79,   79, };
short PFlalg2sql_rule_descriptor_74[] = {   -4,   60,   64,   -2, };
short PFlalg2sql_rule_descriptor_75[] = {   -4,   60,   65,   -2, };
short PFlalg2sql_rule_descriptor_76[] = {   -4,   60,   66,   -2, };
short PFlalg2sql_rule_descriptor_77[] = {   -4,   60,   67,   -2, };
short PFlalg2sql_rule_descriptor_78[] = {   -5,   61,   -6,   -5, };
short PFlalg2sql_rule_descriptor_79[] = {   -5,   61,   -6,   79, };
short PFlalg2sql_rule_descriptor_80[] = {   -6,   62,   -2,   -5, };
short PFlalg2sql_rule_descriptor_81[] = {   -6,   62,   -2,   61,   79,   79, };
short PFlalg2sql_rule_descriptor_82[] = {   -6,   63,   -2,   -5, };
short PFlalg2sql_rule_descriptor_83[] = {   -6,   63,   -2,   61,   79,   79, };
short PFlalg2sql_rule_descriptor_84[] = {   -6,   64,   -2, };
short PFlalg2sql_rule_descriptor_85[] = {   -6,   65,   -2, };
short PFlalg2sql_rule_descriptor_86[] = {   -6,   66,   -2, };
short PFlalg2sql_rule_descriptor_87[] = {   -6,   67,   -2, };
short PFlalg2sql_rule_descriptor_88[] = {   -6,   68,   -3,   -2, };
short PFlalg2sql_rule_descriptor_89[] = {   -4,   69,   -3,   -2, };
short PFlalg2sql_rule_descriptor_97[] = {   -7,   78,   -7,   -2, };
short PFlalg2sql_rule_descriptor_98[] = {   -7,   79, };
short PFlalg2sql_rule_descriptor_99[] = {   -7,   80,   -7,   -2, };
short PFlalg2sql_rule_descriptor_100[] = {   -7,   81,   -7,   -8, };
short PFlalg2sql_rule_descriptor_101[] = {   -8,   82,   -2,   -9, };
short PFlalg2sql_rule_descriptor_102[] = {   -9,   83,   -2,  -10, };
short PFlalg2sql_rule_descriptor_103[] = {  -10,   84,   -2,  -10, };
short PFlalg2sql_rule_descriptor_104[] = {  -10,   79, };
short PFlalg2sql_rule_descriptor_105[] = {   -2,   88, };
short PFlalg2sql_rule_descriptor_106[] = {  -11,   79, };
short PFlalg2sql_rule_descriptor_107[] = {  -12,   87,   -2,   -2, };
short PFlalg2sql_rule_descriptor_108[] = {  -12,   87,   -2,   19,   -2, };
short PFlalg2sql_rule_descriptor_109[] = {   -2,   85,    3,   79,   86,   87,   -2,   -2,   86,  -12,   79,   -2, };
short PFlalg2sql_rule_descriptor_110[] = {   -2,   85,    3,   79,   86,  -12,   79,   -2, };
short PFlalg2sql_rule_descriptor_115[] = {   -2,  120,   -2, };
short PFlalg2sql_rule_descriptor_116[] = {   -2,   96,   -2, };
short PFlalg2sql_rule_descriptor_117[] = {   -2,   97,   -2, };
short PFlalg2sql_rule_descriptor_118[] = {   -2,   90,   -2,  -13, };
short PFlalg2sql_rule_descriptor_119[] = {  -13,   91,   -2,  -13, };
short PFlalg2sql_rule_descriptor_120[] = {  -13,   92,   -3,  -13, };
short PFlalg2sql_rule_descriptor_121[] = {  -13,   79, };
/* PFlalg2sql_rule_descriptors[0][1] = 1 iff grammar is normal form. */
short * PFlalg2sql_rule_descriptors[] = {
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_1,
	PFlalg2sql_rule_descriptor_2,
	PFlalg2sql_rule_descriptor_3,
	PFlalg2sql_rule_descriptor_4,
	PFlalg2sql_rule_descriptor_5,
	PFlalg2sql_rule_descriptor_6,
	PFlalg2sql_rule_descriptor_7,
	PFlalg2sql_rule_descriptor_8,
	PFlalg2sql_rule_descriptor_9,
	PFlalg2sql_rule_descriptor_10,
	PFlalg2sql_rule_descriptor_11,
	PFlalg2sql_rule_descriptor_12,
	PFlalg2sql_rule_descriptor_13,
	PFlalg2sql_rule_descriptor_14,
	PFlalg2sql_rule_descriptor_15,
	PFlalg2sql_rule_descriptor_16,
	PFlalg2sql_rule_descriptor_17,
	PFlalg2sql_rule_descriptor_18,
	PFlalg2sql_rule_descriptor_19,
	PFlalg2sql_rule_descriptor_20,
	PFlalg2sql_rule_descriptor_21,
	PFlalg2sql_rule_descriptor_22,
	PFlalg2sql_rule_descriptor_23,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_25,
	PFlalg2sql_rule_descriptor_26,
	PFlalg2sql_rule_descriptor_27,
	PFlalg2sql_rule_descriptor_28,
	PFlalg2sql_rule_descriptor_29,
	PFlalg2sql_rule_descriptor_30,
	PFlalg2sql_rule_descriptor_31,
	PFlalg2sql_rule_descriptor_32,
	PFlalg2sql_rule_descriptor_33,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_35,
	PFlalg2sql_rule_descriptor_36,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_40,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_43,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_50,
	PFlalg2sql_rule_descriptor_51,
	PFlalg2sql_rule_descriptor_52,
	PFlalg2sql_rule_descriptor_53,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_55,
	PFlalg2sql_rule_descriptor_56,
	PFlalg2sql_rule_descriptor_57,
	PFlalg2sql_rule_descriptor_58,
	PFlalg2sql_rule_descriptor_59,
	PFlalg2sql_rule_descriptor_60,
	PFlalg2sql_rule_descriptor_61,
	PFlalg2sql_rule_descriptor_62,
	PFlalg2sql_rule_descriptor_63,
	PFlalg2sql_rule_descriptor_64,
	PFlalg2sql_rule_descriptor_65,
	PFlalg2sql_rule_descriptor_66,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_70,
	PFlalg2sql_rule_descriptor_71,
	PFlalg2sql_rule_descriptor_72,
	PFlalg2sql_rule_descriptor_73,
	PFlalg2sql_rule_descriptor_74,
	PFlalg2sql_rule_descriptor_75,
	PFlalg2sql_rule_descriptor_76,
	PFlalg2sql_rule_descriptor_77,
	PFlalg2sql_rule_descriptor_78,
	PFlalg2sql_rule_descriptor_79,
	PFlalg2sql_rule_descriptor_80,
	PFlalg2sql_rule_descriptor_81,
	PFlalg2sql_rule_descriptor_82,
	PFlalg2sql_rule_descriptor_83,
	PFlalg2sql_rule_descriptor_84,
	PFlalg2sql_rule_descriptor_85,
	PFlalg2sql_rule_descriptor_86,
	PFlalg2sql_rule_descriptor_87,
	PFlalg2sql_rule_descriptor_88,
	PFlalg2sql_rule_descriptor_89,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_97,
	PFlalg2sql_rule_descriptor_98,
	PFlalg2sql_rule_descriptor_99,
	PFlalg2sql_rule_descriptor_100,
	PFlalg2sql_rule_descriptor_101,
	PFlalg2sql_rule_descriptor_102,
	PFlalg2sql_rule_descriptor_103,
	PFlalg2sql_rule_descriptor_104,
	PFlalg2sql_rule_descriptor_105,
	PFlalg2sql_rule_descriptor_106,
	PFlalg2sql_rule_descriptor_107,
	PFlalg2sql_rule_descriptor_108,
	PFlalg2sql_rule_descriptor_109,
	PFlalg2sql_rule_descriptor_110,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_0,
	PFlalg2sql_rule_descriptor_115,
	PFlalg2sql_rule_descriptor_116,
	PFlalg2sql_rule_descriptor_117,
	PFlalg2sql_rule_descriptor_118,
	PFlalg2sql_rule_descriptor_119,
	PFlalg2sql_rule_descriptor_120,
	PFlalg2sql_rule_descriptor_121,
};
short PFlalg2sql_cost[][4] = {
	{    0,    0,    0,    0}, /* (none) = 0 */
	{   10,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), Rel) = 1 */
	{   10,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), distinct(Rel)) = 2 */
	{   10,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), project(rank(Rel))) = 3 */
	{   10,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), project(rank(distinct(Rel)))) = 4 */
	{   10,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, frag_union(empty_frag, fragment(twig(Twig)))), roots_(twig(Twig))) = 5 */
	{   10,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), empty_tbl) = 6 */
	{   10,    0,    0,    0}, /* Query: serialize_rel(Side, Rel) = 7 */
	{   10,    0,    0,    0}, /* Query: serialize_rel(nil, empty_tbl) = 8 */
	{   10,    0,    0,    0}, /* Rel: lit_tbl = 9 */
	{   10,    0,    0,    0}, /* Rel: ref_tbl = 10 */
	{   10,    0,    0,    0}, /* Rel: attach(Rel) = 11 */
	{   10,    0,    0,    0}, /* Rel: cross(Rel, Rel) = 12 */
	{   10,    0,    0,    0}, /* Rel: eqjoin(Rel, Rel) = 13 */
	{   10,    0,    0,    0}, /* Rel: semijoin(Rel, Rel) = 14 */
	{   10,    0,    0,    0}, /* Rel: thetajoin(Rel, Rel) = 15 */
	{   10,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{   10,    0,    0,    0}, /* Rel: select_(Rel) = 17 */
	{   10,    0,    0,    0}, /* Rel: pos_select(Rel) = 18 */
	{   10,    0,    0,    0}, /* Rel: to(Rel) = 19 */
	{   10,    0,    0,    0}, /* Rel: disjunion(Rel, Rel) = 20 */
	{   10,    0,    0,    0}, /* Rel: intersect(Rel, Rel) = 21 */
	{   10,    0,    0,    0}, /* Rel: difference(Rel, Rel) = 22 */
	{   10,    0,    0,    0}, /* Rel: distinct(Rel) = 23 */
	{    0,    0,    0,    0}, /* (none) = 24 */
	{   10,    0,    0,    0}, /* Rel: fun_1to1(Rel) = 25 */
	{   10,    0,    0,    0}, /* Rel: num_eq(Rel) = 26 */
	{   10,    0,    0,    0}, /* Rel: num_gt(Rel) = 27 */
	{   10,    0,    0,    0}, /* Rel: bool_and(Rel) = 28 */
	{   10,    0,    0,    0}, /* Rel: bool_or(Rel) = 29 */
	{   10,    0,    0,    0}, /* Rel: bool_not(Rel) = 30 */
	{   10,    0,    0,    0}, /* Rel: type(Rel) = 31 */
	{   10,    0,    0,    0}, /* Rel: type_assert(Rel) = 32 */
	{   10,    0,    0,    0}, /* Rel: cast(Rel) = 33 */
	{    0,    0,    0,    0}, /* (none) = 34 */
	{   10,    0,    0,    0}, /* Rel: aggr(Rel) = 35 */
	{   10,    0,    0,    0}, /* Rel: aggr(rank(Rel)) = 36 */
	{    0,    0,    0,    0}, /* (none) = 37 */
	{    0,    0,    0,    0}, /* (none) = 38 */
	{    0,    0,    0,    0}, /* (none) = 39 */
	{    5,    0,    0,    0}, /* Rel: disjunion(aggr(Rel), attach(difference(Rel, project(aggr(Rel))))) = 40 */
	{    0,    0,    0,    0}, /* (none) = 41 */
	{    0,    0,    0,    0}, /* (none) = 42 */
	{   10,    0,    0,    0}, /* Rel: string_join(Rel, Rel) = 43 */
	{    0,    0,    0,    0}, /* (none) = 44 */
	{    0,    0,    0,    0}, /* (none) = 45 */
	{    0,    0,    0,    0}, /* (none) = 46 */
	{    0,    0,    0,    0}, /* (none) = 47 */
	{    0,    0,    0,    0}, /* (none) = 48 */
	{    0,    0,    0,    0}, /* (none) = 49 */
	{   10,    0,    0,    0}, /* Rel: rownum(Rel) = 50 */
	{   10,    0,    0,    0}, /* Rel: rowrank(Rel) = 51 */
	{   10,    0,    0,    0}, /* Rel: rank(Rel) = 52 */
	{   10,    0,    0,    0}, /* Rel: rowid(Rel) = 53 */
	{    0,    0,    0,    0}, /* (none) = 54 */
	{   10,    0,    0,    0}, /* Rel: step(Frag, Rel) = 55 */
	{   10,    0,    0,    0}, /* Rel: guide_step(Frag, Rel) = 56 */
	{   10,    0,    0,    0}, /* Rel: step_join(Frag, Rel) = 57 */
	{   10,    0,    0,    0}, /* Rel: guide_step_join(Frag, Rel) = 58 */
	{   10,    0,    0,    0}, /* Rel: doc_index_join(Frag, Rel) = 59 */
	{   10,    0,    0,    0}, /* Rel: doc_access(Frag, Rel) = 60 */
	{   10,    0,    0,    0}, /* Rel: roots_(Constr) = 61 */
	{   10,    0,    0,    0}, /* Frag: fragment(Constr) = 62 */
	{   10,    0,    0,    0}, /* Frag: frag_extract(Rel) = 63 */
	{   10,    0,    0,    0}, /* Frag: frag_union(Frag, Frag) = 64 */
	{   10,    0,    0,    0}, /* Frag: frag_union(empty_frag, Frag) = 65 */
	{   10,    0,    0,    0}, /* Frag: empty_frag = 66 */
	{    0,    0,    0,    0}, /* (none) = 67 */
	{    0,    0,    0,    0}, /* (none) = 68 */
	{    0,    0,    0,    0}, /* (none) = 69 */
	{   10,    0,    0,    0}, /* Constr: doc_tbl(Rel) = 70 */
	{   10,    0,    0,    0}, /* Constr: twig(Twig) = 71 */
	{   10,    0,    0,    0}, /* Constr: twig(docnode(Rel, fcns(nil, nil))) = 72 */
	{   10,    0,    0,    0}, /* Constr: twig(element(Rel, fcns(nil, nil))) = 73 */
	{   10,    0,    0,    0}, /* Constr: twig(attribute(Rel)) = 74 */
	{   10,    0,    0,    0}, /* Constr: twig(textnode(Rel)) = 75 */
	{   10,    0,    0,    0}, /* Constr: twig(comment(Rel)) = 76 */
	{   10,    0,    0,    0}, /* Constr: twig(processi(Rel)) = 77 */
	{   10,    0,    0,    0}, /* List: fcns(Twig, List) = 78 */
	{   10,    0,    0,    0}, /* List: fcns(Twig, nil) = 79 */
	{   10,    0,    0,    0}, /* Twig: docnode(Rel, List) = 80 */
	{   10,    0,    0,    0}, /* Twig: docnode(Rel, fcns(nil, nil)) = 81 */
	{   10,    0,    0,    0}, /* Twig: element(Rel, List) = 82 */
	{   10,    0,    0,    0}, /* Twig: element(Rel, fcns(nil, nil)) = 83 */
	{   10,    0,    0,    0}, /* Twig: attribute(Rel) = 84 */
	{   10,    0,    0,    0}, /* Twig: textnode(Rel) = 85 */
	{   10,    0,    0,    0}, /* Twig: comment(Rel) = 86 */
	{   10,    0,    0,    0}, /* Twig: processi(Rel) = 87 */
	{   10,    0,    0,    0}, /* Twig: content(Frag, Rel) = 88 */
	{   10,    0,    0,    0}, /* Constr: merge_adjacent(Frag, Rel) = 89 */
	{    0,    0,    0,    0}, /* (none) = 90 */
	{    0,    0,    0,    0}, /* (none) = 91 */
	{    0,    0,    0,    0}, /* (none) = 92 */
	{    0,    0,    0,    0}, /* (none) = 93 */
	{    0,    0,    0,    0}, /* (none) = 94 */
	{    0,    0,    0,    0}, /* (none) = 95 */
	{    0,    0,    0,    0}, /* (none) = 96 */
	{   10,    0,    0,    0}, /* Side: error(Side, Rel) = 97 */
	{   10,    0,    0,    0}, /* Side: nil = 98 */
	{   10,    0,    0,    0}, /* Side: cache(Side, Rel) = 99 */
	{   10,    0,    0,    0}, /* Side: trace(Side, Trc) = 100 */
	{   10,    0,    0,    0}, /* Trc: trace_items(Rel, Msg) = 101 */
	{   10,    0,    0,    0}, /* Msg: trace_msg(Rel, Map) = 102 */
	{   10,    0,    0,    0}, /* Map: trace_map(Rel, Map) = 103 */
	{   10,    0,    0,    0}, /* Map: nil = 104 */
	{   10,    0,    0,    0}, /* Rel: rec_base = 105 */
	{   10,    0,    0,    0}, /* Rec: nil = 106 */
	{   10,    0,    0,    0}, /* Arg: rec_arg(Rel, Rel) = 107 */
	{   10,    0,    0,    0}, /* Arg: rec_arg(Rel, distinct(Rel)) = 108 */
	{   10,    0,    0,    0}, /* Rel: rec_fix(side_effects(nil, rec_param(rec_arg(Rel, Rel), rec_param(Arg, nil))), Rel) = 109 */
	{   10,    0,    0,    0}, /* Rel: rec_fix(side_effects(nil, rec_param(Arg, nil)), Rel) = 110 */
	{    0,    0,    0,    0}, /* (none) = 111 */
	{    0,    0,    0,    0}, /* (none) = 112 */
	{    0,    0,    0,    0}, /* (none) = 113 */
	{    0,    0,    0,    0}, /* (none) = 114 */
	{   10,    0,    0,    0}, /* Rel: dummy(Rel) = 115 */
	{   10,    0,    0,    0}, /* Rel: proxy(Rel) = 116 */
	{   10,    0,    0,    0}, /* Rel: proxy_base(Rel) = 117 */
	{   10,    0,    0,    0}, /* Rel: fun_call(Rel, Param) = 118 */
	{   10,    0,    0,    0}, /* Param: fun_param(Rel, Param) = 119 */
	{   10,    0,    0,    0}, /* Param: fun_frag_param(Frag, Param) = 120 */
	{   10,    0,    0,    0}, /* Param: nil = 121 */
};

short PFlalg2sql_delta_cost[115][14][4] = {
{{0}}, /* state 0 */
{ /* state #1: aggr(rank(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: aggr(rank(Rel)) = 36 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #2: aggr(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: aggr(Rel) = 35 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #3: attach(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: attach(Rel) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #4: attach(difference(rec_base, project(aggr(rank(rec_base))))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* Rel: attach(Rel) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #5: attach(difference(rec_base, project(aggr(rec_base)))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* Rel: attach(Rel) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #6: attribute(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: attribute(Rel) = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #7: bool_and(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: bool_and(Rel) = 28 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #8: bool_not(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: bool_not(Rel) = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #9: bool_or(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: bool_or(Rel) = 29 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #10: cache(nil, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: cache(Side, Rel) = 99 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #11: cast(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cast(Rel) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #12: comment(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: comment(Rel) = 86 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #13: content(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: content(Frag, Rel) = 88 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #14: cross(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cross(Rel, Rel) = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #15: difference(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: difference(Rel, Rel) = 22 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #16: difference(rec_base, project(aggr(rank(rec_base)))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Rel: difference(Rel, Rel) = 22 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #17: difference(rec_base, project(aggr(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* Rel: difference(Rel, Rel) = 22 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #18: disjunion(aggr(rec_base), attach(difference(rec_base, project(aggr(rec_base))))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: disjunion(aggr(Rel), attach(difference(Rel, project(aggr(Rel))))) = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #19: disjunion(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: disjunion(Rel, Rel) = 20 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #20: distinct(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: distinct(Rel) = 23 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #21: doc_access(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: doc_access(Frag, Rel) = 60 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #22: doc_index_join(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: doc_index_join(Frag, Rel) = 59 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #23: doc_tbl(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Constr: doc_tbl(Rel) = 70 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #24: docnode(rec_base, fcns(attribute(rec_base), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: docnode(Rel, List) = 80 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #25: docnode(rec_base, fcns(nil, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: docnode(Rel, fcns(nil, nil)) = 81 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #26: dummy(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: dummy(Rel) = 115 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #27: element(rec_base, fcns(nil, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: element(Rel, fcns(nil, nil)) = 83 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #28: element(rec_base, fcns(attribute(rec_base), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: element(Rel, List) = 82 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #29: empty_frag */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Frag: empty_frag = 66 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #30: empty_tbl */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #31: eqjoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: eqjoin(Rel, Rel) = 13 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #32: error(nil, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: error(Side, Rel) = 97 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #33: fcns(nil, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #34: fcns(attribute(rec_base), fcns(attribute(rec_base), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* List: fcns(Twig, List) = 78 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #35: fcns(attribute(rec_base), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* List: fcns(Twig, nil) = 79 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #36: frag_extract(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Frag: frag_extract(Rel) = 63 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #37: frag_union(empty_frag, fragment(twig(attribute(rec_base)))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Frag: frag_union(empty_frag, Frag) = 65 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #38: frag_union(empty_frag, empty_frag) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Frag: frag_union(empty_frag, Frag) = 65 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #39: frag_union(empty_frag, fragment(twig(content(empty_frag, rec_base)))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* Frag: frag_union(empty_frag, Frag) = 65 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #40: frag_union(frag_extract(rec_base), empty_frag) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Frag: frag_union(Frag, Frag) = 64 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #41: fragment(doc_tbl(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Frag: fragment(Constr) = 62 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #42: fragment(twig(content(empty_frag, rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Frag: fragment(Constr) = 62 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #43: fragment(twig(attribute(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Frag: fragment(Constr) = 62 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #44: fun_1to1(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: fun_1to1(Rel) = 25 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #45: fun_call(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: fun_call(Rel, Param) = 118 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #46: fun_frag_param(empty_frag, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Param: fun_frag_param(Frag, Param) = 120 */
},
{ /* state #47: fun_param(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Param: fun_param(Rel, Param) = 119 */
},
{ /* state #48: guide_step(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: guide_step(Frag, Rel) = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #49: guide_step_join(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: guide_step_join(Frag, Rel) = 58 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #50: intersect(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: intersect(Rel, Rel) = 21 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #51: lit_tbl */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: lit_tbl = 9 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #52: merge_adjacent(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Constr: merge_adjacent(Frag, Rel) = 89 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #53: nil */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Side: nil = 98 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Map: nil = 104 */
	{   10,    0,    0,    0}, /* Rec: nil = 106 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Param: nil = 121 */
},
{ /* state #54: num_eq(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: num_eq(Rel) = 26 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #55: num_gt(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: num_gt(Rel) = 27 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #56: pos_select(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: pos_select(Rel) = 18 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #57: processi(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: processi(Rel) = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #58: project(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #59: project(aggr(rank(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #60: project(aggr(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #61: project(rank(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #62: project(rank(distinct(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #63: proxy(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: proxy(Rel) = 116 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #64: proxy_base(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: proxy_base(Rel) = 117 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #65: rank(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: rank(Rel) = 52 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #66: rank(distinct(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Rel: rank(Rel) = 52 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #67: rec_arg(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Arg: rec_arg(Rel, Rel) = 107 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #68: rec_arg(rec_base, distinct(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Arg: rec_arg(Rel, distinct(Rel)) = 108 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #69: rec_base */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rec_base = 105 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #70: rec_fix(side_effects(nil, rec_param(rec_arg(rec_base, rec_base), rec_param(rec_arg(rec_base, rec_base), nil))), rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rec_fix(side_effects(nil, rec_param(rec_arg(Rel, Rel), rec_param(Arg, nil))), Rel) = 109 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #71: rec_fix(side_effects(nil, rec_param(rec_arg(rec_base, rec_base), nil)), rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rec_fix(side_effects(nil, rec_param(Arg, nil)), Rel) = 110 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #72: rec_param(rec_arg(rec_base, rec_base), rec_param(rec_arg(rec_base, rec_base), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #73: rec_param(rec_arg(rec_base, rec_base), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #74: ref_tbl */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: ref_tbl = 10 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #75: roots_(twig(content(empty_frag, rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Rel: roots_(Constr) = 61 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #76: roots_(twig(attribute(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: roots_(Constr) = 61 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #77: roots_(doc_tbl(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: roots_(Constr) = 61 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #78: rowid(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rowid(Rel) = 53 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #79: rownum(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rownum(Rel) = 50 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #80: rowrank(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rowrank(Rel) = 51 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #81: select_(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: select_(Rel) = 17 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #82: semijoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: semijoin(Rel, Rel) = 14 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #83: serialize_rel(nil, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_rel(Side, Rel) = 7 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #84: serialize_rel(nil, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_rel(nil, empty_tbl) = 8 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #85: serialize_seq(side_effects(nil, empty_frag), project(rank(distinct(rec_base)))) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), project(rank(distinct(Rel)))) = 4 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #86: serialize_seq(side_effects(nil, empty_frag), rec_base) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), Rel) = 1 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #87: serialize_seq(side_effects(nil, empty_frag), empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), empty_tbl) = 6 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #88: serialize_seq(side_effects(nil, empty_frag), distinct(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), distinct(Rel)) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #89: serialize_seq(side_effects(nil, empty_frag), project(rank(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), project(rank(Rel))) = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #90: serialize_seq(side_effects(nil, frag_union(empty_frag, fragment(twig(attribute(rec_base))))), roots_(twig(attribute(rec_base)))) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, frag_union(empty_frag, fragment(twig(Twig)))), roots_(twig(Twig))) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #91: side_effects(nil, frag_union(empty_frag, fragment(twig(attribute(rec_base))))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #92: side_effects(nil, rec_param(rec_arg(rec_base, rec_base), rec_param(rec_arg(rec_base, rec_base), nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #93: side_effects(nil, frag_union(empty_frag, fragment(twig(content(empty_frag, rec_base))))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #94: side_effects(nil, empty_frag) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #95: side_effects(nil, rec_param(rec_arg(rec_base, rec_base), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #96: step(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: step(Frag, Rel) = 55 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #97: step_join(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: step_join(Frag, Rel) = 57 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #98: string_join(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: string_join(Rel, Rel) = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #99: textnode(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: textnode(Rel) = 85 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #100: thetajoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: thetajoin(Rel, Rel) = 15 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #101: to(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: to(Rel) = 19 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #102: trace(nil, trace_items(rec_base, trace_msg(rec_base, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: trace(Side, Trc) = 100 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #103: trace_items(rec_base, trace_msg(rec_base, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Trc: trace_items(Rel, Msg) = 101 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #104: trace_map(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Map: trace_map(Rel, Map) = 103 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #105: trace_msg(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Msg: trace_msg(Rel, Map) = 102 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #106: twig(comment(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Constr: twig(comment(Rel)) = 76 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #107: twig(content(empty_frag, rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Constr: twig(Twig) = 71 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #108: twig(docnode(rec_base, fcns(nil, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Constr: twig(docnode(Rel, fcns(nil, nil))) = 72 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #109: twig(element(rec_base, fcns(nil, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Constr: twig(element(Rel, fcns(nil, nil))) = 73 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #110: twig(processi(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Constr: twig(processi(Rel)) = 77 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #111: twig(textnode(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Constr: twig(textnode(Rel)) = 75 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #112: twig(attribute(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Constr: twig(attribute(Rel)) = 74 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #113: type(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: type(Rel) = 31 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #114: type_assert(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: type_assert(Rel) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
};

char * PFlalg2sql_state_string[] = {
" not a state", /* state 0 */
	"aggr(rank(rec_base))", /* state #1 */
	"aggr(rec_base)", /* state #2 */
	"attach(rec_base)", /* state #3 */
	"attach(difference(rec_base, project(aggr(rank(rec_base)))))", /* state #4 */
	"attach(difference(rec_base, project(aggr(rec_base))))", /* state #5 */
	"attribute(rec_base)", /* state #6 */
	"bool_and(rec_base)", /* state #7 */
	"bool_not(rec_base)", /* state #8 */
	"bool_or(rec_base)", /* state #9 */
	"cache(nil, rec_base)", /* state #10 */
	"cast(rec_base)", /* state #11 */
	"comment(rec_base)", /* state #12 */
	"content(empty_frag, rec_base)", /* state #13 */
	"cross(rec_base, rec_base)", /* state #14 */
	"difference(rec_base, rec_base)", /* state #15 */
	"difference(rec_base, project(aggr(rank(rec_base))))", /* state #16 */
	"difference(rec_base, project(aggr(rec_base)))", /* state #17 */
	"disjunion(aggr(rec_base), attach(difference(rec_base, project(aggr(rec_base)))))", /* state #18 */
	"disjunion(rec_base, rec_base)", /* state #19 */
	"distinct(rec_base)", /* state #20 */
	"doc_access(empty_frag, rec_base)", /* state #21 */
	"doc_index_join(empty_frag, rec_base)", /* state #22 */
	"doc_tbl(rec_base)", /* state #23 */
	"docnode(rec_base, fcns(attribute(rec_base), nil))", /* state #24 */
	"docnode(rec_base, fcns(nil, nil))", /* state #25 */
	"dummy(rec_base)", /* state #26 */
	"element(rec_base, fcns(nil, nil))", /* state #27 */
	"element(rec_base, fcns(attribute(rec_base), nil))", /* state #28 */
	"empty_frag", /* state #29 */
	"empty_tbl", /* state #30 */
	"eqjoin(rec_base, rec_base)", /* state #31 */
	"error(nil, rec_base)", /* state #32 */
	"fcns(nil, nil)", /* state #33 */
	"fcns(attribute(rec_base), fcns(attribute(rec_base), nil))", /* state #34 */
	"fcns(attribute(rec_base), nil)", /* state #35 */
	"frag_extract(rec_base)", /* state #36 */
	"frag_union(empty_frag, fragment(twig(attribute(rec_base))))", /* state #37 */
	"frag_union(empty_frag, empty_frag)", /* state #38 */
	"frag_union(empty_frag, fragment(twig(content(empty_frag, rec_base))))", /* state #39 */
	"frag_union(frag_extract(rec_base), empty_frag)", /* state #40 */
	"fragment(doc_tbl(rec_base))", /* state #41 */
	"fragment(twig(content(empty_frag, rec_base)))", /* state #42 */
	"fragment(twig(attribute(rec_base)))", /* state #43 */
	"fun_1to1(rec_base)", /* state #44 */
	"fun_call(rec_base, nil)", /* state #45 */
	"fun_frag_param(empty_frag, nil)", /* state #46 */
	"fun_param(rec_base, nil)", /* state #47 */
	"guide_step(empty_frag, rec_base)", /* state #48 */
	"guide_step_join(empty_frag, rec_base)", /* state #49 */
	"intersect(rec_base, rec_base)", /* state #50 */
	"lit_tbl", /* state #51 */
	"merge_adjacent(empty_frag, rec_base)", /* state #52 */
	"nil", /* state #53 */
	"num_eq(rec_base)", /* state #54 */
	"num_gt(rec_base)", /* state #55 */
	"pos_select(rec_base)", /* state #56 */
	"processi(rec_base)", /* state #57 */
	"project(rec_base)", /* state #58 */
	"project(aggr(rank(rec_base)))", /* state #59 */
	"project(aggr(rec_base))", /* state #60 */
	"project(rank(rec_base))", /* state #61 */
	"project(rank(distinct(rec_base)))", /* state #62 */
	"proxy(rec_base)", /* state #63 */
	"proxy_base(rec_base)", /* state #64 */
	"rank(rec_base)", /* state #65 */
	"rank(distinct(rec_base))", /* state #66 */
	"rec_arg(rec_base, rec_base)", /* state #67 */
	"rec_arg(rec_base, distinct(rec_base))", /* state #68 */
	"rec_base", /* state #69 */
	"rec_fix(side_effects(nil, rec_param(rec_arg(rec_base, rec_base), rec_param(rec_arg(rec_base, rec_base), nil))), rec_base)", /* state #70 */
	"rec_fix(side_effects(nil, rec_param(rec_arg(rec_base, rec_base), nil)), rec_base)", /* state #71 */
	"rec_param(rec_arg(rec_base, rec_base), rec_param(rec_arg(rec_base, rec_base), nil))", /* state #72 */
	"rec_param(rec_arg(rec_base, rec_base), nil)", /* state #73 */
	"ref_tbl", /* state #74 */
	"roots_(twig(content(empty_frag, rec_base)))", /* state #75 */
	"roots_(twig(attribute(rec_base)))", /* state #76 */
	"roots_(doc_tbl(rec_base))", /* state #77 */
	"rowid(rec_base)", /* state #78 */
	"rownum(rec_base)", /* state #79 */
	"rowrank(rec_base)", /* state #80 */
	"select_(rec_base)", /* state #81 */
	"semijoin(rec_base, rec_base)", /* state #82 */
	"serialize_rel(nil, rec_base)", /* state #83 */
	"serialize_rel(nil, empty_tbl)", /* state #84 */
	"serialize_seq(side_effects(nil, empty_frag), project(rank(distinct(rec_base))))", /* state #85 */
	"serialize_seq(side_effects(nil, empty_frag), rec_base)", /* state #86 */
	"serialize_seq(side_effects(nil, empty_frag), empty_tbl)", /* state #87 */
	"serialize_seq(side_effects(nil, empty_frag), distinct(rec_base))", /* state #88 */
	"serialize_seq(side_effects(nil, empty_frag), project(rank(rec_base)))", /* state #89 */
	"serialize_seq(side_effects(nil, frag_union(empty_frag, fragment(twig(attribute(rec_base))))), roots_(twig(attribute(rec_base))))", /* state #90 */
	"side_effects(nil, frag_union(empty_frag, fragment(twig(attribute(rec_base)))))", /* state #91 */
	"side_effects(nil, rec_param(rec_arg(rec_base, rec_base), rec_param(rec_arg(rec_base, rec_base), nil)))", /* state #92 */
	"side_effects(nil, frag_union(empty_frag, fragment(twig(content(empty_frag, rec_base)))))", /* state #93 */
	"side_effects(nil, empty_frag)", /* state #94 */
	"side_effects(nil, rec_param(rec_arg(rec_base, rec_base), nil))", /* state #95 */
	"step(empty_frag, rec_base)", /* state #96 */
	"step_join(empty_frag, rec_base)", /* state #97 */
	"string_join(rec_base, rec_base)", /* state #98 */
	"textnode(rec_base)", /* state #99 */
	"thetajoin(rec_base, rec_base)", /* state #100 */
	"to(rec_base)", /* state #101 */
	"trace(nil, trace_items(rec_base, trace_msg(rec_base, nil)))", /* state #102 */
	"trace_items(rec_base, trace_msg(rec_base, nil))", /* state #103 */
	"trace_map(rec_base, nil)", /* state #104 */
	"trace_msg(rec_base, nil)", /* state #105 */
	"twig(comment(rec_base))", /* state #106 */
	"twig(content(empty_frag, rec_base))", /* state #107 */
	"twig(docnode(rec_base, fcns(nil, nil)))", /* state #108 */
	"twig(element(rec_base, fcns(nil, nil)))", /* state #109 */
	"twig(processi(rec_base))", /* state #110 */
	"twig(textnode(rec_base))", /* state #111 */
	"twig(attribute(rec_base))", /* state #112 */
	"type(rec_base)", /* state #113 */
	"type_assert(rec_base)", /* state #114 */
};
char *PFlalg2sql_ntname[] = {
	"Error: Nonterminals are > 0",
	"Query",
	"Rel",
	"Frag",
	"Constr",
	"List",
	"Twig",
	"Side",
	"Trc",
	"Msg",
	"Map",
	"Rec",
	"Arg",
	"Param",
	0
};

short PFlalg2sql_closure[14][14] = {
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,},
};
#line 365 "lalg2sql.brg"


#include "sql_mnemonic.h"
#include "properties.h"

#define MAX_KIDS 5

/** Macro determining if a node was already visited */
#define SEEN(p)   ((p)->bit_dag)

/**
 * We collect the SQL statements during compilation here.
 */
static PFsql_t *sql_stmts;

/**
 * true if we are in a recursion branch
 */
static bool rec_branch;

/**
 * Generate DB2 SELECTIVITY hints;
 */
static bool selectivity;
/**
 * Generate bindings for operators with multiple references.
 */
static bool bind_multi_ref;

/* The execute is used to construct the sequence
 * of `common table expressions'.
 */
#define execute(c)      sql_stmts = (sql_stmts == NULL)?  \
                        common_table_expr(nil(),(c)):     \
                        common_table_expr(sql_stmts,(c));

/**
 * We define the fragment with the maximum pre value here.
 */
static PFsql_t *max_pre_frag;

/* we "mask out" the flags regarding the generation of attributes,
 * up to now we don't support attributes */
#define TYPE_MASK(t)  ((t) & ~(aat_frag | aat_attr | aat_nkind))

/* reference counter */
#define REFCTR(p)     ((p)->refctr)

#define BOUND(p)      ((p)->sql_ann->bound)
#define COLMAP(p)     ((p)->sql_ann->colmap)
#define FROMLIST(p)   ((p)->sql_ann->frommap)
#define WHERELIST(p)  ((p)->sql_ann->wheremap)
#define FRAG(p)       ((p)->sql_ann->fragment)
#define CSIZE(p)      ((p)->sql_ann->content_size)
#define TPRE(p)       ((p)->sql_ann->twig_pre)
#define TSIZE(p)      ((p)->sql_ann->twig_size)
#define TLEVEL(p)     ((p)->sql_ann->twig_level)
/* serialization report */
#define SER_REPORT(p) ((p)->sql_ann->ser_report)

/* check if sql_statement is a literal */
#define IS_LITERAL(s) (s->kind == sql_lit_int \
                     || s->kind == sql_lit_lng \
                     || s->kind == sql_lit_dec \
                     || s->kind == sql_lit_str)


/* .......... Generic Helper Functions .......... */

/**
 * Returns the type of an attribute.
 */
static PFalg_simple_type_t
type_of_ (const PFla_op_t * n, PFalg_col_t col)
{
    assert (n);

    for (unsigned int i = 0; i < n->schema.count; i++)
        if (n->schema.items[i].name == col)
            return TYPE_MASK (n->schema.items[i].type);

#ifndef NDEBUG
    return 0;
#else
    PFoops (OOPS_FATAL,
            "SQLgen: cannot determine implementation type of "
            "column %s.",
            PFcol_str (col));

    return aat_nat; /* satisfy picky compilers */
#endif
}
#ifndef NDEBUG
#define type_of(node,col) (assert (type_of_((node), (col))), \
                           type_of_((node), (col)))
#else
#define type_of(node,col) type_of_((node), (col))
#endif

/**
 * Construct a literal from a given algebra atom.
 */
static PFsql_t *
literal (PFalg_atom_t atom)
{
    switch (atom.type) {
        case aat_nat:       return lit_int (atom.val.nat_);
        case aat_int:       return lit_int (atom.val.int_);
        case aat_str:       return lit_str (atom.val.str);
        case aat_bln:       return lit_int (atom.val.bln?1:0);
        case aat_dbl:       return lit_dec (atom.val.dbl);
        case aat_dec:       return lit_dec (atom.val.dec_);
        case aat_qname_loc: return lit_str (PFqname_loc (atom.val.int_));
        case aat_qname_uri: return lit_str (PFqname_uri (atom.val.int_));
        default: break;
    }

    PFoops (OOPS_FATAL,
            "SQLgen: a relational algebra type (0x%X) has not "
            "been implemented yet.",
            atom.type);

    return NULL; /* satisfy picky compilers */
}

/* static variable that holds the actual table-number */
static unsigned int table_varno;

/**
 * Returns a new table name.
 */
static PFsql_tident_t
new_table_name ()
{
    return table_varno++;
}

/* static variable that holds the actual alias-number */
static unsigned int alias_varno;

/**
 * Returns a new alias.
 */
static PFsql_aident_t
new_alias (void)
{
    return alias_varno++;
}

/**
 * Returns a special column name
 * (like pre or size, following our encoding scheme).
 */
static PFsql_col_t *
special_col (PFsql_special_t spc)
{
    PFsql_col_t *ret = (PFsql_col_t *) PFmalloc (sizeof (PFsql_col_t));
    ret->spec = spc;
    ret->id   = PF_SQL_COLUMN_SPECIAL;
    return ret;
}

/* creates a special column like the columns in the XML-document relation */
#define PRE_        column_name (special_col (sql_col_pre))
#define SIZE_       column_name (special_col (sql_col_size))
#define LEVEL_      column_name (special_col (sql_col_level))
#define KIND_       column_name (special_col (sql_col_kind))
#define NAME_       column_name (special_col (sql_col_name))
#define NS_URI_     column_name (special_col (sql_col_ns_uri))
#define GUIDE_      column_name (special_col (sql_col_guide))
#define VALUE_      column_name (special_col (sql_col_value))
#define TWIG_PRE_   column_name (special_col (sql_col_twig_pre))
#define ITER_       column_name (special_col (sql_col_iter))
#define POS_        column_name (special_col (sql_col_pos))
#define MAX_        column_name (special_col (sql_col_max))
#define DIST_       column_name (special_col (sql_col_dist))
#define ERR_        column_name (special_col (sql_col_err))
#define SEP_        column_name (special_col (sql_col_sep))
#define SUR_        column_name (special_col (sql_col_sur))

#define PRE(n)        ext_column_name (n, special_col (sql_col_pre))
#define SIZE(n)       ext_column_name (n, special_col (sql_col_size))
#define LEVEL(n)      ext_column_name (n, special_col (sql_col_level))
#define KIND(n)       ext_column_name (n, special_col (sql_col_kind))
#define NAME(n)       ext_column_name (n, special_col (sql_col_name))
#define NS_URI(n)     ext_column_name (n, special_col (sql_col_ns_uri))
#define GUIDE(n)      ext_column_name (n, special_col (sql_col_guide))
#define VALUE(n)      ext_column_name (n, special_col (sql_col_value))
#define TWIG_PRE(n)   ext_column_name (n, special_col (sql_col_twig_pre))
#define ITER(n)       ext_column_name (n, special_col (sql_col_iter))
#define POS(n)        ext_column_name (n, special_col (sql_col_pos))
#define MAX(n)        ext_column_name (n, special_col (sql_col_max))
#define SEP(n)        ext_column_name (n, special_col (sql_col_sep))
#define SUR(n)        ext_column_name (n, special_col (sql_col_sur))

#define TRUE_STR       lit_str("true")
#define FALSE_STR      lit_str("false")
#define TRUE_DEC       lit_dec(1.0E0)
#define FALSE_DEC      lit_dec(0.0E0)
#define TRUE_INT       lit_int(1)
#define FALSE_INT      lit_int(0)


/* static variable that holds the current col-number */
static unsigned int col_varno;

/**
 * Returns a new column name
 * (also storing its logical algebra name and its type).
 */
static PFsql_col_t *
new_col (PFalg_col_t col, PFalg_simple_type_t ty)
{
    PFsql_col_t *ret = (PFsql_col_t *) PFmalloc (sizeof (PFsql_col_t));
    ret->col = col;
    ret->ty  = ty;
    ret->id  = col_varno++;
    return ret;
}

/** creates a column (determining his type from the given col/ty pair) */
#define COLUMN_NAME(col,ty)           (column_name (new_col ((col),(ty))))
#define EXT_COLUMN_NAME(alias,col,ty) (ext_column_name ( \
                                           (alias), new_col ((col),(ty))))

/* .......... Column Environment Helper Functions .......... */

struct sql_column_env_t
{
    PFalg_simple_type_t type;
    PFalg_col_t         col;
    PFsql_t            *expression;
    PFsql_aident_t      step_alias;
    bool                step_leaf;
};
typedef struct sql_column_env_t sql_column_env_t;

/**
 * Returns a new column environment.
 */
#define col_env_new() (PFarray (sizeof (sql_column_env_t), 20))

/**
 * Adds a (column/type -> expression)
 * mapping to the column-environment.
 */
static void
col_env_add_full (PFarray_t * env, PFalg_col_t col,
                  PFalg_simple_type_t ty, PFsql_t * expr,
                  PFsql_aident_t step_alias,
                  bool step_leaf)
{
    ty = TYPE_MASK (ty);

    /* we can add only the types specified here */
    assert (ty == aat_nat       || ty == aat_int       ||
            ty == aat_dbl       || ty == aat_dec       ||
            ty == aat_str       || ty == aat_uA        ||
            ty == aat_bln       || ty == aat_pre       ||
            ty == aat_qname_loc || ty == aat_qname_uri ||
            ty == aat_date);

    *(sql_column_env_t *) PFarray_add (env) =
        (sql_column_env_t) { .type = ty,
                             .col = col,
                             .expression = expr,
                             .step_alias = step_alias,
                             .step_leaf = step_leaf };
}
#define col_env_add(e,a,t,s) col_env_add_full(e,a,t,s,              \
                                              PF_SQL_ALIAS_UNBOUND, \
                                              false)

/**
 * Returns an environment item at a specific position
 */
#define col_env_at(env,i) (*(sql_column_env_t *) PFarray_at (env, i))

/**
 * Add a given fromlist @a src to another fromlist @a dest.
 */
static void
col_env_copy (PFarray_t * dest, PFarray_t * src)
{
    /* copy all existing expressions */
    for (unsigned int i = 0; i < PFarray_last (src); i++) {
        sql_column_env_t entry = col_env_at (src, i);
        col_env_add_full (dest,
                          entry.col,
                          entry.type,
                          entry.expression,
                          entry.step_alias,
                          entry.step_leaf);
    }
}

/**
 * Returns the expression associated with a given column/type
 * pair. If there doesn't exist an expression, simply return NULL.
 */
static PFsql_t *
col_env_lookup_unsafe (const PFarray_t * env, PFalg_col_t col,
                       PFalg_simple_type_t ty)
{
    for (unsigned int i = 0; i < PFarray_last (env); i++) {
        sql_column_env_t entry =
            *(sql_column_env_t *) PFarray_at ((PFarray_t *) env, i);

        if (entry.col == col && TYPE_MASK (entry.type) == TYPE_MASK (ty))
            return entry.expression;
    }
    return NULL;
}

/**
 * Returns the expression associated with a given column/type
 * pair. Abort the codegeneration and produce an error message,
 * when there is no expression, for the col/type pair.
 */
static PFsql_t *
col_env_lookup_ (const PFarray_t * env, PFalg_col_t col,
                 PFalg_simple_type_t ty)
{
    ty = TYPE_MASK (ty);
    PFsql_t *expr = col_env_lookup_unsafe (env, col, ty);

    if (expr)
        return expr;

#ifndef NDEBUG
    fprintf (stderr, "looking for col: %s, ty: 0x%X\n", PFcol_str (col), ty);
    fprintf (stderr, "environment looks like:\n");
    for (unsigned int i = 0; i < PFarray_last (env); i++) {
        sql_column_env_t entry =
            *(sql_column_env_t *) PFarray_at ((PFarray_t *) env, i);

        fprintf (stderr, "  col: %s, type: 0x%X, sql-op kind: %u\n",
                 PFcol_str (entry.col), entry.type,
                 entry.expression->kind);
    }
#else
    PFoops (OOPS_FATAL,
            "SQLgen: column '%s' with type '0x%X' "
            "not found in environment", PFcol_str (col), ty);
#endif
    return NULL; /* satisfy picky compilers */
}
#ifndef NDEBUG
#define col_env_lookup(env,col,ty) (assert (col_env_lookup_(env,col,ty)), \
                                    col_env_lookup_(env,col,ty))
#else
#define col_env_lookup(env,col,ty) col_env_lookup_(env,col,ty)
#endif

static PFsql_aident_t
col_env_lookup_step (const PFarray_t * env, PFalg_col_t col,
                     PFalg_simple_type_t ty)
{
    for (unsigned int i = 0; i < PFarray_last (env); i++) {
        sql_column_env_t entry =
            *(sql_column_env_t *) PFarray_at ((PFarray_t *) env, i);

        if (entry.col == col && TYPE_MASK (entry.type) == TYPE_MASK (ty))
            return entry.step_alias;
    }
    return PF_SQL_ALIAS_UNBOUND;
}

static bool
col_env_lookup_step_leaf (const PFarray_t * env, PFalg_col_t col,
                          PFalg_simple_type_t ty)
{
    for (unsigned int i = 0; i < PFarray_last (env); i++) {
        sql_column_env_t entry =
            *(sql_column_env_t *) PFarray_at ((PFarray_t *) env, i);

        if (entry.col == col && TYPE_MASK (entry.type) == TYPE_MASK (ty))
            return entry.step_leaf;
    }
    return false;
}

bool
column_eq (PFsql_col_t *a, PFsql_col_t *b)
{
    if (a->id == PF_SQL_COLUMN_SPECIAL &&
        b->id == PF_SQL_COLUMN_SPECIAL)
        return (a->spec == b->spec);
    else
      return (a->col == b->col) &&
             (a->ty  == b->ty);
}

/**
 * Transforms an expression into a selectlist statement.
 */
static PFsql_t *
transform_expression (PFsql_t *n, PFsql_t *col)
{
    assert (col->kind == sql_column_name &&
            col->sem.column.name->id != PF_SQL_COLUMN_SPECIAL);

    /* we have a different strategy when our item is boolean */
    if (col->sem.column.name->ty == aat_bln)
        n = (n->kind == sql_column_name ||
             n->kind == sql_lit_int ||
             /* in case we have a max or min over a boolean
              * value, we don't wrap it into another case
              * statement, since in case of a condition
              * we dump the statement before the aggregate
              * is used. */
             n->kind == sql_max ||
             n->kind == sql_min)?
            n:
            case_ (when (n, TRUE_INT), else_ (FALSE_INT));

    if (n->kind == sql_column_name)
    {
        if (column_eq (n->sem.column.name, col->sem.column.name))
            return n;
        else
            return column_assign (n, col);
    }
    else
        return column_assign (n, col);
}

/**
 * Transform a column environment in a column-list
 */
static PFsql_t *
transform_columnlist (PFarray_t *col_env)
{
    PFsql_t * collist = NULL;
    for (unsigned int i = 0; i < PFarray_last (col_env); i++) {
        sql_column_env_t colitem = col_env_at (col_env, i);
        collist = column_list (collist,
                           column_name (new_col (colitem.col, colitem.type)));
    }
    return collist;
}

/**
 * Transform a column environment in a select-list
 */
static PFsql_t *
transform_selectlist (PFarray_t *col_env)
{
    PFsql_t * sellist = NULL;
    for (unsigned int i = 0; i < PFarray_last (col_env); i++) {
        sql_column_env_t colitem = col_env_at (col_env, i);
        sellist = select_list (sellist,
                       transform_expression (colitem.expression,
                          column_name (new_col (colitem.col, colitem.type))));
    }
    return sellist;
}

/**
 * Bind every column in the environment list to
 * a new alias @a ident.
 */
static void
transform_colenv (PFarray_t *col_env, PFsql_aident_t ident)
{
    for (unsigned int i = 0; i < PFarray_last (col_env); i++) {
        sql_column_env_t * colitem =
            (sql_column_env_t *) PFarray_at (col_env, i);
        if (colitem->expression->kind == sql_column_name) {
            colitem->expression =
                       ext_column_name (
                              ident,
                              colitem->expression->sem.column.name
                              );
        }
        else if (colitem->expression->kind == sql_ref_column_name) {
            colitem->expression =
                       ref_column_name (
                              ident,
                              colitem->expression->sem.ref_column_name.name
                              );
        }
    }
}

/* .......... FROM List Helper Functions .......... */

struct sql_from_list_t
{
    PFsql_t       *table;
    PFsql_t       *alias;
};
typedef struct sql_from_list_t sql_from_list_t;

/**
 * Returns a new fromlist.
 */
#define from_list_new() (PFarray (sizeof (sql_from_list_t), 10))

/**
 * Add a (table, alias) pair to the fromlist.
 */
#define from_list_add(fl,t,a) *(sql_from_list_t *) PFarray_add (fl) = \
                                    (sql_from_list_t) { .table = t, .alias = a }

/**
 * Returns a (table, alias) pair at a specific position.
 */
#define from_list_at(fl,i) (*(sql_from_list_t *) PFarray_at (fl, i))

/**
 * Add a given fromlist @a src to another fromlist @a dest.
 */
static void
from_list_copy (PFarray_t *dest, PFarray_t *src)
{
    for (unsigned int i = 0; i < PFarray_last (src); i++) {
        sql_from_list_t from_clause = from_list_at (src, i);
        from_list_add (dest, from_clause.table, from_clause.alias);
    }
}

/**
 * Transform a fromlist into a list of SQL from clauses.
 *
 * (Use this extended variant if you want to patch holes
 *  (NULL values) with the SQL tree in @a tbl.)
 */
static PFsql_t *
transform_frommap_ext (PFla_op_t *p, PFsql_t *tbl)
{
    PFsql_t *fromlist = NULL;
    sql_from_list_t from_clause;

    assert (PFarray_last (FROMLIST(p)));

    for (int i = PFarray_last (FROMLIST(p)) - 1; i >= 0; i--) {
        from_clause = *(sql_from_list_t *) PFarray_at (FROMLIST(p), i);
        fromlist = from_list (fromlist,
                              alias_bind (
                                  /* check for a NULL value */
                                  from_clause.table
                                  ? from_clause.table : tbl,
                                  from_clause.alias));
    }

    return fromlist;
}
#define transform_frommap(p) transform_frommap_ext(p,NULL)

/* .......... WHERE List Helper Functions .......... */

/**
 * Returns a new wherelist.
 */
#define where_list_new() (PFarray (sizeof (PFsql_t *), 10))

/**
 * Add a predicate to the wherelist.
 */
#define where_list_add(wl,e) *(PFsql_t **) PFarray_add (wl) = e

/**
 * Returns a predicate at a specific position.
 */
#define where_list_at(wl,i) (*(PFsql_t **) PFarray_at (wl, i))

/**
 * Add a given fromlist @a src to another fromlist @a dest.
 */
static void
where_list_copy (PFarray_t *dest, PFarray_t *src)
{
    for (unsigned int i = 0; i < PFarray_last (src); i++) {
        PFsql_t *where_clause = where_list_at (src, i);
        where_list_add (dest, where_clause);
    }
}

/**
 * Transform a wherelist into a list of SQL predicates.
 */
static PFsql_t *
transform_wheremap (PFla_op_t *p)
{
    PFsql_t *wherelist = NULL, *where_clause = NULL;

    for (int i = PFarray_last (WHERELIST(p)) - 1; i >= 0; i--) {
        where_clause = *(PFsql_t **) PFarray_at (WHERELIST(p), i);
        wherelist = where_list (wherelist, where_clause);
    }

    return wherelist;
}



/*............ Annotations ...........*/

/**
 * Return a new algebra annotation.
 * @note
 *     Each node of the algebra contains annotations regarding the
 *     SQL-Codegeneration.
 */
static PFsql_alg_ann_t *
sql_alg_ann_new (void)
{
    PFsql_alg_ann_t *ret =
        (PFsql_alg_ann_t *) PFmalloc (sizeof (PFsql_alg_ann_t));

    ret->bound        = false;
    ret->colmap       = col_env_new ();
    ret->frommap      = from_list_new ();
    ret->wheremap     = where_list_new ();
    ret->fragment     = NULL;
    ret->content_size = NULL;
    ret->ser_report   = ser_no;
    ret->ser_list1    = NULL;
    ret->bind         = true;

    return ret;
}



/* .......... Alias Substitution Helper Functions .......... */

struct sql_alias_map_t
{
    PFsql_aident_t new;
    PFsql_aident_t old;
};
typedef struct sql_alias_map_t sql_alias_map_t;

/**
 * helper for substitute_aliases.
 * It recursively replaces all old aliases by the new ones.
 */
static void
substitute_aliases_helper (PFsql_t *sqlnode,
                           sql_alias_map_t map[],
                           unsigned int map_count)
{
    for (unsigned int i = 0; i < PFSQL_OP_MAXCHILD && sqlnode->child[i]; i++)
        substitute_aliases_helper (sqlnode->child[i], map, map_count);

    if ((sqlnode->kind == sql_column_name &&
        sqlnode->sem.column.alias != PF_SQL_ALIAS_UNBOUND)) {
            for (unsigned int i = 0; i < map_count; i++)
                if (map[i].old == sqlnode->sem.column.alias) {
                    sqlnode->sem.column.alias = map[i].new;
                    break;
                }
    } else if (sqlnode->kind == sql_ref_column_name) {
        for (unsigned int i = 0; i < map_count; i++)
            if (map[i].old == sqlnode->sem.ref_column_name.alias) {
                sqlnode->sem.ref_column_name.alias = map[i].new;
                break;
            }
    }
}

/**
 * substitute_aliases iterates over the from list and creates
 * an alias mapping (old<->new). Then it iterates over colmap,
 * frommap and wheremap and recursively replace all old aliases
 * by the new ones.
 */
static void
substitute_aliases (PFla_op_t * p)
{
    unsigned int count = PFarray_last (FROMLIST(p));
    sql_alias_map_t map[count];
    sql_column_env_t entry;

    /* prepare an alias map with new aliases and
       replace the old aliases in the from list */
    for (unsigned int i = 0; i < count; i++) {
        map[i].new = new_alias ();
        map[i].old = (from_list_at (FROMLIST(p), i)).alias->sem.alias.name;

        /* Copy the expressions in the fromlist */
        (from_list_at (FROMLIST(p), i)).alias
            = duplicate ((from_list_at (FROMLIST(p), i)).alias);
        (from_list_at (FROMLIST(p), i)).table
            = duplicate ((from_list_at (FROMLIST(p), i)).table);

        (from_list_at (FROMLIST(p), i)).alias->sem.alias.name = map[i].new;
    }

    for (unsigned int i = 0; i < PFarray_last (COLMAP(p)); i++) {
        entry = col_env_at (COLMAP(p), i);
        /* Copy the expressions in the column map, ... */
        entry.expression = duplicate (entry.expression);
        /* ... replace all aliases, ... */
        substitute_aliases_helper (entry.expression, map, count);

        /* ... make sure that we replace also the step aliases, ... */
        if (entry.step_alias != PF_SQL_ALIAS_UNBOUND)
            for (unsigned int j = 0; j < count; j++)
                if (map[j].old == entry.step_alias) {
                    entry.step_alias = map[j].new;
                    break;
                }
        /* ... and then replace the binding. */
        *(sql_column_env_t *) PFarray_at ((PFarray_t *) COLMAP(p), i) = entry;
    }

    for (unsigned int i = 0; i < PFarray_last (WHERELIST(p)); i++) {
        /* Copy the wherelist, ... */
        PFsql_t *expr = duplicate (where_list_at (WHERELIST(p), i));
        /* ... replace all aliases, ... */
        substitute_aliases_helper (expr, map, count);
        /* ... and then replace the binding. */
        *(PFsql_t **) PFarray_at ((PFarray_t *) WHERELIST(p), i) = expr;
    }
}

/* returns a copy of the given @a qname_atom with eiter
 * aat_qname_loc or aat_qname_uri to represent either the
 * local part or the uri of the namespace
 */
static PFalg_atom_t
namespace_atom (PFalg_atom_t qname_atom, PFalg_simple_type_t ty)
{
    PFalg_atom_t ret;
    assert (qname_atom.type == aat_qname &&
            (ty == aat_qname_loc ||
             ty == aat_qname_uri));

    ret = qname_atom;
    ret.type = ty;
    return ret;
}



/* .......... Path Step Helper Functions .......... */

static void
step_sibling (PFla_op_t *p, PFsql_aident_t ctx, PFsql_aident_t step,
              PFsql_t *fragment)
{
    PFsql_aident_t par  = new_alias ();
    from_list_add (FROMLIST(p), fragment, alias (par));

    /* parent step */
    /* ctx.pre > par.pre and par.pre + par.size >= ctx.pre */
    where_list_add (WHERELIST(p),
                    between (PRE(ctx), add (PRE(par), lit_int (1)),
                             add(PRE(par), SIZE(par))));
    where_list_add (WHERELIST(p),
                    eq (add (LEVEL(par), lit_int (1)), LEVEL(ctx)));
    /* child step */
    where_list_add (WHERELIST(p),
                    between (PRE(step), add (PRE(par), lit_int (1)),
                             add (PRE(par), SIZE(par))));
    where_list_add (WHERELIST(p),
                    eq (LEVEL(ctx), LEVEL(step)));
}

static bool
is_step (PFla_op_t *p)
{
    return p->kind == la_step ||
           p->kind == la_guide_step ||
           p->kind == la_step_join ||
           p->kind == la_guide_step_join;
}

static void
step_axis (PFla_op_t *p, PFsql_aident_t ctx, PFsql_aident_t step,
           PFalg_axis_t axis, PFsql_t *fragment, int level_in)
{
    switch (axis) {
        /* ancestor axis */
        case alg_anc:
        /* parent axis */
        case alg_par:
            where_list_add (WHERELIST(p),
                            between (PRE(ctx), add (PRE(step), lit_int (1)),
                                     add (PRE(step), SIZE(step))));
            break;

        /* ancestor-or-self axis */
        case alg_anc_s:
            where_list_add (WHERELIST(p),
                            between (PRE(ctx), PRE(step),
                                     add (PRE(step), SIZE(step))));
            break;

        /* descendant axis */
        case alg_desc:
        /* child axis */
        case alg_chld:
        /* attribute axis */
        case alg_attr:
            if (selectivity && is_step (p)) {
                if ((level_in == 0 || level_in == 1) &&
                    /* check for steps from a single document */
                    L(p)->kind == la_frag_union &&
                    LL(p)->kind == la_empty_frag &&
                    LR(p)->kind == la_fragment &&
                    L(LR(p))->kind == la_doc_tbl) {
                    where_list_add (WHERELIST(p),
                                    selectivity (gt (PRE(step), PRE(ctx)),
                                                 lit_dec (1)));
                    where_list_add (WHERELIST(p),
                                    selectivity (gteq (add (PRE(ctx),
                                                            SIZE(ctx)),
                                                       PRE(step)),
                                                 lit_dec (1)));
                } else {
                    where_list_add (WHERELIST(p),
                                    selectivity (gt (PRE(step), PRE(ctx)),
                                                 lit_dec (0.01)));
                    where_list_add (WHERELIST(p),
                                    selectivity (gteq (add (PRE(ctx),
                                                            SIZE(ctx)),
                                                       PRE(step)),
                                                 lit_dec (0.01)));
                }
            } else
                where_list_add (WHERELIST(p),
                                between (PRE(step), add (PRE(ctx),
                                         lit_int (1)),
                                         add (PRE(ctx), SIZE(ctx))));
            break;

        /* descendant-or-self axis */
        case alg_desc_s:
            if (selectivity && is_step (p)) {
                if ((level_in == 0 || level_in == 1) &&
                    /* check for steps from a single document */
                    L(p)->kind == la_frag_union &&
                    LL(p)->kind == la_empty_frag &&
                    LR(p)->kind == la_fragment &&
                    L(LR(p))->kind == la_doc_tbl) {
                    where_list_add (WHERELIST(p),
                                    selectivity (gteq (PRE(step), PRE(ctx)),
                                                 lit_dec (1)));
                    where_list_add (WHERELIST(p),
                                    selectivity (gteq (add (PRE(ctx),
                                                            SIZE(ctx)),
                                                     PRE(step)),
                                                 lit_dec (1)));
                } else {
                    where_list_add (WHERELIST(p),
                                    selectivity (gteq (PRE(step), PRE(ctx)),
                                                 lit_dec (0.01)));
                    where_list_add (WHERELIST(p),
                                    selectivity (gteq (add (PRE(ctx),
                                                            SIZE(ctx)),
                                                     PRE(step)),
                                                 lit_dec (0.01)));
                }
            } else
                where_list_add (WHERELIST(p),
                                between (PRE(step), PRE(ctx),
                                         add (PRE(ctx), SIZE(ctx))));
            break;

        /* following-sibling axis */
        case alg_fol_s:
            step_sibling (p, ctx, step, fragment);
            /* continue with the following axis */

        /* following axis */
        case alg_fol:
            where_list_add (WHERELIST(p),
                            gt (PRE(step), add (PRE(ctx), SIZE(ctx))));
            break;

        /* preceding-sibling axis */
        case alg_prec_s:
            step_sibling (p, ctx, step, fragment);
            /* continue with the preceding axis */

        /* preceding axis */
        case alg_prec:
            where_list_add (WHERELIST(p),
                            gt (PRE(ctx), add (PRE(step), SIZE(step))));
            break;

        /* StandOff axis: select-narrow */
        case alg_so_select_narrow:
            /* FIXME (Wouter): implement */
            break;
        /* StandOff axis: select-wide */
        case alg_so_select_wide:
            /* FIXME (Wouter): implement */
            break;

        /* self axis */
        case alg_self:
            where_list_add (WHERELIST(p),
                            eq (PRE(step), PRE(ctx)));
            break;
    }
}

static void
step_level (PFla_op_t *p, PFsql_aident_t ctx, PFsql_aident_t step,
            PFalg_axis_t axis, int level)
{
    if (LEVEL_KNOWN(level))
        where_list_add (WHERELIST(p), eq (LEVEL(step), lit_int (level)));
    else
        switch (axis) {
            /* parent axis */
            case alg_par:
                where_list_add (WHERELIST(p),
                                eq (add (LEVEL(step), lit_int (1)),
                                    LEVEL(ctx)));
                break;

            /* attribute axis */
            case alg_attr:
            /* child axis */
            case alg_chld:
                where_list_add (WHERELIST(p),
                                eq (add (LEVEL(ctx), lit_int (1)),
                                    LEVEL(step)));
                break;

            default:
                break;
        }
}

/* encoding for the different node types in out XML scheme */
#define ELEM    1    /* element node */
#define ATTR    2    /* attribute */
#define PF_TEXT 3    /* text */
#define COMM    4    /* comment */
#define PI      5    /* processing instruction */
#define DOC     6    /* document root node */

static void
step_kind (PFla_op_t *p, PFsql_aident_t step,
           PFalg_node_kind_t kind, bool *leaf)
{
    int sql_kind = 0;

    switch (kind) {
        case node_kind_elem: sql_kind = ELEM;    break;
        case node_kind_attr: sql_kind = ATTR;    break;
        case node_kind_text: sql_kind = PF_TEXT; break;
        case node_kind_pi:   sql_kind = PI;      break;
        case node_kind_comm: sql_kind = COMM;    break;
        case node_kind_doc:  sql_kind = DOC;     break;
        case node_kind_node:
            where_list_add (WHERELIST (p),
                            not_ (eq (KIND(step), lit_int (ATTR))));
            *leaf = false;
            return;
    }

    if (sql_kind)
        where_list_add (WHERELIST(p),
                        eq (KIND(step), lit_int (sql_kind)));

    *leaf = sql_kind && sql_kind != DOC && sql_kind != ELEM;
}

static void
step_name (PFla_op_t *p, PFsql_aident_t step, PFqname_t qname)
{
    char *name = PFqname_loc (qname);
    char *namespace = PFqname_uri (qname);

    if (name)
        where_list_add (WHERELIST(p), eq (NAME(step), lit_str (name)));
    if (namespace)
        where_list_add (WHERELIST(p), eq (NS_URI(step), lit_str (namespace)));
}

static void
step_guide_join (PFla_op_t *p, PFsql_aident_t step,
                unsigned int count, PFguide_tree_t **guides)
{
    assert (p);

    PFsql_aident_t newalias = new_alias ();

    PFsql_t **list = PFmalloc (count * sizeof (PFsql_t *));

    for (unsigned int i = 0; i < count; i++)
        list[i] = stmt_list (lit_int (guides[i]->guide));

    /* prepare step node */
    from_list_add (FROMLIST(p),
                   values (PFsql_list_list_ (count, (const PFsql_t **) list)),
                   alias_def (newalias, column_list (GUIDE_)));

    where_list_add (WHERELIST(p),
                    eq
                    (
                      GUIDE(step),
                      GUIDE(newalias)
                    ));
}



/* .......... Twig Constructor Helper Functions .......... */

#define construct_simple_twig(p,iter,kind,value,name,uri) \
            construct_twig_generic (p, new_alias(), new_alias(), true, \
                                    NULL, iter, kind, value, name, uri)
#define construct_twig(p,content,new_root,sortkey_list) \
            construct_twig_generic (p, content, new_root, false,       \
                                    sortkey_list, col_iter, 0,         \
                                    NULL, NULL, NULL)
/**
 * Construct a twig binding.
 *
 * This function is used in two flavors:
 * - a 'simple' variant that constructs a single node (order does not matter)
 * - a 'normal' variant that uses the collected list of node constructors
 *   and orders them by the order specified in @a sortkey_list
 */
static void
construct_twig_generic (PFla_op_t *p,
                        PFsql_aident_t content,
                        PFsql_aident_t new_root,
                        bool simple,
                        PFsql_t *sortkey_list,
                        PFalg_col_t citer, int kind,
                        PFsql_t *value, PFsql_t *name,
                        PFsql_t *uri)
{
    PFsql_tident_t      twig_tbl = new_table_name ();
    PFsql_aident_t      max      = new_alias ();
    PFalg_col_t         iter;
    PFalg_simple_type_t iter_ty;
    PFsql_col_t        *iter_col;
    PFsql_t            *twig;

    assert (p->kind == la_twig);

    iter     = p->sem.iter_item.iter;
    iter_ty  = type_of (p, iter);
    iter_col = new_col (iter, iter_ty);

    if (simple)
        twig = select (select_list (
                           column_assign (
                               col_env_lookup (COLMAP(LL(p)),
                                               citer, type_of (LL(p), citer)),
                               column_name (iter_col)),
                           column_assign (
                               add (MAX(max),
                                    over (row_number (),
                                          window_clause (NULL, NULL))),
                               PRE_),
                           column_assign (lit_int (0), SIZE_),
                           column_assign (lit_int (0), LEVEL_),
                           column_assign (lit_int (kind), KIND_),
                           column_assign (value, VALUE_),
                           column_assign (name, NAME_),
                           column_assign (uri, NS_URI_)),
                       from_list (
                           alias_bind (select (
                                           column_assign (max_ (PRE_), MAX_),
                                           from_list (max_pre_frag),
                                           NULL),
                                       alias (max)),
                           transform_frommap (LL(p))),
                       transform_wheremap (LL(p)));
    else
        twig = select (select_list (
                           column_assign (
                               ITER(content),
                               column_name (iter_col)),
                           column_assign (
                               add (MAX(max),
                                    over (row_number (),
                                          window_clause (
                                              NULL,
                                              order_by (sortkey_list)))),
                               PRE_),
                           SIZE(content),
                           LEVEL(content),
                           KIND(content),
                           VALUE(content),
                           NAME(content),
                           NS_URI(content)),
                       from_list (
                           alias_bind (select (
                                           column_assign (max_ (PRE_), MAX_),
                                           from_list (max_pre_frag),
                                           NULL),
                                       alias (max)),
                           alias_bind (FRAG(L(p)), alias (content))),
                       NULL);

    execute (comment ("===================="));
    execute (comment ("= TWIG CONSTRUCTOR ="));
    execute (comment ("===================="));
    execute (bind (table_def (
                       twig_tbl,
                       column_list (
                           column_name (iter_col),
                           PRE_,
                           SIZE_,
                           LEVEL_,
                           KIND_,
                           VALUE_,
                           NAME_,
                           NS_URI_)),
                   twig));

    FRAG(p) = table_name (twig_tbl);

    /* store the new maximum pre value */
    max_pre_frag = table_name (twig_tbl);

    /* prepare the result */
    col_env_add (COLMAP(p),
                 iter,
                 iter_ty,
                 EXT_COLUMN_NAME (new_root, iter, iter_ty));

    if (SER_REPORT (p) == ser_yes)
        col_env_add_full (COLMAP(p),
                          p->sem.iter_item.item,
                          type_of (p, p->sem.iter_item.item),
                          PRE(new_root),
                          new_root,
                          true);
    else
        col_env_add (COLMAP(p),
                     p->sem.iter_item.item,
                     type_of (p, p->sem.iter_item.item),
                     PRE(new_root));

    from_list_add (FROMLIST(p),
                   table_name (twig_tbl),
                   alias (new_root));

    /* mark node p as bound */
    BOUND(p) = true;
}

/**
 * Construct a single node.
 *
 * Depending on the node kind (@a kind) the names (@a name)
 * and values (@a value) differ.
 */
static void
construct_node (PFla_op_t *p, PFalg_col_t iter, int kind,
                PFsql_t *value, PFsql_t *name, PFsql_t *uri)
{
    PFalg_simple_type_t iter_ty = type_of (L(p), iter);

    FRAG (p) = select (
                   select_list (
                       column_assign (
                           col_env_lookup (COLMAP(L(p)), iter, iter_ty),
                           ITER_),
                       column_assign (lit_int (TPRE(p)), TWIG_PRE_),
                       column_assign (lit_int (-1), POS_),
                       column_assign (lit_int (-1), PRE_),
                       column_assign (lit_int (TSIZE(p)), SIZE_),
                       column_assign (lit_int (TLEVEL(p)), LEVEL_),
                       column_assign (lit_int (kind), KIND_),
                       column_assign (value, VALUE_),
                       column_assign (name, NAME_),
                       column_assign (uri, NS_URI_)),
                   transform_frommap (L(p)),
                   transform_wheremap (L(p)));
}



/* .......... Remaining Helper Functions .......... */

/**
 * copy_cols_from_where copies all select, from, and where
 * information from a child operator @a c to a parent
 * operator @a p.
 */
static void
copy_cols_from_where (PFla_op_t *p, PFla_op_t *c)
{
    /* copy the existing environment */
    col_env_copy (COLMAP(p), COLMAP(c));
    /* copy the existing frommap */
    from_list_copy (FROMLIST(p), FROMLIST(c));
    /* copy the existing wheremap */
    where_list_copy (WHERELIST(p), WHERELIST(c));
}

/**
 * bind_operator creates a select-from-where binding
 * for a given operator @a p. The additional boolean
 * flag distinct triggers the generation of the SQL
 * DISTINCT keyword.
 */
static void
bind_operator (PFla_op_t *p, bool distinct)
{
    PFsql_t *selectlist = NULL;
    PFsql_t *columnlist = NULL;
    sql_column_env_t entry;
    PFsql_col_t *colname;

    /* only bind the operator if it is not already bound */
    if (BOUND(p)) return;

    /* create a new table name for binding */
    PFsql_tident_t newtable = new_table_name ();
    /* new correlation name for bounded table */
    PFsql_aident_t newalias = new_alias ();

    /* prepare the selection lists, the column list, and fill in
       the new bindings for the column environment */
    for (unsigned int i = 0; i < PFarray_last (COLMAP(p)); i++) {
        entry = col_env_at (COLMAP(p), i);
        colname = new_col (entry.col, entry.type);

        /* create columnlist for the table name */
        columnlist = column_list (columnlist, column_name (colname));

        /* add the sql operation to the select list */
        selectlist = select_list (
                         selectlist,
                         transform_expression (
                             entry.expression,
                             column_name (colname)));

        /* override expression with columnname */
        entry.expression = ext_column_name (newalias, colname);
        /* reset step alias (as we got rid of the table schema) */
        entry.step_alias = PF_SQL_ALIAS_UNBOUND;

        /* override column map entry */
        *(sql_column_env_t *) PFarray_at (COLMAP(p), i) = entry;
    }

    /* dump the operator binding */
    execute (bind (table_def (newtable, columnlist),
                   PFsql_select (distinct,
                                 selectlist,
                                 transform_frommap (p),
                                 transform_wheremap (p),
                                 NULL,
                                 NULL)));

    /* clear the from and the where list */
    PFarray_last (FROMLIST(p)) = 0;
    PFarray_last (WHERELIST(p)) = 0;

    /* add the new binding to the from list */
    from_list_add (FROMLIST(p),
                   table_name (newtable),
                   alias (newalias));

    /* mark node p as bound */
    BOUND(p) = true;
}

/**
 * Collect a union of all referenced fragments.
 *
 * worker for collect_fragments.
 */
static void
collect_frag_worker (PFla_op_t * p, PFarray_t *frags)
{
    assert (p);
    assert (frags);

    if (p->kind == la_frag_union) {
        collect_frag_worker (L(p), frags);
        collect_frag_worker (R(p), frags);
    }
    else if (p->kind == la_fragment) {
        PFsql_tident_t name;
        unsigned int   i;
        PFsql_t       *frag;
        assert (FRAG(p) && FRAG(p)->kind == sql_tbl_name);

        name = FRAG(p)->sem.tbl.name;
        /* add fragment if we haven't collected it so far */
        for (i = 0; i < PFarray_last (frags); i++) {
            frag = *(PFsql_t **) PFarray_at (frags, i);
            if (frag->sem.tbl.name == name)
                break;
        }
        if (i == PFarray_last (frags))
            *(PFsql_t **) PFarray_add (frags) = FRAG(p);
    }
}

#define frag_select(f) select (select_list (PRE_, SIZE_, LEVEL_,  \
                                            KIND_, VALUE_, NAME_, \
                                            NS_URI_),             \
                               f, NULL)

static PFsql_t *
collect_fragments (PFla_op_t * p)
{
    PFarray_t *frags = PFarray (sizeof (PFsql_t *), 5);

    collect_frag_worker (p, frags);

    if (PFarray_last (frags)) {
        PFsql_t *res = frag_select (*(PFsql_t **) PFarray_at (frags, 0));

        for (unsigned int i = 1; i < PFarray_last (frags); i++)
            res = union_ (res,
                          frag_select (*(PFsql_t **) PFarray_at (frags, i)));

        return res;
    }
    else
        return frag_select (table_name (PF_SQL_TABLE_FRAG));
}

/**
 * Cast from a boolean value
 */
static PFsql_t *
cast_from_bool (PFsql_t * expr, PFalg_simple_type_t res_ty)
{
    switch (res_ty) {
        case aat_uA:
        case aat_str:
            if (expr->kind == sql_column_name)
                expr = eq (expr, TRUE_INT);
            return case_ (when (expr,TRUE_STR),
                          else_ (FALSE_STR));
        case aat_dec:
        case aat_dbl:
            if (expr->kind != sql_column_name)
                return case_ (when (expr, TRUE_DEC),
                              else_ (FALSE_DEC));
            else
                return cast (expr, type (res_ty));
        case aat_int:
            if (expr->kind != sql_column_name)
                return case_ (when (expr, TRUE_INT),
                              else_ (FALSE_INT));
            else
                return expr;
        default:
            PFoops (OOPS_FATAL, "This cast from a boolean"
                                " value is not allowed");
    }

    return NULL; /* satisfy picky compilers */
}

#define FRAG_OP(p) (/* fragment related operators */ \
                    (p)->kind == la_frag_union    || \
                    (p)->kind == la_empty_frag    || \
                    (p)->kind == la_fragment      || \
                    /* and operators that are     */ \
                    /* referenced by 'roots' and  */ \
                    /* 'fragment' only            */ \
                    (p)->kind == la_doc_tbl       || \
                    (p)->kind == la_twig          || \
                    (p)->kind == la_merge_adjacent)

/**
 * This functions tells us during the generation of
 * the recursion branch if recursion is allowed
 */
static bool
rec_allowed (PFla_op_t *p)
{
    /* check if we have to bind this operator */
    if (bind_multi_ref && REFCTR(p) > 1 && !FRAG_OP(p))
        return false;

    switch (p->kind) {
        case la_serialize_seq:
        case la_serialize_rel:
            PFoops (OOPS_FATAL, "serializing during recursion is not possible");
        case la_lit_tbl:
            return (p->sem.lit_tbl.count > 1);
        case la_empty_tbl:
        case la_ref_tbl:
        case la_attach:
            return true;
        case la_cross:
        case la_eqjoin:
            return true;
        case la_semijoin:
            /* FIXME */
            assert (!"FIXME");
        case la_thetajoin:
        case la_project:
        case la_select:
            return true;
        case la_pos_select:
            return false;
        case la_disjunion:
        case la_intersect:
        case la_difference:
        case la_distinct:
            return false;
        case la_fun_1to1:
        case la_num_eq:
        case la_num_gt:
        case la_bool_and:
        case la_bool_or:
        case la_bool_not:
            return true;
        case la_to:
            return false;
        case la_aggr:
            return (!p->sem.aggr.part);
        case la_rownum:
        case la_rowrank:
        case la_rank:
        case la_rowid:
            return false;
        case la_type:
        case la_type_assert:
            /* FIXME */
            assert (!"not yet implemented");
            break;
        case la_cast:
            return true;
        case la_step:
        case la_step_join:
        case la_guide_step:
        case la_guide_step_join:
            return true; /* PFprop_set (p->prop); */
        case la_doc_index_join:
            /* FIXME */
            assert (!"not yet implemented");
            break;
        case la_doc_tbl:
        case la_doc_access:
            return true;
        case la_twig:
        case la_fcns:
        case la_docnode:
        case la_element:
        case la_attribute:
        case la_textnode:
        case la_comment:
        case la_processi:
        case la_content:
        case la_merge_adjacent:
            return false;
        case la_roots:
        case la_fragment:
            return true;
        case la_frag_extract:
            /* FIXME */
            assert (!"not yet implemented");
            break;
        case la_frag_union:
        case la_empty_frag:
        case la_error:
            return true;
        case la_nil:
        case la_trace:
        case la_trace_items:
        case la_trace_msg:
        case la_trace_map:
            /* FIXME */
            assert (!"not yet implemented");
            break;
        case la_string_join:
        case la_dummy:
        case la_rec_fix:
        case la_rec_param:
        case la_rec_arg:
            return false;
        case la_rec_base:
            return true;
        case la_proxy:
        case la_proxy_base:
            return false;
        default:
            PFoops (OOPS_FATAL, "This operation is unknown");
    }
    return false;
}

/**
 * A cast to boolean is has to provide a boolean expression.
 */
static PFsql_t *
cast_to_bool (PFsql_t *expr, PFalg_simple_type_t ty)
{
    switch (ty) {
        case aat_dec:
        case aat_dbl:
            return eq(expr, TRUE_DEC);
        case aat_int:
            return eq(expr, TRUE_INT);
        default:
            PFoops (OOPS_FATAL, "This cast to a boolean"
                                " boolean value is not allowed");
    }

    return NULL; /* satisfy picky compilers */
}

static PFsql_t *
cast_ (PFsql_t * expr, PFalg_simple_type_t ty, PFalg_simple_type_t res_ty)
{
    if (ty == res_ty) return expr;

    #define NUM_TYPE(t)    ((t == aat_nat) || \
                            (t == aat_int) || \
                            (t == aat_dec) || \
                            (t == aat_dbl))
    #define INT_TYPE(t)    ((t == aat_int) || \
                            (t == aat_nat))
    #define CHAR_TYPE(t)   ((t == aat_str) || \
                            (t == aat_uA))
    #define NUM_NOTEXPR(t) ((t == aat_int))
    #define BOOL_TYPE(t)    (t == aat_bln)
    #define DATE_TYPE(t)    (t == aat_date)

    /* Since we handle untypedAtomic and Strings the same
     * way in SQL, its obvious we don't have to
     * perform a cast if res_ty is a CHAR_TYPE and
     * and input type is a CHAR_TYPE */
    if (CHAR_TYPE(ty) && CHAR_TYPE(res_ty)) return expr;

    /* Since we handle NAT and INT the same
     * way in SQL, its obvious we don't have to
     * perform a cast if res_ty is a INT_TYPE and
     * and input type is a INT_TYPE */
    if (INT_TYPE(ty) && INT_TYPE(res_ty)) return expr;

    if (BOOL_TYPE(ty))
        return cast_from_bool (expr, res_ty);

    if (BOOL_TYPE(res_ty))
        return cast_to_bool (expr, ty);

    /* if we cast a numeric type to varchar we have to
       first cast it to CHAR and then to varchar */
    if (NUM_TYPE (ty) && CHAR_TYPE (res_ty))
        expr = cast (expr, type (aat_charseq));
    /* if we cast a string to a less expressive type
       like numeric, we have to first cast it to DECIMAL
       and then to the less expressive type */
    else if (CHAR_TYPE (ty) && NUM_NOTEXPR (res_ty))
        expr = cast (expr, type (aat_dbl));

    /* ensure that the cast to date only gets a string as input */
    if (DATE_TYPE (res_ty) && !CHAR_TYPE (ty))
        PFoops (OOPS_FATAL,
                "can only cast values of type string to a date");

    return cast (expr, type (res_ty));
}

/**
 * Check if a column @a b appears in list @a a.
 */
static bool
clin (PFalg_collist_t *a, PFalg_col_t b)
{
    if (!a) return false;

    for (unsigned int i = 0; i < clsize (a); i++)
        if (b == clat (a, i))
            return true;

    return false;
}

/**
 * Reduce function. This is the core of this source file, containing
 * the actions that should be executed whenever a burg-pattern matches.
 */
#define reduce(p,g) reduce_ ((p), (g), 0)
static void
reduce_ (PFla_op_t * p, int goalnt, int fallback_rule)
{
    int        rule;            /* rule number that matches this node */
    short     *nts;
    PFla_op_t *kids[MAX_KIDS];  /* leaf node of this rule */
    bool       bind     = false;
    bool       distinct = false;

    /* guard against too deep recursion */
    PFrecursion_fence ();

    if (rec_branch && !rec_allowed (p))
        PFoops (OOPS_FATAL, "SQL cannot cope with this recursion");

    if (SEEN(p)) {
        substitute_aliases (p);
        return;
    }

    if (fallback_rule)
        /* we have to clean up the translation for an incomplete pattern */
        rule = fallback_rule;
    else
        /* determine rule that matches for this non-terminal */
        rule = PFlalg2sql_rule (STATE_LABEL(p), goalnt);

    /* error if a rule with value zero is determined */
    assert (rule);

    /* initializing the kids vector */
    for (unsigned short i = 0; i < MAX_KIDS; i++)
        kids[i] = NULL;

    /* get information for dag-traversal */
    nts = PFlalg2sql_nts[rule];
    PFlalg2sql_kids (p, rule, kids);

    switch (rule) {
        /* Rel:    cross (Rel, Rel) */
        case 12:
        /* Rel:    eqjoin (Rel, Rel) */
        case 13:
        /* Rel:    semijoin (Rel, Rel) */
        case 14:
        /* Rel:    thetajoin (Rel, Rel) */
        case 15:
        /* Side:   error (Side, Rel) */
        case 98:
        /* Arg:    rec_arg (Rel, Rel) */
        case 107:
        /* Arg;    rec_arg (Rel, distinct (Rel)) */
        case 108:
        /* Rel:    rec_fix (
                       side_effects (
                           nil,
                           rec_param (
                              rec_arg (Rel, Rel),
                              rec_param(Arg, nil))),
                       Rel) */
        case 109:
        /* Rel:    rec_fix (
                       side_effects (nil,
                                     rec_param (Arg, nil)),
                       Rel) */
        case 110:
            /* top-down translation */
            break;
        default:
            /* bottom-up translation */
            for (unsigned short i = 0; nts[i]; i++)
                reduce (kids[i], nts[i]);
            break;
    }

    switch (rule) {
        /* Query:  serialize_seq (side_effects (Side, Frag),
                                  project (rank (Rel))) */
        case 3:
        /* Query:  serialize_seq (side_effects (Side, Frag),
                                  project (
                                      rank (distinct (Rel)))) */
        case 4:
        {
            /* The main implementation happens inside the scope
               of the next case block into which we fall through.
               Here we prepare the translation by resolving
               any renaming done by the projection operator. */
            PFalg_col_t item = p->sem.ser_seq.item;
            PFalg_col_t pos  = p->sem.ser_seq.pos;

            assert (R(p)->schema.count <= 2);
            if (R(p)->sem.proj.items[0].new == item)
                item = R(p)->sem.proj.items[0].old;
            else if (R(p)->sem.proj.items[1].new == item)
                item = R(p)->sem.proj.items[1].old;

            if (R(p)->sem.proj.items[0].new == pos)
                pos = R(p)->sem.proj.items[0].old;
            else if (R(p)->sem.proj.items[1].new == pos)
                pos = R(p)->sem.proj.items[1].old;

            /* modify the schema of the serialize operator according
             * to the new values for pos and item */
            for (unsigned int i = 0; i < p->schema.count; i++) {
                if (p->schema.items[i].name
                          == p->sem.ser_seq.item) {
                    p->schema.items[i].name = item;
                }
                else if (p->schema.items[i].name
                          == p->sem.ser_seq.pos) {
                    p->schema.items[i].name = pos;
                }
            }

            /* ignore the projection operator */
            p->sem.ser_seq.item = item;
            p->sem.ser_seq.pos  = pos;

        }   /* fall through */

        /* Query:  serialize_seq (
                       side_effects (Side, Frag),
                       Rel) */
        case 1:
        /* Query:  serialize_seq (
                       side_effects (Side, Frag),
                       distinct (Rel)) */
        case 2:
        {
            /* lookup whether we need a SELECT or a SELECT DISTINCT */
            bool                distinct   = rule == 2 || rule == 4;
            /* use the second non-terminal as the query part */
            PFla_op_t          *query      = kids[2];
            PFalg_col_t         item       = p->sem.ser_seq.item;
            PFalg_col_t         pos        = p->sem.ser_seq.pos;
            PFalg_simple_type_t item_ty    = type_of (p, p->sem.ser_seq.item);

            PFalg_simple_type_t pos_ty     = type_of (p, p->sem.ser_seq.pos);


            PFsql_t            *sername, *colname, *colexpr,
                               *selectlist = NULL,
                               *orderby    = NULL,
                               *ser_info,
                               *finalquery = NULL;

            /* merge error checks into the query */
            from_list_copy (FROMLIST(query), FROMLIST(kids[0]));

            /* Make sure that we bind the input if we have
               to perform outer-joins (for mixed results)
               and our input has more than one input relation
               or contains a where clause. */
            if (item_ty & aat_node && item_ty & ~aat_node &&
                (PFarray_last (FROMLIST(query)) != 1 ||
                 PFarray_last(WHERELIST(query))))
                bind_operator (query, false);

            assert (PFarray_last (COLMAP(query)));

            assert (monomorphic (pos_ty));

            /* The order criterion consists of the column pos. */
            if (rule == 1 || rule == 2) {
                orderby = col_env_lookup (COLMAP(query), pos, pos_ty);

                /* transform the order by statement into a sortkey list */

                /* unfold the sorting criteria of a numbering operator */
                if (orderby->kind == sql_over &&
                    R(orderby)->kind == sql_wnd_clause &&
                    RR(orderby)->kind == sql_order_by) {
                    assert (L(orderby)->kind == sql_row_number ||
                            L(orderby)->kind == sql_dense_rank);
                    assert (!RL(orderby));
                    /* orderby may become an empty list (aka. NULL) */
                    orderby = RRL(orderby);
                }
                else if (IS_LITERAL(orderby))
                    orderby = NULL;
                else
                    orderby = sortkey_list (sortkey_item (orderby, true));
            }
            /* The order is represented by the order list of a rank operator.
               Transform the list of order columns into a SQL ORDER BY list. */
            else {
                PFord_ordering_t sortby;
                PFalg_col_t ord;
                bool asc;

                assert (R(p)->kind == la_project &&
                        RL(p)->kind == la_rank &&
                        pos == RL(p)->sem.sort.res);

                sortby = RL(p)->sem.sort.sortby;
                for (int i = PFord_count (sortby) - 1; i >= 0; i--) {
                    ord = PFord_order_col_at (sortby, i);

                    asc = PFord_order_dir_at (sortby, i) == DIR_ASC;
                    orderby = sortkey_list (
                                  sortkey_item (
                                      col_env_lookup (
                                          COLMAP(query),
                                          ord,
                                          type_of (query, ord)),
                                      asc),
                                  orderby);

                }
            }

            /* construct schema information for serializer */
            ser_info = ser_info_item (
                           ser_comment ("END SCHEMA INFORMATION **"
                                        " DO NOT EDIT THESE LINES"),
                           nil ());

            /* fill in the SQL code for the serialization info,
               the column name and the select list */

            /* We conflate the schema information needed by the
             * externalized serializer with the final query,
             * that computes the result of the XQuery-Statement
             */
            if (item_ty & aat_node)
                ser_info = ser_info_item (
                               ser_map (PRE_, PRE_),
                           ser_info_item (
                               ser_map (SIZE_, SIZE_),
                           ser_info_item (
                               ser_map (KIND_, KIND_),
                           ser_info_item (
                               ser_map (VALUE_, VALUE_),
                           ser_info_item (
                               ser_map (NAME_, NAME_),
                           ser_info_item (
                               ser_map (NS_URI_, NS_URI_),
                           ser_info))))));

            /* the item information */
            for (unsigned int i = 0; i < PFarray_last (COLMAP(query)); i++) {
                sql_column_env_t entry = col_env_at (COLMAP(query), i);
                if (((entry.col == item) && !(entry.type & aat_node))) {
                    sername = COLUMN_NAME (col_item, entry.type);
                    colexpr = transform_expression (entry.expression, sername);

                    /* add the sql operation to the select list */
                    selectlist = select_list (colexpr, selectlist);

                    if (colexpr->kind == sql_column_assign)
                        colname = R(colexpr);
                    else {
                        assert (colexpr->kind == sql_column_name);
                        colname = colexpr;
                    }

                    ser_info = ser_info_item (
                                   ser_map (sername, colname),
                                   ser_info);
                }
                /* If we have to eliminate duplicates then we are not
                   allowed to remove any column from the selection list. */
                else if (distinct) {
                    colexpr = entry.expression;
                    /* Ensure that boolean columns are replaced. */
                    if (entry.type == aat_bln)
                        colexpr = (colexpr->kind == sql_column_name)?
                                  colexpr:
                                  case_ (when (colexpr, TRUE_INT),
                                         else_ (FALSE_INT));

                    /* Generate a special column name DIST
                       that can be overloaded ... */
                    sername = DIST_;
                    /* ... and overload it with a unique identifier. */
                    sername->sem.column.name->ty = i;

                    /* Rename the columns to avoid name conflicts
                       during serialization. */
                    if (colexpr->kind != sql_column_assign)
                        colexpr = column_assign (colexpr, sername);

                    /* Add the column to the select list. */
                    selectlist = select_list (colexpr, selectlist);
                }
            }

            /* our result contains only atomic values */
            if (!(item_ty & aat_node)) {
                ser_info = ser_info_item (
                               ser_type (lit_str("Type"),
                                         lit_str("ATOMIC_ONLY")),
                               ser_info);

                finalquery = PFsql_select (
                                     distinct,
                                     select_list (selectlist),
                                     transform_frommap (query),
                                     transform_wheremap (query),
                                     orderby,
                                     NULL);
            }
            /* our result contains only node values */
            else if (!(item_ty & ~aat_node)) {
                ser_info = ser_info_item (
                               ser_type (lit_str("Type"),
                                         lit_str("NODES_ONLY")),
                               ser_info);

                /* we do not need a join to serialize,
                   so we return just the values we get */
                if (SER_REPORT(p) == ser_yes) {
                    PFsql_aident_t twig = col_env_lookup_step (
                                              COLMAP(query),
                                              item,
                                              item_ty);

                    assert (twig != PF_SQL_ALIAS_UNBOUND);

                    /* add minor ordering to ensure that subtrees
                       of the twig nodes are ordered correctly */
                    orderby = sortkey_list (PRE(twig), orderby);

                    finalquery = PFsql_select (
                                     distinct,
                                     select_list (
                                         PRE(twig),
                                         SIZE(twig),
                                         KIND(twig),
                                         VALUE(twig),
                                         NAME(twig),
                                         NS_URI(twig),
                                         selectlist),
                                     transform_frommap (query),
                                     transform_wheremap (query),
                                     orderby,
                                     NULL);
                } else {
                    PFsql_t *frags = FRAG(LR(p));
                    PFsql_aident_t doc1, doc2;

                    /* if fragments does not consists of
                       select clause bind them */
                    if (frags->kind != sql_tbl_name) {
                        PFsql_tident_t newtable = new_table_name ();
                        execute (
                            bind (table_def (
                                      newtable,
                                      column_list (
                                          PRE_, SIZE_, LEVEL_,
                                          KIND_, VALUE_, NAME_,
                                          NS_URI_)),
                                  frags));
                        frags = table_name (newtable);
                    }

                    from_list_copy (FROMLIST(p), FROMLIST(query));
                    where_list_copy (WHERELIST(p), WHERELIST(query));

                    /* make sure to get the full table schema
                       for the context nodes */
                    doc1 = col_env_lookup_step (COLMAP(query), item, item_ty);
                    if (doc1 == PF_SQL_ALIAS_UNBOUND) {
                        doc1 = new_alias ();
                        from_list_add  (FROMLIST(p), frags, alias (doc1));
                        where_list_add (WHERELIST(p),
                                        eq (col_env_lookup (
                                                COLMAP(query), item, item_ty),
                                            PRE(doc1)));
                    }

                    /* avoid step if we already have leaf nodes in our hands */
                    if (col_env_lookup_step_leaf (COLMAP(query), item, item_ty)
                        && col_env_lookup_step (COLMAP(query), item, item_ty))
                        doc2 = doc1;
                    else {
                        doc2 = new_alias ();
                        from_list_add  (FROMLIST(p), frags, alias (doc2));
                        step_axis (p, doc1, doc2, alg_desc_s, NULL, -1);
                        orderby = sortkey_list (orderby,
                                                sortkey_item (PRE(doc2), true));
                    }

                    finalquery = PFsql_select (
                                     distinct,
                                     select_list (
                                         PRE(doc2),
                                         SIZE(doc2),
                                         KIND(doc2),
                                         VALUE(doc2),
                                         NAME(doc2),
                                         NS_URI(doc2),
                                         selectlist),
                                     transform_frommap (p),
                                     transform_wheremap (p),
                                     orderby,
                                     NULL);
                }
            }
            /* the result contains nodes and atomic values */
            else {
                PFsql_t        *frags = FRAG(LR(p)), *item_expr, *from_bind;
                PFsql_aident_t  doc1, doc2;
                sql_from_list_t from;

                ser_info = ser_info_item (
                               ser_type (lit_str("Type"),
                                         lit_str("ATOMIC_AND_NODES")),
                               ser_info);

                /* if fragments does not consists of
                   select clause bind them */
                if (frags->kind != sql_tbl_name) {
                    PFsql_tident_t newtable = new_table_name ();
                    execute (
                        bind (table_def (
                                  newtable,
                                  column_list (
                                      PRE_, SIZE_, LEVEL_,
                                      KIND_, VALUE_, NAME_,
                                      NS_URI_)),
                              frags));
                    frags = table_name (newtable);
                }

                item_expr = col_env_lookup (COLMAP(query), item, aat_pre);
                doc1      = new_alias ();
                doc2      = new_alias ();
                from      = from_list_at (FROMLIST(query), 0);
                from_bind = alias_bind (from.table, from.alias);

                /* add the axis conditions */
                step_axis (p, doc1, doc2, alg_desc_s, NULL, -1);

                finalquery = PFsql_select (
                                 distinct,
                                 select_list (
                                     selectlist,
                                     PRE(doc2),
                                     SIZE(doc2),
                                     KIND(doc2),
                                     VALUE(doc2),
                                     NAME(doc2),
                                     NS_URI(doc2)),
                                 from_list (
                                     on (left_outer_join (
                                             on (left_outer_join (
                                                     from_bind,
                                                     alias_bind (
                                                         frags,
                                                         alias (doc1))),
                                                 eq (PRE(doc1), item_expr)),
                                             alias_bind (frags, alias (doc2))),
                                         transform_wheremap (p))),
                                 NULL,
                                 sortkey_list (orderby,
                                               sortkey_item (PRE(doc2), true)),
                                 NULL);
            }

            /* construct schema information for serialization */
            ser_info = ser_info_item (
                           ser_comment ("START SCHEMA INFORMATION **"
                                        " DO NOT EDIT THESE LINES"),
                           ser_info);

            /* the final query consists of the schema information needed
             * by the serializer and the with clause conflating all queries
             * translated to this point.
             */
            assert (ser_info);
            assert (finalquery);

            /* Check if there are already common-table expressions
             * or we have a standalone query */
            if (sql_stmts)
                sql_stmts = root (ser_info, with (sql_stmts, finalquery));
            else
                sql_stmts = root (ser_info, finalquery);

        }   break;

        /* Query:  serialize_seq (
                       side_effects (
                           Side,
                           frag_union (
                               empty_frag,
                               fragment (twig (Twig)))),
                       roots_ (twig (Twig))) */
        case 5:
        {
            PFsql_aident_t      content      = new_alias ();
            PFsql_t            *sortkey_list = NULL;

            PFsql_t            *ser_info;
            PFsql_t            *final_query;

            assert (L(LRR(p)) == RL(p));

            assert (p->sem.ser_seq.item == RL(p)->sem.iter_item.item);
            assert (p->sem.ser_seq.pos == RL(p)->sem.iter_item.iter);

            /* construct schema information for serialization */
            ser_info = ser_info_item (
                           ser_comment ("START SCHEMA INFORMATION **"
                                        " DO NOT EDIT THESE LINES"),
                       ser_info_item (
                           ser_type (lit_str("Type"),
                                     lit_str("NODES_ONLY")),
                       ser_info_item (
                           ser_map (PRE_, PRE_),
                       ser_info_item (
                           ser_map (SIZE_, SIZE_),
                       ser_info_item (
                           ser_map (KIND_, KIND_),
                       ser_info_item (
                           ser_map (VALUE_, VALUE_),
                       ser_info_item (
                           ser_map (NAME_, NAME_),
                       ser_info_item (
                           ser_map (NS_URI_, NS_URI_),
                       ser_info_item (
                           ser_comment ("END SCHEMA INFORMATION **"
                                        " DO NOT EDIT THESE LINES"),
                       nil ())))))))));


            /* We only need to sort by <pos, pre> if we have a variable
               part (content operator) in the twig constructor. */
            if (CSIZE(L(RL(p))))
                sortkey_list = sortkey_list (
                                        sortkey_item (POS(content), true),
                                        sortkey_item (PRE(content), true),
                                        sortkey_list);

            /* Always sort first by <iter, twig_pre>. */
            sortkey_list = sortkey_list (
                                    sortkey_item (ITER(content), true),
                                    sortkey_item (TWIG_PRE(content), true),
                                    sortkey_list);

            from_list_add (FROMLIST(p), FRAG(L(RL(p))), alias (content));
            /* merge errors into the from list */
            from_list_copy (FROMLIST(p), FROMLIST(kids[0]));

            /* call a helper function that does the 'real' job */
            final_query = PFsql_select (
                              false,
                              select_list (
                                  column_assign (
                                      over (row_number (),
                                            window_clause (NULL, NULL)),
                                      PRE_),
                                  SIZE(content),
                                  LEVEL(content),
                                  KIND(content),
                                  VALUE(content),
                                  NAME(content),
                                  NS_URI(content)),
                              transform_frommap (p),
                              NULL,
                              sortkey_list,
                              NULL);

            /* the final query consists of the schema information needed
             * by the serializer and the with clause conflating all queries
             * translated to this point.
             */
            assert (ser_info);
            assert (final_query);

            /* Check if there are already common-table expressions
             * or we have a standalone query */
            if (sql_stmts)
                sql_stmts = root (ser_info, with (sql_stmts, final_query));
            else
                sql_stmts = root (ser_info, final_query);

        }   break;

        /* Query:  serialize_seq (side_effects (Side, Frag),
                                  empty_tbl) */
        case 6:
            /* FIXME: implementation is missting */
            assert (!"missing");
            break;

        /* Query:  serialize_rel (nil, Rel) */
        case 7:
        {
            PFla_op_t          *query       = R(p);

            PFalg_col_t         iter        = p->sem.ser_rel.iter,
                                pos         = p->sem.ser_rel.pos;
            PFalg_simple_type_t iter_ty     = type_of (p, iter),
                                pos_ty      = type_of (p, pos);
            PFsql_t            *orderby,
                               *orderbyITER,
                               *orderbyPOS,
                               *selectlist = NULL;

            /* transform the ITER order by statement into a sortkey list */
            orderby = col_env_lookup (COLMAP(query), iter, iter_ty);

            /* unfold the sorting criteria of a numbering operator */
            if (orderby->kind == sql_over &&
                R(orderby)->kind == sql_wnd_clause) {
                assert (L(orderby)->kind == sql_row_number ||
                        L(orderby)->kind == sql_dense_rank);
                assert (!RL(orderby));
                /* orderby may become an empty list (aka. NULL) */
                if (RR(orderby) &&
                    RR(orderby)->kind == sql_order_by)
                    orderby = RRL(orderby);
                else
                    orderby = NULL;
            }
            else if (IS_LITERAL(orderby))
                orderby = NULL;
            else
                orderby = sortkey_list (sortkey_item (orderby, true));

            orderbyITER = orderby;

            /* transform the POS order by statement into a sortkey list */
            if (monomorphic (pos_ty)) {
                orderby = col_env_lookup (COLMAP(query), pos, pos_ty);

                /* unfold the sorting criteria of a numbering operator */
                if (orderby->kind == sql_over &&
                    R(orderby)->kind == sql_wnd_clause) {
                    assert (L(orderby)->kind == sql_row_number ||
                            L(orderby)->kind == sql_dense_rank);
                    assert (!RL(orderby));
                    /* orderby may become an empty list (aka. NULL) */
                    if (RR(orderby) &&
                        RR(orderby)->kind == sql_order_by)
                        orderby = RRL(orderby);
                    else
                        orderby = NULL;
                }
                else if (IS_LITERAL(orderby))
                    orderby = NULL;
                else
                    orderby = sortkey_list (sortkey_item (orderby, true));
            } else {
                orderby = NULL;
                for (PFalg_simple_type_t t = 1; t; t <<= 1)
                    if (t & TYPE_MASK (pos_ty)) {
                        PFsql_t *expr = col_env_lookup (COLMAP(query), pos, t);

                        orderby = sortkey_list (
                                      sortkey_item (
                                          /* different handling of boolean
                                             types as search criterion */
                                          (expr->kind == sql_column_name ||
                                           expr->kind == sql_lit_int     ||
                                           t != aat_bln)
                                          ? expr
                                          : case_ (when (expr, TRUE_INT),
                                                   else_ (FALSE_INT)),
                                          true),
                                      orderby);
                    }
            }
            orderbyPOS = orderby;

            orderby = NULL;
            /* combine ITER and POS orders */
            if (orderbyITER && orderbyPOS)
                orderby = sortkey_list (orderbyITER, orderbyPOS);
            else if(orderbyPOS)
                orderby = orderbyPOS;
            else if(orderbyITER)
                orderby = orderbyITER;

            /* Only include iter and item information in the result. */
            for (unsigned int i = 0; i < PFarray_last (COLMAP(query)); i++) {
                sql_column_env_t entry = col_env_at (COLMAP(query), i);
                if (clin (p->sem.ser_rel.items, entry.col) ||
                    p->sem.ser_rel.iter == entry.col)
                    /* add the sql operation to the select list */
                    selectlist = select_list (
                                     transform_expression (
                                         entry.expression,
                                         COLUMN_NAME (entry.col, entry.type)),
                                     selectlist);
            }

            /* call a helper function that does the 'real' job */
            PFsql_t* final_query = PFsql_select (false,
                                       selectlist,
                                       transform_frommap (query),
                                       transform_wheremap (query),
                                       orderby,
                                       NULL);

            /* Check if there are already common-table expressions
               or we have a standalone query */
            if (sql_stmts)
                sql_stmts = root (nil (), with (sql_stmts, final_query));
            else
                sql_stmts = root (nil (), final_query);
        }
        break;

        /* Query:  serialize_rel (nil, empty_tbl) */
        case 8:
        {
            /*
            Let's generate a pseudo-query whose result is an empty table:

            SELECT -1 AS iter_nat, -1 AS pos_nat, ... AS item_...
            FROM (VALUES (-1)) AS a0000(item1_int)
            WHERE 1 = 0;
            */

            PFsql_t *selectlist = NULL;
            PFsql_t **list = NULL;
            PFsql_t **l_list = NULL;
            PFsql_aident_t newalias = new_alias ();

            /* generate the selectlist based on the empty table's schema */
            /* => SELECT -1 AS iter_nat, -1 AS pos_nat, ... AS item_...  */
            PFalg_schema_t schema = p->schema;
            int count = schema.count;
            for(int i = 0; i < count; i++)
            {
                PFalg_schm_item_t schemaItem = schema.items[i];

                PFalg_col_t columnName = schemaItem.name;
                PFalg_simple_type_t columnType = schemaItem.type;

                PFsql_t* columnPseudoVal;
                switch (columnType) {
                    case aat_nat:   columnPseudoVal = lit_int (-1);   break;
                    case aat_int:   columnPseudoVal = lit_int (-1);   break;
                    case aat_str:   columnPseudoVal = lit_str ("");   break;
                    case aat_dec:   columnPseudoVal = lit_dec (-1);   break;
                    default:        columnPseudoVal = lit_int (-1);   break;
                }

                selectlist =
                    select_list (
                        selectlist,
                        column_assign (
                            columnPseudoVal,
                            column_name(
                                new_col (
                                    columnName,
                                    columnType))));

            }

            /* generate the fromlist based on a pseudo literal table */
            /* => FROM (VALUES (-1)) AS a0000(item1_int)             */
            list  = PFmalloc (sizeof (PFsql_t *));
            l_list = PFmalloc (sizeof (PFsql_t *));

            list[0] = lit_int (-1);
            l_list[0] = PFsql_stmt_list_ (1, (const PFsql_t **) list);

            col_env_add (COLMAP (p),
                         col_item1,
                         aat_int,
                         ext_column_name (newalias,
                                          new_col (col_item1, aat_int)));

            from_list_add (FROMLIST(p),
                           values (PFsql_list_list_(1,
                               (const PFsql_t **) l_list)),
                           alias_def (newalias, column_list (
                               NULL, column_name (
                                   new_col (col_item1, aat_int)))));


            /* generate the final query */
            PFsql_t* final_query = PFsql_select (
                false,
                selectlist,
                transform_frommap (p),
                where_list (
                    eq (lit_int (1), lit_int (0))),
                NULL,
                NULL);

            sql_stmts = root (nil (), final_query);
        }
        break;

        /* Rel:    lit_tbl */
        case 9: {
            PFalg_atom_t atom;

            /* literal table has more than one row */
            /* PFsql_tident_t      newtable = new_table_name (); */
            PFsql_aident_t      newalias = new_alias ();

            PFsql_t *valuesquery = NULL;
            PFsql_t **list = NULL;
            PFsql_t **l_list = NULL;
            PFsql_t *columnlist = NULL;

            unsigned int ccount = 0,
                         rcount = p->sem.lit_tbl.count;
            unsigned int colcount = 0;
            unsigned int col = 0;

            /* calculate the size of the list and additionally
             * prepare the column list and even the column
             * environment. */
            for (unsigned int col = 0; col < p->schema.count; col++)
                 for (PFalg_simple_type_t t = 1; t; t <<= 1)
                      if (t & TYPE_MASK (p->schema.items[col].type)) {
                           /* found another literal */
                           ccount ++;
                           columnlist = column_list (columnlist,
                                            column_name (new_col (
                                                 p->schema.items[col]
                                                          .name, t)));
                           col_env_add (COLMAP (p),
                                        p->schema.items[col].name,
                                        t,
                                        ext_column_name (newalias,
                                            new_col (p->schema.items[col]
                                                        .name, t)));
                      }


            /* initialize the list */
            list  = PFmalloc (ccount * sizeof (PFsql_t *));
            l_list = PFmalloc (rcount * sizeof (PFsql_t *));

            /* run over all columns */
            for (unsigned int row = 0; row < p->sem.lit_tbl.count; row++) {
                colcount = 0;
                for (col = 0; col < p->schema.count; col++)
                    for (PFalg_simple_type_t t = 1; t; t <<= 1)
                        if (t & TYPE_MASK (p->schema.items[col].type)) {
                            /* found another literal */
                            atom = p->sem.lit_tbl.tuples[row].atoms[col];

                            if (t & aat_qname_loc ||
                                t & aat_qname_uri)
                                atom = namespace_atom (atom, t);

                            list[colcount] = (t == atom.type)
                                             ? literal(atom)
                                             : cast (null (), type (t));
                            /* increment the countvariable */
                            colcount++;
                        }

                /* generate the list and add it to our list of lists */
                l_list[row] = PFsql_stmt_list_ (ccount,
                                                (const PFsql_t **) list);
            }

            valuesquery = values (PFsql_list_list_(rcount,
                                         (const PFsql_t **) l_list));


            /* prepare the fromlist */
            from_list_add (FROMLIST(p),
                           valuesquery,
                           alias_def (newalias, columnlist));

        }   break;

        /* Rel:  ref_tbl */
        case 10:
        {
            PFsql_aident_t tabalias = new_alias();

            /* add the tables "external"/"real" name to the fromlist */
            from_list_add (FROMLIST(p),
                           ref_table_name (p->sem.ref_tbl.name),
                           alias (tabalias));

            /* lookup the "internal" column names (and types) in the
               schema info */
            PFalg_schema_t schema = p->schema;
            /* lookup the "external"/"real" column names in the
               semantical info */
            PFarray_t* externalCNames = p->sem.ref_tbl.tcols;

            /* iterate the schema and generate a column-mapping for each
               "internal"-"external"-column-name-pair */
            int count = schema.count;
            for(int i = 0; i < count; i++)
            {
                PFalg_schm_item_t schemaItem = schema.items[i];

                PFalg_col_t columnNameInternal = schemaItem.name;
                char* columnNameExternal =
                    *(char**) PFarray_at (externalCNames, i);
                PFalg_simple_type_t columnType = schemaItem.type;

                col_env_add (COLMAP(p),
                         columnNameInternal,
                         columnType,
                         ref_column_name(tabalias, columnNameExternal)
                           );
            }
        }
        break;

        /* Rel:    attach (Rel) */
        case 11:
            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));

            /* add expression for attach to the column environment */
            if (p->sem.attach.value.type == aat_qname) {
                col_env_add (COLMAP(p),
                             p->sem.attach.res,
                             aat_qname_loc,
                             literal (
                                 namespace_atom (
                                     p->sem.attach.value,
                                     aat_qname_loc)));
                col_env_add (COLMAP(p),
                             p->sem.attach.res,
                             aat_qname_uri,
                             literal (
                                 namespace_atom (
                                     p->sem.attach.value,
                                     aat_qname_uri)));
            }
            else
                col_env_add (COLMAP(p),
                             p->sem.attach.res,
                             p->sem.attach.value.type,
                             literal (p->sem.attach.value));

            break;

        /* Rel:    cross (Rel, Rel) */
        case 12:
        /* Rel:    eqjoin (Rel, Rel) */
        case 13:
        /* Rel:    thetajoin (Rel, Rel) */
        case 15:
        {
            assert (kids[0] && nts[0]);
            assert (kids[1] && nts[1]);

            /* reduce the first child */
            reduce (kids[0], nts[0]);

            if (p->kind == la_eqjoin) {
                 PFalg_simple_type_t l_ty;

                 l_ty = type_of (p, p->sem.eqjoin.col1);

                 assert (monomorphic (l_ty));

                 /* if the the eqjoin joins over boolean values
                  * we have to bind the underlying node */
                 if (l_ty == aat_bln && !BOUND(L(p)))
                     bind_operator (L(p), false);
            }
            else if (p->kind == la_thetajoin) {
                PFalg_simple_type_t l_ty;

                /* iterate over all predicates and add them to the wherelist */
                for (unsigned int i = 0; i < p->sem.thetajoin.count; i++) {

                    l_ty   = type_of (p, p->sem.thetajoin.pred[i].left);

                    assert (monomorphic (l_ty));

                    /* if the thetajoin joins over boolean values
                     * we have to bind the underlying node */
                    if (l_ty == aat_bln && !BOUND (L(p)))
                        bind_operator (L(p), false);
                }
            }

            /* copy all existing column, from, and where lists
               of the left child */
            copy_cols_from_where (p, L(p));

            reduce (kids[1], nts[1]);

            if (p->kind == la_eqjoin) {
                 PFalg_simple_type_t r_ty;

                 r_ty = type_of (p, p->sem.eqjoin.col2);

                 assert (monomorphic (r_ty));

                 /* if the the eqjoin joins over boolean values
                  * we have to bind the underlying node */
                 if (r_ty == aat_bln && !BOUND(R(p)))
                     bind_operator (R(p), false);
            }
            else if (p->kind == la_thetajoin) {
                PFalg_simple_type_t r_ty;

                /* iterate over all predicates and add them to the wherelist */
                for (unsigned int i = 0; i < p->sem.thetajoin.count; i++) {

                    r_ty   = type_of (p, p->sem.thetajoin.pred[i].right);

                    assert (monomorphic (r_ty));

                    /* if the thetajoin joins over boolean values
                     * we have to bind the underlying node */
                    if (r_ty == aat_bln && !BOUND (R(p)))
                        bind_operator (R(p), false);
                }
            }

            /* copy all existing expression from right child */
            for (unsigned int i = 0; i < PFarray_last (COLMAP(R(p))); i++) {
                sql_column_env_t entry = col_env_at (COLMAP(R(p)), i);

                /* if the col/type value is just in the environment
                 * throw an error, because the schema of the left and
                 * right child should be disjoint.
                 */
                if (!col_env_lookup_unsafe (COLMAP(p), entry.col, entry.type))
                    col_env_add_full (COLMAP(p),
                                      entry.col,
                                      entry.type,
                                      entry.expression,
                                      entry.step_alias,
                                      entry.step_leaf);
                else
                    PFoops (OOPS_FATAL,
                            "SQLgen: The join tables contains equal"
                            " column/type mappings");
            }

            /* do not copy singleton relation */
            /* todo: trigger the rewrite on cardinality instead of "sysibm" */
            {
                PFsql_t *tbl = from_list_at (FROMLIST(R(p)), 0).table;
                if (!(PFarray_last (FROMLIST(R(p))) == 1 &&
                      tbl->kind == sql_schema_tbl_name &&
                      L(tbl)->kind == sql_tbl_name &&
                      !strcmp (tbl->sem.schema.str, "sysibm") &&
                      L(tbl)->sem.tbl.name == PF_SQL_TABLE_SYSDUMMY1))
                    /* merge the fromlist of the left and right child */
                    from_list_copy (FROMLIST(p), FROMLIST(R(p)));
            }

            /* merge the wherelist of the left and right child */
            where_list_copy (WHERELIST(p), WHERELIST(R(p)));

            /* join predicate for the equi-join operator */
            if (p->kind == la_eqjoin) {
                 PFalg_simple_type_t l_ty, r_ty;

                 l_ty = type_of (p, p->sem.eqjoin.col1);
                 r_ty = type_of (p, p->sem.eqjoin.col2);

                 assert (l_ty == r_ty && monomorphic (l_ty));

                 /* add the constraint that comes from the equijoin semantics */
                 where_list_add (WHERELIST(p),
                                 eq (col_env_lookup (
                                         COLMAP(p),
                                         p->sem.eqjoin.col1,
                                         l_ty),
                                     col_env_lookup (
                                         COLMAP(p),
                                         p->sem.eqjoin.col2,
                                         r_ty)));
            }
            /* join predicates for the theta-join operator */
            else if (p->kind == la_thetajoin) {
                PFalg_col_t left, right;
                PFsql_t *l_expr, *r_expr;
                PFalg_simple_type_t l_ty, r_ty;
                PFsql_t *cond;

                /* iterate over all predicates and add them to the wherelist */
                for (unsigned int i = 0; i < p->sem.thetajoin.count; i++) {
                    left   = p->sem.thetajoin.pred[i].left;
                    right  = p->sem.thetajoin.pred[i].right;

                    l_ty   = type_of (p, left);
                    r_ty   = type_of (p, right);

                    assert (l_ty == r_ty && monomorphic (l_ty));

                    l_expr = col_env_lookup (COLMAP(p), left, l_ty);
                    r_expr = col_env_lookup (COLMAP(p), right, r_ty);

                    switch (p->sem.thetajoin.pred[i].comp) {
                        case alg_comp_eq: cond = eq (l_expr, r_expr); break;
                        case alg_comp_gt: cond = gt (l_expr, r_expr); break;
                        case alg_comp_ge: cond = gteq (l_expr, r_expr); break;
                        case alg_comp_lt: cond = gt (r_expr, l_expr); break;
                        case alg_comp_le: cond = gteq (r_expr, l_expr); break;
                        case alg_comp_ne:
                            cond = not_ (eq (l_expr, r_expr));
                            break;

                        default:
                            PFoops (OOPS_FATAL,
                                    "SQLgen: Cannot determine which "
                                    "comparison operator to use");
                            break;
                    }

                    where_list_add (WHERELIST(p), cond);
                }
            }
        }       break;

        /* Rel:    semijoin (Rel, Rel) */
        case 14:
        {
            assert (kids[0] && nts[0]);
            assert (kids[1] && nts[0]);

            PFalg_col_t         col1 = p->sem.eqjoin.col1,
                                col2 = p->sem.eqjoin.col2;
            PFalg_simple_type_t ty   = type_of (L(p), col1);
            PFsql_alg_ann_t    *right;

            assert (type_of (R(p), col2) == ty);

            /* reduce the first child */
            reduce (kids[0], nts[0]);

            /* for the semijoin we only need the columns of
             * the left relation */
            /* copy all existing column, from, and where lists
               of the left child */
            copy_cols_from_where (p, L(p));

            /* reduce the second child */
            reduce (kids[1], nts[1]);

            /* If we need to ensure the correct cardinality
               we first need to bind the right argument. */
            if (!PFprop_set (p->prop) &&
                !(PFprop_key_left (p->prop, col1) &&
                  PFprop_key_right (p->prop, col2))) {
                PFsql_t            *expr     = col_env_lookup (
                                                   COLMAP(R(p)), col2, ty);
                PFsql_col_t        *colname  = new_col (col2, ty);
                PFsql_tident_t      newtable = new_table_name ();
                PFsql_aident_t      newalias = new_alias ();

                assert (monomorphic(ty));

                /* bind the right side and ensure the distinct
                   is evaluated on the join column only */
                execute (comment ("binding due to semijoin"));
                execute (bind (table_def (
                                   newtable,
                                   column_list (
                                       column_name (colname))),
                               select_distinct (
                                   select_list (
                                       column_assign (
                                           expr,
                                           column_name (colname))),
                                   transform_frommap (R(p)),
                                   transform_wheremap (R(p)))));

                /* prepare a new sql annotation
                   for the rest of the translation */
                right = sql_alg_ann_new ();

                from_list_add (right->frommap,
                               table_name (newtable),
                               alias (newalias));

                col_env_add (right->colmap,
                             col2,
                             ty,
                             ext_column_name (newalias, colname));
            }
            else
                right = R(p)->sql_ann;

            /* merge the fromlist of the left and right child */
            from_list_copy (FROMLIST(p), right->frommap);
            /* merge the wherelist of the left and right child */
            where_list_copy (WHERELIST(p), right->wheremap);

            /* add the constraint coming from semijoin */
            where_list_add (WHERELIST(p),
                            eq (col_env_lookup (COLMAP(p), col1, ty),
                                col_env_lookup (right->colmap, col2, ty)));
        }   break;

        /* Rel:    project (Rel) */
        case 16:
        {
            sql_column_env_t entry;
            unsigned int k;

            /* ensure that ever column we need is in the map */
            for (unsigned int i = 0; i < p->sem.proj.count; i++) {
               for (k = 0; k < PFarray_last (COLMAP(L(p))); k++) {
                   entry = col_env_at (COLMAP(L(p)), k);
                   if (p->sem.proj.items[i].old == entry.col)
                       break;
               }

               if (k >= PFarray_last(COLMAP(L(p))))
                   PFoops (OOPS_FATAL, "Attribute %s not found in project",
                           PFcol_str (p->sem.proj.items[i].old));
            }

            /* copy the column map and update the column names
               for all columns in the projection list */
            for (unsigned int i = 0; i < p->sem.proj.count; i++)
                for (unsigned int j = 0; j < PFarray_last (COLMAP(L(p))); j++) {
                    entry = col_env_at (COLMAP(L(p)), j);
                    if (p->sem.proj.items[i].old == entry.col) {
                        col_env_add_full (COLMAP(p),
                                          p->sem.proj.items[i].new,
                                          entry.type,
                                          entry.expression,
                                          entry.step_alias,
                                          entry.step_leaf);
                    }
                }

            /* copy fromlist */
            from_list_copy (FROMLIST(p), FROMLIST(L(p)));
            /* copy wherelist */

            where_list_copy (WHERELIST(p), WHERELIST(L(p)));
        }   break;

        /* Rel:    select_ (Rel) */
        case 17:
        {
            PFsql_t *sqlnode;

            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));

            assert (type_of (p, p->sem.select.col) == aat_bln);

            sqlnode = col_env_lookup (COLMAP(L(p)),
                                      p->sem.select.col,
                                      aat_bln);

            if (sqlnode->kind == sql_column_name ||
                sqlnode->kind == sql_lit_int)
                /* we introduced a case expression before that produces
                   1 for all true values ... */
                where_list_add (WHERELIST(p), eq (sqlnode, lit_int (1)));
            else {
                /* otherwise we already have a comparison in our hands
                   and use it */
                where_list_add (WHERELIST(p), sqlnode);
            }

        }   break;

        /* Rel:    pos_select (Rel) */
        case 18:
            /* create a special translation for the positional
               predicates [1] and [last()] */
            if (p->schema.count <= 2 &&
                (p->sem.pos_sel.pos == 1 || p->sem.pos_sel.pos == -1) &&
                PFord_count (p->sem.pos_sel.sortby) == 1 &&
                PFord_order_dir_at (p->sem.pos_sel.sortby, 0) == DIR_ASC) {
                PFalg_col_t         col,
                                    part;
                PFalg_simple_type_t ty,
                                    part_ty;
                PFsql_t            *expr,
                                   *part_expr;
                PFsql_col_t        *part_col,
                                   *col_col;
                PFsql_t            *selectlist = NULL;
                PFsql_t            *columnlist = NULL;
                PFsql_t            *groupbylist = NULL;
                PFsql_tident_t      newtable;
                PFsql_aident_t      newalias;

                part = p->sem.pos_sel.part;

                /* Bind the input of the aggregate if the group by
                   criterion is not a column reference. */
                if (part &&
                    (col_env_lookup (
                         COLMAP(L(p)),
                         part,
                         type_of (p, part)))->kind != sql_column_name) {
#ifndef NDEBUG
                    if (!BOUND(L(p)))
                        execute (comment ("bind as a column reference "
                                          "is needed in the following "
                                          "positional predicate"));
#endif
                    bind_operator (L(p), false);
                }

                /* create a new table name for binding */
                newtable = new_table_name ();
                /* new correlation name for bounded table */
                newalias = new_alias ();

                /* start a new from list as a newtable will be bound */
                from_list_add (FROMLIST(p),
                               table_name (newtable),
                               alias (newalias));

                /* add the partition criterion to all lists and environments */
                if (part) {
                    part_ty   = type_of (p, part);
                    part_col  = new_col (part, part_ty);
                    part_expr = col_env_lookup (COLMAP(L(p)), part, part_ty);

                    col_env_add (COLMAP(p), part, part_ty,
                                 ext_column_name (newalias, part_col));

                    /* create columnlist for the table name */
                    columnlist = column_list (columnlist,
                                              column_name (part_col));

                    /* create selectlist for the table name */
                    selectlist = select_list (selectlist,
                                              transform_expression (
                                                  part_expr,
                                                  column_name (part_col)));

                    groupbylist = column_list (groupbylist, part_expr);
                }

                col     = PFord_order_col_at (p->sem.pos_sel.sortby, 0);
                ty      = type_of (p, col);
                col_col = new_col (col, ty);
                expr    = col_env_lookup (COLMAP(L(p)), col, ty);

                /* generate the aggregation */
                expr    = p->sem.pos_sel.pos > 0 ? min_ (expr) : max_ (expr);

                col_env_add (COLMAP(p), col, ty,
                             ext_column_name (newalias, col_col));

                columnlist = column_list (columnlist, column_name (col_col));

                /* add the aggregation to the selection list */
                selectlist = select_list (selectlist,
                                          transform_expression (
                                              expr,
                                              column_name (col_col)));

                /* dump the operator binding */
                execute (comment ("binding due to positional aggregate"));
                execute (bind (table_def (newtable, columnlist),
                               PFsql_select (false,
                                             selectlist,
                                             transform_frommap (L(p)),
                                             transform_wheremap (L(p)),
                                             NULL,
                                             groupbylist)));

                /* mark node p as bound */
                BOUND(p) = true;
            }
            /* we need to translate the positional predicate
               with a ROW_NUMBER clause. */
            else {
                bool             change_order = p->sem.pos_sel.pos < 0;
                int              pos          = (change_order ? -1 : 1)
                                                * p->sem.pos_sel.pos;
                PFalg_col_t      num;
                PFsql_t         *srtbylist    = NULL;
                PFsql_t         *partlist     = NULL;
                PFord_ordering_t sortby       = p->sem.pos_sel.sortby;
                PFalg_col_t      ord;
                bool             asc;

                /* get ourselves a new column name */
                num = PFcol_new (col_pos);

                /* copy all existing column, from, and where lists */
                copy_cols_from_where (p, L(p));

                /* collect all sorting criteria */
                for (int i = PFord_count (sortby) - 1; i >= 0; i--) {
                    ord = PFord_order_col_at (sortby, i);
                    asc = PFord_order_dir_at (sortby, i) == DIR_ASC;
                    srtbylist = sortkey_list (
                                    sortkey_item (
                                        col_env_lookup (
                                            COLMAP(L(p)),
                                            ord,
                                            type_of (L(p), ord)),
                                        change_order ? !asc : asc),
                                    srtbylist);
                }

                /* creat partition criterion if present */
                if (p->sem.pos_sel.part)
                    partlist = partition (
                                   column_list (
                                       col_env_lookup (
                                           COLMAP(L(p)),
                                           p->sem.pos_sel.part,
                                           type_of (
                                               L(p),
                                               p->sem.pos_sel.part))));

                /* calculate the position values */
                col_env_add (COLMAP(p),
                             num,
                             aat_int,
                             over (row_number (),
                                   window_clause (
                                       partlist,
                                       PFord_count (sortby)
                                       ? order_by (srtbylist) : NULL)));

                /* create a binding to make the positions accessible */
                bind_operator (p, false);

                /* add the positional predicate */
                where_list_add (
                    WHERELIST(p),
                    eq (col_env_lookup (COLMAP(p), num, aat_int),
                        lit_int (pos)));

                /* remove the num variable from the column list */
                assert ((*(sql_column_env_t *)
                            PFarray_top (COLMAP(p))).col == num);
                PFarray_del (COLMAP(p));
            }
            break;

        /* Rel:     to (Rel) */
        case 19:
        {
              unsigned int c = 0;

              PFsql_col_t *rescol = NULL;

              PFsql_t *columnlist = NULL;
              PFsql_t *selectlist = NULL;
              PFsql_t *fromlist   = NULL;
              PFsql_t *wherelist  = NULL;

              PFsql_t *col1 = NULL;
              PFsql_t *key  = NULL;

              /* lists for the recursion to
               * simulate a relational-loop */
              PFsql_t *recselectlist = NULL;
              PFsql_t *recfromlist = NULL;
              PFsql_t *recwherelist = NULL;

              PFsql_t *reckey  = NULL;
              PFsql_t *reccol2 = NULL;

              PFsql_tident_t totbl   = new_table_name ();
              PFsql_aident_t toalias = new_alias ();

              rescol = new_col (
                           p->sem.binary.res,
                           type_of (p, p->sem.binary.res));

              /* check if there is a key we can use */
              for (c = 0; c < L(p)->schema.count; c++)
                  if (PFprop_key (L(p)->prop, L(p)->schema.items[c].name))
                      break;

              /* initialize lists with the items
               * from the underlying node */
              columnlist = transform_columnlist (COLMAP(L(p)));
              selectlist = transform_selectlist (COLMAP(L(p)));
              fromlist   = transform_frommap    (L(p));
              wherelist  = transform_wheremap   (L(p));

              col1 = col_env_lookup (COLMAP(L(p)),
                         p->sem.binary.col1,
                         type_of (p, p->sem.binary.col1));

              for (unsigned int i = 0;
                   i < PFarray_last (COLMAP(L(p))); i++) {

                  sql_column_env_t entry = col_env_at (COLMAP(L(p)), i);
                  PFsql_col_t *newcolumn = new_col (entry.col, entry.type);

                  recselectlist = select_list (recselectlist,
                                   ext_column_name (
                                       toalias,
                                       newcolumn));
                  col_env_add (COLMAP(p), entry.col, entry.type,
                               ext_column_name (
                                       toalias,
                                       newcolumn));
              }

              recfromlist = fromlist;

              /* if there is no key present, create an artificial key
               * key with rownumber functionality */
              if (c >= L(p)->schema.count) {
                  PFsql_tident_t keytbl = new_table_name ();
                  PFsql_aident_t keyalias = new_alias ();

                  columnlist = column_list (columnlist, SUR_);

                  execute (bind (
                      table_def (keytbl,
                                columnlist),
                      select (
                          select_list (
                               selectlist,
                               column_assign (
                                   over (row_number (),
                                         window_clause (NULL, NULL)),
                                   SUR_)),
                          fromlist,
                          wherelist)));

                  /* since we have a new base table now we have to
                   * modify the list structures */

                  selectlist = NULL;
                  fromlist = NULL;
                  wherelist = NULL;

                  for (unsigned int i = 0;
                       i < PFarray_last (COLMAP(L(p))); i++) {

                      sql_column_env_t entry = col_env_at (COLMAP(L(p)), i);
                      selectlist = select_list (selectlist,
                                       ext_column_name (
                                           keyalias,
                                           new_col (entry.col, entry.type)));
                  }
                  selectlist = select_list (selectlist,
                                    SUR(keyalias));

                  fromlist = from_list (
                                 alias_bind (table_name (keytbl),
                                             alias (keyalias)));

                  col1 = ext_column_name (
                              keyalias,
                              new_col (
                                  p->sem.binary.col1,
                                  type_of (L(p), p->sem.binary.col1)));

                  key = SUR(keyalias);


                  recselectlist = select_list (
                                       recselectlist,
                                       SUR (toalias));

                  recfromlist = from_list (
                                       alias_bind (table_name (keytbl),
                                                   alias (keyalias)));

                  reckey = SUR(toalias);
              } else {
                  key = col_env_lookup (COLMAP (L(p)),
                             L(p)->schema.items[c].name,
                             type_of (L(p),
                                 L(p)->schema.items[c].name));
                  reckey = ext_column_name (
                               toalias,
                               new_col (
                                   L(p)->schema.items[c].name,
                                   type_of (L(p),
                                       L(p)->schema.items[c].name)));
              }

              /* prepare the lists for the recursion */
              columnlist = column_list (
                               columnlist,
                               column_name (rescol));

              selectlist = select_list (selectlist,
                                 column_assign (
                                      col1,
                                      column_name (rescol)));

              recselectlist = select_list (recselectlist,
                                   column_assign (
                                       add (ext_column_name (
                                               toalias,
                                               rescol),
                                            lit_int (1)),
                                       column_name (rescol)));

              reccol2 = ext_column_name (
                            toalias,
                            new_col (p->sem.binary.col2,
                                type_of (L(p), p->sem.binary.col2)));

              execute (bind (
                  table_def (totbl, columnlist),
                  union_ (
                    select (
                        selectlist,
                        fromlist,
                        wherelist),
                    select (
                        recselectlist,
                        from_list (recfromlist,
                            alias_bind (
                                table_name (totbl),
                                alias (toalias))),
                        where_list (recwherelist,
                              eq (reckey, key),
                              gt (reccol2,
                                  ext_column_name (
                                      toalias,rescol)))))));

            col_env_add (COLMAP(p),
                         p->sem.binary.res,
                         type_of (p, p->sem.binary.res),
                         ext_column_name (
                             toalias, rescol));

            from_list_add (FROMLIST (p),
                          table_name (totbl),
                          alias (toalias));

            BOUND (p) = true;
        }   break;

        /* Rel:    disjunion (Rel, Rel) */
        case 20:
        /* Rel:    intersect (Rel, Rel) */
        case 21:
        /* Rel:    difference (Rel, Rel) */
        case 22:
        {
            PFsql_t * (*op) (const PFsql_t *, const PFsql_t *) = NULL;
            PFsql_t *selectlist1 = NULL;
            PFsql_t *selectlist2 = NULL;
            PFsql_t *columnlist  = NULL;
            PFalg_col_t col;
            PFalg_simple_type_t ty, t;
            PFsql_col_t *colname;

            /* create a new table name for binding */
            PFsql_tident_t newtable = new_table_name ();
            /* new correlation name for bounded table */
            PFsql_aident_t newalias = new_alias ();

            /* start a new from list as @a newtable will be bound */
            from_list_add (FROMLIST(p),
                           table_name (newtable),
                           alias (newalias));

            /* prepare the selection lists, the column list, and fill in
               the new bindings for the column environment */
            for (unsigned int i = 0; i < p->schema.count; i++) {
                col = p->schema.items[i].name;
                ty  = p->schema.items[i].type;
                for (t = 1; t; t <<= 1)
                    if (t & TYPE_MASK (ty)) {
                        colname = new_col (col, t);

                        /* create columnlist for the table name */
                        columnlist = column_list (columnlist,
                                                  column_name (colname));

                        col_env_add (COLMAP(p),
                                     col,
                                     t,
                                     ext_column_name (newalias, colname));

                        /* Type t is in the result relation.
                           See if it is also in the left operand.  */
                        if (!(t & type_of (L(p), col)))
                            selectlist1 = select_list (
                                              selectlist1,
                                              column_assign (
                                                  cast (null (), type (t)),
                                                  column_name (colname)));
                        else
                            selectlist1 = select_list (
                                              selectlist1,
                                              transform_expression (
                                                  col_env_lookup (
                                                      COLMAP(L(p)), col, t),
                                                  column_name (colname)));

                        /* Type t is in the result relation.
                           See if it is also in the left operand. */
                        if (!(t & type_of (R(p), col)))
                            selectlist2 = select_list (
                                              selectlist2,
                                              column_assign (
                                                  cast (null (), type (t)),
                                                  column_name (colname)));
                        else
                            selectlist2 = select_list (
                                              selectlist2,
                                              transform_expression (
                                                  col_env_lookup (
                                                      COLMAP(R(p)), col, t),
                                                  column_name (colname)));
                    }
            }

            switch (p->kind) {
                case la_disjunion:  op = PFsql_union;      break;
                case la_difference: op = PFsql_difference; break;
                case la_intersect:  op = PFsql_intersect;  break;
                default: assert(!"set operator expected");
            };

            /* dump the operator binding */
            execute (comment ("binding due to set operation"));
            execute (bind (table_def (newtable, columnlist),
                           op (select (selectlist1,
                                       transform_frommap (L(p)),
                                       transform_wheremap (L(p))),
                               select (selectlist2,
                                       transform_frommap (R(p)),
                                       transform_wheremap (R(p))))));

            /* mark node p as bound */
            BOUND(p) = true;
        }   break;

        /* Rel:    distinct (Rel) */
        case 23:
            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));

            distinct = true;
            bind = true;
            execute (comment ("binding due to duplicate elimination"));
            break;

        /* Rel:    fun_1to1 (Rel) */
        case 25:
        {
            unsigned int count = PFalg_collist_size (p->sem.fun_1to1.refs);
            PFalg_col_t col[count];
            PFalg_simple_type_t ty[count];
            PFsql_t *expr[count];
            PFalg_col_t res_col = p->sem.fun_1to1.res;
            PFalg_simple_type_t res_ty = type_of (p, res_col);
            PFsql_t *res_expr = NULL;

            for (unsigned int i = 0; i < count; i++) {
                col[i]  = PFalg_collist_at (p->sem.fun_1to1.refs, i);
                ty[i]   = type_of (p, col[i]);
                expr[i] = col_env_lookup (COLMAP(L(p)), col[i], ty[i]);
            }

            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));

            switch (p->sem.fun_1to1.kind) {
                case alg_fun_num_add:
                    res_expr = add (expr[0], expr[1]); break;
                case alg_fun_num_subtract:
                    res_expr = sub (expr[0], expr[1]); break;
                case alg_fun_num_multiply:
                    res_expr = mul (expr[0], expr[1]); break;
                case alg_fun_num_divide:
                    res_expr = div (expr[0], expr[1]); break;
                case alg_fun_num_modulo:
                    res_expr = modulo (expr[0], expr[1]); break;
                case alg_fun_fn_abs:
                    res_expr = abs (expr[0]); break;
                case alg_fun_fn_ceiling:
                    res_expr = ceil (expr[0]); break;
                case alg_fun_fn_floor:
                    res_expr = floor (expr[0]); break;
                case alg_fun_fn_concat:
                    /* the algebra ensures that the expressions are strings */
                    res_expr = concat (expr[0], expr[1]); break;
                case alg_fun_fn_substring:
                    res_expr = substring (expr[0], expr[1]); break;
                case alg_fun_fn_substring_len:
                    res_expr = substring_len (expr[0], expr[1], expr[2]); break;
                case alg_fun_fn_string_length:
                    res_expr = str_length (expr[0]); break;
                case alg_fun_fn_upper_case:
                    res_expr = str_upper (expr[0]); break;
                case alg_fun_fn_lower_case:
                    res_expr = str_lower (expr[0]); break;
                case alg_fun_fn_contains:
                    {
                        /* adding check for constant expression */
                        if (!PFprop_const (L(p)->prop, col[1]) ||
                            ty[1]         != aat_str           ||
                            expr[1]->kind == sql_column_name)
                            PFoops (OOPS_FATAL, "fn_contains works only with constant "
                                                "string expressions");
                        char *str = PFmalloc (strlen(expr[1]->sem.atom.val.s)+2);
                        sprintf (str, "%%%s%%", expr[1]->sem.atom.val.s);
                        res_expr = like (expr[0], PFsql_lit_str(str));
                    }
                    break;
                case alg_fun_fn_like:
                    /* adding check for constant expression */
                    if (!PFprop_const (L(p)->prop, col[1]) ||
                        ty[1]         != aat_str           ||
                        expr[1]->kind == sql_column_name)
                        PFoops (OOPS_FATAL, "fn_like works only with constant "
                                            "string expressions");
                    res_expr = like (expr[0], expr[1]);
                    break;
                case alg_fun_fn_number:
                case alg_fun_fn_number_lax:
                    res_expr = cast_ (expr[0], ty[0], aat_dbl); break;
                case alg_fun_fn_similar_to:
                    res_expr = similar_to (expr[0], expr[1]); break;
                case alg_fun_fn_year_from_date:
                    res_expr = year(expr[0]); break;
                case alg_fun_fn_month_from_date:
                    res_expr = month(expr[0]); break;
                case alg_fun_fn_day_from_date:
                    res_expr = day(expr[0]); break;

                case alg_fun_fn_round:
                case alg_fun_pf_log:
                case alg_fun_pf_sqrt:
                case alg_fun_fn_normalize_space:
                case alg_fun_fn_translate:
                case alg_fun_fn_starts_with:
                case alg_fun_fn_ends_with:
                case alg_fun_fn_substring_before:
                case alg_fun_fn_substring_after:
                case alg_fun_fn_matches:
                case alg_fun_fn_matches_flag:
                case alg_fun_fn_replace:
                case alg_fun_fn_replace_flag:
                case alg_fun_fn_name:
                case alg_fun_fn_local_name:
                case alg_fun_fn_namespace_uri:
                case alg_fun_fn_qname:
                    assert (!"missing");
                    break;

                case alg_fun_fn_doc_available:
                    res_expr = PFsql_eq (lit_int (1),lit_int (1));
                    PFlog ("Document availability check not implemented.");
                    break;

                case alg_fun_pf_fragment:
                case alg_fun_pf_supernode:
                case alg_fun_pf_add_doc_str:
                case alg_fun_pf_add_doc_str_int:
                case alg_fun_pf_del_doc:
                case alg_fun_pf_nid:
                case alg_fun_pf_docname:
                case alg_fun_upd_rename:
                case alg_fun_upd_delete:
                case alg_fun_upd_insert_into_as_first:
                case alg_fun_upd_insert_into_as_last:
                case alg_fun_upd_insert_before:
                case alg_fun_upd_insert_after:
                case alg_fun_upd_replace_value_att:
                case alg_fun_upd_replace_value:
                case alg_fun_upd_replace_element:
                case alg_fun_upd_replace_node:
                case alg_fun_fn_year_from_datetime:
                case alg_fun_fn_month_from_datetime:
                case alg_fun_fn_day_from_datetime:
                case alg_fun_fn_hours_from_datetime:
                case alg_fun_fn_minutes_from_datetime:
                case alg_fun_fn_seconds_from_datetime:
                case alg_fun_fn_hours_from_time:
                case alg_fun_fn_minutes_from_time:
                case alg_fun_fn_seconds_from_time:
                case alg_fun_add_dur:
                case alg_fun_subtract_dur:
                case alg_fun_multiply_dur:
                case alg_fun_divide_dur:
#ifdef HAVE_GEOXML
                case alg_fun_geo_wkb:
                case alg_fun_geo_point:
                case alg_fun_geo_distance:
                case alg_fun_geo_geometry:
                case alg_fun_geo_relate:
                case alg_fun_geo_intersection:
#endif
                    /* FIXME: implementation is missing */
                    assert (!"missing");
                    break;
            }
            col_env_add (COLMAP(p), res_col, res_ty, res_expr);

        }   break;
        /* Rel:    num_eq (Rel) */
        case 26:
        /* Rel:    num_gt (Rel) */
        case 27:
        {
            PFsql_t            *(*op) (const PFsql_t *, const PFsql_t *);
            PFalg_simple_type_t lty = type_of (p, p->sem.binary.col1),
                                rty = type_of (p, p->sem.binary.col2);
            PFsql_t            *lcol,
                               *rcol;

            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));

            if (p->kind == la_num_eq)
                op = PFsql_eq;
            else
                op = PFsql_gt;

            lcol = col_env_lookup (COLMAP(p), p->sem.binary.col1, lty);
            rcol = col_env_lookup (COLMAP(p), p->sem.binary.col2, rty);

            /* for databases without boolean types we have to fake the
               comparison of boolean values (by using integers) */
            if (lty == aat_bln) {
                lcol = (lcol->kind == sql_column_name ||
                        lcol->kind == sql_lit_int)
                       ? lcol
                       : case_ (when (lcol, TRUE_INT), else_ (FALSE_INT));
                rcol = (rcol->kind == sql_column_name ||
                        rcol->kind == sql_lit_int)
                       ? rcol
                       : case_ (when (rcol, TRUE_INT), else_ (FALSE_INT));
            }

            /* add the new column to the environment */
            col_env_add (COLMAP(p),
                         p->sem.binary.res,
                         type_of (p, p->sem.binary.res),
                         op (lcol, rcol));
        }   break;

        /* Rel:    bool_and (Rel) */
        case 28:
        /* Rel:    bool_or (Rel) */
        case 29:
        {
            PFsql_t *sqlnode1;
            PFsql_t *sqlnode2;

            PFsql_t * (*op) (const PFsql_t *a, const PFsql_t *b);

            /* copy all existing column, from and where lists */
            copy_cols_from_where (p, L(p));

            sqlnode1 = col_env_lookup (COLMAP(p), p->sem.binary.col1, aat_bln);
            sqlnode2 = col_env_lookup (COLMAP(p), p->sem.binary.col2, aat_bln);

            if (sqlnode1->kind == sql_column_name ||
                sqlnode1->kind == sql_lit_int)
                sqlnode1 = eq (sqlnode1, lit_int (1));
            if (sqlnode2->kind == sql_column_name ||
                sqlnode2->kind == sql_lit_int)
                sqlnode2 = eq (sqlnode2, lit_int (1));

            switch (p->kind) {
                case la_bool_and: op = PFsql_and; break;
                case la_bool_or:  op = PFsql_or;  break;
                default:
                    PFoops (OOPS_FATAL,
                            "la_bool_and or la_bool_or expected!");
            }

            col_env_add (COLMAP(p),
                         p->sem.binary.res,
                         aat_bln,
                         op (sqlnode1, sqlnode2));
        }   break;

        /* Rel:    bool_not (Rel) */
        case 30:
        {
            PFsql_t *sqlnode;

            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));

            sqlnode = col_env_lookup (COLMAP(p), p->sem.unary.col, aat_bln);

            if (sqlnode->kind == sql_column_name)
                sqlnode = eq (sqlnode, lit_int (1));

            /* add the new column to the environment */
            col_env_add (COLMAP(p),
                         p->sem.unary.res,
                         aat_bln,
                         not_ (sqlnode));
        }   break;

        /* Rel:    type (Rel) */
        case 31:
            /* FIXME: implementation is missing */
            assert (!"missing");
            break;

        /* Rel:    type_assert (Rel) */
        case 32:
            /* FIXME: implementation is missing */
            assert (!"missing");
            break;

        /* Rel:    cast (Rel) */
        case 33:
        {
            PFalg_col_t col = p->sem.type.col;
            PFalg_simple_type_t ty = TYPE_MASK (type_of (p, col));
            PFalg_col_t res = p->sem.type.res;
            PFalg_simple_type_t res_ty = p->sem.type.ty;
            PFsql_t *expr;


            /* copy all existing column, from, and where lists */
            if (monomorphic (ty)) {
                copy_cols_from_where (p, L(p));

                expr = col_env_lookup (COLMAP(L(p)), col, ty);

                col_env_add (COLMAP(p), res, res_ty,
                             cast_ (expr, ty, res_ty));
            }
            else {
                /* if the type is polymorphic we have to dump
                 * the query immediatly */
                PFsql_t * selectlist,
                        * columnlist;

                /* create a new table name for binding */
                PFsql_tident_t newtable = new_table_name ();
                /* new correlation name for bounded table */
                PFsql_aident_t newalias = new_alias ();

                PFsql_col_t *res_col = new_col (res, res_ty);

                PFsql_t * query = NULL;

                /* prepare columnlist and selectlist,
                 * be careful that both are aligned */
                columnlist = transform_columnlist (COLMAP(L(p)));
                selectlist = transform_selectlist (COLMAP(L(p)));

                /* we can add the resulting column already
                 * here  to columnlist and environment. */
                columnlist = column_list (columnlist,
                                      column_name (res_col));

                col_env_copy (COLMAP(p), COLMAP(L(p)));
                /* bind every column to a new alias */
                transform_colenv (COLMAP(p), newalias);
                col_env_add (COLMAP(p), res, res_ty,
                             ext_column_name (newalias, res_col));

                /* prepare fromlist */
                from_list_add (FROMLIST(p),
                               table_name(newtable),
                               alias (newalias));

                /* run over the possible types */
                for (PFalg_simple_type_t t = 1; t; t <<= 1)
                    if (t & ty) {
                         expr = col_env_lookup (COLMAP(L(p)), col, t);

                         /* prepare statement */
                         PFsql_t * temp =
                            select (
                                select_list (selectlist,
                                    transform_expression (
                                        cast_ (expr, t, res_ty),
                                        column_name (res_col))),
                                transform_frommap (L(p)),
                                where_list (
                                    transform_wheremap (L(p)),
                                    is_not (expr, null ())));

                         query = (query)?union_(query,temp):temp;
                    }

                execute (comment ("bind due to polymorphic cast"));
                execute (bind (table_def (newtable, columnlist),
                               query));

                BOUND(p) = true;
            }
        }   break;

        /* Rel:    aggr (rank (Rel)) */
        case 36: /* reference to this rule also appears below */
        {
            PFord_ordering_t sortby = L(p)->sem.sort.sortby;

            if (!p->sem.aggr.part ||
                p->sem.aggr.part != L(p)->sem.sort.res ||
                PFprop_icol (p->prop, p->sem.aggr.part)) {
                /* Our pattern does not match anymore we have to make sure
                   to counteract correctly. We do that by triggering the
                   compilation with the standard aggr rule. */

                reduce_ (p, goalnt, /* BE AWARE -- a hard-coded rule: */ 35);
                return;
            }

            for (unsigned int i = 0; i < PFord_count (sortby); i++) {
                PFalg_col_t  col  = PFord_order_col_at (sortby, i);
                PFsql_kind_t kind = col_env_lookup (
                                        COLMAP(LL(p)),
                                        col,
                                        type_of (L(p), col))->kind;
                if (kind != sql_column_name &&
                    kind != sql_ref_column_name) {
#ifndef NDEBUG
                    if (!BOUND(LL(p)))
                        execute (comment ("bind as a column reference "
                                          "is needed in the following "
                                          "aggregate"));
#endif
                    bind_operator (LL(p), false);
                    break;
                }
            }
        }
            /* fall through */

        /* Rel:    aggr (Rel) */
        case 35: /* reference to this rule also appears below */

            /* Bind the input of the aggregate if the group by
               criterion is not a column reference. */
            if (p->sem.aggr.part &&
                rule == 35) {
                PFsql_kind_t kind = col_env_lookup (
                                        COLMAP(L(p)),
                                        p->sem.aggr.part,
                                        type_of (L(p), p->sem.aggr.part))->kind;
                if (kind != sql_column_name &&
                    kind != sql_ref_column_name) {
#ifndef NDEBUG
                    if (!BOUND(L(p)))
                        execute (comment ("bind as a column reference "
                                          "is needed in the following "
                                          "aggregate"));
#endif
                    bind_operator (L(p), false);
                }
            }
        {
            PFla_op_t *in_op = (rule == 35) ? L(p) : LL(p);

            PFsql_t *selectlist = NULL;
            PFsql_t *columnlist = NULL;
            PFsql_t *groupbylist = NULL;
            /* create a new table name for binding */
            PFsql_tident_t newtable = new_table_name ();
            /* new correlation name for bounded table */
            PFsql_aident_t newalias = new_alias ();

            /* start a new from list as @a newtable will be bound */
            from_list_add (FROMLIST(p),
                           table_name (newtable),
                           alias (newalias));

            /* add the partition criterion to all lists and environments */
            if (p->sem.aggr.part && rule == 35) {
                PFalg_col_t         part      = p->sem.aggr.part;
                PFalg_simple_type_t part_ty   = type_of (L(p), part);
                PFsql_col_t        *part_col  = new_col (part, part_ty);
                PFsql_t            *part_expr = col_env_lookup (COLMAP(L(p)),
                                                                part,
                                                                part_ty);
                /* provide the column information for the result
                   (after binding) */
                col_env_add (COLMAP(p), part, part_ty,
                             ext_column_name (newalias, part_col));

                /* create columnlist for the table name
                   (used during binding) */
                columnlist = column_list (columnlist,
                                          column_name (part_col));

                /* create selectlist for group by query */
                selectlist = select_list (selectlist,
                                          transform_expression (
                                              part_expr,
                                              column_name (part_col)));

                /* extend group by list */
                groupbylist = column_list (groupbylist, part_expr);
            }
            else if (p->sem.aggr.part && rule == 36) {
                PFord_ordering_t    sortby = L(p)->sem.sort.sortby;
                PFalg_col_t         ord;
                PFalg_simple_type_t ord_ty;

                for (unsigned int i = 0; i < PFord_count (sortby); i++) {
                    ord    = PFord_order_col_at (sortby, i);
                    ord_ty = type_of (L(p), ord);

                    /* extend group by list */
                    groupbylist = column_list (groupbylist,
                                               col_env_lookup (COLMAP(LL(p)),
                                                               ord,
                                                               ord_ty));
                }
            }

            /* add the aggregates to all lists and environments */
            for (unsigned int i = 0; i < p->sem.aggr.count; i++) {
                PFalg_col_t         col     = p->sem.aggr.aggr[i].col,
                                    res     = p->sem.aggr.aggr[i].res;
                PFalg_simple_type_t res_ty  = type_of (p, res);
                PFsql_t            *expr    = NULL;
                PFsql_col_t        *res_col = new_col (res, res_ty);

                /* provide the column information for the result
                   (after binding) */
                col_env_add (COLMAP(p), res, res_ty,
                             ext_column_name (newalias, res_col));

                /* create columnlist for the table name
                   (used during binding) */
                columnlist = column_list (columnlist, column_name (res_col));

                /* cope with missing col column in case of count */
                if (col)
                    expr = col_env_lookup (COLMAP(in_op),
                                           col,
                                           type_of (in_op, col));

                /* generate the aggregation */
                switch (p->sem.aggr.aggr[i].kind) {
                    case alg_aggr_dist:
                    {
                        bool found = false;
                        /* Try to find the column col in the rank order list. */
                        if (rule == 36) {
                            PFord_ordering_t sortby = L(p)->sem.sort.sortby;
                            unsigned int     i;
                            for (i = 0; i < PFord_count (sortby); i++)
                                if (PFord_order_col_at (sortby, i) == col) {
                                    found = true;
                                    break;
                                }
                        }
                        /* In case the column did not exist in
                           the column list already ... */
                        if (!found && !IS_LITERAL(expr))
                            /* ... extend the group by list. */
                            groupbylist = column_list (groupbylist, expr);
                    }   break;

                    case alg_aggr_min:   expr = min_ (expr);     break;
                    case alg_aggr_max:   expr = max_ (expr);     break;
                    case alg_aggr_all:
                        expr = min_ (((expr)->kind == sql_column_name)?
                                    expr:
                                    case_(
                                       when (expr,
                                             lit_int(1)),
                                       else_ (lit_int (0))));
                        break;
                    case alg_aggr_count: expr = count (star ()); break;
                    case alg_aggr_avg:   expr = avg (expr);      break;
                    case alg_aggr_sum:   expr = sum (expr);      break;
                    case alg_aggr_seqty1:
                    case alg_aggr_prod:
                        PFoops (OOPS_FATAL, "Unsupported aggregate.");
                        break;
                }

                /* add the aggregation to the selection list */
                selectlist = select_list (selectlist,
                                          transform_expression (
                                              expr,
                                              column_name (res_col)));
            }

            /* dump the operator binding */
            execute (comment ("binding due to aggregate"));
            execute (bind (table_def (newtable, columnlist),
                           PFsql_select (false,
                                         selectlist,
                                         transform_frommap (in_op),
                                         transform_wheremap (in_op),
                                         NULL,
                                         groupbylist)));

            /* mark node p as bound */
            BOUND(p) = true;
        }   break;

        /* Rel:    disjunion (
                       aggr (Rel),
                       attach (difference (
                                   Rel,
                                   project (aggr (Rel))))) */
        case 40:
            /**
             * ensure the following pattern:
             *
             *     union
             *     /   \
             *    /     \
             *   |     attach
             *   |       |
             *   |     diff
             *   |     /  \
             *   |   Rel   \
             *   |       project
             *   |         /
             *   |        /
             *    \      /
             *     \    /
             *      count
             */
            if (!(L(p) == RLRL(p) &&
                  L(p)->sem.aggr.count == 1 &&
                  L(p)->sem.aggr.aggr[0].kind == alg_aggr_count &&
                  R(p)->sem.attach.res == L(p)->sem.aggr.aggr[0].res &&
                  R(p)->sem.attach.value.type == aat_int &&
                  R(p)->sem.attach.value.val.int_ == 0 &&
                  RLL(p)->schema.count == 1 &&
                  RLR(p)->schema.count == 1 &&
                  L(p)->sem.aggr.part != col_NULL &&
                  L(p)->sem.aggr.part == RLR(p)->schema.items[0].name)) {
                /* Our pattern does not match anymore we have to make sure
                   to counteract correctly. We do that by triggering the
                   compilation with the standard union rule. */

                reduce_ (p, goalnt, /* BE AWARE -- a hard-coded rule: */ 20);
                return;
            }

        {
            PFalg_col_t part, res;
            PFalg_simple_type_t part_ty, res_ty;
            PFsql_col_t *part_col, *res_col;
            PFsql_t *loop, *part_expr, *loop_from, *part_from;
            sql_from_list_t from;

            PFsql_t *selectlist = NULL;
            PFsql_t *columnlist = NULL;
            PFsql_t *groupbylist = NULL;
            PFsql_tident_t newtable;
            PFsql_aident_t newalias;

            part      = L(p)->sem.aggr.part;
            res       = L(p)->sem.aggr.aggr[0].res;
            part_ty   = type_of (p, part);
            res_ty    = type_of (p, res);

            /* Bind the inner relation if it contains more
               than one input relation (as right outer join
               only works on exactly two relations). */
            if (PFarray_last (FROMLIST(LL(p))) != 1) {
#ifndef NDEBUG
                if (!BOUND(LL(p)))
                    execute (comment ("bind as a single relation "
                                      "is needed in the following outerjoin"));
#endif
                bind_operator (LL(p), false);
            }

            /* bind the outer relation if it contains more
               than one input relation (as right outer join
               only works on exactly two relations) or if the
               loop column is computed. */
            if (PFarray_last (FROMLIST(RLL(p))) != 1 ||
                col_env_lookup (COLMAP(RLL(p)),
                                part,
                                part_ty)->kind != sql_column_name) {
#ifndef NDEBUG
                if (!BOUND(RLL(p)))
                    execute (comment ("bind as a single relation "
                                      "is needed in the following outerjoin"));
#endif
                bind_operator (RLL(p), false);
            }

            part_col  = new_col (part, part_ty);
            res_col   = new_col (res, res_ty);
            loop      = col_env_lookup (COLMAP(RLL(p)), part, part_ty);
            part_expr = col_env_lookup (COLMAP(LL(p)), part, part_ty);
            from      = from_list_at (FROMLIST(RLL(p)), 0);
            loop_from = alias_bind (from.table, from.alias);
            from      = from_list_at (FROMLIST(LL(p)), 0);
            part_from = alias_bind (from.table, from.alias);

            /* create a new table name for binding */
            newtable = new_table_name ();
            /* new correlation name for bounded table */
            newalias = new_alias ();
            /* start a new from list as @a newtable will be bound */
            from_list_add (FROMLIST(p),
                           table_name (newtable),
                           alias (newalias));

            /* PREPARE EVERYTHING FOR THE RESULT ATTRIBUTE */
            col_env_add (COLMAP(p), res, res_ty,
                         ext_column_name (newalias, res_col));

            columnlist = column_list (columnlist, column_name (res_col));

            /* add the aggregation to the selection list */
            selectlist = select_list (selectlist,
                                      column_assign (
                                          coalesce (
                                              count (part_expr),
                                              literal (
                                                  R(p)->sem.attach.value)),
                                          column_name (res_col)));

            /* PREPARE EVERYTHING FOR THE PARTITION ATTRIBUTE */
            col_env_add (COLMAP(p), part, part_ty,
                         ext_column_name (newalias, part_col));

            /* create columnlist for the table name */
            columnlist = column_list (columnlist,
                                      column_name (part_col));

            /* create selectlist for the table name */
            selectlist = select_list (selectlist, loop);

            groupbylist = column_list (groupbylist, loop);

            /* DUMP THE OPERATOR BINDING */
            execute (comment ("binding due to count aggregate"));
            execute (bind (table_def (newtable, columnlist),
                           PFsql_select (
                                    false,
                                    selectlist,
                                    from_list (
                                        on (left_outer_join (
                                               loop_from, part_from),
                                            eq (part_expr, loop))),
                                    transform_wheremap (LL(p)),
                                    NULL,
                                    groupbylist)));

            /* mark node p as bound */
            BOUND(p) = true;
        }   break;

        /* Rel:    string_join (Rel, Rel) */
        case 43:
        {
            /* TOPDOWN */
            PFalg_col_t txt_iter = p->sem.string_join.iter,
                        txt_pos  = p->sem.string_join.pos,
                        txt_item = p->sem.string_join.item;

            PFalg_col_t sep_iter = p->sem.string_join.iter_sep,
                        sep_item = p->sem.string_join.item_sep;

            PFsql_t *srtbylist = NULL,
                    *partlist = NULL;

            reduce (kids[0], nts[0]);
            /* collect all sorting criteria */

            PFsql_tident_t numbering_tbl = new_table_name ();;
            PFsql_aident_t numbering_alias = new_alias ();;

            PFsql_tident_t strjoin_tbl = new_table_name ();;
            PFsql_aident_t strjoin_alias = new_alias ();;

            PFsql_tident_t interm_tbl = new_table_name ();;
            PFsql_aident_t interm_alias = new_alias ();

            /* first of all ensure the pos column in
             * the string table is a dense sequence */
            partlist = partition (
                           column_list (
                                col_env_lookup (
                                    COLMAP(L(p)),
                                    txt_iter,
                                    type_of (L(p), txt_iter))));

            srtbylist = sortkey_list (
                            sortkey_item (
                                col_env_lookup (
                                    COLMAP(L(p)),
                                    txt_pos,
                                    type_of (L(p), txt_pos)), DIR_ASC),
                            srtbylist);

            PFsql_t *txt_iter_col = column_name (
                                        new_col (txt_iter,
                                                 type_of (L(p), txt_iter))),
                    *txt_pos_col  = column_name (
                                        new_col (txt_pos,
                                                 type_of (L(p), txt_pos))),
                    *txt_item_col = column_name (
                                        new_col (txt_item,
                                                 type_of (L(p), txt_item)));

            execute (comment ("====================="));
            execute (comment ("==== String-Join ===="));
            execute (comment ("====================="));
            execute (bind (table_def (numbering_tbl,
                                      column_list (txt_iter_col,
                                                   txt_pos_col,
                                                   txt_item_col)),
                           select (
                               select_list (
                                   column_assign (
                                       col_env_lookup (
                                           COLMAP (L(p)),
                                           txt_iter,
                                           type_of (L(p), txt_iter)),
                                       txt_iter_col),
                                   column_assign (
                                       over (row_number (),
                                             window_clause (
                                                 partlist,
                                                 order_by (
                                                     srtbylist))),
                                       txt_pos_col),
                                   column_assign (
                                      col_env_lookup (
                                         COLMAP (L(p)),
                                         txt_item,
                                         type_of (L(p), txt_item)),
                                      txt_item_col)
                                ),
                               transform_frommap (L(p)),
                               transform_wheremap (L(p))
                           )));

            reduce (kids[1], nts[1]);

#define COL(alias,col)  EXT_COLUMN_NAME ( \
                         alias,           \
                         col,             \
                         type_of (L(p), col))

            /* calculate the stringjoin in a recursion */
            execute (bind (table_def (
                            strjoin_tbl,
                              column_list (txt_iter_col,
                                           txt_pos_col,
                                           txt_item_col,
                                           SEP_)),
                     union_ (
                     PFsql_select (
                        false,
                        select_list (
                            column_assign (COL(numbering_alias, txt_iter),
                                           txt_iter_col),
                            column_assign (COL(numbering_alias, txt_pos),
                                           txt_pos_col),
                            column_assign (COL(numbering_alias, txt_item),
                                           txt_item_col),
                            column_assign (col_env_lookup (
                                               COLMAP (R(p)),
                                               sep_item,
                                               type_of (R(p), sep_item)),
                                           SEP_)
                        ),
                        from_list (transform_frommap (R(p)),
                                       alias_bind (table_name (numbering_tbl),
                                           alias (numbering_alias))),
                        where_list (transform_wheremap (R(p)),
                                    eq (col_env_lookup (
                                               COLMAP (R(p)),
                                               sep_iter,
                                               type_of (R(p), sep_iter)),
                                        COL (numbering_alias, txt_iter)),
                                    eq (txt_pos_col, lit_int (1))),
                        NULL,
                        NULL),
                     PFsql_select (
                        false,
                        select_list (
                            column_assign (COL(strjoin_alias, txt_iter),
                                           txt_iter_col),
                            column_assign (COL (strjoin_alias, txt_pos),
                                           txt_pos_col),
                            column_assign (COL (strjoin_alias, txt_item),
                                           txt_item_col),
                            column_assign (concat (
                                               col_env_lookup (
                                                   COLMAP (R(p)),
                                                   sep_item,
                                                   type_of (R(p), sep_item)),
                                               concat (
                                                   SEP(strjoin_alias),
                                                   COL(numbering_alias, txt_item))),
                                           SEP_)),
                        from_list (alias_bind (table_name (strjoin_tbl),
                                               alias (strjoin_alias)),
                                   alias_bind (table_name (numbering_tbl),
                                               alias (numbering_alias))),
                        where_list (eq (COL(strjoin_alias, txt_iter),
                                        COL(numbering_alias, txt_iter)),
                                    eq (COL(strjoin_alias, txt_pos),
                                        sub (COL(numbering_alias, txt_pos),
                                             lit_int (1)))),
                        NULL,
                        NULL))
                       ));

            /* filter only relevant tuples, since the recursion returns more values
             * than we need for the final result */
            execute (bind (table_def (
                            interm_tbl,
                              column_list (txt_iter_col,
                                           txt_pos_col)),
                     PFsql_select (
                         false,
                         select_list (
                             column_assign (COL(strjoin_alias, txt_iter),
                                            txt_iter_col),
                             column_assign (max_ (COL(strjoin_alias, txt_pos)),
                                            txt_pos_col)),
                         from_list (alias_bind (table_name (strjoin_tbl),
                                                alias (strjoin_alias))),
                         NULL,
                         NULL,
                         column_list (COL (strjoin_alias, txt_iter))
                     )
                    ));

            col_env_add (COLMAP (p),
                         p->sem.string_join.iter_res,
                         type_of (p, p->sem.string_join.iter_res),
                         COL (strjoin_alias, txt_iter)
                        );

            col_env_add (COLMAP (p),
                         p->sem.string_join.item_res,
                         type_of (p, p->sem.string_join.item_res),
                         COL (strjoin_alias, txt_item)
                        );

            from_list_add (FROMLIST(p),
                           table_name (interm_tbl), alias (interm_alias));
            from_list_add (FROMLIST(p),
                           table_name (strjoin_tbl), alias (strjoin_alias));

            where_list_add (WHERELIST(p),
                            eq (COL (strjoin_alias, txt_iter),
                                COL (interm_alias, txt_iter)));
            where_list_add (WHERELIST (p),
                            eq (COL (strjoin_alias, txt_pos),
                                COL (interm_alias, txt_pos)));
        }   break;

        /* Rel:    rownum (Rel) */
        case 50:
        {
            PFsql_t *srtbylist = NULL;
            PFsql_t *orderby  = NULL;
            PFsql_t *partlist = NULL;
            PFalg_col_t ord;
            bool asc;

            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));

            /* collect all sorting criteria */
            for (int i = PFord_count (p->sem.sort.sortby) - 1; i >= 0; i--) {
                ord = PFord_order_col_at (p->sem.sort.sortby, i);
                asc = PFord_order_dir_at (p->sem.sort.sortby, i) == DIR_ASC;
                srtbylist = sortkey_list (
                                sortkey_item (
                                    col_env_lookup (
                                        COLMAP(L(p)),
                                        ord,
                                        type_of (L(p), ord)),
                                    asc),
                                srtbylist);
            }

            /* create partition criterion if present */
            if (p->sem.sort.part)
                partlist = partition (
                               column_list (
                                   col_env_lookup (
                                       COLMAP(L(p)),
                                       p->sem.sort.part,
                                       type_of (L(p), p->sem.sort.part))));

            if (srtbylist) orderby = order_by (srtbylist);

            col_env_add (COLMAP(p),
                         p->sem.sort.res,
                         aat_nat,
                         over (row_number (),
                               window_clause (
                                   partlist,
                                   orderby)));

            /* Use the information collected in decide_numbering_bind()
               to decide whether we need to bind the numbering operator. */
            if (p->sql_ann->bind) {
                bind = true;
                execute (comment ("binding due to rownum operator"));
            }
        }   break;

        /* Rel:    rowrank (Rel) */
        case 51:
        /* Rel:    rank (Rel) */
        case 52:
        {
            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));

            /* Normal translation of rank operator (using a DENSE_RANK
               operator). */
            PFord_ordering_t sortby = p->sem.sort.sortby;
            PFsql_t *srtbylist = NULL;
            PFalg_col_t ord;
            bool asc;
            PFsql_t* expr = NULL;
            PFalg_simple_type_t expr_ty;

            /* collect all sorting criteria */
            for (int i = PFord_count (sortby) - 1; i >= 0; i--) {
                ord = PFord_order_col_at (sortby, i);
                asc = PFord_order_dir_at (sortby, i) == DIR_ASC;

                expr_ty = type_of (L(p), ord);
                /* cope with polymorphic columns here */
                for (PFalg_simple_type_t t = 1; t; t <<= 1)
                    if (t & TYPE_MASK (expr_ty)) {
                        expr = col_env_lookup (COLMAP(L(p)),
                                               ord,
                                               t);

                        srtbylist = sortkey_list (
                                        sortkey_item (
                                            /* different handling of boolean
                                               types as search criterion */
                                            (expr->kind == sql_column_name ||
                                             expr->kind == sql_lit_int     ||
                                             t != aat_bln)
                                            ? expr
                                            : case_ (when (expr, TRUE_INT),
                                                     else_ (FALSE_INT)),
                                            asc),
                                        srtbylist);
                    }
            }
            col_env_add (COLMAP(p),
                         p->sem.sort.res,
                         aat_nat,
                         over (dense_rank (),
                               window_clause (NULL, order_by (srtbylist))));

            /* Use the information collected in decide_numbering_bind()
               to decide whether we need to bind the numbering operator. */
            if (p->sql_ann->bind) {
                bind = true;
                execute (comment ("binding due to rank operator"));
            }
        }   break;

        /* Rel:    rowid (Rel) */
        case 53:
            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));

            col_env_add (COLMAP(p),
                         p->sem.rowid.res,
                         aat_nat,
                         over (row_number (),
                               window_clause (NULL, NULL)));

            /* Use the information collected in decide_numbering_bind()
               to decide whether we need to bind the numbering operator. */
            if (p->sql_ann->bind) {
                bind = true;
                execute (comment ("binding due to rowid operator"));
            }
            break;

        /* Rel:    step (Frag, Rel) */
        case 55:
        /* Rel:    guide_step (Frag, Rel) */
        case 56:
        /* Rel:    step_join (Frag, Rel) */
        case 57:
        /* Rel:    guide_step_join (Frag, Rel) */
        case 58:
        {
            PFarray_t *colmap = col_env_new ();
            PFalg_col_t item = p->sem.step.item,
                        item_res = p->sem.step.item_res;
            PFalg_simple_type_t item_ty = type_of (R(p), item),
                                item_res_ty = type_of (p, item_res);
            PFsql_aident_t ctxalias, stepalias;
            bool leaf = false;

            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, R(p));

            /* make sure to get the full table schema for the context nodes */
            ctxalias = col_env_lookup_step (COLMAP(p), item, item_ty);
            if (ctxalias == PF_SQL_ALIAS_UNBOUND) {
                ctxalias = new_alias ();
                from_list_add (FROMLIST(p), FRAG(L(p)), alias (ctxalias));
                where_list_add (WHERELIST(p),
                                eq (col_env_lookup (COLMAP(p), item, item_ty),
                                    PRE(ctxalias)));
            }

            /* add the binding for the new document relation */
            stepalias = new_alias ();
            from_list_add (FROMLIST(p),
                           FRAG(L(p)),
                           alias (stepalias));

            /* add the axis conditions */
            step_axis (p,
                       ctxalias,
                       stepalias,
                       p->sem.step.spec.axis,
                       FRAG(L(p)),
                       PFprop_level (R(p)->prop, p->sem.step.item));

            if (p->kind == la_step || p->kind == la_step_join) {
                step_name (p, stepalias, p->sem.step.spec.qname);
                step_kind (p, stepalias, p->sem.step.spec.kind, &leaf);
                step_level (p, ctxalias, stepalias,
                            p->sem.step.spec.axis, p->sem.step.level);
            } else {
                assert (p->kind == la_guide_step ||
                        p->kind == la_guide_step_join);

                /* if there is more than one guide node
                 * we represent the guides as a seperate table and
                 * perform a join. */
                if (p->sem.step.guide_count > 1) {
                    step_guide_join (p,
                                     stepalias,
                                     p->sem.step.guide_count,
                                     p->sem.step.guides);
                } else {
                    assert (p->sem.step.guide_count);

                    where_list_add (WHERELIST(p),
                                    eq (GUIDE(stepalias),
                                        lit_int (
                                            p->sem.step.guides[0]->guide)));
                }

                if (p->sem.step.guide_count)
                    leaf = p->sem.step.guides[0]->child_list == NULL;
                for (unsigned int i = 1; i < p->sem.step.guide_count; i++)
                    leaf &= p->sem.step.guides[i]->child_list == NULL;
            }

            if (p->kind == la_step || p->kind == la_guide_step) {
                PFalg_col_t iter = p->sem.step.iter;
                PFalg_simple_type_t iter_ty = type_of (p, iter);

                /* prune the selection list */
                col_env_add_full (colmap, iter, iter_ty,
                                  col_env_lookup (COLMAP(p), iter, iter_ty),
                                  col_env_lookup_step (
                                      COLMAP(p), iter, iter_ty),
                                  col_env_lookup_step_leaf (
                                      COLMAP(p), iter, iter_ty));
                COLMAP(p) = colmap;

                /* dump the relation if a distinct is required */
                if (!PFprop_set (p->prop) && !rec_branch) {
                    distinct = true;
                    bind = true;
                    execute (comment ("binding due to %sstep operator",
                                      p->kind == la_step ? "" : "guide_"));
                }
            }
            col_env_add_full (COLMAP(p), item_res, item_res_ty,
                              PRE(stepalias), stepalias, leaf);
        }   break;

        /* Rel:    doc_index_join (Frag, Rel) */
        case 59:
            /* FIXME: implementation is missing */
            PFoops (OOPS_FATAL,
                    "SQLgen: Translation for the logical "
                    "algebra pattern (%s) is still missing.",
                    PFlalg2sql_string[rule]);
            break;

        /* Rel:    doc_access (Frag, Rel) */
        case 60:
        {
            PFalg_col_t item = p->sem.doc_access.col,
                        item_res = p->sem.doc_access.res;
            PFalg_simple_type_t item_ty = type_of (p, item),
                                item_res_ty = type_of (p, item_res);
            PFalg_doc_t doc_col = p->sem.doc_access.doc_col;
            PFsql_aident_t ctxalias;

            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, R(p));

            /* make sure to get the full table schema for the context nodes */
            ctxalias = col_env_lookup_step (COLMAP(p), item, item_ty);
            if (ctxalias == PF_SQL_ALIAS_UNBOUND) {
                ctxalias = new_alias ();
                from_list_add (FROMLIST(p), FRAG(L(p)), alias (ctxalias));
                where_list_add (WHERELIST(p),
                                eq (PRE(ctxalias),
                                    col_env_lookup (COLMAP(p), item, item_ty)));
            }

            switch ( doc_col ) {
                case doc_atext:
                case doc_text:
                case doc_comm:
                case doc_pi_text:
                    col_env_add (COLMAP(p), item_res, item_res_ty, VALUE(ctxalias));
                    break;
                case doc_qname:
                    col_env_add (COLMAP(p), item_res, aat_qname_loc, NAME(ctxalias));
                    col_env_add (COLMAP(p), item_res, aat_qname_uri, NS_URI(ctxalias));
                    break;
                default: PFoops (OOPS_FATAL,
                                    "SQLgen: Unknown access identifier in "
                                    "document access");
            }


        }   break;

        /* Rel:    roots_ (Constr) */
        case 61:
            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));
            break;

        /* Frag:   fragment (Constr) */
        case 62:
            FRAG(p) = FRAG(L(p));
            break;

        /* Frag:   frag_extract (Rel) */
        case 63:
            /* FIXME: implementation is missing */
            PFoops (OOPS_FATAL,
                    "SQLgen: Translation for the logical "
                    "algebra pattern (%s) is still missing.",
                    PFlalg2sql_string[rule]);
            break;

        /* Frag:   frag_union (Frag, Frag) */
        case 64:
            /* Try to keep simple references (and thus merge
               equal document references into a single one). */
            if (FRAG(L(p))->kind == sql_tbl_name &&
                FRAG(R(p))->kind == sql_tbl_name &&
                FRAG(L(p))->sem.tbl.name == FRAG(R(p))->sem.tbl.name)
                FRAG(p) = FRAG(L(p));
            else
                /* Otherwise build a SFW that represents
                   the union of all referenced documents */
                FRAG(p) = collect_fragments (p);
            break;

        /* Frag:   frag_union (empty_frag, Frag) */
        case 65:
            FRAG(p) = FRAG(R(p));
            break;

        /* Frag:   empty_frag */
        case 66:
            FRAG(p) = table_name (PF_SQL_TABLE_FRAG);
            break;

        /* Constr: doc_tbl (Rel) */
        case 70:
        {
            PFalg_col_t         col    = p->sem.doc_tbl.col,
                                res    = p->sem.doc_tbl.res;
            PFalg_simple_type_t res_ty = type_of (p, res);
            PFsql_t            *item_expr;
            PFsql_aident_t      doc_tbl;

            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, L(p));

            item_expr = col_env_lookup (COLMAP(p), col, aat_str);

            /* throw away singleton relation */
            /* todo: trigger the rewrite on cardinality instead of "sysibm" */
            if (PFarray_last (FROMLIST(p)) == 1) {
                PFsql_t *tbl = from_list_at (FROMLIST(p), 0).table;
                if (tbl->kind == sql_schema_tbl_name &&
                    L(tbl)->kind == sql_tbl_name &&
                    !strcmp (tbl->sem.schema.str, "sysibm") &&
                    L(tbl)->sem.tbl.name == PF_SQL_TABLE_SYSDUMMY1)
                    PFarray_del (FROMLIST(p));
            }

            /* introduce a new alias... */
            doc_tbl = new_alias ();
            /* ... and use it to refer to a fresh document relation */
            from_list_add (FROMLIST(p),
                           table_name (PF_SQL_TABLE_FRAG),
                           alias (doc_tbl));

            /* add the output columns to the column map */
            col_env_add_full (COLMAP(p), res, res_ty,
                              PRE(doc_tbl), doc_tbl, false);

            /* add the two checks to lookup the correct document */
            where_list_add (WHERELIST(p), eq (KIND(doc_tbl), lit_int (DOC)));
            where_list_add (WHERELIST(p), eq (VALUE(doc_tbl), item_expr));

            /* set the fragment relation */
            FRAG(p) = table_name (PF_SQL_TABLE_FRAG);
        }   break;

        /* Constr: twig (Twig) */
        case 71:
        {
            PFsql_aident_t      content      = new_alias ();
            PFsql_aident_t      new_root     = new_alias ();
            PFsql_t            *sortkey_list = NULL;

            /* We only need to sort by <pos, pre> if we have a variable
               part (content operator) in the twig constructor. */
            if (CSIZE(L(p)))
                sortkey_list = sortkey_list (
                                        sortkey_item (POS(content), true),
                                        sortkey_item (PRE(content), true),
                                        sortkey_list);

            /* Always sort first by <iter, twig_pre>. */
            sortkey_list = sortkey_list (
                                    sortkey_item (ITER(content), true),
                                    sortkey_item (TWIG_PRE(content), true),
                                    sortkey_list);

            /* call a helper function that does the 'real' job */
            construct_twig (p, content, new_root, sortkey_list);

            if (SER_REPORT(p) != ser_yes)
                where_list_add (WHERELIST(p),
                                eq (LEVEL(new_root), lit_int (0)));
        }   break;

        /* Constr: twig (docnode (Rel, fcns (nil, nil))) */
        case 72:
            construct_simple_twig (p, L(p)->sem.docnode.iter, DOC,
                                   lit_str (""), lit_str (""),
                                   lit_str (""));
            break;

        /* Constr: twig (element (Rel, fcns (nil, nil))) */
        case 73:
        {
            PFalg_col_t item = L(p)->sem.iter_item.item;
            assert (type_of (LL(p), item) == aat_qname);

            construct_simple_twig (
                p, L(p)->sem.iter_item.iter, ELEM,
                lit_str (""),
                col_env_lookup (COLMAP(LL(p)), item, aat_qname_loc),
                col_env_lookup (COLMAP(LL(p)), item, aat_qname_uri));
        }   break;

        /* Constr: twig (attribute (Rel)) */
        case 74:
        {
            PFalg_col_t item1 = L(p)->sem.iter_item1_item2.item1;
            PFalg_col_t item2 = L(p)->sem.iter_item1_item2.item2;

            construct_simple_twig (
                p, L(p)->sem.iter_item1_item2.iter,
                ATTR,
                col_env_lookup (COLMAP(LL(p)), item2, type_of (LL(p), item2)),
                col_env_lookup (COLMAP(LL(p)), item1, aat_qname_loc),
                col_env_lookup (COLMAP(LL(p)), item1, aat_qname_uri));
        }   break;
        /* Constr: twig (processi (Rel)) */
        case 77:
        {
            PFalg_col_t item1 = L(p)->sem.iter_item1_item2.item1;
            PFalg_col_t item2 = L(p)->sem.iter_item1_item2.item2;

            construct_simple_twig (
                p, L(p)->sem.iter_item1_item2.iter,
                PI,
                col_env_lookup (COLMAP(LL(p)), item2, type_of (LL(p), item2)),
                col_env_lookup (COLMAP(LL(p)), item1, type_of (LL(p), item1)),
                lit_str (""));
        }   break;

        /* Constr: twig (textnode (Rel)) */
        case 75:
        /* Constr: twig (comment (Rel)) */
        case 76:
        {
            PFalg_col_t item = L(p)->sem.iter_item.item;

            construct_simple_twig (
                p, L(p)->sem.iter_item.iter,
                L(p)->kind == la_textnode ? PF_TEXT : COMM,
                col_env_lookup (COLMAP(LL(p)), item, type_of (LL(p), item)),
                lit_str (""), lit_str (""));
        }   break;

        /* List:   fcns (Twig, List) */
        case 78:
            FRAG(p) = union_ (FRAG(L(p)), FRAG(R(p)));

            if (CSIZE(L(p)) && CSIZE(R(p))) {
                /* For the content sizes we try to maintain
                   simple table names as long as possible. Here
                   this is not possible anymore and we have to
                   turn the reference into a union on subselects. */
                PFsql_t *l_csize = CSIZE(L(p)),
                        *r_csize = CSIZE(R(p));

                if (l_csize->kind != sql_union) {
                    assert (l_csize->kind == sql_tbl_name);
                    l_csize = select (select_list (ITER_, SIZE_),
                                      l_csize, NULL);
                }
                if (r_csize->kind != sql_union) {
                    assert (r_csize->kind == sql_tbl_name);
                    r_csize = select (select_list (ITER_, SIZE_),
                                      r_csize, NULL);
                }

                CSIZE(p) = union_ (l_csize, r_csize);
            }
            else if (CSIZE(L(p)))
                CSIZE(p) = CSIZE(L(p));
            else if (CSIZE(R(p)))
                CSIZE(p) = CSIZE(R(p));
            break;

        /* List:   fcns (Twig, nil) */
        case 79:
            FRAG(p) = FRAG(L(p));
            CSIZE(p) = CSIZE(L(p));
            break;

        /* Twig:   docnode (Rel, List) */
        case 80:
            if (CSIZE(R(p))) {
                PFalg_col_t     iter = p->sem.docnode.iter;
                sql_from_list_t name_from;
                PFsql_aident_t  csize_alias;
                PFsql_t        *iter_col;

                CSIZE(p) = CSIZE(R(p));
                csize_alias = new_alias ();

                if (PFarray_last (FROMLIST(L(p))) != 1 ||
                    col_env_lookup (
                        COLMAP(L(p)),
                        iter,
                        type_of (L(p), iter))->kind != sql_column_name) {
#ifndef NDEBUG
                    if (!BOUND(L(p)))
                        execute (comment ("bind loop relation as a single "
                                          "relation is needed in the "
                                          "following outerjoin"));
#endif
                    bind_operator (L(p), false);
                }

                name_from   = from_list_at (FROMLIST(L(p)), 0);
                iter_col    = col_env_lookup (
                                  COLMAP(L(p)),
                                  iter,
                                  type_of (L(p), iter));

                FRAG (p) = PFsql_select (
                               false,
                               select_list (
                                   column_assign (iter_col, ITER_),
                                   column_assign (lit_int (TPRE(p)), TWIG_PRE_),
                                   column_assign (lit_int (-1), POS_),
                                   column_assign (lit_int (-1), PRE_),
                                   column_assign (
                                       add (lit_int (TSIZE(p)),
                                            coalesce (
                                                sum (SIZE(csize_alias)),
                                                lit_int (0))),
                                       SIZE_),
                                   column_assign (lit_int (TLEVEL(p)), LEVEL_),
                                   column_assign (lit_int (DOC), KIND_),
                                   column_assign (lit_str (""), VALUE_),
                                   column_assign (lit_str (""), NAME_),
                                   column_assign (lit_str (""), NS_URI_)),
                               from_list (
                                   on (left_outer_join (
                                           alias_bind (
                                               name_from.table,
                                               name_from.alias),
                                           alias_bind (
                                               CSIZE(R(p)),
                                               alias (csize_alias))),
                                       eq (ITER(csize_alias),
                                           iter_col))),
                               NULL,
                               NULL,
                               column_list (iter_col));

                FRAG(p) = union_ (FRAG(p), FRAG(R(p)));
            } else {
                construct_node (p, p->sem.docnode.iter, DOC,
                                lit_str (""), lit_str (""),
                                lit_str (""));

                FRAG(p) = union_ (FRAG(p), FRAG(R(p)));
            }
            break;

        /* Twig:   docnode (Rel, fcns (nil, nil)) */
        case 81:
            construct_node (p, p->sem.docnode.iter, DOC,
                            lit_str (""), lit_str (""),
                            lit_str (""));
            break;

        /* Twig:   element (Rel, List) */
        case 82:
            if (CSIZE(R(p))) {
                PFalg_col_t     iter = p->sem.iter_item.iter,
                                item = p->sem.iter_item.item;
                sql_from_list_t name_from;
                PFsql_aident_t  csize_alias;
                PFsql_t        *iter_col, *item_col_loc, *item_col_uri,
                               *grpbylist;
                bool            item_const = PFprop_const (L(p)->prop, item);

                CSIZE(p) = CSIZE(R(p));
                csize_alias = new_alias ();

                /* bind the element names if we cannot avoid it */
                if (!item_const ||
                    PFarray_last (FROMLIST(L(p))) != 1 ||
                    col_env_lookup (
                        COLMAP(L(p)),
                        iter,
                        type_of (L(p), iter))->kind != sql_column_name) {
#ifndef NDEBUG
                    if (!BOUND(L(p)))
                        execute (comment ("bind element name as a single "
                                          "relation is needed in the "
                                          "following outerjoin"));
#endif
                    bind_operator (L(p), false);
                }

                name_from   = from_list_at (FROMLIST(L(p)), 0);
                iter_col    = col_env_lookup (
                                  COLMAP(L(p)),
                                  iter,
                                  type_of (L(p), iter));

                /* If we have a constant QName we directly use it. */
                if (item_const) {
                    item_col_loc = literal (
                                       namespace_atom (
                                           PFprop_const_val (L(p)->prop, item),
                                           aat_qname_loc));
                    item_col_uri = literal (
                                       namespace_atom (
                                           PFprop_const_val (L(p)->prop, item),
                                           aat_qname_uri));
                    grpbylist = column_list (iter_col);
                }
                /* Otherwise we need to put the item column
                   also into the list of groupby criteria. */
                else {
                    assert (type_of (L(p), item) == aat_qname);
                    item_col_loc = EXT_COLUMN_NAME (
                                       name_from.alias->sem.alias.name,
                                       item,
                                       aat_qname_loc);
                    item_col_uri = EXT_COLUMN_NAME (
                                       name_from.alias->sem.alias.name,
                                       item,
                                       aat_qname_uri);
                    grpbylist = column_list (iter_col, item_col_loc,
                                             item_col_uri);
                }

                FRAG (p) = PFsql_select (
                               false,
                               select_list (
                                   column_assign (iter_col, ITER_),
                                   column_assign (lit_int (TPRE(p)), TWIG_PRE_),
                                   column_assign (lit_int (-1), POS_),
                                   column_assign (lit_int (-1), PRE_),
                                   column_assign (
                                       add (lit_int (TSIZE(p)),
                                            coalesce (
                                                sum (SIZE(csize_alias)),
                                                lit_int (0))),
                                       SIZE_),
                                   column_assign (lit_int (TLEVEL(p)), LEVEL_),
                                   column_assign (lit_int (ELEM), KIND_),
                                   column_assign (lit_str (""), VALUE_),
                                   column_assign (item_col_loc, NAME_),
                                   column_assign (item_col_uri, NS_URI_)),
                               from_list (
                                   on (left_outer_join (
                                           alias_bind (
                                               name_from.table,
                                               name_from.alias),
                                           alias_bind (
                                               CSIZE(R(p)),
                                               alias (csize_alias))),
                                       eq (ITER(csize_alias),
                                           iter_col))),
                               NULL,
                               NULL,
                               grpbylist);

                FRAG(p) = union_ (FRAG(p), FRAG(R(p)));
            } else {
                /* simple translation (as we already have all size values) */
                PFalg_col_t item = p->sem.iter_item.item;

                construct_node (
                    p, p->sem.iter_item.iter, ELEM,
                    lit_str (""),
                    col_env_lookup (COLMAP(L(p)), item, aat_qname_loc),
                    col_env_lookup (COLMAP(L(p)), item, aat_qname_uri));

                FRAG(p) = union_ (FRAG(p), FRAG(R(p)));
            }
            break;

        /* Twig:   element (Rel, fcns (nil, nil)) */
        case 83:
        {
            PFalg_col_t item = p->sem.iter_item.item;

            construct_node (
                p, p->sem.iter_item.iter, ELEM,
                lit_str (""),
                col_env_lookup (COLMAP(L(p)), item, aat_qname_loc),
                col_env_lookup (COLMAP(L(p)), item, aat_qname_uri));
        }   break;

        /* Twig:   attribute (Rel) */
        case 84:
        {
            PFalg_col_t item1 = p->sem.iter_item1_item2.item1;
            PFalg_col_t item2 = p->sem.iter_item1_item2.item2;

            construct_node (
                p, p->sem.iter_item1_item2.iter,
                ATTR,
                col_env_lookup (COLMAP(L(p)), item2, type_of (L(p), item2)),
                col_env_lookup (COLMAP(L(p)), item1, aat_qname_loc),
                col_env_lookup (COLMAP(L(p)), item1, aat_qname_uri));
        }   break;
        /* Twig:   processi (Rel) */
        case 87:
        {
            PFalg_col_t item1 = p->sem.iter_item1_item2.item1;
            PFalg_col_t item2 = p->sem.iter_item1_item2.item2;

            construct_node (
                p, p->sem.iter_item1_item2.iter,
                PI,
                col_env_lookup (COLMAP(L(p)), item2, type_of (L(p), item2)),
                col_env_lookup (COLMAP(L(p)), item1, type_of (L(p), item1)),
                lit_str (""));
        }   break;

        /* Twig:   textnode (Rel) */
        case 85:
        /* Twig:   comment (Rel) */
        case 86:
        {
            PFalg_col_t item = p->sem.iter_item.item;

            construct_node (
                p, p->sem.iter_item.iter,
                p->kind == la_textnode ? PF_TEXT : COMM,
                col_env_lookup (COLMAP(L(p)), item, type_of (L(p), item)),
                lit_str (""), lit_str (""));
        }   break;

        /* Twig:   content (Frag, Rel) */
        case 88:
        {
            PFalg_col_t         iter          = p->sem.iter_pos_item.iter,
                                pos           = p->sem.iter_pos_item.pos,
                                item          = p->sem.iter_pos_item.item;
            PFalg_simple_type_t iter_ty       = type_of (R(p), iter),
                                pos_ty        = type_of (R(p), pos),
                                item_ty       = type_of (R(p), item);

            PFsql_aident_t ctx, step;
            PFsql_tident_t iter_size_tbl, content_tbl;
            PFsql_t *iter_expr, *pos_expr, *item_expr,
                    *iter_size = NULL, *content = NULL,
                    *frag, *sel, *selectlist;

            PFarray_t *frags = PFarray (sizeof (PFsql_t *), 5);
            /* collect the duplicate free list of fragment references */
            collect_frag_worker (L(p), frags);
            assert (PFarray_last (frags));

#ifndef NDEBUG
            if (!BOUND(R(p)))
                execute (comment ("bind input as it will be referenced "
                                  "at least twice."));
#endif
            bind_operator (R(p), false);

            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, R(p));

            iter_expr = col_env_lookup (COLMAP(p), iter, iter_ty);
            pos_expr  = col_env_lookup (COLMAP(p), pos, pos_ty);
            item_expr = col_env_lookup (COLMAP(p), item, item_ty);

            /* add the document relation */
            ctx = new_alias ();
            from_list_add (FROMLIST(p), NULL, alias (ctx));
            where_list_add (WHERELIST(p), eq (item_expr, PRE(ctx)));

            for (unsigned int i = 0; i < PFarray_last (frags); i++) {
                frag = *(PFsql_t **) PFarray_at (frags, i);

                sel = select (select_list (
                                  column_assign (iter_expr, ITER_),
                                  column_assign (
                                      add (SIZE(ctx), lit_int (1)),
                                      SIZE_)),
                              transform_frommap_ext (p, frag),
                              transform_wheremap (p));
                iter_size = (i == 0) ? sel : union_ (iter_size, sel);
            }

            iter_size_tbl = new_table_name (),
            execute (comment ("====================="));
            execute (comment ("= CONSTRUCTOR SIZES ="));
            execute (comment ("====================="));
            execute (bind (table_def (iter_size_tbl,
                                      column_list (ITER_, SIZE_)),
                           iter_size));

            CSIZE(p) = table_name (iter_size_tbl);

            /* ................................................... */

            /* add the binding for the new document relation */
            step = new_alias ();
            from_list_add (FROMLIST(p), NULL, alias (step));
            /* add the axis conditions */
            step_axis (p, ctx, step, alg_desc_s, NULL, -1);

            selectlist = select_list (
                             column_assign (iter_expr, ITER_),
                             column_assign (lit_int (TPRE(p)), TWIG_PRE_),
                             column_assign (pos_expr, POS_),
                             column_assign (PRE(step), PRE_),
                             column_assign (SIZE(step), SIZE_),
                             column_assign (
                                 add (sub (LEVEL(step), LEVEL(ctx)),
                                      lit_int (TLEVEL(p))),
                                 LEVEL_),
                             column_assign (KIND(step), KIND_),
                             column_assign (VALUE(step), VALUE_),
                             column_assign (NAME(step), NAME_),
                             column_assign (NS_URI(step), NS_URI_));

            for (unsigned int i = 0; i < PFarray_last (frags); i++) {
                frag = *(PFsql_t **) PFarray_at (frags, i);

                sel = select (selectlist,
                              transform_frommap_ext (p, frag),
                              transform_wheremap (p));
                content = (i == 0) ? sel : union_ (content, sel);
            }

            content_tbl = new_table_name ();
            execute (comment ("======================="));
            execute (comment ("= CONSTRUCTOR CONTENT ="));
            execute (comment ("======================="));
            execute (bind (table_def (
                               content_tbl,
                               column_list (
                                   ITER_, TWIG_PRE_, POS_, PRE_,
                                   SIZE_, LEVEL_, KIND_, VALUE_, NAME_,
                                   NS_URI_)),
                           content));

            FRAG(p) = select (select_list (
                                  ITER_, TWIG_PRE_, POS_, PRE_,
                                  SIZE_, LEVEL_, KIND_, VALUE_, NAME_,
                                  NS_URI_),
                              table_name (content_tbl),
                              NULL);
        }   break;

        /* Constr: merge_adjacent (Frag, Rel) */
        case 89:
            /* FIXME: this rule is implemented as identity operator */

            /* copy all existing column, from, and where lists */
            copy_cols_from_where (p, R(p));

            /* align the column names */
            for (unsigned int i = 0; i < PFarray_last (COLMAP(p)); i++) {
                PFalg_col_t col;
                col = (*(sql_column_env_t *) PFarray_at (COLMAP(p), i)).col;
                if (col == p->sem.merge_adjacent.iter_in) {
                    (*(sql_column_env_t *) PFarray_at (COLMAP(p), i)).col
                        = p->sem.merge_adjacent.iter_res;
                    continue;
                }
                if (col == p->sem.merge_adjacent.pos_in) {
                    (*(sql_column_env_t *) PFarray_at (COLMAP(p), i)).col
                        = p->sem.merge_adjacent.pos_res;
                    continue;
                }
                if (col == p->sem.merge_adjacent.item_in) {
                    (*(sql_column_env_t *) PFarray_at (COLMAP(p), i)).col
                        = p->sem.merge_adjacent.item_res;
                    continue;
                }
            }

            FRAG(p) = FRAG(L(p));
            break;

        /* Side:   error (Side, Rel) */

        /********************************************************/
        /*            cond_err                                  */
        /*             /    \                                   */
        /*            /      \                                  */
        /*           /\      /\                                 */
        /*          /q1\    /q2\                                */
        /*         ------  ------                               */
        /* We will translate this plan into the following       */
        /* SQL query.                                           */
        /*                                                      */
        /* SELECT q.*                                           */
        /*   FROM q1 AS q, (SELECT CASE                         */
        /*                             WHEN MIN(CASE            */
        /*                                      WHEN col THEN 1 */
        /*                                      ELSE 0          */
        /*                                      END) < 1        */
        /*                                  THEN raise_error    */
        /*                             ELSE 1 END               */
        /*                  FROM q2 AS err) AS foo;             */
        /********************************************************/
        case 97: {
#define ERR_SQLSTATE "70001"
            assert (kids[0] && nts[0]);
            assert (kids[1] && nts[1]);

            PFsql_t *err = NULL;
            char    *msg;

            reduce (kids[0], nts[0]);

            /* copy all existing side effect information */
            from_list_copy (FROMLIST(p), FROMLIST(L(p)));

            if (PFprop_const (p->prop, p->sem.err.col)) {
                msg = (PFprop_const_val (p->prop, p->sem.err.col)).val.str;
                if (PFstrUtils_beginsWith(msg, "err:FODC0002"))
                    /* discard document availability check */
                    break;
            }
            else
                msg = "error in query evaluation";

            reduce (kids[1], nts[1]);

            err = case_ (when (gt (count (star ()), lit_int (0)),
                               raise_error (lit_str (ERR_SQLSTATE),
                                            lit_str (msg))),
                         else_ (lit_int(42)));

            PFsql_aident_t nalias = new_alias ();

            from_list_add (FROMLIST (p),
                           select (
                               column_assign (err, ERR_),
                               transform_frommap (R(p)),
                               transform_wheremap (R(p))
                           ), alias (nalias));
        }   break;

        /* Side:   nil */
        case 98:
            break;

        /* Side:   cache (Side, Rel) */
        case 99:
        /* Side:   trace (Side, Trc) */
        case 100:
        /* Trc:    trace_items (Rel, Msg) */
        case 101:
        /* Msg:    trace_msg (Rel, Map) */
        case 102:
        /* Map:    trace_map (Rel, Map) */
        case 103:
        /* Map:    nil */
        case 104:
            /* FIXME: implementation is missing */
            PFoops (OOPS_FATAL,
                    "SQLgen: Translation for the logical "
                    "algebra pattern (%s) is still missing.",
                    PFlalg2sql_string[rule]);
            break;
        /* Rel:    rec_base */
        case 105:
            /* do nothing, the magic happens in rec_arg */
            break;
        /* Rec:    nil */
        case 106:
            /* FIXME: implementation is missing */
            PFoops (OOPS_FATAL,
                    "SQLgen: Translation for the logical "
                    "algebra pattern (%s) is still missing.",
                    PFlalg2sql_string[rule]);
            break;
        /* Arg:    rec_arg (Rel, Rel) */
        case 107:
        /* Arg:    rec_arg (Rel, distinct (Rel)) */
        case 108: {
            /** TOPDOWN **/
            PFla_op_t *base = p->sem.rec_arg.base;
            PFla_op_t *seed = L(p);
            PFla_op_t *recursion = (rule == 107)
                                   ? R(p)
                                   : RL(p);
            /* if we are in rule 107, the operator under
             * distinct must have the set property */
            assert (!(rule == 108) || (PFprop_set (RL(p)->prop)));

            PFsql_t *columnlist = NULL;
            PFsql_t *rec_selectlist = NULL;

            PFsql_col_t *colname = NULL;

            /* generate SQL code for the seed branch */
            reduce (kids[0], nts[0]);

            /* for the recursion we have to create a new binding */
            PFsql_tident_t basetable = new_table_name ();
            /* new correlation name for bounded table */
            PFsql_aident_t basealias = new_alias ();

            /* clear colmap */
            PFarray_last (COLMAP(base)) = 0;

            for (unsigned int i = 0; i < base->schema.count; i++) {
                for (PFalg_simple_type_t t = 1; t; t <<= 1)
                    if (t & TYPE_MASK (p->schema.items[i].type)) {
                        colname = new_col (base->schema.items[i].name,
                                           t);

                        /* prepare the column list */
                        columnlist = column_list (
                                         columnlist,
                                         column_name (colname));

                        col_env_add (COLMAP(base),
                                     base->schema.items[i].name,
                                     t,
                                     ext_column_name (basealias, colname));
                        col_env_add (COLMAP(p),
                                     base->schema.items[i].name,
                                     t,
                                     ext_column_name (basealias, colname));

                    }
            }

            /* clear from and where list */
            PFarray_last (FROMLIST(base)) = 0;
            PFarray_last (WHERELIST(base)) = 0;
            PFarray_last (FROMLIST(p)) = 0;
            PFarray_last (WHERELIST(p)) = 0;

            /* add the new binding to the fromlist */
            from_list_add (FROMLIST (base),
                           table_name (basetable),
                           alias (basealias));

            /* add the new binding to the fromlist */
            from_list_add (FROMLIST (p),
                           table_name (basetable),
                           alias (basealias));


            /* generate SQL code for the recursion branch */
            rec_branch = true;
            reduce (kids[1], nts[1]);
            rec_branch = false;

            for (unsigned int i = 0; i < base->schema.count; i++) {
                for (PFalg_simple_type_t t = 1; t; t <<= 1)
                    if (t & TYPE_MASK (p->schema.items[i].type)) {
                        rec_selectlist = select_list (
                                             rec_selectlist,
                                             col_env_lookup (COLMAP(recursion),
                                                             p->schema.items[i].name,
                                                             t));
                    }
            }

            execute (comment ("============="));
            execute (comment ("= RECURSION ="));
            execute (comment ("============="));
            execute (bind (table_def (
                            basetable,
                            columnlist),
                     union_ (
                     PFsql_select (
                        false,
                        transform_selectlist (COLMAP(seed)),
                        transform_frommap (seed),
                        transform_wheremap (seed),
                        NULL,
                        NULL),
                     PFsql_select (
                        false,
                        rec_selectlist,
                        transform_frommap (recursion),
                        transform_wheremap (recursion),
                        NULL,
                        NULL))));

            copy_cols_from_where (recursion, p);
        }   break;

        /* Rel:    rec_fix (
                       side_effects (
                           nil,
                           rec_param (
                              rec_arg (Rel, Rel),
                              rec_param(Arg, nil))),
                       Rel) */
        case 109:
        {
            /*** TOPDOWN ***/
            PFla_op_t *loop_param = LRL(p),
                      *base  = LRL(p)->sem.rec_arg.base;

            PFla_op_t *overall_result = R(p);
            PFla_op_t *recarg = RL(LR(p));

            /* if we are sure, that the loop returns
             * results in any case, and the base is
             * used only once, we can continue the
             * translation, since we are sure the
             * loop is not needed anywhere */
            if (!(PFprop_card(loop_param->prop)) ||
                !(REFCTR(base) == 1))
                PFoops (OOPS_FATAL, "SQL cannot cope with this "
                                    "query");

            reduce (kids[2], nts[2]);

            /* manually decrement the reference counter,
             * of the overall_result since we don't need
             * this edge */
            REFCTR(overall_result)--;

            copy_cols_from_where (p, recarg);
            bind = true; distinct = true;
            execute (comment ("Binding due to recursion"));
        } break;

        /* Rel:    rec_fix (
                       side_effects (nil,
                                     rec_param (Arg, nil)),
                       Rel) */
        case 110:
        {
            /*** TOPDOWN ***/
            PFla_op_t *overall_result = R(p);
            PFla_op_t *recarg = LRL(p);

            reduce (kids[0], nts[0]);

            /* manually decrement the reference counter,
             * of the overall_result since we don't need
             * this edge */
            REFCTR(overall_result)--;

            copy_cols_from_where (p, recarg);
            bind = true; distinct = true;
            execute (comment ("Binding due to recursion"));
        }   break;
        /* Rel:    dummy (Rel) */
        case 115:
        /* Rel:    proxy (Rel) */
        case 116:
        /* Rel:    proxy_base (Rel) */
        case 117:
        /* Rel:    fun_call (Rel, Param) */
        case 118:
        /* Param:  fun_param (Rel, Param) */
        case 119:
        /* Param:  fun_frag_param (Frag, Param) */
        case 120:
        /* Param:  nil */
        case 121:

        default:
            PFoops (OOPS_FATAL,
                    "SQLgen: Logical algebra operator "
                    "(%s) is not allowed here.",
                    PFlalg2sql_string[rule]);
            break;
    }

    /* BINDING: execute the statement at the end
       if the node is dirty, and bind it to a new SQL variable.
       The strategy behind this late binding is to merge
       as many operators as possible into one SQL statement.  */
    if (bind)
        bind_operator (p, distinct);
    else if (bind_multi_ref && REFCTR(p) > 1 && !FRAG_OP(p)) {
        execute (comment ("binding due to multiple references"));
        bind_operator (p, distinct);
    }
    SEEN(p) = true;
}

/* Attach node labels in a DAG walk bottom-up */
static void
label (PFla_op_t *p)
{
    /* label the nodes */
    if (!L(p) && !R(p)) {
        STATE_LABEL(p) = PFlalg2sql_state (OP_LABEL(p), 0, 0);
    }
    else if (L(p) && !R(p)) {
        if (!SEEN(L(p))) label (L(p));
        STATE_LABEL(p) = PFlalg2sql_state (OP_LABEL(p),
                                         STATE_LABEL(L(p)),
                                         0);
        /* update also control reference */
        CHILD_STATE_LABEL(p, 0) = STATE_LABEL(L(p));
    }
    else if (!L(p) && R(p)) {
        if (!SEEN(R(p))) label (R(p));
        STATE_LABEL(p) = PFlalg2sql_state (OP_LABEL(p),
                                         STATE_LABEL(R(p)),
                                         0);
        /* update also control reference */
        CHILD_STATE_LABEL(p, 1) = STATE_LABEL(R(p));
    }
    else {
        if (!SEEN(L(p))) label (L(p));
        if (!SEEN(R(p))) label (R(p));
        STATE_LABEL(p) = PFlalg2sql_state (OP_LABEL(p),
                                         STATE_LABEL(L(p)),
                                         STATE_LABEL(R(p)));
        /* update also control reference */
        CHILD_STATE_LABEL(p, 0) = STATE_LABEL(L(p));
        CHILD_STATE_LABEL(p, 1) = STATE_LABEL(R(p));
    }
    SEEN(p) = true;

    /* and add annotations to them */
    p->sql_ann = sql_alg_ann_new ();

    assert (STATE_LABEL(p));
}

/**
 * Check if a column name is used by an operator.
 */
static bool
col_used (PFla_op_t * p, PFalg_col_t col)
{
    switch (p->kind) {
        case la_attach:
        case la_project:
        case la_rowid:
            return false;

        case la_fun_1to1:
            for (unsigned int i = 0; i < clsize (p->sem.fun_1to1.refs); i++)
                if (clat (p->sem.fun_1to1.refs, i) == col)
                    return true;

            return false;

        case la_num_eq:
        case la_num_gt:
        case la_bool_and:
        case la_bool_or:
            return col == p->sem.binary.col1 || col == p->sem.binary.col2;

        case la_bool_not:
            return col == p->sem.unary.col;

        case la_rownum:
        case la_rowrank:
        case la_rank:
            if (p->sem.sort.part &&
                p->sem.sort.part == col)
                return true;

            for (unsigned int i = 0; i < PFord_count (p->sem.sort.sortby); i++)
                if (PFord_order_col_at (p->sem.sort.sortby, i) == col)
                    return true;

            return false;

        case la_type:
        case la_cast:
            return col == p->sem.type.col;

        default:
            break;
    }
    return true;
}

/* mapping structure that records the numbering operator
   together with its (possibly update) column name */
struct num_map_t
{
    PFalg_col_t         col;
    PFla_op_t          *op;
};
typedef struct num_map_t num_map_t;

/**
 * Worker for decide_numbering_bind adding numbering operators
 * to the operator list @a num_map. Furthermore all numbering
 * operators that are used in an operator are removed from the
 * list again.
 */
static void
collect_numberings (PFla_op_t *p, PFarray_t *num_map)
{
    /* avoid inconsistencies */
    if (REFCTR (p) > 1)
        return;

    /* only analyze operators that don't change the cardinality */
    switch (p->kind) {
        case la_project:
        case la_attach:
        case la_fun_1to1:
        case la_num_eq:
        case la_num_gt:
        case la_bool_and:
        case la_bool_or:
        case la_bool_not:
        case la_rownum:
        case la_rowrank:
        case la_rank:
        case la_rowid:
        case la_type:
        case la_cast:
            break;

        default:
            return;
    }

    /* collect the numbering operators in the subplan */
    collect_numberings (L(p), num_map);

    switch (p->kind) {
        case la_project:
            /* update the column names of the numbering operators */
            for (unsigned int i = 0; i < PFarray_last (num_map); i++)
                for (unsigned int j = 0; j < p->sem.proj.count; j++)
                    if ((*(num_map_t *) PFarray_at (num_map, i)).col
                            == p->sem.proj.items[j].old) {
                        (*(num_map_t *) PFarray_at (num_map, i)).col
                            = p->sem.proj.items[j].new;
                        break;
                    }
            break;

        case la_rowid:
            /* Add the numbering operator. */
            *(num_map_t *) PFarray_add (num_map)
                = (num_map_t) { .col = p->sem.rowid.res, .op = p };
            break;

        case la_rownum:
        case la_rowrank:
        case la_rank:
            /* Add the numbering operators.
               Avoid partitioned variants as we don't know how to
               fix the order by list for partitioned operators. */
            if (!p->sem.sort.part)
                *(num_map_t *) PFarray_add (num_map)
                    = (num_map_t) { .col = p->sem.sort.res, .op = p };
            /* fall through */

        default:
        {
            /* remove numbering operators whose output is used anywhere */
            PFalg_col_t  col;
            unsigned int i = 0;
            while (i < PFarray_last (num_map)) {
                col = (*(num_map_t *) PFarray_at (num_map, i)).col;
                if (col_used (p, col)) {
                    *(num_map_t *) PFarray_at (num_map, i)
                        = *(num_map_t *) PFarray_top (num_map);
                    PFarray_del (num_map);
                }
                else
                    i++;
            }
        }   break;
    }
}

/**
 * Change the default behavior to always bind numbering
 * operators.
 *
 * This is done by analysing whether numbering operators are
 * used before the serialization or not. In case they
 * are unused we can avoid the binding and cope with it
 * in the serialization operators.
 */
static void
decide_numbering_bind (PFla_op_t *p)
{
    PFarray_t       *num_map;

    assert (p->kind == la_serialize_seq ||
            p->kind == la_serialize_rel);

    num_map = PFarray (sizeof (num_map_t), 3);

    /* Collect all numbering operators that are
       only used by the serialize operators. */
    collect_numberings (R(p), num_map);

    /* All numbering operators that are in the list are not used
       before the serialization operator and thus don't need to be
       bound immediately. */
    for (unsigned int i = 0; i < PFarray_last (num_map); i++)
        (*(num_map_t *) PFarray_at (num_map, i)).op->sql_ann->bind = false;
}

/**
 * Collect a list of the logical operators of all
 * referenced fragments.
 *
 * Returns true if there are
 */
static bool
collect_twigs (PFla_op_t * p, PFarray_t *frags)
{
    assert (p);
    assert (frags);

    switch (p->kind) {

        case la_frag_union:
            return ((collect_twigs (L(p), frags)) &&
                    (collect_twigs (R(p), frags)));

        case la_fragment:
        {
            PFla_op_t * fragment = NULL;
            unsigned int i;
            assert (L(p));

            /* if kind is not a twig operator return false */
            if (L(p)->kind != la_twig) {
                return false;
            }

            /* add fragment if we haven't collected it so far */
            for (i = 0; i < PFarray_last (frags); i++) {
                fragment = *(PFla_op_t **) PFarray_at (frags, i);
                if (fragment == L(p))
                    break;
            }

            /* add fragment to the list */
            if (i == PFarray_last (frags))
                *(PFla_op_t **) PFarray_add (frags) = L(p);

        }   return true;

        case la_empty_frag:
            return true;

        default:
            /* we should never reach this point */
            assert (0);
            return false;
    }

}

#define IS_LEAF(p) (!L(p) && !R(p))
#define MIN(a,b) (((a) < (b))?(a):(b))
#define SER_OPERATORS(p) (((p)->kind == la_project)            \
                          || ((p)->kind == la_roots)           \
                          || ((p)->kind == la_attach)          \
                          || ((p)->kind == la_step_join)       \
                          || ((p)->kind == la_guide_step_join) \
                          || ((p)->kind == la_doc_access)      \
                          || ((p)->kind == la_rank)            \
                          || ((p)->kind == la_eqjoin)          \
                          || ((p)->kind == la_thetajoin))
/* item list */
#define ITEM_LIST(p)  ((p)->sql_ann->ser_list1)

static void
ser_info_worker (PFla_op_t *p, PFarray_t *twigs)
{
    assert (p);
    assert (twigs);

    ser_report_t status = ser_yes;

    /* descend only once */
    if (SEEN(p))
        return;

    SEEN(p) = true;

    /* check if we find one of the collected twigs */
    if (p->kind == la_twig)
        for (unsigned int i = 0; i < PFarray_last (twigs); i++)
            if (*(PFla_op_t **) PFarray_at (twigs, i) == p) {
                /* if we found a twig operator we have to store
                   the item in the item_list to avoid the item
                   to be abused in the above operators */

                /* add the item column */
                ITEM_LIST(p) = PFalg_collist (1);
                cladd (ITEM_LIST(p)) = p->sem.iter_item.item;

                SER_REPORT(p) = ser_tc;
                return;
            }

    /* if we find a leaf return yes */
    if (IS_LEAF(p)) {
        SER_REPORT(p) = ser_yes;
        return;
    }

    /* DAG walk */
    for (unsigned int i = 0; i < PFLA_OP_MAXCHILD && p->child[i]; i++) {
         ser_info_worker (p->child[i], twigs);
         status = MIN(status, SER_REPORT(p->child[i]));
    }

    switch (status) {
        /* if we cannot serialize by expanding the schema
         * there is no reason to move on */
        case ser_no:
            SER_REPORT (p) = ser_no;
            return;

        /* if we found a twig in one of the descending
         * operators we must take care if the
         * ancestors do not  */
        case ser_tc:
            if (!SER_OPERATORS(p) || (REFCTR(p) > 1)) {
                SER_REPORT (p) = ser_no;
                return;
            }
            /* it is not sure the operator is 'clean' so go on */
            break;

        /* No constructors involved until now */
        case ser_yes:
            SER_REPORT (p) = ser_yes;
            return;

        default:
            assert (!"Serialization report status unknown");
    }

    /* maintain item information */
    switch (p->kind) {
        case la_project:
        {
            PFalg_col_t old, new;
            if (ITEM_LIST(L(p)))
                ITEM_LIST(p) = PFalg_collist (clsize (ITEM_LIST(L(p))));
            /* projection has the ability to omit and change names */
            for (unsigned int i = 0; i < p->sem.proj.count; i++) {
                old = p->sem.proj.items[i].old;
                new = p->sem.proj.items[i].new;

                if (clin (ITEM_LIST(L(p)), old)) cladd (ITEM_LIST(p)) = new;
            }
        }   break;

        case la_rank:
            ITEM_LIST(p) = ITEM_LIST(L(p));
            break;

        case la_roots:
        case la_attach:
            ITEM_LIST(p) = ITEM_LIST(L(p));
            break;

        case la_step_join:
        case la_guide_step_join:
        case la_doc_access:
            ITEM_LIST(p) = ITEM_LIST(R(p));
            break;

        case la_eqjoin:
        case la_thetajoin:
            if (ITEM_LIST(L(p)) && ITEM_LIST(R(p)))
                ITEM_LIST(p) = PFalg_collist_concat (
                                   PFalg_collist_copy (ITEM_LIST(L(p))),
                                   ITEM_LIST(R(p)));
            else if (ITEM_LIST(L(p)))
                ITEM_LIST(p) = ITEM_LIST(L(p));
            else
                ITEM_LIST(p) = ITEM_LIST(R(p));
            break;

        default:
            PFoops (OOPS_FATAL, "Have not expected this operator");
            break;
    }

    /* check if operators are save */
    switch (p->kind) {
        /* just return, this operators are save */
        case la_project:
        case la_roots:
        case la_attach:
            SER_REPORT(p) = ser_tc;
            return;

        case la_step:
        case la_step_join:
        case la_guide_step:
        case la_guide_step_join:
            if (clin (ITEM_LIST(p), p->sem.step.item)) {
                SER_REPORT(p) = ser_no;
                return;
            }
            SER_REPORT(p) = ser_tc;
            break;

        case la_doc_access:
            if (clin (ITEM_LIST(p), p->sem.doc_access.col)) {
               SER_REPORT(p) = ser_no;
               return;
             }
             SER_REPORT(p) = ser_tc;
             break;

        case la_rank:
        {
            PFalg_col_t ord;
            /* if the sort criterion contains an item in the list
             * the rank is not save.
             * Except the case where item is the last sort criterion
             * but we don't handle this. */
            for (int i = PFord_count (p->sem.sort.sortby) - 1; i >= 0; i--) {
                ord = PFord_order_col_at (p->sem.sort.sortby, i);
                if (clin (ITEM_LIST(p), ord)) {
                    SER_REPORT(p) = ser_no;
                    return;
                }
            }

            /* check if we bind the rank operator or not */
            SER_REPORT(p) = p->sql_ann->bind ? ser_no: ser_tc;
        }   break;

        case la_eqjoin:
            if (clin (ITEM_LIST(p), p->sem.eqjoin.col1) ||
                clin (ITEM_LIST(p), p->sem.eqjoin.col2)) {
                SER_REPORT(p) = ser_no;
                return;
            }
            SER_REPORT(p) = ser_tc;
            break;

        case la_thetajoin:
            for (unsigned int i = 0; i < p->sem.thetajoin.count; i++)
                if (clin (ITEM_LIST(p), p->sem.thetajoin.pred[i].left)  ||
                    clin (ITEM_LIST(p), p->sem.thetajoin.pred[i].right)) {
                    SER_REPORT(p) = ser_no;
                    return;
                }
            SER_REPORT(p) = ser_tc;
            break;

        default:
            PFoops (OOPS_FATAL, "Have not expected this operator");
            break;
    }
}

/* Infer serialization information, so we
 * can avoid an expensive join. */
static void
infer_ser_info (PFla_op_t * p)
{
    PFarray_t *twigs     = PFarray (sizeof (PFla_op_t*), 2);
    bool       twig_only = false;

    assert (p->kind == la_serialize_seq);

    /* collect the twigs referenced in this query */
    twig_only = collect_twigs (LR(p), twigs);

    if (!twig_only)
        return;

    /* infer the serialization info */
    ser_info_worker (R(p), twigs);

    /* the serialize operator either contains yes or no */
    SER_REPORT(p) = (SER_REPORT(R(p)) != ser_no) ? ser_yes : ser_no;

    if (SER_REPORT(p) == ser_no)
        return;

    /* set all collected twigs to ser_yes to indicate we can
       omit the level check */
    for (unsigned int i = 0; i < PFarray_last (twigs); i++) {
         PFla_op_t *twig = *(PFla_op_t **) PFarray_at (twigs, i);
         assert (twig);
         assert (twig->kind == la_twig);
         SER_REPORT(twig) = ser_yes;
    }
}

/**
 * Assign each constructor in a twig pattern a delta value in pre-order,
 * a level value, and a size value. */
static unsigned int
assign_twig_info (PFla_op_t *n, unsigned int twig_pre, unsigned int level)
{
    assert (n);

    /* only descend once */
    if (SEEN (n))
        return twig_pre;
    else
        SEEN (n) = true;

    if (n->kind == la_twig) {
        assign_twig_info (L(n), 0, 0);
        return twig_pre;
    } else if (n->kind == la_fcns) {
        /* this is the only place we need to ensure the order */
        twig_pre = assign_twig_info (L(n), twig_pre, level);
        twig_pre = assign_twig_info (R(n), twig_pre, level);

        if (L(n)->kind == la_nil && R(n)->kind == la_nil)
            TSIZE(n) = 0;
        else if (R(n)->kind == la_nil)
            TSIZE(n) = TSIZE(L(n)) + 1;
        else
            TSIZE(n) = (TSIZE(L(n)) + 1) + TSIZE(R(n));

        return twig_pre;
    } else if (n->kind == la_docnode ||
               n->kind == la_element) {
        TPRE(n)   = twig_pre++;
        TLEVEL(n) = level++;

        /* assign pre, size, and level information for the children */
        twig_pre = assign_twig_info (L(n), twig_pre, level);
        twig_pre = assign_twig_info (R(n), twig_pre, level);

        TSIZE(n) = TSIZE(R(n));
        return twig_pre;
    } else if (n->kind == la_attribute ||
               n->kind == la_textnode  ||
               n->kind == la_comment   ||
               n->kind == la_processi  ||
               n->kind == la_content) {
        TPRE(n)   = twig_pre++;
        TSIZE(n)  = n->kind == la_content ? -1 : 0;
        TLEVEL(n) = level;
    }

    /* traverse the children */
    for (unsigned int i = 0; i < PFLA_OP_MAXCHILD && n->child[i]; i++)
        twig_pre = assign_twig_info (n->child[i], twig_pre, level);

    return twig_pre;
}


/* initializing global variables */
static void
PFsql_init (void)
{
    sql_stmts      = NULL;
    max_pre_frag   = NULL;
    rec_branch     = false;
    selectivity    = false;
    bind_multi_ref = false;
    table_varno    = PF_SQL_RES_TABLE_COUNT;
    alias_varno    = PF_SQL_RES_ALIAS_COUNT;
    col_varno      = PF_SQL_RES_COLUMN_COUNT;
}


PFsql_t *
PFlalg2sql (PFla_op_t * n)
{
    /* initializing global variables */
    PFsql_init ();

    /* read in environment variables */
    char *selectivity_str = getenv ("PFSQL_USE_DB2_SELECTIVITY");
    char *bind_str        = getenv ("PFSQL_BIND_MULTIPLE_REFERENCES");


    /* interpret environment variables */
    selectivity    = selectivity_str && !strcmp (selectivity_str, "1");
    bind_multi_ref = bind_str && !strcmp (bind_str, "1");

    assert (n);

    if ((n->kind != la_serialize_seq) && (n->kind != la_serialize_rel))
        PFoops (OOPS_FATAL,
                "SQL code generation can only "
                "cope with result sequences.");

    /* Set reference counters in algebra tree nodes. */
    PFprop_infer_refctr (n);

    /* Set the initial fragment. */
    max_pre_frag = table_name (PF_SQL_TABLE_FRAG);

    /* Label and annotate the complete DAG. */
    label (n);
    PFla_dag_reset (n);

    /* Decide for all numbering operators (rownum, rank, rowrank, rowid)
       whether they need to be bound immediately or at the next binding. */
    decide_numbering_bind (n);

    /* The following checks introduce additional annotations that allow the SQL
       code generation to generate more efficient code for queries that result
       in new XML fragments. */
    if (n->kind == la_serialize_seq) {
        /* check if serialize returns a node* */
        PFalg_simple_type_t ser_ty = PFprop_type_of (n, n->sem.ser_seq.item);
        /* check if ser_ty has no other type */
        if ((ser_ty & aat_node) && !(ser_ty & ~aat_node)) {
            /* infer the serialization information */
            infer_ser_info (n);
            PFla_dag_reset (n);
        }
    }

    /* Assign the delta-pre, level, and size value for node constructors */
    assign_twig_info (n, 0, 0);
    PFla_dag_reset (n);

    /* Traverse the tree and collect as a side effect
       the SQL code in the global variable @a sql_stmts. */
    reduce (n, 1);

    return sql_stmts;
}

/* vim:set shiftwidth=4 expandtab filetype=c: */
