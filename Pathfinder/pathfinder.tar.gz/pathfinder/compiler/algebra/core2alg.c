#line 1 "core2alg.brg"


/**
 * @file
 *
 * Compile Core tree into relational algebra.
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *
 * $Id$
 */


#include "pf_config.h"
#include "pathfinder.h"
#include <assert.h>
#include <stdio.h>

#include "compile.h"
#include "oops.h"
#include "core.h"
#include "subtyping.h"
#include "qname.h"
#include "mem.h"
#include "alg_dag.h"
/* recursion-depth option */
#include "options.h"

/* PFvar_t */
#include "variable.h"

#include "algebra.h"
#include "builtins.h"

/* Easily access subtree-parts */
#include "child_mnemonic.h"

/*
 * Accessors for the burg matcher
 */
typedef struct PFcnode_t *NODEPTR_TYPE;

/* accessor to the node kind */
#define OP_LABEL(p)    ((p)->kind)

/* accessors to left and right child node */
#define LEFT_CHILD(p)  ((p)->child[0])
#define RIGHT_CHILD(p) ((p)->child[1])

/* the state determined during bottom-up labeling is stored here */
#define STATE_LABEL(p) ((p)->state_label)

/* If something goes wrong, call PFoops */
#define PANIC(...) PFoops (OOPS_BURG, __VA_ARGS__)

#ifndef PFcore2alg_PANIC
#define PFcore2alg_PANIC	PANIC
#endif /* PFcore2alg_PANIC */
#include <stdlib.h> /* for abort() */
#ifdef NDEBUG
#define PFcore2alg_assert(x,y)	;
#else
#define PFcore2alg_assert(x,y)	if(!(x)) {y; abort();}
#endif
static short PFcore2alg_r1_nts[] ={ 16, 2, 0 };
static short PFcore2alg_r2_nts[] ={ 2, 0 };
static short PFcore2alg_r3_nts[] ={ 3, 0 };
static short PFcore2alg_r4_nts[] ={ 5, 8, 0 };
static short PFcore2alg_r5_nts[] ={ 5, 7, 0 };
static short PFcore2alg_r6_nts[] ={ 6, 2, 5, 0 };
static short PFcore2alg_r7_nts[] ={ 2, 5, 0 };
static short PFcore2alg_r8_nts[] ={ 0 };
static short PFcore2alg_r9_nts[] ={ 2, 7, 0 };
static short PFcore2alg_r10_nts[] ={ 9, 2, 0 };
static short PFcore2alg_r11_nts[] ={ 2, 8, 0 };
static short PFcore2alg_r13_nts[] ={ 2, 2, 2, 0 };
static short PFcore2alg_r14_nts[] ={ 2, 10, 0 };
static short PFcore2alg_r15_nts[] ={ 2, 2, 0 };
static short PFcore2alg_r45_nts[] ={ 12, 0 };
static short PFcore2alg_r46_nts[] ={ 12, 11, 0 };
static short PFcore2alg_r50_nts[] ={ 11, 0 };
static short PFcore2alg_r51_nts[] ={ 13, 11, 0 };
static short PFcore2alg_r52_nts[] ={ 13, 2, 0 };
static short PFcore2alg_r60_nts[] ={ 14, 0 };
static short PFcore2alg_r61_nts[] ={ 2, 14, 0 };
static short PFcore2alg_r71_nts[] ={ 17, 16, 0 };
static short PFcore2alg_r101_nts[] ={ 4, 0 };
static short PFcore2alg_r301_nts[] ={ 2, 9, 0 };
static short PFcore2alg_r501_nts[] ={ 15, 14, 0 };
static short PFcore2alg_r600_nts[] ={ 18, 19, 0 };
static short PFcore2alg_r602_nts[] ={ 20, 18, 0 };
short *PFcore2alg_nts[] = {
	0,
	PFcore2alg_r1_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r3_nts,
	PFcore2alg_r4_nts,
	PFcore2alg_r5_nts,
	PFcore2alg_r6_nts,
	PFcore2alg_r7_nts,
	PFcore2alg_r8_nts,
	PFcore2alg_r9_nts,
	PFcore2alg_r10_nts,
	PFcore2alg_r11_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r13_nts,
	PFcore2alg_r14_nts,
	PFcore2alg_r15_nts,
	PFcore2alg_r14_nts,
	PFcore2alg_r15_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r13_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	0,
	PFcore2alg_r45_nts,
	PFcore2alg_r46_nts,
	PFcore2alg_r45_nts,
	PFcore2alg_r8_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r50_nts,
	PFcore2alg_r51_nts,
	PFcore2alg_r52_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r15_nts,
	0,
	0,
	0,
	0,
	PFcore2alg_r60_nts,
	PFcore2alg_r61_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFcore2alg_r8_nts,
	PFcore2alg_r71_nts,
	PFcore2alg_r15_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFcore2alg_r8_nts,
	PFcore2alg_r101_nts,
	PFcore2alg_r8_nts,
	PFcore2alg_r8_nts,
	PFcore2alg_r8_nts,
	PFcore2alg_r8_nts,
	PFcore2alg_r8_nts,
	PFcore2alg_r8_nts,
	PFcore2alg_r8_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFcore2alg_r8_nts,
	PFcore2alg_r8_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFcore2alg_r2_nts,
	PFcore2alg_r301_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFcore2alg_r8_nts,
	PFcore2alg_r2_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFcore2alg_r8_nts,
	PFcore2alg_r501_nts,
	PFcore2alg_r2_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFcore2alg_r600_nts,
	PFcore2alg_r8_nts,
	PFcore2alg_r602_nts,
	PFcore2alg_r2_nts,
	PFcore2alg_r8_nts,
};
static unsigned char PFcore2alg_seq_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFcore2alg_twig_seq_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_flwr_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFcore2alg_let_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_letbind_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_for__transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_forbind_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_forvars_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_where_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFcore2alg_orderby_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_orderspecs_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFcore2alg_arg_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_typesw_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_cases_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_case__transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_seqcast_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_if__transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_then_else_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_locsteps_transition[15][2] = {
{    0,    0}	/* row 0 */,
{    0,   11}	/* row 1 */,
{    0,   12}	/* row 2 */,
{    0,    5}	/* row 3 */,
{    0,    9}	/* row 4 */,
{    0,   10}	/* row 5 */,
{    0,    8}	/* row 6 */,
{    0,   14}	/* row 7 */,
{    0,    4}	/* row 8 */,
{    0,    2}	/* row 9 */,
{    0,    1}	/* row 10 */,
{    0,   13}	/* row 11 */,
{    0,    6}	/* row 12 */,
{    0,    7}	/* row 13 */,
{    0,    3}	/* row 14 */
};
static unsigned char PFcore2alg_elem_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_attr_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_pi_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_main_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_fun_decls_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_fun_decl_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_params_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_param_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_cast_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_recursion_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_seed_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcore2alg_xrpc_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static struct {
	unsigned int f30:4;
	unsigned int f31:2;
	unsigned int f32:2;
	unsigned int f33:2;
	unsigned int f34:2;
	unsigned int f35:2;
	unsigned int f36:2;
	unsigned int f37:3;
	unsigned int f38:4;
	unsigned int f39:2;
	unsigned int f40:5;
	unsigned int f41:2;
} PFcore2alg_plank_0[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  11,   2,},	/* row 3 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 4 */
	{   1,   1,   0,   0,   2,   0,   0,   0,   0,   0,  24,   2,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  17,   2,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   7,   1,   0,   0,   2,   0,   0,   0,   0,   0,  24,   2,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   3,   1,   0,   0,   2,   0,   0,   0,   0,   0,  24,   2,},	/* row 15 */
	{   2,   1,   0,   0,   2,   0,   0,   0,   0,   0,  24,   2,},	/* row 16 */
	{   4,   1,   0,   0,   2,   0,   0,   0,   4,   1,   1,   2,},	/* row 17 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   3,   1,   1,   2,},	/* row 18 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,   3,   2,},	/* row 19 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,   2,   2,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,   4,   2,},	/* row 28 */
	{   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   1,   1,   1,   2,},	/* row 31 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   7,   1,   1,   2,},	/* row 32 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   6,   1,   1,   2,},	/* row 33 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   5,   1,   1,   2,},	/* row 34 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  29,   2,},	/* row 35 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,   7,   2,},	/* row 36 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  25,   2,},	/* row 37 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,   5,   2,},	/* row 38 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  21,   2,},	/* row 39 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  27,   2,},	/* row 40 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  26,   2,},	/* row 41 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,   6,   2,},	/* row 42 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  22,   2,},	/* row 43 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  23,   2,},	/* row 44 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  19,   2,},	/* row 45 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  20,   2,},	/* row 46 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  28,   2,},	/* row 47 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,   8,   2,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   2,   1,   0,   0,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  14,   2,},	/* row 52 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   6,   1,   0,   0,   2,   0,   0,   0,   0,   0,  24,   2,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,   9,   2,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   5,   1,   1,   0,   2,   0,   0,   0,   0,   0,  13,   2,},	/* row 64 */
	{   5,   1,   2,   0,   2,   0,   0,   0,   0,   0,  12,   2,},	/* row 65 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  18,   2,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   8,   1,   0,   0,   2,   0,   0,   0,   0,   0,  24,   2,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   2,   1,   1,   2,},	/* row 73 */
	{   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  16,   2,},	/* row 75 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  15,   2,},	/* row 76 */
	{   5,   1,   0,   0,   2,   0,   1,   0,   0,   2,   1,   2,},	/* row 77 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   5,   1,   0,   0,   2,   0,   0,   0,   0,   0,  10,   2,},	/* row 80 */
};
static struct {
	unsigned int f15:2;
	unsigned int f16:2;
	unsigned int f17:2;
	unsigned int f18:4;
	unsigned int f19:2;
	unsigned int f20:2;
	unsigned int f21:2;
	unsigned int f22:2;
	unsigned int f23:2;
	unsigned int f24:2;
	unsigned int f25:2;
	unsigned int f26:2;
	unsigned int f27:2;
	unsigned int f28:2;
	unsigned int f29:2;
} PFcore2alg_plank_1[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   1,   0,   0,   0,   1,},	/* row 3 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 4 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 5 */
	{   0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 9 */
	{   0,   0,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 11 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   5,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   6,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 15 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 16 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 17 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 18 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 19 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 20 */
	{   0,   0,   0,   7,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   8,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 28 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 31 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 32 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 33 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 34 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 35 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 36 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 37 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 38 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 39 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 40 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 41 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 42 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 43 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 44 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 45 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 46 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 47 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   1,   0,   1,   0,   0,   0,   2,   1,   2,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   1,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   9,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 58 */
	{   0,   0,   0,  10,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,  11,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,  12,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 64 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 65 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 66 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,  13,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,  14,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,},	/* row 70 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 71 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 75 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 76 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 80 */
};
static struct {
	unsigned int f0:2;
	unsigned int f1:2;
	unsigned int f2:2;
	unsigned int f3:2;
	unsigned int f4:2;
	unsigned int f5:2;
	unsigned int f6:2;
	unsigned int f7:2;
	unsigned int f8:2;
	unsigned int f9:2;
	unsigned int f10:2;
	unsigned int f11:2;
	unsigned int f12:2;
	unsigned int f13:2;
	unsigned int f14:2;
} PFcore2alg_plank_2[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 3 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 4 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 8 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 18 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 19 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 28 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 31 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 32 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 33 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 34 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 35 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 36 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 37 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 38 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 39 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 40 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 41 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 42 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 43 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 44 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 45 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 46 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   1,   0,   1,   1,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   2,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   2,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   1,   2,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   1,   2,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 75 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 76 */
	{   1,   1,   1,   0,   1,   0,   1,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   1,   1,   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 80 */
};
static short PFcore2alg_eruleMap[] = {
    0,  101,  100,    0,    3,    4,    5,   13,   37,   35,	/* 0-9 */
   38,   36,   72,   61,   60,   14,   15,   18,   19,   20,	/* 10-19 */
   21,   22,   30,   31,   32,   33,   34,   45,   43,   42,	/* 20-29 */
   41,   40,   39,    0,  604,    0,  502,    0,  501,  500,	/* 30-39 */
    0,  603,    0,  600,    0,   70,   71,    0,  105,  106,	/* 40-49 */
  107,  108,  102,  103,  104,    0,    8,    6,    7,    0,	/* 50-59 */
  200,  201,    0,    9,   10,    0,  301,  300,    0,  602,	/* 60-69 */
  601,    0,    1,    2,    0,   17,   16,    0,  401,  400,	/* 70-79 */
    0,   52,   51,   50,   48,   49,   55,   54,   53,    0,	/* 80-89 */
   47,   46,    0,   11,   12
};
#define PFcore2alg_Query_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f41 +71]
#define PFcore2alg_CoreExpr_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f40 +3]
#define PFcore2alg_Atom_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f39 +0]
#define PFcore2alg_LiteralValue_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f38 +47]
#define PFcore2alg_OptBindExpr_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f37 +55]
#define PFcore2alg_OptVar_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f36 +59]
#define PFcore2alg_OrdWhereExpr_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f35 +62]
#define PFcore2alg_WhereExpr_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f34 +92]
#define PFcore2alg_OrderSpecs_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f33 +65]
#define PFcore2alg_SeqCoreExpr_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f32 +74]
#define PFcore2alg_TwigSeq_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f31 +89]
#define PFcore2alg_TwigExpr_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_0[state].f30 +80]
#define PFcore2alg_TagName_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_1[state].f29 +77]
#define PFcore2alg_FunctionArgs_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_1[state].f28 +37]
#define PFcore2alg_FunctionArg_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_2[state].f0 +35]
#define PFcore2alg_FunctionDecls_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_1[state].f27 +44]
#define PFcore2alg_FunctionDecl_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_1[state].f21 +42]
#define PFcore2alg_ParamList_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_1[state].f26 +68]
#define PFcore2alg_FunctionBody_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_2[state].f0 +40]
#define PFcore2alg_FunParam_rule(state)	PFcore2alg_eruleMap[PFcore2alg_plank_1[state].f23 +33]

#ifdef __STDC__
int PFcore2alg_rule(int state, int goalnt) {
#else
int PFcore2alg_rule(state, goalnt) int state; int goalnt; {
#endif
	PFcore2alg_assert(state >= 0 && state < 81, PFcore2alg_PANIC("Bad state %d passed to PFcore2alg_rule\n", state));
	switch(goalnt) {
	case 1:
		return PFcore2alg_Query_rule(state);
	case 2:
		return PFcore2alg_CoreExpr_rule(state);
	case 3:
		return PFcore2alg_Atom_rule(state);
	case 4:
		return PFcore2alg_LiteralValue_rule(state);
	case 5:
		return PFcore2alg_OptBindExpr_rule(state);
	case 6:
		return PFcore2alg_OptVar_rule(state);
	case 7:
		return PFcore2alg_OrdWhereExpr_rule(state);
	case 8:
		return PFcore2alg_WhereExpr_rule(state);
	case 9:
		return PFcore2alg_OrderSpecs_rule(state);
	case 10:
		return PFcore2alg_SeqCoreExpr_rule(state);
	case 11:
		return PFcore2alg_TwigSeq_rule(state);
	case 12:
		return PFcore2alg_TwigExpr_rule(state);
	case 13:
		return PFcore2alg_TagName_rule(state);
	case 14:
		return PFcore2alg_FunctionArgs_rule(state);
	case 15:
		return PFcore2alg_FunctionArg_rule(state);
	case 16:
		return PFcore2alg_FunctionDecls_rule(state);
	case 17:
		return PFcore2alg_FunctionDecl_rule(state);
	case 18:
		return PFcore2alg_ParamList_rule(state);
	case 19:
		return PFcore2alg_FunctionBody_rule(state);
	case 20:
		return PFcore2alg_FunParam_rule(state);
	default:
		PFcore2alg_PANIC("Unknown nonterminal %d in PFcore2alg_rule;\n", goalnt);
		abort();
		return 0;
	}
}

int PFcore2alg_TEMP;
#define PFcore2alg_var_state	77
#define PFcore2alg_lit_str_state	34
#define PFcore2alg_lit_int_state	33
#define PFcore2alg_lit_dec_state	32
#define PFcore2alg_lit_dbl_state	31
#define PFcore2alg_nil_state	50
#define PFcore2alg_seq_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_seq_transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_2[r].f1]) ? PFcore2alg_TEMP + 63 : 0 )
#define PFcore2alg_twig_seq_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_twig_seq_transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_2[r].f2]) ? PFcore2alg_TEMP + 73 : 0 )
#define PFcore2alg_ordered_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_2[l].f0) ? PFcore2alg_TEMP + 51 : 0 )
#define PFcore2alg_unordered_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_2[l].f0) ? PFcore2alg_TEMP + 75 : 0 )
#define PFcore2alg_flwr_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_flwr_transition[PFcore2alg_plank_2[l].f3][PFcore2alg_plank_2[r].f4]) ? PFcore2alg_TEMP + 18 : 0 )
#define PFcore2alg_let_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_let_transition[PFcore2alg_plank_2[l].f5][PFcore2alg_plank_2[r].f3]) ? PFcore2alg_TEMP + 28 : 0 )
#define PFcore2alg_letbind_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_letbind_transition[PFcore2alg_plank_2[l].f6][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 29 : 0 )
#define PFcore2alg_for__state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_for__transition[PFcore2alg_plank_2[l].f7][PFcore2alg_plank_2[r].f3]) ? PFcore2alg_TEMP + 22 : 0 )
#define PFcore2alg_forbind_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_forbind_transition[PFcore2alg_plank_2[l].f8][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 23 : 0 )
#define PFcore2alg_forvars_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_forvars_transition[PFcore2alg_plank_2[l].f6][PFcore2alg_plank_2[r].f9]) ? PFcore2alg_TEMP + 24 : 0 )
#define PFcore2alg_where_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_where_transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_2[r].f4]) ? PFcore2alg_TEMP + 77 : 0 )
#define PFcore2alg_orderby_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_orderby_transition[PFcore2alg_plank_2[l].f10][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 50 : 0 )
#define PFcore2alg_orderspecs_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_orderspecs_transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_2[r].f11]) ? PFcore2alg_TEMP + 52 : 0 )
#define PFcore2alg_apply_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_2[l].f12) ? PFcore2alg_TEMP + 2 : 0 )
#define PFcore2alg_arg_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_arg_transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_2[r].f12]) ? PFcore2alg_TEMP + 3 : 0 )
#define PFcore2alg_typesw_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_typesw_transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_2[r].f13]) ? PFcore2alg_TEMP + 74 : 0 )
#define PFcore2alg_cases_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_cases_transition[PFcore2alg_plank_2[l].f14][PFcore2alg_plank_1[r].f15]) ? PFcore2alg_TEMP + 7 : 0 )
#define PFcore2alg_case__state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_case__transition[PFcore2alg_plank_1[l].f16][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 6 : 0 )
#define PFcore2alg_default__state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_2[l].f0) ? PFcore2alg_TEMP + 11 : 0 )
#define PFcore2alg_seqtype_state	67
#define PFcore2alg_seqcast_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_seqcast_transition[PFcore2alg_plank_1[l].f16][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 65 : 0 )
#define PFcore2alg_if__state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_if__transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_1[r].f17]) ? PFcore2alg_TEMP + 27 : 0 )
#define PFcore2alg_then_else_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_then_else_transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 71 : 0 )
#define PFcore2alg_locsteps_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_locsteps_transition[PFcore2alg_plank_1[l].f18][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 34 : 0 )
#define PFcore2alg_ancestor_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 0 : 0 )
#define PFcore2alg_ancestor_or_self_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 1 : 0 )
#define PFcore2alg_attribute_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 5 : 0 )
#define PFcore2alg_child_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 9 : 0 )
#define PFcore2alg_descendant_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 12 : 0 )
#define PFcore2alg_descendant_or_self_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 13 : 0 )
#define PFcore2alg_following_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 20 : 0 )
#define PFcore2alg_following_sibling_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 21 : 0 )
#define PFcore2alg_parent_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 56 : 0 )
#define PFcore2alg_preceding_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 58 : 0 )
#define PFcore2alg_preceding_sibling_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 59 : 0 )
#define PFcore2alg_self_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 62 : 0 )
#define PFcore2alg_so_select_narrow_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 67 : 0 )
#define PFcore2alg_so_select_wide_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_1[l].f16) ? PFcore2alg_TEMP + 68 : 0 )
#define PFcore2alg_elem_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_elem_transition[PFcore2alg_plank_1[l].f19][PFcore2alg_plank_2[r].f2]) ? PFcore2alg_TEMP + 15 : 0 )
#define PFcore2alg_attr_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_attr_transition[PFcore2alg_plank_1[l].f19][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 4 : 0 )
#define PFcore2alg_text_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_2[l].f0) ? PFcore2alg_TEMP + 70 : 0 )
#define PFcore2alg_doc_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_2[l].f2) ? PFcore2alg_TEMP + 14 : 0 )
#define PFcore2alg_comment_state(l)	( (PFcore2alg_TEMP = PFcore2alg_plank_2[l].f0) ? PFcore2alg_TEMP + 10 : 0 )
#define PFcore2alg_pi_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_pi_transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 57 : 0 )
#define PFcore2alg_tag_state	70
#define PFcore2alg_true__state	73
#define PFcore2alg_false__state	18
#define PFcore2alg_empty_state	17
#define PFcore2alg_main_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_main_transition[PFcore2alg_plank_1[l].f20][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 48 : 0 )
#define PFcore2alg_fun_decls_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_fun_decls_transition[PFcore2alg_plank_1[l].f21][PFcore2alg_plank_1[r].f20]) ? PFcore2alg_TEMP + 26 : 0 )
#define PFcore2alg_fun_decl_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_fun_decl_transition[PFcore2alg_plank_1[l].f22][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 25 : 0 )
#define PFcore2alg_params_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_params_transition[PFcore2alg_plank_1[l].f23][PFcore2alg_plank_1[r].f22]) ? PFcore2alg_TEMP + 55 : 0 )
#define PFcore2alg_param_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_param_transition[PFcore2alg_plank_1[l].f16][PFcore2alg_plank_2[r].f6]) ? PFcore2alg_TEMP + 54 : 0 )
#define PFcore2alg_cast_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_cast_transition[PFcore2alg_plank_1[l].f16][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 8 : 0 )
#define PFcore2alg_recursion_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_recursion_transition[PFcore2alg_plank_2[l].f6][PFcore2alg_plank_1[r].f24]) ? PFcore2alg_TEMP + 60 : 0 )
#define PFcore2alg_seed_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_seed_transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_2[r].f0]) ? PFcore2alg_TEMP + 61 : 0 )
#define PFcore2alg_xrpc_state(l,r)	( (PFcore2alg_TEMP = PFcore2alg_xrpc_transition[PFcore2alg_plank_2[l].f0][PFcore2alg_plank_1[r].f25]) ? PFcore2alg_TEMP + 79 : 0 )

#ifdef __STDC__
int PFcore2alg_state(int op, int l, int r) {
#else
int PFcore2alg_state(op, l, r) int op; int l; int r; {
#endif
	register int PFcore2alg_TEMP;
#ifndef NDEBUG
	switch (op) {
	case 7:
	case 8:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 24:
	case 25:
	case 26:
	case 27:
	case 30:
	case 34:
	case 35:
	case 40:
	case 55:
	case 56:
	case 60:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
		PFcore2alg_assert(r >= 0 && r < 81, PFcore2alg_PANIC("Bad state %d passed to PFcore2alg_state\n", r));
		/*FALLTHROUGH*/
	case 9:
	case 10:
	case 23:
	case 28:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 57:
	case 58:
	case 59:
		PFcore2alg_assert(l >= 0 && l < 81, PFcore2alg_PANIC("Bad state %d passed to PFcore2alg_state\n", l));
		/*FALLTHROUGH*/
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 29:
	case 61:
	case 65:
	case 66:
	case 67:
		break;
	}
#endif
	switch (op) {
	default: PFcore2alg_PANIC("Unknown op %d in PFcore2alg_state\n", op); abort(); return 0;
	case 1:
		return PFcore2alg_var_state;
	case 2:
		return PFcore2alg_lit_str_state;
	case 3:
		return PFcore2alg_lit_int_state;
	case 4:
		return PFcore2alg_lit_dec_state;
	case 5:
		return PFcore2alg_lit_dbl_state;
	case 6:
		return PFcore2alg_nil_state;
	case 7:
		return PFcore2alg_seq_state(l,r);
	case 8:
		return PFcore2alg_twig_seq_state(l,r);
	case 9:
		return PFcore2alg_ordered_state(l);
	case 10:
		return PFcore2alg_unordered_state(l);
	case 14:
		return PFcore2alg_flwr_state(l,r);
	case 15:
		return PFcore2alg_let_state(l,r);
	case 16:
		return PFcore2alg_letbind_state(l,r);
	case 17:
		return PFcore2alg_for__state(l,r);
	case 18:
		return PFcore2alg_forbind_state(l,r);
	case 19:
		return PFcore2alg_forvars_state(l,r);
	case 20:
		return PFcore2alg_where_state(l,r);
	case 21:
		return PFcore2alg_orderby_state(l,r);
	case 22:
		return PFcore2alg_orderspecs_state(l,r);
	case 23:
		return PFcore2alg_apply_state(l);
	case 24:
		return PFcore2alg_arg_state(l,r);
	case 25:
		return PFcore2alg_typesw_state(l,r);
	case 26:
		return PFcore2alg_cases_state(l,r);
	case 27:
		return PFcore2alg_case__state(l,r);
	case 28:
		return PFcore2alg_default__state(l);
	case 29:
		return PFcore2alg_seqtype_state;
	case 30:
		return PFcore2alg_seqcast_state(l,r);
	case 34:
		return PFcore2alg_if__state(l,r);
	case 35:
		return PFcore2alg_then_else_state(l,r);
	case 40:
		return PFcore2alg_locsteps_state(l,r);
	case 41:
		return PFcore2alg_ancestor_state(l);
	case 42:
		return PFcore2alg_ancestor_or_self_state(l);
	case 43:
		return PFcore2alg_attribute_state(l);
	case 44:
		return PFcore2alg_child_state(l);
	case 45:
		return PFcore2alg_descendant_state(l);
	case 46:
		return PFcore2alg_descendant_or_self_state(l);
	case 47:
		return PFcore2alg_following_state(l);
	case 48:
		return PFcore2alg_following_sibling_state(l);
	case 49:
		return PFcore2alg_parent_state(l);
	case 50:
		return PFcore2alg_preceding_state(l);
	case 51:
		return PFcore2alg_preceding_sibling_state(l);
	case 52:
		return PFcore2alg_self_state(l);
	case 53:
		return PFcore2alg_so_select_narrow_state(l);
	case 54:
		return PFcore2alg_so_select_wide_state(l);
	case 55:
		return PFcore2alg_elem_state(l,r);
	case 56:
		return PFcore2alg_attr_state(l,r);
	case 57:
		return PFcore2alg_text_state(l);
	case 58:
		return PFcore2alg_doc_state(l);
	case 59:
		return PFcore2alg_comment_state(l);
	case 60:
		return PFcore2alg_pi_state(l,r);
	case 61:
		return PFcore2alg_tag_state;
	case 65:
		return PFcore2alg_true__state;
	case 66:
		return PFcore2alg_false__state;
	case 67:
		return PFcore2alg_empty_state;
	case 68:
		return PFcore2alg_main_state(l,r);
	case 69:
		return PFcore2alg_fun_decls_state(l,r);
	case 70:
		return PFcore2alg_fun_decl_state(l,r);
	case 71:
		return PFcore2alg_params_state(l,r);
	case 72:
		return PFcore2alg_param_state(l,r);
	case 73:
		return PFcore2alg_cast_state(l,r);
	case 74:
		return PFcore2alg_recursion_state(l,r);
	case 75:
		return PFcore2alg_seed_state(l,r);
	case 76:
		return PFcore2alg_xrpc_state(l,r);
	}
}
#ifdef PFcore2alg_STATE_LABEL
#define PFcore2alg_INCLUDE_EXTRA
#else
#ifdef STATE_LABEL
#define PFcore2alg_INCLUDE_EXTRA
#define PFcore2alg_STATE_LABEL 	STATE_LABEL
#define PFcore2alg_NODEPTR_TYPE	NODEPTR_TYPE
#define PFcore2alg_LEFT_CHILD  	LEFT_CHILD
#define PFcore2alg_OP_LABEL    	OP_LABEL
#define PFcore2alg_RIGHT_CHILD 	RIGHT_CHILD
#endif /* STATE_LABEL */
#endif /* PFcore2alg_STATE_LABEL */

#ifdef PFcore2alg_INCLUDE_EXTRA

#ifdef __STDC__
int PFcore2alg_label(PFcore2alg_NODEPTR_TYPE n) {
#else
int PFcore2alg_label(n) PFcore2alg_NODEPTR_TYPE n; {
#endif
	PFcore2alg_assert(n, PFcore2alg_PANIC("NULL pointer passed to PFcore2alg_label\n"));
	switch (PFcore2alg_OP_LABEL(n)) {
	default: PFcore2alg_PANIC("Bad op %d in PFcore2alg_label\n", PFcore2alg_OP_LABEL(n)); abort(); return 0;
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 29:
	case 61:
	case 65:
	case 66:
	case 67:
		return PFcore2alg_STATE_LABEL(n) = PFcore2alg_state(PFcore2alg_OP_LABEL(n), 0, 0);
	case 9:
	case 10:
	case 23:
	case 28:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 57:
	case 58:
	case 59:
		return PFcore2alg_STATE_LABEL(n) = PFcore2alg_state(PFcore2alg_OP_LABEL(n), PFcore2alg_label(PFcore2alg_LEFT_CHILD(n)), 0);
	case 7:
	case 8:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 24:
	case 25:
	case 26:
	case 27:
	case 30:
	case 34:
	case 35:
	case 40:
	case 55:
	case 56:
	case 60:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
		return PFcore2alg_STATE_LABEL(n) = PFcore2alg_state(PFcore2alg_OP_LABEL(n), PFcore2alg_label(PFcore2alg_LEFT_CHILD(n)), PFcore2alg_label(PFcore2alg_RIGHT_CHILD(n)));
	}
}
#ifdef __STDC__
PFcore2alg_NODEPTR_TYPE * PFcore2alg_kids(PFcore2alg_NODEPTR_TYPE p, int rulenumber, PFcore2alg_NODEPTR_TYPE *kids) {
#else
PFcore2alg_NODEPTR_TYPE * PFcore2alg_kids(p, rulenumber, kids) PFcore2alg_NODEPTR_TYPE p; int rulenumber; PFcore2alg_NODEPTR_TYPE *kids; {
#endif
	PFcore2alg_assert(p, PFcore2alg_PANIC("NULL node pointer passed to PFcore2alg_kids\n"));
	PFcore2alg_assert(kids, PFcore2alg_PANIC("NULL kids pointer passed to PFcore2alg_kids\n"));
	switch (rulenumber) {
	default:
		PFcore2alg_PANIC("Unknown Rule %d in PFcore2alg_kids;\n", rulenumber);
		abort();
		/* NOTREACHED */
	case 6:
		kids[0] = PFcore2alg_RIGHT_CHILD(PFcore2alg_LEFT_CHILD(PFcore2alg_LEFT_CHILD(p)));
		kids[1] = PFcore2alg_RIGHT_CHILD(PFcore2alg_LEFT_CHILD(p));
		kids[2] = PFcore2alg_RIGHT_CHILD(p);
		break;
	case 7:
		kids[0] = PFcore2alg_RIGHT_CHILD(PFcore2alg_LEFT_CHILD(p));
		kids[1] = PFcore2alg_RIGHT_CHILD(p);
		break;
	case 13:
		kids[0] = PFcore2alg_LEFT_CHILD(p);
		kids[1] = PFcore2alg_LEFT_CHILD(PFcore2alg_RIGHT_CHILD(p));
		kids[2] = PFcore2alg_RIGHT_CHILD(PFcore2alg_RIGHT_CHILD(p));
		break;
	case 20:
		kids[0] = PFcore2alg_LEFT_CHILD(p);
		kids[1] = PFcore2alg_RIGHT_CHILD(PFcore2alg_LEFT_CHILD(PFcore2alg_RIGHT_CHILD(p)));
		kids[2] = PFcore2alg_LEFT_CHILD(PFcore2alg_RIGHT_CHILD(PFcore2alg_RIGHT_CHILD(p)));
		break;
	case 21:
	case 22:
	case 30:
	case 31:
	case 32:
	case 33:
	case 34:
	case 35:
	case 36:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
		kids[0] = PFcore2alg_RIGHT_CHILD(p);
		break;
	case 300:
	case 18:
	case 19:
	case 50:
	case 53:
	case 54:
	case 60:
		kids[0] = PFcore2alg_LEFT_CHILD(p);
		break;
	case 61:
		kids[0] = PFcore2alg_LEFT_CHILD(p);
		kids[1] = PFcore2alg_LEFT_CHILD(PFcore2alg_RIGHT_CHILD(p));
		break;
	case 1:
	case 4:
	case 5:
	case 9:
	case 10:
	case 11:
	case 301:
	case 14:
	case 15:
	case 16:
	case 17:
	case 46:
	case 51:
	case 52:
	case 55:
	case 501:
	case 71:
	case 600:
	case 602:
		kids[0] = PFcore2alg_LEFT_CHILD(p);
		kids[1] = PFcore2alg_RIGHT_CHILD(p);
		break;
	case 2:
	case 3:
	case 101:
	case 12:
	case 45:
	case 47:
	case 49:
	case 401:
	case 502:
	case 603:
		kids[0] = p;
		break;
	case 100:
	case 102:
	case 103:
	case 104:
	case 105:
	case 106:
	case 107:
	case 108:
	case 200:
	case 201:
	case 8:
	case 48:
	case 400:
	case 500:
	case 70:
	case 601:
	case 604:
		break;
	case 72:
		kids[0] = PFcore2alg_LEFT_CHILD(PFcore2alg_RIGHT_CHILD(p));
		kids[1] = PFcore2alg_RIGHT_CHILD(PFcore2alg_RIGHT_CHILD(p));
		break;
	}
	return kids;
}
#ifdef __STDC__
PFcore2alg_NODEPTR_TYPE PFcore2alg_child(PFcore2alg_NODEPTR_TYPE p, int index) {
#else
PFcore2alg_NODEPTR_TYPE PFcore2alg_child(p, index) PFcore2alg_NODEPTR_TYPE p; int index; {
#endif
	PFcore2alg_assert(p, PFcore2alg_PANIC("NULL pointer passed to PFcore2alg_child\n"));
	switch (index) {
	case 0:
		return PFcore2alg_LEFT_CHILD(p);
	case 1:
		return PFcore2alg_RIGHT_CHILD(p);
	}
	PFcore2alg_PANIC("Bad index %d in PFcore2alg_child;\n", index);
	abort();
	return 0;
}
#ifdef __STDC__
int PFcore2alg_op_label(PFcore2alg_NODEPTR_TYPE p) {
#else
int PFcore2alg_op_label(p) PFcore2alg_NODEPTR_TYPE p; {
#endif
	PFcore2alg_assert(p, PFcore2alg_PANIC("NULL pointer passed to PFcore2alg_op_label\n"));
	return PFcore2alg_OP_LABEL(p);
}
#ifdef __STDC__
int PFcore2alg_state_label(PFcore2alg_NODEPTR_TYPE p) {
#else
int PFcore2alg_state_label(p) PFcore2alg_NODEPTR_TYPE p; {
#endif
	PFcore2alg_assert(p, PFcore2alg_PANIC("NULL pointer passed to PFcore2alg_state_label\n"));
	return PFcore2alg_STATE_LABEL(p);
}
#endif /* PFcore2alg_INCLUDE_EXTRA */
#define PFcore2alg_FunParam_NT 20
#define PFcore2alg_FunctionBody_NT 19
#define PFcore2alg_ParamList_NT 18
#define PFcore2alg_FunctionDecl_NT 17
#define PFcore2alg_FunctionDecls_NT 16
#define PFcore2alg_FunctionArg_NT 15
#define PFcore2alg_FunctionArgs_NT 14
#define PFcore2alg_TagName_NT 13
#define PFcore2alg_TwigExpr_NT 12
#define PFcore2alg_TwigSeq_NT 11
#define PFcore2alg_SeqCoreExpr_NT 10
#define PFcore2alg_OrderSpecs_NT 9
#define PFcore2alg_WhereExpr_NT 8
#define PFcore2alg_OrdWhereExpr_NT 7
#define PFcore2alg_OptVar_NT 6
#define PFcore2alg_OptBindExpr_NT 5
#define PFcore2alg_LiteralValue_NT 4
#define PFcore2alg_Atom_NT 3
#define PFcore2alg_CoreExpr_NT 2
#define PFcore2alg_Query_NT 1
#define PFcore2alg_NT 20
char * PFcore2alg_opname[] = {
	0, /* 0 */
	"var", /* 1 */
	"lit_str", /* 2 */
	"lit_int", /* 3 */
	"lit_dec", /* 4 */
	"lit_dbl", /* 5 */
	"nil", /* 6 */
	"seq", /* 7 */
	"twig_seq", /* 8 */
	"ordered", /* 9 */
	"unordered", /* 10 */
	0, /* 11 */
	0, /* 12 */
	0, /* 13 */
	"flwr", /* 14 */
	"let", /* 15 */
	"letbind", /* 16 */
	"for_", /* 17 */
	"forbind", /* 18 */
	"forvars", /* 19 */
	"where", /* 20 */
	"orderby", /* 21 */
	"orderspecs", /* 22 */
	"apply", /* 23 */
	"arg", /* 24 */
	"typesw", /* 25 */
	"cases", /* 26 */
	"case_", /* 27 */
	"default_", /* 28 */
	"seqtype", /* 29 */
	"seqcast", /* 30 */
	0, /* 31 */
	0, /* 32 */
	0, /* 33 */
	"if_", /* 34 */
	"then_else", /* 35 */
	0, /* 36 */
	0, /* 37 */
	0, /* 38 */
	0, /* 39 */
	"locsteps", /* 40 */
	"ancestor", /* 41 */
	"ancestor_or_self", /* 42 */
	"attribute", /* 43 */
	"child", /* 44 */
	"descendant", /* 45 */
	"descendant_or_self", /* 46 */
	"following", /* 47 */
	"following_sibling", /* 48 */
	"parent", /* 49 */
	"preceding", /* 50 */
	"preceding_sibling", /* 51 */
	"self", /* 52 */
	"so_select_narrow", /* 53 */
	"so_select_wide", /* 54 */
	"elem", /* 55 */
	"attr", /* 56 */
	"text", /* 57 */
	"doc", /* 58 */
	"comment", /* 59 */
	"pi", /* 60 */
	"tag", /* 61 */
	0, /* 62 */
	0, /* 63 */
	0, /* 64 */
	"true_", /* 65 */
	"false_", /* 66 */
	"empty", /* 67 */
	"main", /* 68 */
	"fun_decls", /* 69 */
	"fun_decl", /* 70 */
	"params", /* 71 */
	"param", /* 72 */
	"cast", /* 73 */
	"recursion", /* 74 */
	"seed", /* 75 */
	"xrpc"
};
char PFcore2alg_arity[] = {
	-1, /* 0 */
	0, /* 1 */
	0, /* 2 */
	0, /* 3 */
	0, /* 4 */
	0, /* 5 */
	0, /* 6 */
	2, /* 7 */
	2, /* 8 */
	1, /* 9 */
	1, /* 10 */
	-1, /* 11 */
	-1, /* 12 */
	-1, /* 13 */
	2, /* 14 */
	2, /* 15 */
	2, /* 16 */
	2, /* 17 */
	2, /* 18 */
	2, /* 19 */
	2, /* 20 */
	2, /* 21 */
	2, /* 22 */
	1, /* 23 */
	2, /* 24 */
	2, /* 25 */
	2, /* 26 */
	2, /* 27 */
	1, /* 28 */
	0, /* 29 */
	2, /* 30 */
	-1, /* 31 */
	-1, /* 32 */
	-1, /* 33 */
	2, /* 34 */
	2, /* 35 */
	-1, /* 36 */
	-1, /* 37 */
	-1, /* 38 */
	-1, /* 39 */
	2, /* 40 */
	1, /* 41 */
	1, /* 42 */
	1, /* 43 */
	1, /* 44 */
	1, /* 45 */
	1, /* 46 */
	1, /* 47 */
	1, /* 48 */
	1, /* 49 */
	1, /* 50 */
	1, /* 51 */
	1, /* 52 */
	1, /* 53 */
	1, /* 54 */
	2, /* 55 */
	2, /* 56 */
	1, /* 57 */
	1, /* 58 */
	1, /* 59 */
	2, /* 60 */
	0, /* 61 */
	-1, /* 62 */
	-1, /* 63 */
	-1, /* 64 */
	0, /* 65 */
	0, /* 66 */
	0, /* 67 */
	2, /* 68 */
	2, /* 69 */
	2, /* 70 */
	2, /* 71 */
	2, /* 72 */
	2, /* 73 */
	2, /* 74 */
	2, /* 75 */
	2
};
int PFcore2alg_max_op = 76;
int PFcore2alg_max_state = 80;
#define PFcore2alg_Max_state 80
char *PFcore2alg_string[] = {
	0,
	"Query: main(FunctionDecls, CoreExpr)",
	"Query: CoreExpr",
	"CoreExpr: Atom",
	"CoreExpr: flwr(OptBindExpr, WhereExpr)",
	"CoreExpr: flwr(OptBindExpr, OrdWhereExpr)",
	"OptBindExpr: for_(forbind(forvars(var, OptVar), CoreExpr), OptBindExpr)",
	"OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr)",
	"OptBindExpr: nil",
	"OrdWhereExpr: where(CoreExpr, OrdWhereExpr)",
	"OrdWhereExpr: orderby(OrderSpecs, CoreExpr)",
	"WhereExpr: where(CoreExpr, WhereExpr)",
	"WhereExpr: CoreExpr",
	"CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr))",
	"CoreExpr: seq(CoreExpr, SeqCoreExpr)",
	"CoreExpr: seq(CoreExpr, CoreExpr)",
	"SeqCoreExpr: seq(CoreExpr, SeqCoreExpr)",
	"SeqCoreExpr: seq(CoreExpr, CoreExpr)",
	"CoreExpr: ordered(CoreExpr)",
	"CoreExpr: unordered(CoreExpr)",
	"CoreExpr: typesw(CoreExpr, cases(case_(seqtype, CoreExpr), default_(CoreExpr)))",
	"CoreExpr: cast(seqtype, CoreExpr)",
	"CoreExpr: seqcast(seqtype, CoreExpr)",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"CoreExpr: locsteps(ancestor(seqtype), CoreExpr)",
	"CoreExpr: locsteps(ancestor_or_self(seqtype), CoreExpr)",
	"CoreExpr: locsteps(attribute(seqtype), CoreExpr)",
	"CoreExpr: locsteps(child(seqtype), CoreExpr)",
	"CoreExpr: locsteps(descendant(seqtype), CoreExpr)",
	"CoreExpr: locsteps(descendant_or_self(seqtype), CoreExpr)",
	"CoreExpr: locsteps(following(seqtype), CoreExpr)",
	"CoreExpr: locsteps(following_sibling(seqtype), CoreExpr)",
	"CoreExpr: locsteps(parent(seqtype), CoreExpr)",
	"CoreExpr: locsteps(preceding(seqtype), CoreExpr)",
	"CoreExpr: locsteps(preceding_sibling(seqtype), CoreExpr)",
	"CoreExpr: locsteps(self(seqtype), CoreExpr)",
	"CoreExpr: locsteps(so_select_narrow(seqtype), CoreExpr)",
	"CoreExpr: locsteps(so_select_wide(seqtype), CoreExpr)",
	0,
	"CoreExpr: TwigExpr",
	"TwigSeq: twig_seq(TwigExpr, TwigSeq)",
	"TwigSeq: TwigExpr",
	"TwigExpr: empty",
	"TwigExpr: CoreExpr",
	"TwigExpr: doc(TwigSeq)",
	"TwigExpr: elem(TagName, TwigSeq)",
	"TwigExpr: attr(TagName, CoreExpr)",
	"TwigExpr: text(CoreExpr)",
	"TwigExpr: comment(CoreExpr)",
	"TwigExpr: pi(CoreExpr, CoreExpr)",
	0,
	0,
	0,
	0,
	"CoreExpr: apply(FunctionArgs)",
	"CoreExpr: xrpc(CoreExpr, apply(FunctionArgs))",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"FunctionDecls: nil",
	"FunctionDecls: fun_decls(FunctionDecl, FunctionDecls)",
	"CoreExpr: recursion(var, seed(CoreExpr, CoreExpr))",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"Atom: var",
	"Atom: LiteralValue",
	"LiteralValue: lit_str",
	"LiteralValue: lit_int",
	"LiteralValue: lit_dec",
	"LiteralValue: lit_dbl",
	"LiteralValue: true_",
	"LiteralValue: false_",
	"LiteralValue: empty",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"OptVar: var",
	"OptVar: nil",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"OrderSpecs: orderspecs(CoreExpr, nil)",
	"OrderSpecs: orderspecs(CoreExpr, OrderSpecs)",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"TagName: tag",
	"TagName: CoreExpr",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"FunctionArgs: nil",
	"FunctionArgs: arg(FunctionArg, FunctionArgs)",
	"FunctionArg: CoreExpr",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"FunctionDecl: fun_decl(ParamList, FunctionBody)",
	"ParamList: nil",
	"ParamList: params(FunParam, ParamList)",
	"FunctionBody: CoreExpr",
	"FunParam: param(seqtype, var)",
};
int PFcore2alg_max_rule = 604;
#define PFcore2alg_Max_rule 604
short PFcore2alg_rule_descriptor_0[] = { 0, 0 };
short PFcore2alg_rule_descriptor_1[] = {   -1,   68,  -16,   -2, };
short PFcore2alg_rule_descriptor_2[] = {   -1,   -2, };
short PFcore2alg_rule_descriptor_3[] = {   -2,   -3, };
short PFcore2alg_rule_descriptor_4[] = {   -2,   14,   -5,   -8, };
short PFcore2alg_rule_descriptor_5[] = {   -2,   14,   -5,   -7, };
short PFcore2alg_rule_descriptor_6[] = {   -5,   17,   18,   19,    1,   -6,   -2,   -5, };
short PFcore2alg_rule_descriptor_7[] = {   -5,   15,   16,    1,   -2,   -5, };
short PFcore2alg_rule_descriptor_8[] = {   -5,    6, };
short PFcore2alg_rule_descriptor_9[] = {   -7,   20,   -2,   -7, };
short PFcore2alg_rule_descriptor_10[] = {   -7,   21,   -9,   -2, };
short PFcore2alg_rule_descriptor_11[] = {   -8,   20,   -2,   -8, };
short PFcore2alg_rule_descriptor_12[] = {   -8,   -2, };
short PFcore2alg_rule_descriptor_13[] = {   -2,   34,   -2,   35,   -2,   -2, };
short PFcore2alg_rule_descriptor_14[] = {   -2,    7,   -2,  -10, };
short PFcore2alg_rule_descriptor_15[] = {   -2,    7,   -2,   -2, };
short PFcore2alg_rule_descriptor_16[] = {  -10,    7,   -2,  -10, };
short PFcore2alg_rule_descriptor_17[] = {  -10,    7,   -2,   -2, };
short PFcore2alg_rule_descriptor_18[] = {   -2,    9,   -2, };
short PFcore2alg_rule_descriptor_19[] = {   -2,   10,   -2, };
short PFcore2alg_rule_descriptor_20[] = {   -2,   25,   -2,   26,   27,   29,   -2,   28,   -2, };
short PFcore2alg_rule_descriptor_21[] = {   -2,   73,   29,   -2, };
short PFcore2alg_rule_descriptor_22[] = {   -2,   30,   29,   -2, };
short PFcore2alg_rule_descriptor_30[] = {   -2,   40,   41,   29,   -2, };
short PFcore2alg_rule_descriptor_31[] = {   -2,   40,   42,   29,   -2, };
short PFcore2alg_rule_descriptor_32[] = {   -2,   40,   43,   29,   -2, };
short PFcore2alg_rule_descriptor_33[] = {   -2,   40,   44,   29,   -2, };
short PFcore2alg_rule_descriptor_34[] = {   -2,   40,   45,   29,   -2, };
short PFcore2alg_rule_descriptor_35[] = {   -2,   40,   46,   29,   -2, };
short PFcore2alg_rule_descriptor_36[] = {   -2,   40,   47,   29,   -2, };
short PFcore2alg_rule_descriptor_37[] = {   -2,   40,   48,   29,   -2, };
short PFcore2alg_rule_descriptor_38[] = {   -2,   40,   49,   29,   -2, };
short PFcore2alg_rule_descriptor_39[] = {   -2,   40,   50,   29,   -2, };
short PFcore2alg_rule_descriptor_40[] = {   -2,   40,   51,   29,   -2, };
short PFcore2alg_rule_descriptor_41[] = {   -2,   40,   52,   29,   -2, };
short PFcore2alg_rule_descriptor_42[] = {   -2,   40,   53,   29,   -2, };
short PFcore2alg_rule_descriptor_43[] = {   -2,   40,   54,   29,   -2, };
short PFcore2alg_rule_descriptor_45[] = {   -2,  -12, };
short PFcore2alg_rule_descriptor_46[] = {  -11,    8,  -12,  -11, };
short PFcore2alg_rule_descriptor_47[] = {  -11,  -12, };
short PFcore2alg_rule_descriptor_48[] = {  -12,   67, };
short PFcore2alg_rule_descriptor_49[] = {  -12,   -2, };
short PFcore2alg_rule_descriptor_50[] = {  -12,   58,  -11, };
short PFcore2alg_rule_descriptor_51[] = {  -12,   55,  -13,  -11, };
short PFcore2alg_rule_descriptor_52[] = {  -12,   56,  -13,   -2, };
short PFcore2alg_rule_descriptor_53[] = {  -12,   57,   -2, };
short PFcore2alg_rule_descriptor_54[] = {  -12,   59,   -2, };
short PFcore2alg_rule_descriptor_55[] = {  -12,   60,   -2,   -2, };
short PFcore2alg_rule_descriptor_60[] = {   -2,   23,  -14, };
short PFcore2alg_rule_descriptor_61[] = {   -2,   76,   -2,   23,  -14, };
short PFcore2alg_rule_descriptor_70[] = {  -16,    6, };
short PFcore2alg_rule_descriptor_71[] = {  -16,   69,  -17,  -16, };
short PFcore2alg_rule_descriptor_72[] = {   -2,   74,    1,   75,   -2,   -2, };
short PFcore2alg_rule_descriptor_100[] = {   -3,    1, };
short PFcore2alg_rule_descriptor_101[] = {   -3,   -4, };
short PFcore2alg_rule_descriptor_102[] = {   -4,    2, };
short PFcore2alg_rule_descriptor_103[] = {   -4,    3, };
short PFcore2alg_rule_descriptor_104[] = {   -4,    4, };
short PFcore2alg_rule_descriptor_105[] = {   -4,    5, };
short PFcore2alg_rule_descriptor_106[] = {   -4,   65, };
short PFcore2alg_rule_descriptor_107[] = {   -4,   66, };
short PFcore2alg_rule_descriptor_108[] = {   -4,   67, };
short PFcore2alg_rule_descriptor_200[] = {   -6,    1, };
short PFcore2alg_rule_descriptor_201[] = {   -6,    6, };
short PFcore2alg_rule_descriptor_300[] = {   -9,   22,   -2,    6, };
short PFcore2alg_rule_descriptor_301[] = {   -9,   22,   -2,   -9, };
short PFcore2alg_rule_descriptor_400[] = {  -13,   61, };
short PFcore2alg_rule_descriptor_401[] = {  -13,   -2, };
short PFcore2alg_rule_descriptor_500[] = {  -14,    6, };
short PFcore2alg_rule_descriptor_501[] = {  -14,   24,  -15,  -14, };
short PFcore2alg_rule_descriptor_502[] = {  -15,   -2, };
short PFcore2alg_rule_descriptor_600[] = {  -17,   70,  -18,  -19, };
short PFcore2alg_rule_descriptor_601[] = {  -18,    6, };
short PFcore2alg_rule_descriptor_602[] = {  -18,   71,  -20,  -18, };
short PFcore2alg_rule_descriptor_603[] = {  -19,   -2, };
short PFcore2alg_rule_descriptor_604[] = {  -20,   72,   29,    1, };
/* PFcore2alg_rule_descriptors[0][1] = 1 iff grammar is normal form. */
short * PFcore2alg_rule_descriptors[] = {
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_1,
	PFcore2alg_rule_descriptor_2,
	PFcore2alg_rule_descriptor_3,
	PFcore2alg_rule_descriptor_4,
	PFcore2alg_rule_descriptor_5,
	PFcore2alg_rule_descriptor_6,
	PFcore2alg_rule_descriptor_7,
	PFcore2alg_rule_descriptor_8,
	PFcore2alg_rule_descriptor_9,
	PFcore2alg_rule_descriptor_10,
	PFcore2alg_rule_descriptor_11,
	PFcore2alg_rule_descriptor_12,
	PFcore2alg_rule_descriptor_13,
	PFcore2alg_rule_descriptor_14,
	PFcore2alg_rule_descriptor_15,
	PFcore2alg_rule_descriptor_16,
	PFcore2alg_rule_descriptor_17,
	PFcore2alg_rule_descriptor_18,
	PFcore2alg_rule_descriptor_19,
	PFcore2alg_rule_descriptor_20,
	PFcore2alg_rule_descriptor_21,
	PFcore2alg_rule_descriptor_22,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_30,
	PFcore2alg_rule_descriptor_31,
	PFcore2alg_rule_descriptor_32,
	PFcore2alg_rule_descriptor_33,
	PFcore2alg_rule_descriptor_34,
	PFcore2alg_rule_descriptor_35,
	PFcore2alg_rule_descriptor_36,
	PFcore2alg_rule_descriptor_37,
	PFcore2alg_rule_descriptor_38,
	PFcore2alg_rule_descriptor_39,
	PFcore2alg_rule_descriptor_40,
	PFcore2alg_rule_descriptor_41,
	PFcore2alg_rule_descriptor_42,
	PFcore2alg_rule_descriptor_43,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_45,
	PFcore2alg_rule_descriptor_46,
	PFcore2alg_rule_descriptor_47,
	PFcore2alg_rule_descriptor_48,
	PFcore2alg_rule_descriptor_49,
	PFcore2alg_rule_descriptor_50,
	PFcore2alg_rule_descriptor_51,
	PFcore2alg_rule_descriptor_52,
	PFcore2alg_rule_descriptor_53,
	PFcore2alg_rule_descriptor_54,
	PFcore2alg_rule_descriptor_55,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_60,
	PFcore2alg_rule_descriptor_61,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_70,
	PFcore2alg_rule_descriptor_71,
	PFcore2alg_rule_descriptor_72,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_100,
	PFcore2alg_rule_descriptor_101,
	PFcore2alg_rule_descriptor_102,
	PFcore2alg_rule_descriptor_103,
	PFcore2alg_rule_descriptor_104,
	PFcore2alg_rule_descriptor_105,
	PFcore2alg_rule_descriptor_106,
	PFcore2alg_rule_descriptor_107,
	PFcore2alg_rule_descriptor_108,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_200,
	PFcore2alg_rule_descriptor_201,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_300,
	PFcore2alg_rule_descriptor_301,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_400,
	PFcore2alg_rule_descriptor_401,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_500,
	PFcore2alg_rule_descriptor_501,
	PFcore2alg_rule_descriptor_502,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_0,
	PFcore2alg_rule_descriptor_600,
	PFcore2alg_rule_descriptor_601,
	PFcore2alg_rule_descriptor_602,
	PFcore2alg_rule_descriptor_603,
	PFcore2alg_rule_descriptor_604,
};
short PFcore2alg_cost[][4] = {
	{    0,    0,    0,    0}, /* (none) = 0 */
	{   10,    0,    0,    0}, /* Query: main(FunctionDecls, CoreExpr) = 1 */
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   10,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 4 */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, OrdWhereExpr) = 5 */
	{   10,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, OptVar), CoreExpr), OptBindExpr) = 6 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr) = 7 */
	{   10,    0,    0,    0}, /* OptBindExpr: nil = 8 */
	{   10,    0,    0,    0}, /* OrdWhereExpr: where(CoreExpr, OrdWhereExpr) = 9 */
	{   10,    0,    0,    0}, /* OrdWhereExpr: orderby(OrderSpecs, CoreExpr) = 10 */
	{   10,    0,    0,    0}, /* WhereExpr: where(CoreExpr, WhereExpr) = 11 */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{   10,    0,    0,    0}, /* CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr)) = 13 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, SeqCoreExpr) = 14 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, CoreExpr) = 15 */
	{   10,    0,    0,    0}, /* SeqCoreExpr: seq(CoreExpr, SeqCoreExpr) = 16 */
	{   10,    0,    0,    0}, /* SeqCoreExpr: seq(CoreExpr, CoreExpr) = 17 */
	{   10,    0,    0,    0}, /* CoreExpr: ordered(CoreExpr) = 18 */
	{   10,    0,    0,    0}, /* CoreExpr: unordered(CoreExpr) = 19 */
	{   10,    0,    0,    0}, /* CoreExpr: typesw(CoreExpr, cases(case_(seqtype, CoreExpr), default_(CoreExpr))) = 20 */
	{   10,    0,    0,    0}, /* CoreExpr: cast(seqtype, CoreExpr) = 21 */
	{   10,    0,    0,    0}, /* CoreExpr: seqcast(seqtype, CoreExpr) = 22 */
	{    0,    0,    0,    0}, /* (none) = 23 */
	{    0,    0,    0,    0}, /* (none) = 24 */
	{    0,    0,    0,    0}, /* (none) = 25 */
	{    0,    0,    0,    0}, /* (none) = 26 */
	{    0,    0,    0,    0}, /* (none) = 27 */
	{    0,    0,    0,    0}, /* (none) = 28 */
	{    0,    0,    0,    0}, /* (none) = 29 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(ancestor(seqtype), CoreExpr) = 30 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(ancestor_or_self(seqtype), CoreExpr) = 31 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(attribute(seqtype), CoreExpr) = 32 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(child(seqtype), CoreExpr) = 33 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(descendant(seqtype), CoreExpr) = 34 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(descendant_or_self(seqtype), CoreExpr) = 35 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(following(seqtype), CoreExpr) = 36 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(following_sibling(seqtype), CoreExpr) = 37 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(parent(seqtype), CoreExpr) = 38 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(preceding(seqtype), CoreExpr) = 39 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(preceding_sibling(seqtype), CoreExpr) = 40 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(self(seqtype), CoreExpr) = 41 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(so_select_narrow(seqtype), CoreExpr) = 42 */
	{   10,    0,    0,    0}, /* CoreExpr: locsteps(so_select_wide(seqtype), CoreExpr) = 43 */
	{    0,    0,    0,    0}, /* (none) = 44 */
	{   20,    0,    0,    0}, /* CoreExpr: TwigExpr = 45 */
	{   10,    0,    0,    0}, /* TwigSeq: twig_seq(TwigExpr, TwigSeq) = 46 */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{   20,    0,    0,    0}, /* TwigExpr: empty = 48 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TwigExpr: doc(TwigSeq) = 50 */
	{   10,    0,    0,    0}, /* TwigExpr: elem(TagName, TwigSeq) = 51 */
	{   10,    0,    0,    0}, /* TwigExpr: attr(TagName, CoreExpr) = 52 */
	{   10,    0,    0,    0}, /* TwigExpr: text(CoreExpr) = 53 */
	{   10,    0,    0,    0}, /* TwigExpr: comment(CoreExpr) = 54 */
	{   10,    0,    0,    0}, /* TwigExpr: pi(CoreExpr, CoreExpr) = 55 */
	{    0,    0,    0,    0}, /* (none) = 56 */
	{    0,    0,    0,    0}, /* (none) = 57 */
	{    0,    0,    0,    0}, /* (none) = 58 */
	{    0,    0,    0,    0}, /* (none) = 59 */
	{   10,    0,    0,    0}, /* CoreExpr: apply(FunctionArgs) = 60 */
	{   10,    0,    0,    0}, /* CoreExpr: xrpc(CoreExpr, apply(FunctionArgs)) = 61 */
	{    0,    0,    0,    0}, /* (none) = 62 */
	{    0,    0,    0,    0}, /* (none) = 63 */
	{    0,    0,    0,    0}, /* (none) = 64 */
	{    0,    0,    0,    0}, /* (none) = 65 */
	{    0,    0,    0,    0}, /* (none) = 66 */
	{    0,    0,    0,    0}, /* (none) = 67 */
	{    0,    0,    0,    0}, /* (none) = 68 */
	{    0,    0,    0,    0}, /* (none) = 69 */
	{   10,    0,    0,    0}, /* FunctionDecls: nil = 70 */
	{   10,    0,    0,    0}, /* FunctionDecls: fun_decls(FunctionDecl, FunctionDecls) = 71 */
	{   10,    0,    0,    0}, /* CoreExpr: recursion(var, seed(CoreExpr, CoreExpr)) = 72 */
	{    0,    0,    0,    0}, /* (none) = 73 */
	{    0,    0,    0,    0}, /* (none) = 74 */
	{    0,    0,    0,    0}, /* (none) = 75 */
	{    0,    0,    0,    0}, /* (none) = 76 */
	{    0,    0,    0,    0}, /* (none) = 77 */
	{    0,    0,    0,    0}, /* (none) = 78 */
	{    0,    0,    0,    0}, /* (none) = 79 */
	{    0,    0,    0,    0}, /* (none) = 80 */
	{    0,    0,    0,    0}, /* (none) = 81 */
	{    0,    0,    0,    0}, /* (none) = 82 */
	{    0,    0,    0,    0}, /* (none) = 83 */
	{    0,    0,    0,    0}, /* (none) = 84 */
	{    0,    0,    0,    0}, /* (none) = 85 */
	{    0,    0,    0,    0}, /* (none) = 86 */
	{    0,    0,    0,    0}, /* (none) = 87 */
	{    0,    0,    0,    0}, /* (none) = 88 */
	{    0,    0,    0,    0}, /* (none) = 89 */
	{    0,    0,    0,    0}, /* (none) = 90 */
	{    0,    0,    0,    0}, /* (none) = 91 */
	{    0,    0,    0,    0}, /* (none) = 92 */
	{    0,    0,    0,    0}, /* (none) = 93 */
	{    0,    0,    0,    0}, /* (none) = 94 */
	{    0,    0,    0,    0}, /* (none) = 95 */
	{    0,    0,    0,    0}, /* (none) = 96 */
	{    0,    0,    0,    0}, /* (none) = 97 */
	{    0,    0,    0,    0}, /* (none) = 98 */
	{    0,    0,    0,    0}, /* (none) = 99 */
	{   10,    0,    0,    0}, /* Atom: var = 100 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 101 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_str = 102 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_int = 103 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_dec = 104 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_dbl = 105 */
	{   10,    0,    0,    0}, /* LiteralValue: true_ = 106 */
	{   10,    0,    0,    0}, /* LiteralValue: false_ = 107 */
	{   10,    0,    0,    0}, /* LiteralValue: empty = 108 */
	{    0,    0,    0,    0}, /* (none) = 109 */
	{    0,    0,    0,    0}, /* (none) = 110 */
	{    0,    0,    0,    0}, /* (none) = 111 */
	{    0,    0,    0,    0}, /* (none) = 112 */
	{    0,    0,    0,    0}, /* (none) = 113 */
	{    0,    0,    0,    0}, /* (none) = 114 */
	{    0,    0,    0,    0}, /* (none) = 115 */
	{    0,    0,    0,    0}, /* (none) = 116 */
	{    0,    0,    0,    0}, /* (none) = 117 */
	{    0,    0,    0,    0}, /* (none) = 118 */
	{    0,    0,    0,    0}, /* (none) = 119 */
	{    0,    0,    0,    0}, /* (none) = 120 */
	{    0,    0,    0,    0}, /* (none) = 121 */
	{    0,    0,    0,    0}, /* (none) = 122 */
	{    0,    0,    0,    0}, /* (none) = 123 */
	{    0,    0,    0,    0}, /* (none) = 124 */
	{    0,    0,    0,    0}, /* (none) = 125 */
	{    0,    0,    0,    0}, /* (none) = 126 */
	{    0,    0,    0,    0}, /* (none) = 127 */
	{    0,    0,    0,    0}, /* (none) = 128 */
	{    0,    0,    0,    0}, /* (none) = 129 */
	{    0,    0,    0,    0}, /* (none) = 130 */
	{    0,    0,    0,    0}, /* (none) = 131 */
	{    0,    0,    0,    0}, /* (none) = 132 */
	{    0,    0,    0,    0}, /* (none) = 133 */
	{    0,    0,    0,    0}, /* (none) = 134 */
	{    0,    0,    0,    0}, /* (none) = 135 */
	{    0,    0,    0,    0}, /* (none) = 136 */
	{    0,    0,    0,    0}, /* (none) = 137 */
	{    0,    0,    0,    0}, /* (none) = 138 */
	{    0,    0,    0,    0}, /* (none) = 139 */
	{    0,    0,    0,    0}, /* (none) = 140 */
	{    0,    0,    0,    0}, /* (none) = 141 */
	{    0,    0,    0,    0}, /* (none) = 142 */
	{    0,    0,    0,    0}, /* (none) = 143 */
	{    0,    0,    0,    0}, /* (none) = 144 */
	{    0,    0,    0,    0}, /* (none) = 145 */
	{    0,    0,    0,    0}, /* (none) = 146 */
	{    0,    0,    0,    0}, /* (none) = 147 */
	{    0,    0,    0,    0}, /* (none) = 148 */
	{    0,    0,    0,    0}, /* (none) = 149 */
	{    0,    0,    0,    0}, /* (none) = 150 */
	{    0,    0,    0,    0}, /* (none) = 151 */
	{    0,    0,    0,    0}, /* (none) = 152 */
	{    0,    0,    0,    0}, /* (none) = 153 */
	{    0,    0,    0,    0}, /* (none) = 154 */
	{    0,    0,    0,    0}, /* (none) = 155 */
	{    0,    0,    0,    0}, /* (none) = 156 */
	{    0,    0,    0,    0}, /* (none) = 157 */
	{    0,    0,    0,    0}, /* (none) = 158 */
	{    0,    0,    0,    0}, /* (none) = 159 */
	{    0,    0,    0,    0}, /* (none) = 160 */
	{    0,    0,    0,    0}, /* (none) = 161 */
	{    0,    0,    0,    0}, /* (none) = 162 */
	{    0,    0,    0,    0}, /* (none) = 163 */
	{    0,    0,    0,    0}, /* (none) = 164 */
	{    0,    0,    0,    0}, /* (none) = 165 */
	{    0,    0,    0,    0}, /* (none) = 166 */
	{    0,    0,    0,    0}, /* (none) = 167 */
	{    0,    0,    0,    0}, /* (none) = 168 */
	{    0,    0,    0,    0}, /* (none) = 169 */
	{    0,    0,    0,    0}, /* (none) = 170 */
	{    0,    0,    0,    0}, /* (none) = 171 */
	{    0,    0,    0,    0}, /* (none) = 172 */
	{    0,    0,    0,    0}, /* (none) = 173 */
	{    0,    0,    0,    0}, /* (none) = 174 */
	{    0,    0,    0,    0}, /* (none) = 175 */
	{    0,    0,    0,    0}, /* (none) = 176 */
	{    0,    0,    0,    0}, /* (none) = 177 */
	{    0,    0,    0,    0}, /* (none) = 178 */
	{    0,    0,    0,    0}, /* (none) = 179 */
	{    0,    0,    0,    0}, /* (none) = 180 */
	{    0,    0,    0,    0}, /* (none) = 181 */
	{    0,    0,    0,    0}, /* (none) = 182 */
	{    0,    0,    0,    0}, /* (none) = 183 */
	{    0,    0,    0,    0}, /* (none) = 184 */
	{    0,    0,    0,    0}, /* (none) = 185 */
	{    0,    0,    0,    0}, /* (none) = 186 */
	{    0,    0,    0,    0}, /* (none) = 187 */
	{    0,    0,    0,    0}, /* (none) = 188 */
	{    0,    0,    0,    0}, /* (none) = 189 */
	{    0,    0,    0,    0}, /* (none) = 190 */
	{    0,    0,    0,    0}, /* (none) = 191 */
	{    0,    0,    0,    0}, /* (none) = 192 */
	{    0,    0,    0,    0}, /* (none) = 193 */
	{    0,    0,    0,    0}, /* (none) = 194 */
	{    0,    0,    0,    0}, /* (none) = 195 */
	{    0,    0,    0,    0}, /* (none) = 196 */
	{    0,    0,    0,    0}, /* (none) = 197 */
	{    0,    0,    0,    0}, /* (none) = 198 */
	{    0,    0,    0,    0}, /* (none) = 199 */
	{   10,    0,    0,    0}, /* OptVar: var = 200 */
	{   10,    0,    0,    0}, /* OptVar: nil = 201 */
	{    0,    0,    0,    0}, /* (none) = 202 */
	{    0,    0,    0,    0}, /* (none) = 203 */
	{    0,    0,    0,    0}, /* (none) = 204 */
	{    0,    0,    0,    0}, /* (none) = 205 */
	{    0,    0,    0,    0}, /* (none) = 206 */
	{    0,    0,    0,    0}, /* (none) = 207 */
	{    0,    0,    0,    0}, /* (none) = 208 */
	{    0,    0,    0,    0}, /* (none) = 209 */
	{    0,    0,    0,    0}, /* (none) = 210 */
	{    0,    0,    0,    0}, /* (none) = 211 */
	{    0,    0,    0,    0}, /* (none) = 212 */
	{    0,    0,    0,    0}, /* (none) = 213 */
	{    0,    0,    0,    0}, /* (none) = 214 */
	{    0,    0,    0,    0}, /* (none) = 215 */
	{    0,    0,    0,    0}, /* (none) = 216 */
	{    0,    0,    0,    0}, /* (none) = 217 */
	{    0,    0,    0,    0}, /* (none) = 218 */
	{    0,    0,    0,    0}, /* (none) = 219 */
	{    0,    0,    0,    0}, /* (none) = 220 */
	{    0,    0,    0,    0}, /* (none) = 221 */
	{    0,    0,    0,    0}, /* (none) = 222 */
	{    0,    0,    0,    0}, /* (none) = 223 */
	{    0,    0,    0,    0}, /* (none) = 224 */
	{    0,    0,    0,    0}, /* (none) = 225 */
	{    0,    0,    0,    0}, /* (none) = 226 */
	{    0,    0,    0,    0}, /* (none) = 227 */
	{    0,    0,    0,    0}, /* (none) = 228 */
	{    0,    0,    0,    0}, /* (none) = 229 */
	{    0,    0,    0,    0}, /* (none) = 230 */
	{    0,    0,    0,    0}, /* (none) = 231 */
	{    0,    0,    0,    0}, /* (none) = 232 */
	{    0,    0,    0,    0}, /* (none) = 233 */
	{    0,    0,    0,    0}, /* (none) = 234 */
	{    0,    0,    0,    0}, /* (none) = 235 */
	{    0,    0,    0,    0}, /* (none) = 236 */
	{    0,    0,    0,    0}, /* (none) = 237 */
	{    0,    0,    0,    0}, /* (none) = 238 */
	{    0,    0,    0,    0}, /* (none) = 239 */
	{    0,    0,    0,    0}, /* (none) = 240 */
	{    0,    0,    0,    0}, /* (none) = 241 */
	{    0,    0,    0,    0}, /* (none) = 242 */
	{    0,    0,    0,    0}, /* (none) = 243 */
	{    0,    0,    0,    0}, /* (none) = 244 */
	{    0,    0,    0,    0}, /* (none) = 245 */
	{    0,    0,    0,    0}, /* (none) = 246 */
	{    0,    0,    0,    0}, /* (none) = 247 */
	{    0,    0,    0,    0}, /* (none) = 248 */
	{    0,    0,    0,    0}, /* (none) = 249 */
	{    0,    0,    0,    0}, /* (none) = 250 */
	{    0,    0,    0,    0}, /* (none) = 251 */
	{    0,    0,    0,    0}, /* (none) = 252 */
	{    0,    0,    0,    0}, /* (none) = 253 */
	{    0,    0,    0,    0}, /* (none) = 254 */
	{    0,    0,    0,    0}, /* (none) = 255 */
	{    0,    0,    0,    0}, /* (none) = 256 */
	{    0,    0,    0,    0}, /* (none) = 257 */
	{    0,    0,    0,    0}, /* (none) = 258 */
	{    0,    0,    0,    0}, /* (none) = 259 */
	{    0,    0,    0,    0}, /* (none) = 260 */
	{    0,    0,    0,    0}, /* (none) = 261 */
	{    0,    0,    0,    0}, /* (none) = 262 */
	{    0,    0,    0,    0}, /* (none) = 263 */
	{    0,    0,    0,    0}, /* (none) = 264 */
	{    0,    0,    0,    0}, /* (none) = 265 */
	{    0,    0,    0,    0}, /* (none) = 266 */
	{    0,    0,    0,    0}, /* (none) = 267 */
	{    0,    0,    0,    0}, /* (none) = 268 */
	{    0,    0,    0,    0}, /* (none) = 269 */
	{    0,    0,    0,    0}, /* (none) = 270 */
	{    0,    0,    0,    0}, /* (none) = 271 */
	{    0,    0,    0,    0}, /* (none) = 272 */
	{    0,    0,    0,    0}, /* (none) = 273 */
	{    0,    0,    0,    0}, /* (none) = 274 */
	{    0,    0,    0,    0}, /* (none) = 275 */
	{    0,    0,    0,    0}, /* (none) = 276 */
	{    0,    0,    0,    0}, /* (none) = 277 */
	{    0,    0,    0,    0}, /* (none) = 278 */
	{    0,    0,    0,    0}, /* (none) = 279 */
	{    0,    0,    0,    0}, /* (none) = 280 */
	{    0,    0,    0,    0}, /* (none) = 281 */
	{    0,    0,    0,    0}, /* (none) = 282 */
	{    0,    0,    0,    0}, /* (none) = 283 */
	{    0,    0,    0,    0}, /* (none) = 284 */
	{    0,    0,    0,    0}, /* (none) = 285 */
	{    0,    0,    0,    0}, /* (none) = 286 */
	{    0,    0,    0,    0}, /* (none) = 287 */
	{    0,    0,    0,    0}, /* (none) = 288 */
	{    0,    0,    0,    0}, /* (none) = 289 */
	{    0,    0,    0,    0}, /* (none) = 290 */
	{    0,    0,    0,    0}, /* (none) = 291 */
	{    0,    0,    0,    0}, /* (none) = 292 */
	{    0,    0,    0,    0}, /* (none) = 293 */
	{    0,    0,    0,    0}, /* (none) = 294 */
	{    0,    0,    0,    0}, /* (none) = 295 */
	{    0,    0,    0,    0}, /* (none) = 296 */
	{    0,    0,    0,    0}, /* (none) = 297 */
	{    0,    0,    0,    0}, /* (none) = 298 */
	{    0,    0,    0,    0}, /* (none) = 299 */
	{   10,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, nil) = 300 */
	{   10,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, OrderSpecs) = 301 */
	{    0,    0,    0,    0}, /* (none) = 302 */
	{    0,    0,    0,    0}, /* (none) = 303 */
	{    0,    0,    0,    0}, /* (none) = 304 */
	{    0,    0,    0,    0}, /* (none) = 305 */
	{    0,    0,    0,    0}, /* (none) = 306 */
	{    0,    0,    0,    0}, /* (none) = 307 */
	{    0,    0,    0,    0}, /* (none) = 308 */
	{    0,    0,    0,    0}, /* (none) = 309 */
	{    0,    0,    0,    0}, /* (none) = 310 */
	{    0,    0,    0,    0}, /* (none) = 311 */
	{    0,    0,    0,    0}, /* (none) = 312 */
	{    0,    0,    0,    0}, /* (none) = 313 */
	{    0,    0,    0,    0}, /* (none) = 314 */
	{    0,    0,    0,    0}, /* (none) = 315 */
	{    0,    0,    0,    0}, /* (none) = 316 */
	{    0,    0,    0,    0}, /* (none) = 317 */
	{    0,    0,    0,    0}, /* (none) = 318 */
	{    0,    0,    0,    0}, /* (none) = 319 */
	{    0,    0,    0,    0}, /* (none) = 320 */
	{    0,    0,    0,    0}, /* (none) = 321 */
	{    0,    0,    0,    0}, /* (none) = 322 */
	{    0,    0,    0,    0}, /* (none) = 323 */
	{    0,    0,    0,    0}, /* (none) = 324 */
	{    0,    0,    0,    0}, /* (none) = 325 */
	{    0,    0,    0,    0}, /* (none) = 326 */
	{    0,    0,    0,    0}, /* (none) = 327 */
	{    0,    0,    0,    0}, /* (none) = 328 */
	{    0,    0,    0,    0}, /* (none) = 329 */
	{    0,    0,    0,    0}, /* (none) = 330 */
	{    0,    0,    0,    0}, /* (none) = 331 */
	{    0,    0,    0,    0}, /* (none) = 332 */
	{    0,    0,    0,    0}, /* (none) = 333 */
	{    0,    0,    0,    0}, /* (none) = 334 */
	{    0,    0,    0,    0}, /* (none) = 335 */
	{    0,    0,    0,    0}, /* (none) = 336 */
	{    0,    0,    0,    0}, /* (none) = 337 */
	{    0,    0,    0,    0}, /* (none) = 338 */
	{    0,    0,    0,    0}, /* (none) = 339 */
	{    0,    0,    0,    0}, /* (none) = 340 */
	{    0,    0,    0,    0}, /* (none) = 341 */
	{    0,    0,    0,    0}, /* (none) = 342 */
	{    0,    0,    0,    0}, /* (none) = 343 */
	{    0,    0,    0,    0}, /* (none) = 344 */
	{    0,    0,    0,    0}, /* (none) = 345 */
	{    0,    0,    0,    0}, /* (none) = 346 */
	{    0,    0,    0,    0}, /* (none) = 347 */
	{    0,    0,    0,    0}, /* (none) = 348 */
	{    0,    0,    0,    0}, /* (none) = 349 */
	{    0,    0,    0,    0}, /* (none) = 350 */
	{    0,    0,    0,    0}, /* (none) = 351 */
	{    0,    0,    0,    0}, /* (none) = 352 */
	{    0,    0,    0,    0}, /* (none) = 353 */
	{    0,    0,    0,    0}, /* (none) = 354 */
	{    0,    0,    0,    0}, /* (none) = 355 */
	{    0,    0,    0,    0}, /* (none) = 356 */
	{    0,    0,    0,    0}, /* (none) = 357 */
	{    0,    0,    0,    0}, /* (none) = 358 */
	{    0,    0,    0,    0}, /* (none) = 359 */
	{    0,    0,    0,    0}, /* (none) = 360 */
	{    0,    0,    0,    0}, /* (none) = 361 */
	{    0,    0,    0,    0}, /* (none) = 362 */
	{    0,    0,    0,    0}, /* (none) = 363 */
	{    0,    0,    0,    0}, /* (none) = 364 */
	{    0,    0,    0,    0}, /* (none) = 365 */
	{    0,    0,    0,    0}, /* (none) = 366 */
	{    0,    0,    0,    0}, /* (none) = 367 */
	{    0,    0,    0,    0}, /* (none) = 368 */
	{    0,    0,    0,    0}, /* (none) = 369 */
	{    0,    0,    0,    0}, /* (none) = 370 */
	{    0,    0,    0,    0}, /* (none) = 371 */
	{    0,    0,    0,    0}, /* (none) = 372 */
	{    0,    0,    0,    0}, /* (none) = 373 */
	{    0,    0,    0,    0}, /* (none) = 374 */
	{    0,    0,    0,    0}, /* (none) = 375 */
	{    0,    0,    0,    0}, /* (none) = 376 */
	{    0,    0,    0,    0}, /* (none) = 377 */
	{    0,    0,    0,    0}, /* (none) = 378 */
	{    0,    0,    0,    0}, /* (none) = 379 */
	{    0,    0,    0,    0}, /* (none) = 380 */
	{    0,    0,    0,    0}, /* (none) = 381 */
	{    0,    0,    0,    0}, /* (none) = 382 */
	{    0,    0,    0,    0}, /* (none) = 383 */
	{    0,    0,    0,    0}, /* (none) = 384 */
	{    0,    0,    0,    0}, /* (none) = 385 */
	{    0,    0,    0,    0}, /* (none) = 386 */
	{    0,    0,    0,    0}, /* (none) = 387 */
	{    0,    0,    0,    0}, /* (none) = 388 */
	{    0,    0,    0,    0}, /* (none) = 389 */
	{    0,    0,    0,    0}, /* (none) = 390 */
	{    0,    0,    0,    0}, /* (none) = 391 */
	{    0,    0,    0,    0}, /* (none) = 392 */
	{    0,    0,    0,    0}, /* (none) = 393 */
	{    0,    0,    0,    0}, /* (none) = 394 */
	{    0,    0,    0,    0}, /* (none) = 395 */
	{    0,    0,    0,    0}, /* (none) = 396 */
	{    0,    0,    0,    0}, /* (none) = 397 */
	{    0,    0,    0,    0}, /* (none) = 398 */
	{    0,    0,    0,    0}, /* (none) = 399 */
	{   10,    0,    0,    0}, /* TagName: tag = 400 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) = 402 */
	{    0,    0,    0,    0}, /* (none) = 403 */
	{    0,    0,    0,    0}, /* (none) = 404 */
	{    0,    0,    0,    0}, /* (none) = 405 */
	{    0,    0,    0,    0}, /* (none) = 406 */
	{    0,    0,    0,    0}, /* (none) = 407 */
	{    0,    0,    0,    0}, /* (none) = 408 */
	{    0,    0,    0,    0}, /* (none) = 409 */
	{    0,    0,    0,    0}, /* (none) = 410 */
	{    0,    0,    0,    0}, /* (none) = 411 */
	{    0,    0,    0,    0}, /* (none) = 412 */
	{    0,    0,    0,    0}, /* (none) = 413 */
	{    0,    0,    0,    0}, /* (none) = 414 */
	{    0,    0,    0,    0}, /* (none) = 415 */
	{    0,    0,    0,    0}, /* (none) = 416 */
	{    0,    0,    0,    0}, /* (none) = 417 */
	{    0,    0,    0,    0}, /* (none) = 418 */
	{    0,    0,    0,    0}, /* (none) = 419 */
	{    0,    0,    0,    0}, /* (none) = 420 */
	{    0,    0,    0,    0}, /* (none) = 421 */
	{    0,    0,    0,    0}, /* (none) = 422 */
	{    0,    0,    0,    0}, /* (none) = 423 */
	{    0,    0,    0,    0}, /* (none) = 424 */
	{    0,    0,    0,    0}, /* (none) = 425 */
	{    0,    0,    0,    0}, /* (none) = 426 */
	{    0,    0,    0,    0}, /* (none) = 427 */
	{    0,    0,    0,    0}, /* (none) = 428 */
	{    0,    0,    0,    0}, /* (none) = 429 */
	{    0,    0,    0,    0}, /* (none) = 430 */
	{    0,    0,    0,    0}, /* (none) = 431 */
	{    0,    0,    0,    0}, /* (none) = 432 */
	{    0,    0,    0,    0}, /* (none) = 433 */
	{    0,    0,    0,    0}, /* (none) = 434 */
	{    0,    0,    0,    0}, /* (none) = 435 */
	{    0,    0,    0,    0}, /* (none) = 436 */
	{    0,    0,    0,    0}, /* (none) = 437 */
	{    0,    0,    0,    0}, /* (none) = 438 */
	{    0,    0,    0,    0}, /* (none) = 439 */
	{    0,    0,    0,    0}, /* (none) = 440 */
	{    0,    0,    0,    0}, /* (none) = 441 */
	{    0,    0,    0,    0}, /* (none) = 442 */
	{    0,    0,    0,    0}, /* (none) = 443 */
	{    0,    0,    0,    0}, /* (none) = 444 */
	{    0,    0,    0,    0}, /* (none) = 445 */
	{    0,    0,    0,    0}, /* (none) = 446 */
	{    0,    0,    0,    0}, /* (none) = 447 */
	{    0,    0,    0,    0}, /* (none) = 448 */
	{    0,    0,    0,    0}, /* (none) = 449 */
	{    0,    0,    0,    0}, /* (none) = 450 */
	{    0,    0,    0,    0}, /* (none) = 451 */
	{    0,    0,    0,    0}, /* (none) = 452 */
	{    0,    0,    0,    0}, /* (none) = 453 */
	{    0,    0,    0,    0}, /* (none) = 454 */
	{    0,    0,    0,    0}, /* (none) = 455 */
	{    0,    0,    0,    0}, /* (none) = 456 */
	{    0,    0,    0,    0}, /* (none) = 457 */
	{    0,    0,    0,    0}, /* (none) = 458 */
	{    0,    0,    0,    0}, /* (none) = 459 */
	{    0,    0,    0,    0}, /* (none) = 460 */
	{    0,    0,    0,    0}, /* (none) = 461 */
	{    0,    0,    0,    0}, /* (none) = 462 */
	{    0,    0,    0,    0}, /* (none) = 463 */
	{    0,    0,    0,    0}, /* (none) = 464 */
	{    0,    0,    0,    0}, /* (none) = 465 */
	{    0,    0,    0,    0}, /* (none) = 466 */
	{    0,    0,    0,    0}, /* (none) = 467 */
	{    0,    0,    0,    0}, /* (none) = 468 */
	{    0,    0,    0,    0}, /* (none) = 469 */
	{    0,    0,    0,    0}, /* (none) = 470 */
	{    0,    0,    0,    0}, /* (none) = 471 */
	{    0,    0,    0,    0}, /* (none) = 472 */
	{    0,    0,    0,    0}, /* (none) = 473 */
	{    0,    0,    0,    0}, /* (none) = 474 */
	{    0,    0,    0,    0}, /* (none) = 475 */
	{    0,    0,    0,    0}, /* (none) = 476 */
	{    0,    0,    0,    0}, /* (none) = 477 */
	{    0,    0,    0,    0}, /* (none) = 478 */
	{    0,    0,    0,    0}, /* (none) = 479 */
	{    0,    0,    0,    0}, /* (none) = 480 */
	{    0,    0,    0,    0}, /* (none) = 481 */
	{    0,    0,    0,    0}, /* (none) = 482 */
	{    0,    0,    0,    0}, /* (none) = 483 */
	{    0,    0,    0,    0}, /* (none) = 484 */
	{    0,    0,    0,    0}, /* (none) = 485 */
	{    0,    0,    0,    0}, /* (none) = 486 */
	{    0,    0,    0,    0}, /* (none) = 487 */
	{    0,    0,    0,    0}, /* (none) = 488 */
	{    0,    0,    0,    0}, /* (none) = 489 */
	{    0,    0,    0,    0}, /* (none) = 490 */
	{    0,    0,    0,    0}, /* (none) = 491 */
	{    0,    0,    0,    0}, /* (none) = 492 */
	{    0,    0,    0,    0}, /* (none) = 493 */
	{    0,    0,    0,    0}, /* (none) = 494 */
	{    0,    0,    0,    0}, /* (none) = 495 */
	{    0,    0,    0,    0}, /* (none) = 496 */
	{    0,    0,    0,    0}, /* (none) = 497 */
	{    0,    0,    0,    0}, /* (none) = 498 */
	{    0,    0,    0,    0}, /* (none) = 499 */
	{   10,    0,    0,    0}, /* FunctionArgs: nil = 500 */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(FunctionArg, FunctionArgs) = 501 */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) = 503 */
	{    0,    0,    0,    0}, /* (none) = 504 */
	{    0,    0,    0,    0}, /* (none) = 505 */
	{    0,    0,    0,    0}, /* (none) = 506 */
	{    0,    0,    0,    0}, /* (none) = 507 */
	{    0,    0,    0,    0}, /* (none) = 508 */
	{    0,    0,    0,    0}, /* (none) = 509 */
	{    0,    0,    0,    0}, /* (none) = 510 */
	{    0,    0,    0,    0}, /* (none) = 511 */
	{    0,    0,    0,    0}, /* (none) = 512 */
	{    0,    0,    0,    0}, /* (none) = 513 */
	{    0,    0,    0,    0}, /* (none) = 514 */
	{    0,    0,    0,    0}, /* (none) = 515 */
	{    0,    0,    0,    0}, /* (none) = 516 */
	{    0,    0,    0,    0}, /* (none) = 517 */
	{    0,    0,    0,    0}, /* (none) = 518 */
	{    0,    0,    0,    0}, /* (none) = 519 */
	{    0,    0,    0,    0}, /* (none) = 520 */
	{    0,    0,    0,    0}, /* (none) = 521 */
	{    0,    0,    0,    0}, /* (none) = 522 */
	{    0,    0,    0,    0}, /* (none) = 523 */
	{    0,    0,    0,    0}, /* (none) = 524 */
	{    0,    0,    0,    0}, /* (none) = 525 */
	{    0,    0,    0,    0}, /* (none) = 526 */
	{    0,    0,    0,    0}, /* (none) = 527 */
	{    0,    0,    0,    0}, /* (none) = 528 */
	{    0,    0,    0,    0}, /* (none) = 529 */
	{    0,    0,    0,    0}, /* (none) = 530 */
	{    0,    0,    0,    0}, /* (none) = 531 */
	{    0,    0,    0,    0}, /* (none) = 532 */
	{    0,    0,    0,    0}, /* (none) = 533 */
	{    0,    0,    0,    0}, /* (none) = 534 */
	{    0,    0,    0,    0}, /* (none) = 535 */
	{    0,    0,    0,    0}, /* (none) = 536 */
	{    0,    0,    0,    0}, /* (none) = 537 */
	{    0,    0,    0,    0}, /* (none) = 538 */
	{    0,    0,    0,    0}, /* (none) = 539 */
	{    0,    0,    0,    0}, /* (none) = 540 */
	{    0,    0,    0,    0}, /* (none) = 541 */
	{    0,    0,    0,    0}, /* (none) = 542 */
	{    0,    0,    0,    0}, /* (none) = 543 */
	{    0,    0,    0,    0}, /* (none) = 544 */
	{    0,    0,    0,    0}, /* (none) = 545 */
	{    0,    0,    0,    0}, /* (none) = 546 */
	{    0,    0,    0,    0}, /* (none) = 547 */
	{    0,    0,    0,    0}, /* (none) = 548 */
	{    0,    0,    0,    0}, /* (none) = 549 */
	{    0,    0,    0,    0}, /* (none) = 550 */
	{    0,    0,    0,    0}, /* (none) = 551 */
	{    0,    0,    0,    0}, /* (none) = 552 */
	{    0,    0,    0,    0}, /* (none) = 553 */
	{    0,    0,    0,    0}, /* (none) = 554 */
	{    0,    0,    0,    0}, /* (none) = 555 */
	{    0,    0,    0,    0}, /* (none) = 556 */
	{    0,    0,    0,    0}, /* (none) = 557 */
	{    0,    0,    0,    0}, /* (none) = 558 */
	{    0,    0,    0,    0}, /* (none) = 559 */
	{    0,    0,    0,    0}, /* (none) = 560 */
	{    0,    0,    0,    0}, /* (none) = 561 */
	{    0,    0,    0,    0}, /* (none) = 562 */
	{    0,    0,    0,    0}, /* (none) = 563 */
	{    0,    0,    0,    0}, /* (none) = 564 */
	{    0,    0,    0,    0}, /* (none) = 565 */
	{    0,    0,    0,    0}, /* (none) = 566 */
	{    0,    0,    0,    0}, /* (none) = 567 */
	{    0,    0,    0,    0}, /* (none) = 568 */
	{    0,    0,    0,    0}, /* (none) = 569 */
	{    0,    0,    0,    0}, /* (none) = 570 */
	{    0,    0,    0,    0}, /* (none) = 571 */
	{    0,    0,    0,    0}, /* (none) = 572 */
	{    0,    0,    0,    0}, /* (none) = 573 */
	{    0,    0,    0,    0}, /* (none) = 574 */
	{    0,    0,    0,    0}, /* (none) = 575 */
	{    0,    0,    0,    0}, /* (none) = 576 */
	{    0,    0,    0,    0}, /* (none) = 577 */
	{    0,    0,    0,    0}, /* (none) = 578 */
	{    0,    0,    0,    0}, /* (none) = 579 */
	{    0,    0,    0,    0}, /* (none) = 580 */
	{    0,    0,    0,    0}, /* (none) = 581 */
	{    0,    0,    0,    0}, /* (none) = 582 */
	{    0,    0,    0,    0}, /* (none) = 583 */
	{    0,    0,    0,    0}, /* (none) = 584 */
	{    0,    0,    0,    0}, /* (none) = 585 */
	{    0,    0,    0,    0}, /* (none) = 586 */
	{    0,    0,    0,    0}, /* (none) = 587 */
	{    0,    0,    0,    0}, /* (none) = 588 */
	{    0,    0,    0,    0}, /* (none) = 589 */
	{    0,    0,    0,    0}, /* (none) = 590 */
	{    0,    0,    0,    0}, /* (none) = 591 */
	{    0,    0,    0,    0}, /* (none) = 592 */
	{    0,    0,    0,    0}, /* (none) = 593 */
	{    0,    0,    0,    0}, /* (none) = 594 */
	{    0,    0,    0,    0}, /* (none) = 595 */
	{    0,    0,    0,    0}, /* (none) = 596 */
	{    0,    0,    0,    0}, /* (none) = 597 */
	{    0,    0,    0,    0}, /* (none) = 598 */
	{    0,    0,    0,    0}, /* (none) = 599 */
	{   10,    0,    0,    0}, /* FunctionDecl: fun_decl(ParamList, FunctionBody) = 600 */
	{   10,    0,    0,    0}, /* ParamList: nil = 601 */
	{   10,    0,    0,    0}, /* ParamList: params(FunParam, ParamList) = 602 */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{   10,    0,    0,    0}, /* FunParam: param(seqtype, var) = 604 */
};

short PFcore2alg_delta_cost[81][21][4] = {
{{0}}, /* state 0 */
{ /* state #1: ancestor(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #2: ancestor_or_self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #3: apply(nil) */
	{0},
	{   20,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   10,    0,    0,    0}, /* CoreExpr: apply(FunctionArgs) = 60 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{   10,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #4: arg(empty, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionArgs: arg(FunctionArg, FunctionArgs) = 501 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #5: attr(tag, empty) */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: TwigExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: attr(TagName, CoreExpr) = 52 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #6: attribute(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #7: case_(seqtype, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #8: cases(case_(seqtype, empty), default_(empty)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #9: cast(seqtype, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: cast(seqtype, CoreExpr) = 21 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #10: child(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #11: comment(empty) */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: TwigExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: comment(CoreExpr) = 54 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #12: default_(empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #13: descendant(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #14: descendant_or_self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #15: doc(empty) */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: TwigExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: doc(TwigSeq) = 50 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #16: elem(tag, empty) */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: TwigExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: elem(TagName, TwigSeq) = 51 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #17: empty */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 101 */
	{    0,    0,    0,    0}, /* LiteralValue: empty = 108 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{   10,    0,    0,    0}, /* TwigExpr: empty = 48 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #18: false_ */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 101 */
	{    0,    0,    0,    0}, /* LiteralValue: false_ = 107 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{   20,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #19: flwr(nil, orderby(orderspecs(empty, nil), empty)) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, OrdWhereExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #20: flwr(nil, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 4 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #21: following(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #22: following_sibling(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #23: for_(forbind(forvars(var, nil), empty), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, OptVar), CoreExpr), OptBindExpr) = 6 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #24: forbind(forvars(var, nil), empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #25: forvars(var, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #26: fun_decl(nil, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionDecl: fun_decl(ParamList, FunctionBody) = 600 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #27: fun_decls(fun_decl(nil, empty), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionDecls: fun_decls(FunctionDecl, FunctionDecls) = 71 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #28: if_(empty, then_else(empty, empty)) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr)) = 13 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #29: let(letbind(var, empty), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr) = 7 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #30: letbind(var, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #31: lit_dbl */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 101 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_dbl = 105 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{   20,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #32: lit_dec */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 101 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_dec = 104 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{   20,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #33: lit_int */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 101 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_int = 103 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{   20,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #34: lit_str */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 101 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_str = 102 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{   20,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #35: locsteps(preceding(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(preceding(seqtype), CoreExpr) = 39 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #36: locsteps(parent(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(parent(seqtype), CoreExpr) = 38 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #37: locsteps(so_select_wide(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(so_select_wide(seqtype), CoreExpr) = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #38: locsteps(following_sibling(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(following_sibling(seqtype), CoreExpr) = 37 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #39: locsteps(attribute(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(attribute(seqtype), CoreExpr) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #40: locsteps(self(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(self(seqtype), CoreExpr) = 41 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #41: locsteps(so_select_narrow(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(so_select_narrow(seqtype), CoreExpr) = 42 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #42: locsteps(descendant_or_self(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(descendant_or_self(seqtype), CoreExpr) = 35 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #43: locsteps(child(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(child(seqtype), CoreExpr) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #44: locsteps(descendant(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(descendant(seqtype), CoreExpr) = 34 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #45: locsteps(ancestor(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(ancestor(seqtype), CoreExpr) = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #46: locsteps(ancestor_or_self(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(ancestor_or_self(seqtype), CoreExpr) = 31 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #47: locsteps(preceding_sibling(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(preceding_sibling(seqtype), CoreExpr) = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #48: locsteps(following(seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: locsteps(following(seqtype), CoreExpr) = 36 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #49: main(nil, empty) */
	{0},
	{    0,    0,    0,    0}, /* Query: main(FunctionDecls, CoreExpr) = 1 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #50: nil */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: nil = 8 */
	{   10,    0,    0,    0}, /* OptVar: nil = 201 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: nil = 500 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionDecls: nil = 70 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* ParamList: nil = 601 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #51: orderby(orderspecs(empty, nil), empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrdWhereExpr: orderby(OrderSpecs, CoreExpr) = 10 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #52: ordered(empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: ordered(CoreExpr) = 18 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #53: orderspecs(empty, orderspecs(empty, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, OrderSpecs) = 301 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #54: orderspecs(empty, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, nil) = 300 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #55: param(seqtype, var) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunParam: param(seqtype, var) = 604 */
},
{ /* state #56: params(param(seqtype, var), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* ParamList: params(FunParam, ParamList) = 602 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #57: parent(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #58: pi(empty, empty) */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: TwigExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: pi(CoreExpr, CoreExpr) = 55 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #59: preceding(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #60: preceding_sibling(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #61: recursion(var, seed(empty, empty)) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: recursion(var, seed(CoreExpr, CoreExpr)) = 72 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #62: seed(empty, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #63: self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #64: seq(empty, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, CoreExpr) = 15 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SeqCoreExpr: seq(CoreExpr, CoreExpr) = 17 */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #65: seq(empty, seq(empty, empty)) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, SeqCoreExpr) = 14 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SeqCoreExpr: seq(CoreExpr, SeqCoreExpr) = 16 */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #66: seqcast(seqtype, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: seqcast(seqtype, CoreExpr) = 22 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #67: seqtype */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #68: so_select_narrow(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #69: so_select_wide(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #70: tag */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* TagName: tag = 400 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #71: text(empty) */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: TwigExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: text(CoreExpr) = 53 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #72: then_else(empty, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #73: true_ */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 101 */
	{    0,    0,    0,    0}, /* LiteralValue: true_ = 106 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{   20,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #74: twig_seq(empty, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* TwigSeq: twig_seq(TwigExpr, TwigSeq) = 46 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #75: typesw(empty, cases(case_(seqtype, empty), default_(empty))) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: typesw(CoreExpr, cases(case_(seqtype, CoreExpr), default_(CoreExpr))) = 20 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #76: unordered(empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: unordered(CoreExpr) = 19 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #77: var */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{   10,    0,    0,    0}, /* Atom: var = 100 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptVar: var = 200 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{   20,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #78: where(empty, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* WhereExpr: where(CoreExpr, WhereExpr) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #79: where(empty, orderby(orderspecs(empty, nil), empty)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrdWhereExpr: where(CoreExpr, OrdWhereExpr) = 9 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #80: xrpc(empty, apply(nil)) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: xrpc(CoreExpr, apply(FunctionArgs)) = 61 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TwigSeq: TwigExpr = 47 */
	{    0,    0,    0,    0}, /* TwigExpr: CoreExpr = 49 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 401 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 502 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 603 */
	{    0,    0,    0,    0}, /* (none) */
},
};

char * PFcore2alg_state_string[] = {
" not a state", /* state 0 */
	"ancestor(seqtype)", /* state #1 */
	"ancestor_or_self(seqtype)", /* state #2 */
	"apply(nil)", /* state #3 */
	"arg(empty, nil)", /* state #4 */
	"attr(tag, empty)", /* state #5 */
	"attribute(seqtype)", /* state #6 */
	"case_(seqtype, empty)", /* state #7 */
	"cases(case_(seqtype, empty), default_(empty))", /* state #8 */
	"cast(seqtype, empty)", /* state #9 */
	"child(seqtype)", /* state #10 */
	"comment(empty)", /* state #11 */
	"default_(empty)", /* state #12 */
	"descendant(seqtype)", /* state #13 */
	"descendant_or_self(seqtype)", /* state #14 */
	"doc(empty)", /* state #15 */
	"elem(tag, empty)", /* state #16 */
	"empty", /* state #17 */
	"false_", /* state #18 */
	"flwr(nil, orderby(orderspecs(empty, nil), empty))", /* state #19 */
	"flwr(nil, empty)", /* state #20 */
	"following(seqtype)", /* state #21 */
	"following_sibling(seqtype)", /* state #22 */
	"for_(forbind(forvars(var, nil), empty), nil)", /* state #23 */
	"forbind(forvars(var, nil), empty)", /* state #24 */
	"forvars(var, nil)", /* state #25 */
	"fun_decl(nil, empty)", /* state #26 */
	"fun_decls(fun_decl(nil, empty), nil)", /* state #27 */
	"if_(empty, then_else(empty, empty))", /* state #28 */
	"let(letbind(var, empty), nil)", /* state #29 */
	"letbind(var, empty)", /* state #30 */
	"lit_dbl", /* state #31 */
	"lit_dec", /* state #32 */
	"lit_int", /* state #33 */
	"lit_str", /* state #34 */
	"locsteps(preceding(seqtype), empty)", /* state #35 */
	"locsteps(parent(seqtype), empty)", /* state #36 */
	"locsteps(so_select_wide(seqtype), empty)", /* state #37 */
	"locsteps(following_sibling(seqtype), empty)", /* state #38 */
	"locsteps(attribute(seqtype), empty)", /* state #39 */
	"locsteps(self(seqtype), empty)", /* state #40 */
	"locsteps(so_select_narrow(seqtype), empty)", /* state #41 */
	"locsteps(descendant_or_self(seqtype), empty)", /* state #42 */
	"locsteps(child(seqtype), empty)", /* state #43 */
	"locsteps(descendant(seqtype), empty)", /* state #44 */
	"locsteps(ancestor(seqtype), empty)", /* state #45 */
	"locsteps(ancestor_or_self(seqtype), empty)", /* state #46 */
	"locsteps(preceding_sibling(seqtype), empty)", /* state #47 */
	"locsteps(following(seqtype), empty)", /* state #48 */
	"main(nil, empty)", /* state #49 */
	"nil", /* state #50 */
	"orderby(orderspecs(empty, nil), empty)", /* state #51 */
	"ordered(empty)", /* state #52 */
	"orderspecs(empty, orderspecs(empty, nil))", /* state #53 */
	"orderspecs(empty, nil)", /* state #54 */
	"param(seqtype, var)", /* state #55 */
	"params(param(seqtype, var), nil)", /* state #56 */
	"parent(seqtype)", /* state #57 */
	"pi(empty, empty)", /* state #58 */
	"preceding(seqtype)", /* state #59 */
	"preceding_sibling(seqtype)", /* state #60 */
	"recursion(var, seed(empty, empty))", /* state #61 */
	"seed(empty, empty)", /* state #62 */
	"self(seqtype)", /* state #63 */
	"seq(empty, empty)", /* state #64 */
	"seq(empty, seq(empty, empty))", /* state #65 */
	"seqcast(seqtype, empty)", /* state #66 */
	"seqtype", /* state #67 */
	"so_select_narrow(seqtype)", /* state #68 */
	"so_select_wide(seqtype)", /* state #69 */
	"tag", /* state #70 */
	"text(empty)", /* state #71 */
	"then_else(empty, empty)", /* state #72 */
	"true_", /* state #73 */
	"twig_seq(empty, empty)", /* state #74 */
	"typesw(empty, cases(case_(seqtype, empty), default_(empty)))", /* state #75 */
	"unordered(empty)", /* state #76 */
	"var", /* state #77 */
	"where(empty, empty)", /* state #78 */
	"where(empty, orderby(orderspecs(empty, nil), empty))", /* state #79 */
	"xrpc(empty, apply(nil))", /* state #80 */
};
char *PFcore2alg_ntname[] = {
	"Error: Nonterminals are > 0",
	"Query",
	"CoreExpr",
	"Atom",
	"LiteralValue",
	"OptBindExpr",
	"OptVar",
	"OrdWhereExpr",
	"WhereExpr",
	"OrderSpecs",
	"SeqCoreExpr",
	"TwigSeq",
	"TwigExpr",
	"TagName",
	"FunctionArgs",
	"FunctionArg",
	"FunctionDecls",
	"FunctionDecl",
	"ParamList",
	"FunctionBody",
	"FunParam",
	0
};

short PFcore2alg_closure[21][21] = {
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    2,    2,    2,    0,    0,    0,    0,    0,
	     0,    0,    2,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    3,    3,    0,    0,    0,    0,    0,
	     0,    0,   45,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,  101,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,   12,   12,   12,    0,    0,    0,    0,    0,
	     0,    0,   12,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,   47,   47,   47,    0,    0,    0,    0,    0,
	     0,    0,   47,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,   49,   49,   49,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,  401,  401,  401,    0,    0,    0,    0,    0,
	     0,    0,  401,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,  502,  502,  502,    0,    0,    0,    0,    0,
	     0,    0,  502,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,  603,  603,  603,    0,    0,    0,    0,    0,
	     0,    0,  603,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
};
#line 293 "core2alg.brg"


/** Algebra equivalent of a Core tree node */
#define A(p) ((p)->alg)

#define SEEN(n) ((n)->bit_dag)

/** Maximum number of pattern leaves */
#define MAX_KIDS 10

/** mnemonic algebra constructors */
#include "logical_mnemonic.h"

struct map_rel_info_t {
    PFla_op_t   *map;   /* map relation */
    unsigned int count; /* column counter of the map relation */
    unsigned int dir;   /* sort direction of the columns in the
                           map relation */
};
typedef struct map_rel_info_t map_rel_info_t;

/**
 * Current map relation
 */
#define MAP (((map_rel_info_t *) PFarray_top (ctx->mapping))->map)

/**
 * Attribute counter of current map relation
 */
#define MAP_COUNT (((map_rel_info_t *) PFarray_top (ctx->mapping))->count)

/**
 * Sort direction of the columns
 * of the current map relation
 */
#define MAP_DIR (((map_rel_info_t *) PFarray_top (ctx->mapping))->dir)

/**
 * Remember the result of the initial algebra translation
 * (@a rel and @a frag) for core operators @a core
 * whose algebra translation is inferred a second time.
 */
struct core2alg_map_t {
    PFcnode_t *core;
    PFla_op_t *rel;
    PFarray_t *frag;
};
typedef struct core2alg_map_t core2alg_map_t;

#define CORE2ALG_MAP_AT(i) (*(core2alg_map_t *) PFarray_at (ctx->core2alg_map, \
                                                            (i)))

/**
 * structure to collect the active recursive functions
 * and their current ``unfold'' count
 */
struct fun_active_t {
    PFcnode_t   *node;
    unsigned int count;
};
typedef struct fun_active_t fun_active_t;

#define FUN_ACTIVE_AT(i) (*((fun_active_t *) PFarray_at (ctx->fun_active, (i))))

/**
 * Store global context information
 */
struct core2alg_ctx_t {
    PFarray_t   *env;          /* Variable environment (Gamma in our papers) */
    PFla_op_t   *loop;         /* Current loop relation */
    PFla_op_t   *side_effects; /* list of side effects (error or trace nodes) */
    PFarray_t   *mapping;      /* Mapping stack */
    bool         ordering;     /* ordering mode indicator */
    unsigned int seq_count;    /* sequence item counter (for long sequences) */

    PFarray_t   *fun_args;     /* Algebraic representations of the function
                                  arguments. (Aligned with the PFfun_t function
                                  parameters) */
    unsigned int recursion_depth; /* depth of how often we unfold a recursive
                                     function*/
    PFarray_t   *fun_active;   /* List recording all active user-defined
                                  functions as well as their unfold count. */
    PFarray_t   *core2alg_map; /* List of core to algebra translation mappings.
                                  (Used to clean up the side effects of a
                                   recursive traversal of the core tree.) */
};
typedef struct core2alg_ctx_t core2alg_ctx_t;

#define ENV          (ctx->env)
#define LOOP         (ctx->loop)
#define SIDE_EFFECTS (ctx->side_effects)
#define ORDERING     (ctx->ordering)
#define SEQ_COUNT    (ctx->seq_count)
#define FUN_ARGS     (ctx->fun_args)
#define CORE2ALG_MAP (ctx->core2alg_map)



/* Constructor for a path step */
static struct PFla_pair_t locstep (core2alg_ctx_t *ctx,
                                   PFalg_axis_t axis, PFty_t seqty,
                                   struct PFla_pair_t p);

/* Constructor for environment entry */
static PFla_env_t enventry (PFvar_t *var, PFla_op_t *rel,
                            PFla_op_t *map, PFarray_t *doc);

/* worker to implement type tests */
static PFla_op_t *type_test (PFty_t ty, PFla_pair_t e, PFla_op_t *loop);

/* Extract all possible algebra types from the XQuery type.  */
static PFalg_simple_type_t PFalg_type (PFty_t ty);

/* Extract occurrence indicator from the XQuery type.  */
static PFalg_occ_ind_t PFalg_type_occ (PFty_t ty);


typedef PFla_op_t * (rec_strategy_t) (
                                 int strategy,
                                 PFla_op_t *body,
                                 PFla_op_t *seed,
                                 PFla_op_t *res_seed,
                                 PFla_op_t *base,
                                 PFla_op_t *base_res,
                                 bool x_used,
                                 bool loop_used,
                                 PFla_op_t *old_loop,
                                 PFla_op_t *base_loop,
                                 PFla_op_t *side_effects);

/* recursion translation strategy for SQL */
static PFla_op_t *recursion_sql (int strategy,
                                 PFla_op_t *body,
                                 PFla_op_t *seed,
                                 PFla_op_t *res_seed,
                                 PFla_op_t *base,
                                 PFla_op_t *base_res,
                                 bool x_used,
                                 bool loop_used,
                                 PFla_op_t *old_loop,
                                 PFla_op_t *base_loop,
                                 PFla_op_t *side_effects);

/* recursion translation strategy for Monet */
static PFla_op_t *recursion_mil (int strategy,
                                 PFla_op_t *body,
                                 PFla_op_t *seed,
                                 PFla_op_t *res_seed,
                                 PFla_op_t *base,
                                 PFla_op_t *base_res,
                                 bool x_used,
                                 bool loop_used,
                                 PFla_op_t *old_loop,
                                 PFla_op_t *base_loop,
                                 PFla_op_t *side_effects);

enum PFoutput_format_t PFoutput_format;

/**
 * Reducer function. This is the heart of this source file. It
 * contains all the action code for the above burg patterns.
 */
static void
reduce (core2alg_ctx_t *ctx, PFcnode_t * p, int goalnt)
{
    int           rule;           /* rule number that matches for this node */
    short        *nts;            /* target non-terminals for the leaf nodes of
                                     the current rule */
    PFcnode_t    *kids[MAX_KIDS]; /* leaf nodes of this rule */
    bool          topdown;        /* is this a top-down rule? */
    PFla_op_t    *rel  = NULL;
    PFarray_t    *frag = NULL;

    /* guard against too dep recursion */
    PFrecursion_fence();

    assert(p);

    /* determine rule that matches for this non-terminal */
    rule = PFcore2alg_rule (STATE_LABEL (p), goalnt);

    assert(rule);

    /* initialize the kids[] vector */
    for (unsigned short i = 0; i < MAX_KIDS; i++)
        kids[i] = NULL;

    /*
     * prepare recursive traversal: get information on leaf nodes of
     * this rule
     */
    nts = PFcore2alg_nts[rule];
    PFcore2alg_kids (p, rule, kids);

    /* In case we recursively generate the algebra plan
       we need to record the mappings that have changed
       to ensure that we are able to clean up the side
       effects again. */
    if (CORE2ALG_MAP) {
        rel  = A(p).rel;
        frag = A(p).frag;
    }

    /*
     * Few translation rules require top-down processing. We figure
     * them out here and skip the recursive compilation. The respective
     * rules will explicitly trigger the compilation of their kids.
     */
    switch (rule) {
        /* Query:              main (FunctionDecls, CoreExpr) */
        case 1:

        /* CoreExpr:           flwr (OptBindExpr, WhereExpr) */
        case 4:

        /* CoreExpr:           flwr (OptBindExpr, OrdWhereExpr) */
        case 5:

        /* OptBindExpr:        for_ (forbind (forvars (var, nil),
                                              CoreExpr),
                                     CoreExpr) */
        case 6:

        /* OptBindExpr:        let (letbind (var, CoreExpr), CoreExpr) */
        case 7:

        /* OrdWhereExpr:       where (CoreExpr, OrdWhereExpr) */
        case 9:

        /* OrdCoreExpr:        orderby (OrderSpecs, CoreExpr) */
        case 10:

        /* WhereExpr:          where (CoreExpr, WhereExpr) */
        case 11:

        /* OrderSpecs:         orderspecs (CoreExpr, nil) */
        case 300:

        /* OrderSpecs:         orderspecs (CoreExpr, OrderSpecs) */
        case 301:

        /* CoreExpr:           if_ (CoreExpr, then_else (CoreExpr, CoreExpr)) */
        case 13:

        /* CoreExpr:           seq (CoreExpr, SeqCoreExpr) */
        case 14:

        /* SeqCoreExpr:        seq (CoreExpr, SeqCoreExpr) */
        case 16:

        /* SeqCoreExpr:        seq (CoreExpr, CoreExpr) */
        case 17:

        /* CoreExpr:           ordered (CoreExpr) */
        case 18:

        /* CoreExpr:           unordered (CoreExpr) */
        case 19:

        /* CoreExpr:           typesw (CoreExpr,
                                       cases (case_ (seqtype,
                                                     CoreExpr),
                                              default_ (CoreExpr))) */
        case 20:

        /* CoreExpr:           apply (FunctionArgs) */
        case 60:

        /* CoreExpr:           xrpc (CoreExpr, apply (FunctionArgs)) */
        case 61:

        /* FunctionArgs:       arg (FunctionArg, FunctionArgs) */
        case 501:

        /* CoreExpr:           recursion (var, seed (CoreExpr, CoreExpr)) */
        case 72:
            topdown = true;
            break;

        default:
            topdown = false;
    }

    /*
     * Recursively invoke compilation.  This means bottom-up compilation.
     */
    if (!topdown)
        for (unsigned short i = 0; nts[i]; i++)
            reduce (ctx, kids[i], nts[i]);

    switch (rule) {

        /* Query:              main (FunctionDecls, CoreExpr) */
        case 1:
            /* TOPDOWN */

            /*
             * Only the real XQuery expression is of interest, not the
             * function declaration part. Apply serialize_seq() to the
             * XQuery Core result.
             */
            reduce (ctx, kids[1], nts[1]);
            A(p) = (PFla_pair_t) {
                     .rel = serialize_seq (PFla_side_effects (
                                               SIDE_EFFECTS,
                                               PFla_set_to_la (A(R(p)).frag)),
                                           A(R(p)).rel, col_pos, col_item),
                     .frag = NULL };
            break;

        /* Query:              CoreExpr */
        case 2:
            /*
             * Defining CoreExpr also as a top-level non-terminal
             * allows us to recursively invoke matching for function
             * calls.
             */
            break;

        /* CoreExpr:           Atom */
        case 3:
            break;

        /* Atom:               var */
        case 100:
        {
            /*
             * Reference to variable, so look it up in the environment. It
             * was inserted into the environment by a let or for expression.
             *
             * ---------------------------------------------------------------
             * ENV, (v -> q(v)) e env, loop: v => (q(v), 0)
             */
            unsigned int i;
            PFla_op_t *var_rel;

            /*
             * look up the variable in the environment;
             * since it has already been ensured beforehand, that
             * each variable was declared before being used, we are
             * guarenteed to find the required binding in the
             * environment
             */

            /*
             * The variable representations in the variable environment
             * consist of 4 parts:
             *  - var: the variable name
             *  - rel: the initial relation representing the variable
             *  - map: the mapping information needed to map the relation
             *         rel to the current scope
             *  - frag: the document fragment information
             *
             * In constrast to the variable mapping described in our
             * papers we do not map the relation representing the variable
             * in each new scope, but first create a chain of mapping
             * joins. The variable representations therefore have to
             * be mapped to the current scope -- if necessary
             * (map != NULL) -- (via map) only during look-up (here).
             *
             * The reason is that this makes the optimization of such
             * chains of joins easier in later phases.
             */
            for (i = 0; i < PFarray_last (ENV); i++) {
                PFla_env_t e = *((PFla_env_t *) PFarray_at (ENV, i));

                if (p->sem.var == e.var) {
                    if (!e.map)
                        var_rel = e.rel;
                    else
                        var_rel = project (
                                      eqjoin (
                                          e.rel,
                                          e.map,
                                          col_iter,
                                          col_outer),
                                      proj (col_iter, col_inner),
                                      proj (col_pos,  col_pos),
                                      proj (col_item, col_item));

                    A(p) = (struct  PFla_pair_t) { .rel  = var_rel,
                                                   .frag = e.frag };
                    break;
                }
            }

            assert (A(p).rel); assert (A(p).frag);

        } break;

        /* Atom:               LiteralValue */
        case 101:
            break;

        /* LiteralValue:       lit_str */
        case 102:
        {
            /*
             *  -------------------------------------------------------------
             *                   /        / pos | item \     \
             *  env, loop: c => | loop X | -----+------ | , 0 |
             *                   \        \   1 |   c  /     /
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = attach (
                                attach (LOOP,
                                        col_pos, lit_nat (1)),
                                col_item, lit_str (p->sem.str)),
                     .frag = PFla_empty_set () };
        } break;

        /* LiteralValue:       lit_int */
        case 103:
        {
            /*
             *  -------------------------------------------------------------
             *                   /        / pos | item \     \
             *  env, loop: c => | loop X | -----+------ | , 0 |
             *                   \        \   1 |   c  /     /
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = attach (
                                attach (LOOP,
                                        col_pos, lit_nat (1)),
                                col_item, lit_int (p->sem.num)),
                     .frag = PFla_empty_set () };
        } break;

        /* LiteralValue:       lit_dec */
        case 104:
        {
            /*
             *  -------------------------------------------------------------
             *                   /        / pos | item \     \
             *  env, loop: c => | loop X | -----+------ | , 0 |
             *                   \        \   1 |   c  /     /
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = attach (
                                attach (LOOP,
                                        col_pos, lit_nat (1)),
                                col_item, lit_dec (p->sem.dec)),
                     .frag = PFla_empty_set () };
        } break;

        /* LiteralValue:       lit_dbl */
        case 105:
        {
            /*
             *  -------------------------------------------------------------
             *                   /        / pos | item \     \
             *  env, loop: c => | loop X | -----+------ | , 0 |
             *                   \        \   1 |   c  /     /
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = attach (
                                attach (LOOP,
                                        col_pos, lit_nat (1)),
                                col_item, lit_dbl (p->sem.dbl)),
                     .frag = PFla_empty_set () };
        } break;


        /* LiteralValue:       true_ */
        case 106:
        {
            /*
             *  -------------------------------------------------------------
             *                   /        / pos | item \     \
             *  env, loop: c => | loop X | -----+------ | , 0 |
             *                   \        \   1 |   c  /     /
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = attach (
                                attach (LOOP,
                                        col_pos, lit_nat (1)),
                                col_item, lit_bln (true)),
                     .frag = PFla_empty_set () };
        } break;

        /* LiteralValue:       false_ */
        case 107:
        {
            /*
             *  -------------------------------------------------------------
             *                   /        / pos | item \     \
             *  env, loop: c => | loop X | -----+------ | , 0 |
             *                   \        \   1 |   c  /     /
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = attach (
                                attach (LOOP,
                                        col_pos, lit_nat (1)),
                                col_item, lit_bln (false)),
                     .frag = PFla_empty_set () };
        } break;

        /* LiteralValue:       empty */
        case 108:
        {
            /*
             *  -------------------------------------------------------------
             *                       iter | pos | item
             *  env, loop: empty => ------+-----+------ , 0
             *
             */
            PFalg_schema_t schema;
            schema.count = 3;
            schema.items = PFmalloc (3 * sizeof (PFalg_schema_t));

            /* We know that iter and pos would have type nat.
               For item on the other side we have no type. */
            schema.items[0].name = col_iter;
            schema.items[0].type = aat_nat;
            schema.items[1].name = col_pos;
            schema.items[1].type = aat_nat;
            schema.items[2].name = col_item;
            schema.items[2].type = 0;

            A(p) = (struct  PFla_pair_t) {
                     .rel = PFla_empty_tbl_ (schema),
                     .frag = PFla_empty_set () };
        } break;

        /* CoreExpr:           flwr (OptBindExpr, WhereExpr) */
        case 4:
        /* CoreExpr:           flwr (OptBindExpr, OrdWhereExpr) */
        case 5:
        /* Note: Rule 4 and Rule 5 differ with respect to the ordering.
                 Adjust the code if the rule number changes!!! */
        {   /* TOPDOWN */
            /**
             * The flwr expression maps back the result of
             * one or more nested for-loops at once. It therefore
             * distincts between the ordering mode ordered and
             * unordered.
             *
             * unordered:
             *
             *        pi_(iter, pos:pos1, item)
             *        |
             *       row_(pos1:<iter, pos>/outer)
             *        |
             *       |X|_(iter, inner)
             *      /  \
             *    /      \
             * result    map
             *
             * ordered:
             *
             *        pi_(iter, pos:pos1, item)
             *        |
             *       row_(pos1:<sort_0, sort_1, ..., sort_n, pos>/outer)
             *        |
             *       |X|_(iter, inner)
             *      /  \
             *    /      \
             * result    map
             *
             * In the ordered case each for-loop adds one sort criterion
             * to the map relation (sort_0, sort_1, ..., sort_n)
             *      or if an order by is present it removes all sort
             * criteria introduced by the for-loop and adds for each
             * order specification a sort column (sort_0, sort_1,
             * ..., sort_n)
             */

            /* store current state information */
            PFla_op_t   *old_loop      = LOOP;
            PFarray_t    *old_env      = ENV;

            /* start with empty map relation */
            *((map_rel_info_t *) PFarray_add (ctx->mapping))
                = (map_rel_info_t) { .map = NULL, .count = 0, .dir = 0 };

            /* initiate translation of bindings */
            reduce (ctx, kids[0], nts[0]);

            /* as side effect from the bindings a possibly
               new loop relation is input to the return expression */

            /* initiate translation of return expression */
            reduce (ctx, kids[1], nts[1]);

            /* the map relation has been changed by a for loop
               (and an order by) and therefore backmapping is
               required */
            if (MAP) {
                /* Note that ordering mode has no effect on a FLWOR
                   expression if an order by clause is present,
                   since order by takes precedence over ordering mode. */
                if (!ORDERING && rule == 4 /* without ordering */)
                    /* in unordered context the new numbering only
                       needs to respect the sequence order
                       (in- and outside the flwor block). */
                    A(p) = (struct PFla_pair_t) {
                            .rel = project (rank (eqjoin (A(R(p)).rel,
                                                          MAP,
                                                          col_iter,
                                                          col_inner),
                                                  col_pos1,
                                                  sortby (col_iter, col_pos)),
                                            proj (col_iter, col_outer),
                                            proj (col_pos, col_pos1),
                                            proj (col_item, col_item)),
                            .frag = A(R(p)).frag };
                else {
                    /**
                     * If an order by clause is present we need
                     * the iter column as a row ranking criterion
                     * (sort_0, sort_1, ..., sort_n, iter, pos).
                     *
                     * Without an order by the combination of sort
                     * columns and partitioning column outer already
                     * contain the information of column iter. Thus
                     * the row numbering needs to sort on:
                     * (sort_0, sort_1, ..., sort_n, pos).
                     */
                    /* create sortby column list: */
                    PFord_ordering_t sortby = PFordering ();
                    if (rule == 5 /* with ordering */)
                    {
                        PFalg_col_t cur;

                        /* don't include columns inner and outer */
                        /* starting from column sort add consecutive
                           columns ... */
                        for (unsigned int i = 0; i < MAP_COUNT - 2; i++) {
                            cur = col_sort << i;
                            sortby = PFord_refine (sortby,
                                                   cur,
                                                   cur & MAP_DIR
                                                   ? DIR_DESC : DIR_ASC);
                        }

                        /* ... and complete sortby list with columns
                           iter and  pos */
                        sortby = PFord_refine (sortby, col_iter, DIR_ASC);
                        sortby = PFord_refine (sortby, col_pos, DIR_ASC);
                    } else {
                        /* don't include columns inner and outer */
                        /* starting from column sort add consecutive
                           columns ... */
                        for (unsigned int i = 0; i < MAP_COUNT - 2; i++)
                            sortby = PFord_refine (sortby,
                                                   col_sort << i,
                                                   DIR_ASC);

                        /* ... and complete sortby list with column pos */
                        sortby = PFord_refine (sortby, col_pos, DIR_ASC);
                    }

                    A(p) = (struct PFla_pair_t) {
                            .rel = project (rank (eqjoin (A(R(p)).rel,
                                                          MAP,
                                                          col_iter,
                                                          col_inner),
                                                  col_pos1,
                                                  sortby),
                                            proj (col_iter, col_outer),
                                            proj (col_pos, col_pos1),
                                            proj (col_item, col_item)),
                            .frag = A(R(p)).frag };
                }
            } else
                A(p) = A(R(p));

            /* restore loop relation */
            LOOP = old_loop;
            /* restore map relation and its column counter */
            PFarray_del (ctx->mapping);
            /* restore old environment */
            ENV = old_env;

        }   break;

        /* OptBindExpr:        for_ (forbind (forvars (var, OptVar),
                                              CoreExpr),
                                     OptBindExpr) */
        case 6:
        {   /* TOPDOWN */

            /*
             * for $v in e1 return e2                    OR
             * for $v at $p in e1 return e2
             *
             * Given the current environment (which may or may not contain
             * bindings), the current loop relation and delta with e1
             * already compiled:
             * - declare variable $v by loop lifting the result of q1,
             *(- declare variable $p if present)
             * - create a new loop relation and
             * - a new var_map relation,
             * - as the for expression opens up a scope, update all existing
             *   bindings to the new scope and add the binding of $v
             * Given the updated environment and the new loop relation
             * compile e2. Return the (possibly intermediate) result.
             *
             * env,loop: e1 => q1,delta1
             *
             *        pos
             * q(v) = --- X proj_iter:inner,item(row_inner:<iter,pos> q1)
             *         1
             *
             * loop(v) = proj_iter(q(v))
             *
             * var_map = proj_outer:iter,inner(row_inner:<iter,pos> q1)
             *
             * updated_env,(v->q(v)) e updated_env,loop(v): e2 => (q2,delta2)
             * -----------------------------------------------------------------
             * env,loop: for &v in e1 return e2 =>
             * (proj_iter:outer, pos:pos1,item
             *   (row_pos1:<iter,pos>/outer (q2 |X| (iter = inner) var_map)),
             *  delta2)
             */
            PFla_op_t   *var;
            PFla_op_t   *opt_var;
            PFla_op_t   *var_map;
            PFla_op_t   *rowid;
            unsigned int  i;
            PFla_env_t   e;
            PFla_op_t   *new_map;
            /* save old environment */
            PFarray_t  *old_env = ENV;

            /* initiate translation of e1 */
            reduce (ctx, kids[1], nts[1]);

            /*
             * Add 'real' positions and the new iter values.
             * (Note: We add the positions outside as some proxy rewrites
             *        expect that no rownum can escape its 'scope'. The
             *        result of the rownum operator is discarded in the
             *        first icols optimization if no positional variable
             *        exists.)
             */
            rowid = rowid (rownum (A(LR(p)).rel,
                                   col_pos1,
                                   sortby (col_pos),
                                   col_iter),
                           col_inner);

            /* translate $v */
            var = attach (project (rowid,
                                   proj (col_iter, col_inner),
                                   proj (col_item, col_item)),
                          col_pos, lit_nat (1));

            /* create new environment */
            ENV = PFarray (sizeof (PFla_env_t), 50);

            /* insert $v and "its document" into NEW environment */
            *((PFla_env_t *) PFarray_add (ENV))
                = enventry (LLL(p)->sem.var, var, NULL, A(LR(p)).frag);

            /* create new loop operator */
            LOOP = project (var, proj (col_iter, col_iter));

            /* create var_map relation. */
            var_map = project (rowid,
                               proj (col_outer, col_iter),
                               proj (col_sort, col_pos),
                               proj (col_inner, col_inner));

            /*
             * Handle optional variable ($p).
             * (Note: The rownum () routine was used to create
             *        the 'item' column of $p's operator. Since this
             *        column must be of type integer instead of nat, we
             *        cast it accordingly.)
             */
            if (LLR(p)->kind == c_var) {
                assert (LLR(p)->sem.var);
                opt_var = attach (project (cast (rowid,
                                                 col_cast,
                                                 col_pos1,
                                                 aat_int),
                                           proj (col_iter, col_inner),
                                           proj (col_item, col_cast)),
                                  col_pos, lit_nat (1));

                /* insert $p into NEW environment */
                *((PFla_env_t *) PFarray_add (ENV)) =
                    enventry (LLR(p)->sem.var,
                              opt_var,
                              NULL,
                              PFla_empty_set ());
            }

            /* update all variable bindings in old environment and put
             * them into new environment */
            for (i = 0; i < PFarray_last (old_env); i++) {
                e = *((PFla_env_t *) PFarray_at (old_env, i));

                if (!e.map)
                    new_map = project (var_map,
                                       proj (col_outer, col_outer),
                                       proj (col_inner, col_inner));
                else
                    new_map = project (
                                  eqjoin (
                                      project (
                                          e.map,
                                          proj (col_iter, col_inner),
                                          proj (col_outer, col_outer)),
                                      project (
                                          var_map,
                                          proj (col_iter2, col_outer),
                                          proj (col_inner, col_inner)),
                                      col_iter,
                                      col_iter2),
                                  proj (col_outer, col_outer),
                                  proj (col_inner, col_inner));

                *((PFla_env_t *) PFarray_add (ENV)) =
                    enventry (e.var, e.rel, new_map, e.frag);
            }

            if (!MAP) {
                /* create a first backmapping relation */
                MAP = var_map;
                MAP_COUNT = 3;
            } else {
                /* extend the backmapping relation map with
                 * (a) position information of the for-loop input sequence and
                 * (b) the current iteration values */

                MAP_COUNT++;
                PFalg_proj_t *cols = PFmalloc (MAP_COUNT *
                                               sizeof (PFalg_proj_t));
                /* column outer remains the same */
                cols[0].new = col_outer;
                cols[0].old = col_outer;
                /* column iter1 becomes the new inner column */
                cols[1].new = col_inner;
                cols[1].old = col_iter1;
                /* copy all old sort columns */
                for (unsigned i = 2; i < MAP_COUNT - 1; i++)
                    cols[i].new =
                    cols[i].old = col_sort << (i - 2);
                /* we now have on additional sort column generated
                   from column pos */
                /* the first sort criterion is column sort itself */
                cols[MAP_COUNT -1].new = col_sort << (MAP_COUNT - 3);
                cols[MAP_COUNT -1].old = col_pos;

                MAP = PFla_project_ (
                          eqjoin (MAP,
                                  project (rowid,
                                           proj (col_iter1, col_inner),
                                           proj (col_iter, col_iter),
                                           proj (col_pos, col_pos)),
                                  col_inner,
                                  col_iter),
                          MAP_COUNT, cols);
            }

            /* translate e2 under the specified conditions (updated
             * environment, loop(v))
             */
            reduce (ctx, kids[2], nts[2]);

            /* compute result using old env and old loop. */
            /* backmapping is now done in flwr
            A(p) = (struct PFla_pair_t) {
                     .rel = project (rownum (eqjoin(A(R(p)).rel,
                                                    var_map,
                                                    col_iter,
                                                    col_inner),
                                             col_pos1,
                                             sortby (col_sort, col_pos),
                                             col_outer),
                                     proj (col_iter, col_outer),
                                     proj (col_pos, col_pos1),
                                     proj (col_item, col_item)),
                     .frag = A(R(p)).frag };
            */
        } break;

        /* OptVar:             var */
        case 200:
            /* (will never be called anyway, Rule 6 is top-down) */
            break;

        /* OptVar:             nil */
        case 201:
            /* (will never be called anyway, Rule 6 is top-down) */
            break;

        /* OptBindExpr:        let (letbind (var, CoreExpr), OptBindExpr) */
        case 7:
        {   /* TOPDOWN */

            /*
             * let $v := e1 return e2
             *
             * Translate e1 in the current environment, translate the
             * variable $v and add the resulting binding to the environment.
             * Compile e2 in the enriched environment.
             *
             * env,loop: e1 => (q1,delta1)
             *
             * env + (v -> q(v)),loop: e2 => (q2,delta2)
             * -----------------------------------------------------------------
             * env,loop: let $v := e1 return e2 => (q2,delta2)
             *
             * NB: Translation of variable is:
             *
             *         /pos                                                   \
             * q(v) = | --- X proj_iter:inner,item(row_inner:<iter,pos>(q(e1)))|
             *         \ 1                                                    /
             *
             */

            /* initiate translation of e1 */
            reduce (ctx, kids[0], nts[0]);

            /* assign result of e1 to $v, i.e. add resulting binding to
             * environment together with the currently live nodes
             */
            *((PFla_env_t *) PFarray_add (ENV))
                = enventry (LL(p)->sem.var, A(LR(p)).rel, NULL, A(LR(p)).frag);

            /* now translate remaining bindings in the new context */
            reduce (ctx, kids[1], nts[1]);

            /* let is embedded in a flwr expression - a
               return expression therefore is not needed
            A(p) = A(R(p));
            */
        } break;

        /* OptBindExpr:        nil */
        case 8:
            /* we don't need a translation -- it would be ignored anyway */
            break;

        /* OrdWhereExpr:       where (CoreExpr, OrdWhereExpr) */
        case 9:
        /* WhereExpr:          where (CoreExpr, WhereExpr) */
        case 11:
        {   /* TOPDOWN */

            /*
             * where e1 'return' e2
             *
             * NB: SEL: select those rows where column value = true
             *
             *
             * {..., $v -> q(v), ...},loop: e1 => q1,delta1
             *
             * map  = rowid_inner (proj_outer:iter (SEL item q1))
             * loop = proj_iter:inner (map)
             *
             * { ...,
             *   $v -> proj_iter:inner,pos,item (q(v)|X|(iter=outer)(map)),
             *   ...}, hen_loop: e2 => (q2,delta2)
             * -----------------------------------------------------------------
             * {..., $v -> q(v), ...},loop,delta: where e1 'return' e2 =>
             *                         proj_iter:outer,pos,item (
             *                             q2 |X|(iter=inner) (map)),
             *                         delta2)
             */
            PFarray_t *old_env;
            unsigned int i;
            PFla_env_t e;
            PFla_op_t *new_map,
                      *rowid,
                      *var_map;

            /* initiate translation of e1 */
            reduce (ctx, kids[0], nts[0]);

            /* prepare the loop relation for the then-branch */
            rowid    = rowid (select_ (A(L(p)).rel, col_item),
                              col_inner);
            /* create new loop operator */
            LOOP     = project (rowid, proj (col_iter, col_inner));
            /* create var_map relation. */
            var_map  = project (rowid,
                                proj (col_outer, col_iter),
                                proj (col_inner, col_inner));

            /* save old environment */
            old_env = ENV;

            /* update the environment for translation of e2 */
            ENV = PFarray (sizeof (PFla_env_t), 50);

            /* update all variable bindings in old environment and put
             * them into new environment */
            for (i = 0; i < PFarray_last (old_env); i++) {
                e = *((PFla_env_t *) PFarray_at (old_env, i));

                if (!e.map)
                    new_map = project (var_map,
                                       proj (col_outer, col_outer),
                                       proj (col_inner, col_inner));
                else
                    new_map = project (
                                  eqjoin (
                                      project (
                                          e.map,
                                          proj (col_iter, col_inner),
                                          proj (col_outer, col_outer)),
                                      project (
                                          var_map,
                                          proj (col_iter2, col_outer),
                                          proj (col_inner, col_inner)),
                                      col_iter,
                                      col_iter2),
                                  proj (col_outer, col_outer),
                                  proj (col_inner, col_inner));

                *((PFla_env_t *) PFarray_add (ENV)) =
                    enventry (e.var, e.rel, new_map, e.frag);
            }

            if (!MAP) {
                /* create a first backmapping relation */
                MAP = var_map;
                MAP_COUNT = 2;
            } else {
                /* extend the backmapping relation map with
                 * (a) position information of the for-loop input sequence and
                 * (b) the current iteration values */

                PFalg_proj_t *cols = PFmalloc (MAP_COUNT *
                                               sizeof (PFalg_proj_t));

                /* column outer remains the same */
                cols[0].new = col_outer;
                cols[0].old = col_outer;
                /* column iter1 becomes the new inner column */
                cols[1].new = col_inner;
                cols[1].old = col_iter1;

                for (unsigned i = 2; i < MAP_COUNT; i++)
                    cols[i].new =
                    cols[i].old = col_sort << (i - 2);

                MAP = PFla_project_ (
                          eqjoin (MAP,
                                  project (rowid,
                                           proj (col_iter1, col_inner),
                                           proj (col_iter, col_iter)),
                                  col_inner,
                                  col_iter),
                          MAP_COUNT, cols);
            }

            /* translate return expression */
            reduce (ctx, kids[1], nts[1]);

            A(p) = A(R(p));
        } break;

        /* OrdWhereExpr:       orderby (OrderSpecs, CoreExpr) */
        case 10:
        {   /* TOPDOWN */

            /* Having no map relation indicates that we have no
               for loop. We have at most one item and thus can
               skip sorting. */
            if (MAP) {
                /* throw away all sort criteria -- each orderspec
                   adds a new one instead */
                MAP = project (MAP,
                               proj (col_outer, col_outer),
                               proj (col_inner, col_inner));
                MAP_COUNT = 2;

                /* translate OrderSpecs */
                reduce (ctx, kids[0], nts[0]);
            }

            /* translate return expression */
            reduce (ctx, kids[1], nts[1]);

            A(p) = A(R(p));
        } break;

        /* WhereExpr:          CoreExpr */
        case 12:
            break;

        /* OrderSpecs:         orderspecs (CoreExpr, nil) */
        case 300:
        /* OrderSpecs:         orderspecs (CoreExpr, OrderSpecs) */
        case 301: /* NOTE: some code specific to rule 301 stands
                     at the end of this block */
        {   /* TOPDOWN */
            PFla_op_t          *sort_attr,
                               *empty_case;
            PFalg_proj_t       *cols;
            PFty_t              t;
            PFalg_simple_type_t algty;
            PFalg_col_t         sort_col;
            unsigned int        empty = 0;

            /* translate order expression */
            reduce (ctx, kids[0], nts[0]);

            sort_attr = project (A(L(p)).rel,
                                 proj (col_iter, col_iter),
                                 proj (col_item, col_item));

            /*
             * If we we know (from static typing) that all
             * iterations allways have a sequence length of 1
             * we do not need to add min/max values.
             */
            if (!PFty_subtype (L(p)->type, PFty_xs_anyItem ())) {
                t = PFty_prime (PFty_defn (L(p)->type));
                empty_case = difference (
                                 LOOP,
                                 project (A(L(p)).rel,
                                          proj (col_iter,
                                                col_iter)));
                /*
                 * Unfortunately, we only know how to cast atomic types
                 * into (exactly) one of our builtin atomic types. We
                 * cannot sensibly cast, e.g., into subtypes thereof.
                 */
                if (PFty_equality (t, PFty_xs_string ())) {
                    algty = aat_str;
                    empty_case = attach (empty_case, col_item, lit_str (""));
                }
                else if (PFty_equality (t, PFty_xs_integer ())) {
                    algty = aat_int;
                    empty_case = attach (empty_case, col_item, lit_int (0));
                }
                else if (PFty_subtype (t, PFty_xs_decimal ())) {
                    algty = aat_dec;
                    empty_case = attach (empty_case, col_item, lit_dec (0));
                }
                else if (PFty_equality (t, PFty_xs_double ())) {
                    algty = aat_dbl;
                    empty_case = attach (empty_case, col_item, lit_dbl (0));
                }
                else if (PFty_equality (t, PFty_xs_boolean ())) {
                    algty = aat_bln;
                    empty_case = attach (empty_case, col_item, lit_bln (true));
                }
                else if (PFty_equality (t, PFty_xs_datetime ())) {
                    algty = aat_dtime;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("1-01-01")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_xs_date ())) {
                    algty = aat_date;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("1-01-01")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_xs_time ())) {
                    algty = aat_time;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("0:0:0")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_xs_gyearmonth ())) {
                    algty = aat_gymonth;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("1-01")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_xs_gyear ())) {
                    algty = aat_gyear;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("1")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_xs_gmonthday ())) {
                    algty = aat_gmday;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("01-01")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_xs_gmonth ())) {
                    algty = aat_gmonth;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("01")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_xs_gday ())) {
                    algty = aat_gday;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("01")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_xs_duration ())) {
                    algty = aat_duration;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("PT0S")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_xs_yearmonthduration ())) {
                    algty = aat_ymduration;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("P0M")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_xs_daytimeduration ())) {
                    algty = aat_dtduration;
                    empty_case = project (cast (attach (
                                                    empty_case,
                                                    col_item,
                                                    lit_str("PT0S")),
                                                col_cast, col_item, algty),
                                          proj (col_iter, col_iter),
                                          proj (col_item, col_cast));
                }
                else if (PFty_equality (t, PFty_untypedAtomic ())) {
                    algty = aat_uA;
                    empty_case = attach (empty_case, col_item, lit_uA (""));
                }
                else
                    PFoops (OOPS_FATAL,
                            "don't know the algebra equivalent of type %s",
                            PFty_str (L(p)->type));

                sort_attr = disjunion (
                                attach (
                                    project (cast (sort_attr,
                                                   col_cast, col_item, algty),
                                             proj (col_iter, col_iter),
                                             proj (col_item, col_cast)),
                                    col_pos,
                                    lit_nat ((p->sem.mode.dir == p_desc) ^
                                             (p->sem.mode.empty == p_least))),
                                attach (
                                    empty_case,
                                    col_pos,
                                    lit_nat ((p->sem.mode.dir == p_desc) ^
                                             (p->sem.mode.empty != p_least))));
                empty = 1;
            }

            /* extend the backmapping relation map with
             * (a) position information of the for-loop input sequence and
             * (b) the current iteration values */
            MAP_COUNT++;
            cols = PFmalloc ((MAP_COUNT + empty) * sizeof (PFalg_proj_t));
            /* columns outer and inner remain the same */
            cols[0].new = col_outer;
            cols[0].old = col_outer;
            cols[1].new = col_inner;
            cols[1].old = col_inner;

            /* copy all old sort columns */
            for (unsigned i = 2; i < MAP_COUNT - 1; i++)
                cols[i].new =
                cols[i].old = col_sort << (i - 2);

            /* we now have on additional sort column generated
               from column item (and possible pos) */
            if (empty) {
                sort_col = col_sort << (MAP_COUNT - 3);
                cols[MAP_COUNT -1].new = sort_col;
                cols[MAP_COUNT -1].old = col_pos;
                MAP_COUNT++;
            }
            /* the first sort criterion is column sort itself */
            sort_col = col_sort << (MAP_COUNT - 3);
            cols[MAP_COUNT -1].new = sort_col;
            cols[MAP_COUNT -1].old = col_item;

            if (p->sem.mode.dir == p_desc)
                /* mark the bit corresponding to the last
                   entry to cope with descending order */
                MAP_DIR |= sort_col;

            MAP = PFla_project_ (eqjoin (MAP, sort_attr, col_inner, col_iter),
                                 MAP_COUNT, cols);

        /* OrderSpecs:         orderspecs (CoreExpr, OrderSpecs) */
        /* case 301: */
            /* complete rule 301 */
            if (rule == 301)
                /* translate remaining OrderSpecs */
                reduce (ctx, kids[1], nts[1]);

        } break;

        /* CoreExpr:           if_ (CoreExpr, then_else (CoreExpr, CoreExpr)) */
        case 13:
        {   /* TOPDOWN */

            /*
             * if e1 then e2 else e3
             *
             * NB: SEL: select those rows where column value != 0
             *
             *
             * {..., $v -> q(v), ...},loop: e1 => q1,delta1
             *
             * then_map  = rowid_inner (proj_outer:iter (SEL item q1))
             * then_loop = proj_iter:inner (then_map)
             *
             * { ...,
             *   $v -> proj_iter:inner,pos,item (q(v)|X|(iter=outer)(then_map)),
             *   ...}, then_loop: e2 => (q2,delta2)
             *
             * else_map  = rowid_inner (proj_outer:iter (SEL res (NOT res item q1))
             * else_loop = proj_iter:inner (else_map)
             *
             * { ...,
             *   $v -> proj_iter:inner,pos,item (q(v)|X|(iter=outer)(else_map)),
             *   ...}, else_loop: e3 => (q3,delta3)
             * -----------------------------------------------------------------
             * {..., $v -> q(v), ...},loop,delta: if e1 then e2 else e3 =>
             *                        ((proj_iter:outer,pos,item (
             *                              q2 |X|(iter=inner) (then_map)))
             *                         U
             *                         (proj_iter:outer,pos,item (
             *                              q3 |X|(iter=inner) (else_map))),
             *                         delta2 U delta3)
             */
            PFla_op_t *old_loop;
            PFarray_t  *old_env;
            unsigned int i;
            PFla_env_t e;
            PFla_op_t *new_map,
                      *rowid,
                      *var_map,
                      *then_map,
                      *else_map,
                      *then_res,
                      *else_res;

            /* initiate translation of e1 */
            reduce (ctx, kids[0], nts[0]);

            /* save old loop operator */
            old_loop = LOOP;

            /* prepare the loop relation for the then-branch */
            rowid    = rowid (select_ (A(L(p)).rel, col_item),
                              col_inner);
            /* create new loop operator */
            LOOP     = project (rowid, proj (col_iter, col_inner));
            /* create var_map relation. */
            var_map  = project (rowid,
                                proj (col_outer, col_iter),
                                proj (col_inner, col_inner));
            /* store the variable map to retrieve the old iter values */
            then_map = var_map;

            /* save old environment */
            old_env = ENV;

            /* update the environment for translation of e2 */
            ENV = PFarray (sizeof (PFla_env_t), 50);

            /* update all variable bindings in old environment and put
             * them into new environment */
            for (i = 0; i < PFarray_last (old_env); i++) {
                e = *((PFla_env_t *) PFarray_at (old_env, i));

                if (!e.map)
                    new_map = project (var_map,
                                       proj (col_outer, col_outer),
                                       proj (col_inner, col_inner));
                else
                    new_map = project (
                                  eqjoin (
                                      project (
                                          e.map,
                                          proj (col_iter, col_inner),
                                          proj (col_outer, col_outer)),
                                      project (
                                          var_map,
                                          proj (col_iter2, col_outer),
                                          proj (col_inner, col_inner)),
                                      col_iter,
                                      col_iter2),
                                  proj (col_outer, col_outer),
                                  proj (col_inner, col_inner));

                *((PFla_env_t *) PFarray_add (ENV)) =
                    enventry (e.var, e.rel, new_map, e.frag);
            }

            /* translate e2 (then-branch) */
            reduce (ctx, kids[1], nts[1]);

            /* prepare the loop relation for the else-branch */
            rowid    = rowid (select_ (not (A(L(p)).rel, col_res, col_item),
                                       col_res),
                              col_inner);
            /* create new loop operator */
            LOOP     = project (rowid, proj (col_iter, col_inner));
            /* create var_map relation. */
            var_map  = project (rowid,
                                proj (col_outer, col_iter),
                                proj (col_inner, col_inner));
            /* store the variable map to retrieve the old iter values */
            else_map = var_map;

            /* update the environment for translation of e3 */
            ENV = PFarray (sizeof (PFla_env_t), 50);

            /* update all variable bindings in old environment and put
             * them into new environment */
            for (i = 0; i < PFarray_last (old_env); i++) {
                e = *((PFla_env_t *) PFarray_at (old_env, i));

                if (!e.map)
                    new_map = project (var_map,
                                       proj (col_outer, col_outer),
                                       proj (col_inner, col_inner));
                else
                    new_map = project (
                                  eqjoin (
                                      project (
                                          e.map,
                                          proj (col_iter, col_inner),
                                          proj (col_outer, col_outer)),
                                      project (
                                          var_map,
                                          proj (col_iter2, col_outer),
                                          proj (col_inner, col_inner)),
                                      col_iter,
                                      col_iter2),
                                  proj (col_outer, col_outer),
                                  proj (col_inner, col_inner));

                *((PFla_env_t *) PFarray_add (ENV)) =
                    enventry (e.var, e.rel, new_map, e.frag);
            }

            /* translate e3 (else-branch) */
            reduce (ctx, kids[2], nts[2]);

            /* reset loop relation and environment */
            LOOP = old_loop;
            ENV = old_env;

            /* merge back the old iter values */
            then_res = project (
                           eqjoin (A(RL(p)).rel, then_map, col_iter, col_inner),
                           proj (col_iter, col_outer),
                           proj (col_pos, col_pos),
                           proj (col_item, col_item));

            /* merge back the old iter values */
            else_res = project (
                           eqjoin (A(RR(p)).rel, else_map, col_iter, col_inner),
                           proj (col_iter, col_outer),
                           proj (col_pos, col_pos),
                           proj (col_item, col_item));

            A(p) = (struct  PFla_pair_t) {
                     .rel  = disjunion (then_res, else_res),
                     .frag = PFla_set_union (A(RL(p)).frag, A(RR(p)).frag) };

        } break;

        /* CoreExpr:           seq (CoreExpr, SeqCoreExpr) */
        case 14:
        {   /* TOPDOWN */

            /*
             *     env,loop: e1 => q1,delta1      env,loop: e2 => q2,delta2
             * -----------------------------------------------------------------
             *                        env,loop: (e1, e2) =>
             *
             *                      proj_iter,pos:pos1,item
             *  /                          / ord       \     / ord       \ \
             * |  row_pos1:<ord,pos>/iter | ----- X q1  | U | ----- X q2  | |
             *  \                          \  1        /     \  2        / /
             *
             */
            unsigned int old_seq_count;

            /* initiate translation of e1 */
            reduce (ctx, kids[0], nts[0]);

            /* save seq_count and start a new sequence counter */
            old_seq_count = SEQ_COUNT;
            SEQ_COUNT = 2;

            /* initiate translation of e2 */
            reduce (ctx, kids[1], nts[1]);

            /* re-set seq_count */
            SEQ_COUNT = old_seq_count;

            A(p) = (struct  PFla_pair_t) {
                     .rel = project (
                                rank (
                                    disjunion (
                                        attach (
                                            A(L(p)).rel,
                                            col_ord, lit_nat (1)),
                                        A(R(p)).rel),
                                    col_pos1,
                                    sortby (col_ord, col_pos)),
                                proj (col_iter, col_iter),
                                proj (col_pos, col_pos1),
                                proj (col_item, col_item)),
                     .frag = PFla_set_union (A(L(p)).frag, A(R(p)).frag) };
        } break;

        /* CoreExpr:           seq (CoreExpr, CoreExpr) */
        case 15:
        {
            /*
             *     env,loop: e1 => q1,delta1      env,loop: e2 => q2,delta2
             * -----------------------------------------------------------------
             *                        env,loop: (e1, e2) =>
             *
             *                      proj_iter,pos:pos1,item
             *  /                          / ord       \     / ord       \ \
             * |  row_pos1:<ord,pos>/iter | ----- X q1  | U | ----- X q2  | |
             *  \                          \  1        /     \  2        / /
             *
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = project (
                                rank (
                                    disjunion (
                                        attach (
                                            A(L(p)).rel,
                                            col_ord, lit_nat (1)),
                                        attach (
                                            A(R(p)).rel,
                                            col_ord, lit_nat (2))),
                                    col_pos1,
                                    sortby (col_ord, col_pos)),
                                proj (col_iter, col_iter),
                                proj (col_pos, col_pos1),
                                proj (col_item, col_item)),
                     .frag = PFla_set_union (A(L(p)).frag, A(R(p)).frag) };
        } break;

        /* SeqCoreExpr:        seq (CoreExpr, SeqCoreExpr) */
        case 16:
        {   /* TOPDOWN */

            unsigned int cur_seq_count = SEQ_COUNT++;

            /* initiate translation of e1 and e2 */
            reduce (ctx, kids[0], nts[0]);
            reduce (ctx, kids[1], nts[1]);

            A(p) = (struct  PFla_pair_t) {
                     .rel = disjunion (
                                attach (
                                    A(L(p)).rel,
                                    col_ord, lit_nat (cur_seq_count)),
                                A(R(p)).rel),
                     .frag = PFla_set_union (A(L(p)).frag, A(R(p)).frag) };
        } break;

        /* SeqCoreExpr:        seq (CoreExpr, CoreExpr) */
        case 17:
            /* TOPDOWN */

            /* initiate translation of e1 and e2 */
            reduce (ctx, kids[0], nts[0]);
            reduce (ctx, kids[1], nts[1]);

            A(p) = (struct  PFla_pair_t) {
                     .rel = disjunion (
                                attach (
                                    A(L(p)).rel,
                                    col_ord, lit_nat (SEQ_COUNT)),
                                attach (
                                    A(R(p)).rel,
                                    col_ord, lit_nat (SEQ_COUNT+1))),
                     .frag = PFla_set_union (A(L(p)).frag, A(R(p)).frag) };
            break;

        /* CoreExpr:           ordered (CoreExpr) */
        case 18:
        {   /* TOPDOWN */

            /* use `ordered' information */
            bool old_ordering = ORDERING;
            ORDERING = true;

            reduce (ctx, kids[0], nts[0]);

            A(p) = A(L(p));

            /* reset ordering mode */
            ORDERING = old_ordering;
        } break;

        /* CoreExpr:           unordered (CoreExpr) */
        case 19:
        {   /* TOPDOWN */

            /* use `ordered' information */
            bool old_ordering = ORDERING;
            ORDERING = false;

            reduce (ctx, kids[0], nts[0]);

            A(p) = A(L(p));

            /* reset ordering mode */
            ORDERING = old_ordering;
        } break;

        /* CoreExpr:           typesw (CoreExpr,
                                       cases (case_ (seqtype,
                                                     CoreExpr),
                                              default_ (CoreExpr))) */
        case 20:
        {   /* TOPDOWN */

            /*
             * CoreExpr1 is the expression to be switched. CoreExpr2
             * compiles one (the current) case branch. CoreExpr3 is
             * either another typeswitch representing the next case
             * branch or the default branch of the overall typeswitch.
             *
             * A lot of work for this translation is captured in the
             * function type_test(). Given an algebra expression and
             * an XQuery sequence type, it will return a relation
             * with columns `iter' and `subty', with `subty' set to
             * true or false, depending on whether for this iteration
             * the sequence type test succeeds or not.
             *
             * env,loop: e1 => q1,delta1
             * tested_q1 = type_test (ty, q1, loop)
             *
             * -- translate stuff in the `case' branch
             *  loop2 = proj_iter (select_subty (tested_q1))
             *  {..., $v -> proj_iter,pos,item (
             *    qv |X| (iter = iter1) (proj_iter1:iter loop2))},
             *   loop2: e2 => q2,delta2
             *
             * -- and in the `default' branch
             *  loop3 = proj_iter (select_notsub (not_notsub:subty (tested_q1)))
             *  {..., $v -> proj_iter,pos,item (
             *    qv |X| (iter = iter1) (proj_iter1:iter loop3))},
             *   loop3: e3 => q3,delta3
             *
             * ---------------------------------------------------------------
             *  env,loop:
             *  typeswitch (e1) case ty return e2 default return e3 =>
             *    (q2 U q3, delta2 U delta3)
             *
             * NB: the TYPE operator creates a new column of type boolean;
             * it examines whether the specified column is of given type "ty";
             * if this is the case, it sets the new column to true, otherwise
             * to false.
             */

            PFla_op_t   *tested_q1;  /* true/false if iterat. satisfies test */
            PFarray_t   *old_env;    /* backup of surrounding environment */
            PFla_op_t   *old_loop;   /* backup of surrounding loop relation */
            PFla_env_t   e;          /* helper variable */
            PFla_op_t   *new_map;    /* helper variable */
            unsigned int  i;

            /* translate CoreExpr1 */
            reduce (ctx, kids[0], nts[0]);

            tested_q1 = type_test (RLL(p)->sem.type, A(L(p)), LOOP);

            /* translate stuff in the `case' branch */

            /* map `loop' relation */
            old_loop = LOOP;
            LOOP = project (select_ (tested_q1, col_subty),
                            proj (col_iter, col_iter));

            /* map variable environment */
            old_env = ENV;
            ENV = PFarray (sizeof (PFla_env_t), 50);

            for (i = 0; i < PFarray_last (old_env); i++) {
                e = *((PFla_env_t *) PFarray_at (old_env, i));

                if (!e.map)
                    new_map = project (
                                  LOOP,
                                  proj (col_outer, col_iter),
                                  proj (col_inner, col_iter));
                else
                    new_map = project (
                                  eqjoin (
                                      e.map,
                                      LOOP,
                                      col_inner,
                                      col_iter),
                                  proj (col_outer, col_outer),
                                  proj (col_inner, col_inner));

                *((PFla_env_t *) PFarray_add (ENV))
                    = enventry (e.var, e.rel, new_map, e.frag);
            }

            /* translate CoreExpr2 */
            reduce (ctx, kids[1], nts[1]);

            /* translate stuff in the `default' branch (equivalently) */

            /* map `loop' relation */
            LOOP = project (select_ (not (tested_q1, col_notsub, col_subty),
                                     col_notsub),
                            proj (col_iter, col_iter));

            ENV = PFarray (sizeof (PFla_env_t), 50);

            for (i = 0; i < PFarray_last (old_env); i++) {
                e = *((PFla_env_t *) PFarray_at (old_env, i));

                if (!e.map)
                    new_map = project (
                                  LOOP,
                                  proj (col_outer, col_iter),
                                  proj (col_inner, col_iter));
                else
                    new_map = project (
                                  eqjoin (
                                      e.map,
                                      LOOP,
                                      col_inner,
                                      col_iter),
                                  proj (col_outer, col_outer),
                                  proj (col_inner, col_inner));

                *((PFla_env_t *) PFarray_add (ENV))
                    = enventry (e.var, e.rel, new_map, e.frag);
            }

            /* translate CoreExpr3 */
            reduce (ctx, kids[2], nts[2]);

            /* reset loop relation and environment */
            LOOP = old_loop;
            ENV = old_env;

            A(p) = (struct PFla_pair_t) {
                .rel  = disjunion (A(RLR(p)).rel, A(RRL(p)).rel),
                .frag = PFla_set_union (A(RLR(p)).frag, A(RRL(p)).frag)
            };

        } break;

        /* CoreExpr:           cast (seqtype, CoreExpr) */
        case 21:
        {
            struct  PFla_pair_t pair = A(R(p));
            PFty_t              t;
            PFalg_simple_type_t algty;

            t = PFty_prime (PFty_defn (L(p)->sem.type));

            /*
             * Unfortunately, we only know how to cast atomic types
             * into (exactly) one of our builtin atomic types. We
             * cannot sensibly cast, e.g., into subtypes thereof.
             */
            if (PFty_equality (t, PFty_xs_string ()))
                algty = aat_str;
            else if (PFty_equality (t, PFty_untypedAtomic ()))
                algty = aat_uA;
            else if (PFty_equality (t, PFty_xs_integer ()))
                algty = aat_int;
            else if (PFty_equality (t, PFty_xs_decimal ()))
                algty = aat_dec;
            else if (PFty_equality (t, PFty_xs_double ()))
                algty = aat_dbl;
            else if (PFty_equality (t, PFty_xs_boolean ()))
                algty = aat_bln;
            else if (PFty_equality (t, PFty_xs_datetime ()))
                algty = aat_dtime;
            else if (PFty_equality (t, PFty_xs_date ()))
                algty = aat_date;
            else if (PFty_equality (t, PFty_xs_time ()))
                algty = aat_time;
            else if (PFty_equality (t, PFty_xs_gyearmonth ()))
                algty = aat_gymonth;
            else if (PFty_equality (t, PFty_xs_gyear ()))
                algty = aat_gyear;
            else if (PFty_equality (t, PFty_xs_gmonthday ()))
                algty = aat_gmday;
            else if (PFty_equality (t, PFty_xs_gmonth ()))
                algty = aat_gmonth;
            else if (PFty_equality (t, PFty_xs_gday ()))
                algty = aat_gday;
            else if (PFty_equality (t, PFty_xs_duration ()))
                algty = aat_duration;
            else if (PFty_equality (t, PFty_xs_yearmonthduration ()))
                algty = aat_ymduration;
            else if (PFty_equality (t, PFty_xs_daytimeduration ()))
                algty = aat_dtduration;
            else
                PFoops (OOPS_FATAL,
                        "don't know the algebra equivalent of type %s",
                        PFty_str (L(p)->sem.type));

            /* in case we require a single item and the input
               may be less or more than a single item add a runtime check */
            if (PFty_subtype (L(p)->sem.type, PFty_item ()) &&
                !PFty_subtype (R(p)->type, PFty_item ()))
                pair = PFbui_fn_exactly_one (LOOP,
                                             ORDERING,
                                             &SIDE_EFFECTS,
                                             &pair);
            /* in case we require zero or one items and the input
               may be more than a single item add a runtime check */
            else if (PFty_subtype (L(p)->sem.type, PFty_opt (PFty_item ())) &&
                     !PFty_subtype (R(p)->type, PFty_opt (PFty_item ())))
                pair = PFbui_fn_zero_or_one (LOOP,
                                             ORDERING,
                                             &SIDE_EFFECTS,
                                             &pair);

            A(p) = (struct PFla_pair_t) {
                .rel  = project (cast (pair.rel, col_cast, col_item, algty),
                                 proj (col_iter, col_iter),
                                 proj (col_pos, col_pos),
                                 proj (col_item, col_cast)),
                .frag = pair.frag };

        } break;

        /* CoreExpr:           seqcast (seqtype, CoreExpr) */
        case 22:
        {
            /*
             * `seqcast' nodes are only introduced for static typing.
             * They are not meant to be executed.
             */
            struct  PFla_pair_t pair = A(R(p));
            PFty_t              t;
            PFalg_simple_type_t algty;

            t = PFty_prime (PFty_defn (L(p)->sem.type));

            /*
             * Unfortunately, we only know how to cast atomic types
             * into (exactly) one of our builtin atomic types. We
             * cannot sensibly cast, e.g., into subtypes thereof.
             */
            if (PFty_equality (t, PFty_xs_string ()))
                algty = aat_str;
            else if (PFty_equality (t, PFty_untypedAtomic ()))
                algty = aat_uA;
            else if (PFty_equality (t, PFty_xs_integer ()))
                algty = aat_int;
            else if (PFty_equality (t, PFty_xs_decimal ()))
                algty = aat_dec;
            else if (PFty_equality (t, PFty_xs_double ()))
                algty = aat_dbl;
            else if (PFty_equality (t, PFty_xs_boolean ()))
                algty = aat_bln;
            else if (PFty_equality (t, PFty_xs_datetime ()))
                algty = aat_dtime;
            else if (PFty_equality (t, PFty_xs_date ()))
                algty = aat_date;
            else if (PFty_equality (t, PFty_xs_time ()))
                algty = aat_time;
            else if (PFty_equality (t, PFty_xs_gyearmonth ()))
                algty = aat_gymonth;
            else if (PFty_equality (t, PFty_xs_gyear ()))
                algty = aat_gyear;
            else if (PFty_equality (t, PFty_xs_gmonthday ()))
                algty = aat_gmday;
            else if (PFty_equality (t, PFty_xs_gmonth ()))
                algty = aat_gmonth;
            else if (PFty_equality (t, PFty_xs_gday ()))
                algty = aat_gday;
            else if (PFty_equality (t, PFty_xs_duration ()))
                algty = aat_duration;
            else if (PFty_equality (t, PFty_xs_yearmonthduration ()))
                algty = aat_ymduration;
            else if (PFty_equality (t, PFty_xs_daytimeduration ()))
                algty = aat_dtduration;
            else
                algty = 0;

            if (algty)
                A(p) = (struct PFla_pair_t) {
                    .rel  = type_assert_pos (pair.rel, col_item, algty),
                    .frag = pair.frag };
            else
                A(p) = pair;
        }   break;

        /* CoreExpr:     locsteps (ancestor (seqtype), CoreExpr) */
        case 30:
            A(p) = locstep (ctx, alg_anc, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (ancestor_or_self (seqtype), CoreExpr) */
        case 31:
            A(p) = locstep (ctx, alg_anc_s, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (attribute (seqtype), CoreExpr) */
        case 32:
            A(p) = locstep (ctx, alg_attr, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (child (seqtype), CoreExpr) */
        case 33:
            A(p) = locstep (ctx, alg_chld, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (descendant (seqtype), CoreExpr) */
        case 34:
            A(p) = locstep (ctx, alg_desc, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (descendant_or_self (seqtype), CoreExpr) */
        /* LocationStep:       descendant_or_self (seqtype) */
        case 35:
            A(p) = locstep (ctx, alg_desc_s, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (following (seqtype), CoreExpr) */
        case 36:
            A(p) = locstep (ctx, alg_fol, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (following_sibling (seqtype), CoreExpr) */
        case 37:
            A(p) = locstep (ctx, alg_fol_s, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (parent (seqtype), CoreExpr) */
        case 38:
            A(p) = locstep (ctx, alg_par, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (preceding (seqtype), CoreExpr) */
        case 39:
            A(p) = locstep (ctx, alg_prec, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (preceding_sibling (seqtype), CoreExpr) */
        case 40:
            A(p) = locstep (ctx, alg_prec_s, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:     locsteps (self (seqtype), CoreExpr) */
        case 41:
            A(p) = locstep (ctx, alg_self, LL(p)->sem.type, A(R(p)));
            break;

        /* StandOff axes */
        /* CoreExpr:     locsteps (select_narrow (seqtype), CoreExpr) */
        case 42:
            A(p) = locstep (ctx, alg_so_select_narrow, LL(p)->sem.type, A(R(p)));
            break;
        /* CoreExpr:     locsteps (select_wide (seqtype), CoreExpr) */
        case 43:
            A(p) = locstep (ctx, alg_so_select_wide, LL(p)->sem.type, A(R(p)));
            break;

        /* CoreExpr:           TwigExpr */
        case 45:
        {   /*
             * Introduce a twig operator that generates
             * the correct new pre values and provides a result
             * and a new document fragment.
             *
             * env, loop: e => q
             *
             * n = twig (q)
             * ----------------------------------------------------------------
             * env, loop: twig e =>
             *                                           pos
             * rel:  (proj_iter,item:pre (roots (n))) x -----
             *                                            1
             *                                                          zero
             *    where roots (n) = sel (res)(= res:(level, zero) (n x ------))
             *                                                            0
             *
             * frag: proj_pre,size,level,kind,prop,frag (n)
             */

            PFla_op_t *twig = twig (A(p).rel,
                                    col_iter,
                                    col_item);

            A(p) = (struct  PFla_pair_t) {
                     .rel = attach (roots (twig),
                                    col_pos, lit_nat (1)),
                     .frag = PFla_set (fragment (twig))};
        }   break;

        /* TwigExpr:           twig_seq (TwigExpr, TwigSeq) */
        case 46:
            /* Represent a sequence in a twig constructor by
               the special operator fcns (first-child-next-sibling) */

            A(p) = (struct  PFla_pair_t) {
                     .rel = fcns (A(L(p)).rel, A(R(p)).rel),
                     .frag = PFla_empty_set () };
            break;

        /* TwigSeq:            TwigExpr: */
        case 47:
            /* Represent the end of a twig sequence by nil token:
               fcns (expr, nil). */

            A(p) = (struct  PFla_pair_t) {
                     .rel = fcns (A(p).rel, nil ()),
                     .frag = PFla_empty_set () };
            break;

        /* TwigExpr:           empty */
        case 48:
            /* Represent the empty content of a document or element
               constructor by the nil token. */

            A(p) = (struct  PFla_pair_t) {
                     .rel = nil (),
                     .frag = PFla_empty_set () };
            break;

        /* TwigExpr:           CoreExpr */
        case 49:
            /* Represent the (already generated) node content of a document
               or element constructor (e.g., nodes from a queried document)
               by a content operator. The task of this operator is to collect
               all subtree nodes and prepare them for a subtree copy. */

            A(p) = (struct  PFla_pair_t) {
                     .rel = content (PFla_set_to_la (A(p).frag), A(p).rel,
                                     col_iter, col_pos, col_item),
                     .frag = PFla_empty_set () };
            break;

        /* TwigExpr:           doc (TwigSeq) */
        case 50:
            /*
             * env, loop: e => q, doc (q)
             * ----------------------------------------------------------------
             * env, loop: docnode e =>
             *
             * rel:       docnode (loop, q)
             * frag:      _
             *
             * Inside a twig constructor every node constructor produces
             * neither a schema nor a fragment information. This allows
             * different implementations to use whatever document layout
             * they prefer. Only after the complete twig is constructed
             * the twig operator provides a schema and the new fragment
             * information.
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = docnode (LOOP, A(L(p)).rel, col_iter),
                     .frag = PFla_empty_set () };
            break;

        /* TwigExpr:           elem (TagName, TwigSeq) */
        case 51:
            /*
             * CoreExpr (q2) evaluates to a sequence of nodes (fcns operators).
             * TagName (q1) is the name of a new node which becomes the common
             * root of the constructed tree.
             *
             * env, loop: e1 => q1, doc (q1)
             * env, loop: e2 => q2, _
             * -----------------------------------------------------------------
             * env, loop: element e1 {e2} =>
             *
             * rel:       element (q1, q2)
             * frag:      _
             *
             * Inside a twig constructor every node constructor produces
             * neither a schema nor a fragment information. This allows
             * different implementations to use whatever document layout
             * they prefer. Only after the complete twig is constructed
             * the twig operator provides a schema and the new fragment
             * information.
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = element (A(L(p)).rel, A(R(p)).rel,
                                     col_iter,
                                     col_item),
                     .frag = PFla_empty_set () };
            break;

        /* TwigExpr:           attr (TagName, CoreExpr) */
        case 52:
            /*
             * CoreExpr (q2) evaluates to a sequence of attribute values.
             * TagName (q1) is the name of a new node.
             *
             * env, loop: e1 => q1, doc (q1)
             * env, loop: e2 => q2, doc (q2)
             * ----------------------------------------------------------------
             * env, loop: attribute e1 {e2} =>
             *
             * rel:       attribute (q1
             *                       |X|_iter1,iter
             *                       (proj_iter1:iter,item1:item (q2)))
             * frag:      _
             *
             * Inside a twig constructor every node constructor produces
             * neither a schema nor a fragment information. This allows
             * different implementations to use whatever document layout
             * they prefer. Only after the complete twig is constructed
             * the twig operator provides a schema and the new fragment
             * information.
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = attribute (
                                eqjoin (
                                    A(L(p)).rel,
                                    project (A(R(p)).rel,
                                             proj (col_iter1, col_iter),
                                             proj (col_item1, col_item)),
                                    col_iter, col_iter1),
                                col_iter, col_item, col_item1),
                     .frag = PFla_empty_set () };
            break;

        /* TagName:            tag */
        case 400:
            A(p) = (struct PFla_pair_t) {
                .rel = attach (
                           attach (LOOP,
                                   col_pos, lit_nat (1)),
                           col_item, lit_qname (p->sem.qname)),
                .frag = PFla_empty_set () };
            break;

        /* TagName:            CoreExpr */
        case 401:
            break;

        /* TwigExpr:           text (CoreExpr) */
        case 53:
            /*
             * env, loop: e => q, doc (q)
             * ----------------------------------------------------------------
             * env, loop: textnode e =>
             *
             * rel:       textnode (q)
             * frag:      _
             *
             * Inside a twig constructor every node constructor produces
             * neither a schema nor a fragment information. This allows
             * different implementations to use whatever document layout
             * they prefer. Only after the complete twig is constructed
             * the twig operator provides a schema and the new fragment
             * information.
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = textnode (A(L(p)).rel, col_iter, col_item),
                     .frag = PFla_empty_set () };
            break;

        /* TwigExpr:           comment (CoreExpr) */
        case 54:
            /*
             * env, loop: e => q, doc (q)
             * ----------------------------------------------------------------
             * env, loop: comment e =>
             *
             * rel:       comment (q)
             * frag:      _
             *
             * Inside a twig constructor every node constructor produces
             * neither a schema nor a fragment information. This allows
             * different implementations to use whatever document layout
             * they prefer. Only after the complete twig is constructed
             * the twig operator provides a schema and the new fragment
             * information.
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = comment (A(L(p)).rel, col_iter, col_item),
                     .frag = PFla_empty_set () };
            break;

        /* TwigExpr:           pi (CoreExpr, CoreExpr) */
        case 55:
            /*
             * CoreExpr (q2) evaluates to the string content.
             * CoreExpr (q1) is the target of a new node.
             *
             * env, loop: e1 => q1, doc (q1)
             * env, loop: e2 => q2, doc (q2)
             * ----------------------------------------------------------------
             * env, loop: processi {e1}{e2} =>
             *
             * rel:       processi (q1
             *                      |X|_iter1,iter
             *                      (proj_iter1:iter,item1:item (q2)))
             * frag:      _
             *
             * Inside a twig constructor every node constructor produces
             * neither a schema nor a fragment information. This allows
             * different implementations to use whatever document layout
             * they prefer. Only after the complete twig is constructed
             * the twig operator provides a schema and the new fragment
             * information.
             */
            A(p) = (struct  PFla_pair_t) {
                     .rel = processi (
                                eqjoin (
                                    A(L(p)).rel,
                                    project (A(R(p)).rel,
                                             proj (col_iter1, col_iter),
                                             proj (col_item1, col_item)),
                                    col_iter, col_iter1),
                                col_iter, col_item, col_item1),
                     .frag = PFla_empty_set () };
            break;

        /* CoreExpr:           apply (FunctionArgs) */
        case 60:
        {   /* TOPDOWN*/

            /*
             * Function application (user-defined functions):
             *
             * (1) Save current variable and function parameter environment.
             * (2) Enter bindings for all variables in the function
             *     signature to the variable environment.
             * (3) Invoke compilation for the function body (accessible
             *     via the PFfun_t struct).
             * (4) Restore variable and function parameter environment.
             */

            PFarray_t  *old_env;
            PFarray_t  *old_fun_args;

            /* (1) Save current variable and function parameter environment
               and create new ones. */
            old_env = ENV;

            ENV = PFarray (sizeof (PFla_env_t), 50);

            for (unsigned int i = 0; i < PFarray_last (old_env); i++)
                *((PFla_env_t *) PFarray_add (ENV))
                    = *((PFla_env_t *) PFarray_at (old_env, i));

            old_fun_args = FUN_ARGS;

            /* We will collect the argument values here */
            FUN_ARGS = PFarray (sizeof (struct PFla_pair_t), 10);

            /* (2) Enter bindings for function parameters.
             *     We do this by reducing our child nodes in a
             *     top-down fashion.
             */

            /* Top-down processing puts all argument values into this array */
            reduce (ctx, kids[0], nts[0]);

            /* All function arguments are now in the array `fun_args'. */

            if (p->sem.fun->builtin) {
                /**
                 * Translation of fn:trace ()
                 */
                if (! PFqname_eq (p->sem.fun->qname,
                                  PFqname (PFns_fn, "trace"))) {
                    /* For fn:trace we need to introduce for each map relation
                       an additional trace operator. */
                    PFla_pair_t seq = *(PFla_pair_t *) PFarray_at (FUN_ARGS, 0);
                    PFla_pair_t str = *(PFla_pair_t *) PFarray_at (FUN_ARGS, 1);
                    PFla_op_t  *map_traces = nil ();

                    unsigned int i = 0;
                    for (; i < PFarray_last (ctx->mapping); i++) {
                        PFla_op_t *map =
                            ((map_rel_info_t *) PFarray_at (ctx->mapping,
                                                            i))->map;

                        if (map) {
                            map_traces = trace_map (map,
                                                    map_traces,
                                                    col_inner,
                                                    col_outer);
                        }
                    }

                    SIDE_EFFECTS = trace (SIDE_EFFECTS,
                                          trace_items (seq.rel,
                                                       trace_msg (str.rel,
                                                                  map_traces,
                                                                  col_iter,
                                                                  col_item),
                                                       col_iter,
                                                       col_pos,
                                                       col_item));

                    A(p) = (struct PFla_pair_t) {
                        .rel  = seq.rel,
                        .frag = seq.frag };
                } else {
                    /*
                     * For built-in functions use this array to call the
                     * algebraic representation of the function (builtins.c)
                     */
                    if (!p->sem.fun->alg)
                        PFoops (
                            OOPS_FATAL,
                            "Algebra implementation for function `%s' unknown.",
                            PFqname_str (p->sem.fun->qname));

                    A(p) = p->sem.fun->alg (LOOP,
                                            ORDERING,
                                            &SIDE_EFFECTS,
                                            FUN_ARGS->base);
                }
            }
            else {
                /* check for active (recursive) user-defined functions */
                unsigned int i = 0;
                for (; i < PFarray_last (ctx->fun_active); i++)
                    if (FUN_ACTIVE_AT(i).node == p->sem.fun->core)
                        break;

                /* if this function appears the first time */
                if (i == PFarray_last (ctx->fun_active)) {
                    /* add function to the active ones */
                    *((fun_active_t *) PFarray_add (ctx->fun_active)) =
                        (fun_active_t) { .node  = p->sem.fun->core,
                                         .count = 1 };

                    /* Bind parameter variables to the argument values
                       and ... */
                    for (unsigned int j = 0; j < p->sem.fun->arity; j++) {
                        PFla_pair_t curr_arg
                            = *(PFla_pair_t *) PFarray_at (FUN_ARGS, j);

                        *((PFla_env_t *) PFarray_add (ENV))
                            = enventry (p->sem.fun->params[j],
                                        curr_arg.rel,
                                        NULL,
                                        curr_arg.frag);
                    }

                    /* (3) invoke compilation of the function body. */
                    reduce (ctx, p->sem.fun->core, 1);

                    /* remove function from the active ones */
                    PFarray_del (ctx->fun_active);

                    A(p) = A(p->sem.fun->core);
                }
                /* cope with recursive functions */
                else if (ctx->recursion_depth == 0) {
                    PFoops (OOPS_FATAL,
                            "Algebra implementation cannot cope with recursive"
                            " functions yet.\n             "
                            "(If the recursion depth is known at compile time"
                            " adding the option\n              "
                            "'declare option pf:recursion-depth \"<number>\";'"
                            " to the query text\n              "
                            "will ensure that the recursive function is"
                            " unfolded <number> times.)");
                }
                /* unfold recursive function as long as
                   we haven't hit the unfold boundary */
                else if (FUN_ACTIVE_AT(i).count < ctx->recursion_depth) {
                    unsigned int j, k;
                    PFarray_t *old_core2alg_map = CORE2ALG_MAP;
                    CORE2ALG_MAP = PFarray (sizeof (core2alg_map_t), 50);

                    /* replace the variables that are not visible
                       anymore due to the recursive call */
                    for (j = 0; j < PFarray_last (ENV); j++) {
                        PFla_env_t e = *((PFla_env_t *) PFarray_at (ENV, j));

                        for (k = 0; k < p->sem.fun->arity; k++)
                            if (e.var == p->sem.fun->params[k]) {
                                PFla_pair_t curr_arg
                                    = *(PFla_pair_t *) PFarray_at (FUN_ARGS, k);

                                *(PFla_env_t *) PFarray_at (ENV, j)
                                    = enventry (p->sem.fun->params[k],
                                                curr_arg.rel,
                                                NULL,
                                                curr_arg.frag);
                                break;
                            }
                    }

                    /* add function once more to the active ones */
                    FUN_ACTIVE_AT(i).count += 1;

                    /* (3) Invoke compilation of the function body. */
                    reduce (ctx, p->sem.fun->core, 1);

                    /* remove function once from the active ones */
                    FUN_ACTIVE_AT(i).count -= 1;

                    /* store the resulting algebra expression */
                    PFla_op_t *res_rel  = A(p->sem.fun->core).rel;
                    PFarray_t *res_frag = A(p->sem.fun->core).frag;

                    /* clean up the side effects introduced
                       by the recursive core tree traversal */
                    for (j = 0; j < PFarray_last (CORE2ALG_MAP); j++)
                        A(CORE2ALG_MAP_AT(j).core) =
                            (struct PFla_pair_t) {
                                .rel  = CORE2ALG_MAP_AT(j).rel,
                                .frag = CORE2ALG_MAP_AT(j).frag };

                    CORE2ALG_MAP = old_core2alg_map;

                    A(p) = (struct PFla_pair_t) {
                               .rel  = res_rel,
                               .frag = res_frag };
                }
                /* we hit the unfold boundary for recursive functions
                   and add a runtime error in case this recursion depth
                   is reached */
                else {
                    SIDE_EFFECTS = error (SIDE_EFFECTS,
                                          attach (LOOP,
                                                  col_item,
                                                  lit_str ("recursion to deep")),
                                          col_item);

                    A(p) = (struct PFla_pair_t) {
                        .rel  = PFla_empty_tbl_ (ipi_schema (PFalg_type (p->type))),
                        .frag = PFla_empty_set () };
                }
            }

            /* (4) Restore variable and function parameter environments. */
            ENV = old_env;
            FUN_ARGS = old_fun_args;

        } break;

        /* CoreExpr:           xrpc (CoreExpr, apply (FunctionArgs)) */
        case 61:
        {   /* TOPDOWN*/
            PFla_op_t     *param_list = PFla_nil (),
                          *fun_call;
            PFalg_schema_t schema;
            PFarray_t     *old_env;
            PFarray_t     *old_fun_args;

            /* prepare the standard in/output schema */
            schema.count = 3;
            schema.items = PFmalloc (schema.count *
                                     sizeof (PFalg_schm_item_t));
            schema.items[0].name = col_iter;
            schema.items[0].type = aat_nat;
            schema.items[1].name = col_pos;
            schema.items[1].type = aat_nat;
            schema.items[2].name = col_item;
            /* Note: the item type has to be adjusted for each parameter */
            schema.items[2].type = 0;

            PFty_t ty = p->type;

            /* Collect the destinations */
            reduce (ctx, kids[0], nts[0]);

            /*
             * Function application:
             *
             * (1) Save current variable and function parameter environment.
             * (2) Enter bindings for all variables in the function
             *     signature to the variable environment.
             * (3) Transform the function parameters
             *     into an XRPC function call.
             * (4) Restore variable and function parameter environment.
             */

            /* (1) Save current variable and function parameter environment
               and create new ones. */
            old_env = ENV;

            ENV = PFarray (sizeof (PFla_env_t), 50);

            for (unsigned int i = 0; i < PFarray_last (old_env); i++)
                *((PFla_env_t *) PFarray_add (ENV))
                    = *((PFla_env_t *) PFarray_at (old_env, i));

            old_fun_args = FUN_ARGS;

            /* We will collect the argument values here */
            FUN_ARGS = PFarray (sizeof (struct PFla_pair_t), 10);

            /* (2) Enter bindings for function parameters.
             *     We do this by reducing our child nodes in a
             *     top-down fashion.
             */

            /* Top-down processing puts all argument values into this array */
            reduce (ctx, kids[1], nts[1]);

            /* All function arguments are now in the array `fun_args'. */

            /* (3) Transform the function parameters into an XRPC function
             *     call.
             */

            /* Create a linked list of parameters. */
            for (unsigned int i = R(p)->sem.fun->arity; i > 0; i--) {
                PFla_pair_t curr_arg
                    = *(PFla_pair_t *) PFarray_at (FUN_ARGS, i-1);

                /* adjust the item type */
                schema.items[2].type = PFprop_type_of (curr_arg.rel, col_item);
                /* create a new parameter */
                param_list = fun_param (curr_arg.rel, param_list, schema);

                /* create a new fragment parameter if the parameter
                   represents a sequence with nodes */
                if (schema.items[2].type & aat_node)
                    param_list = fun_frag_param (
                                     PFla_set_to_la (curr_arg.frag),
                                     param_list,
                                     2 /* referencing column item */);
            }

            /* As the top-most argument add the XRPC destination strings */
            schema.items[2].type = PFprop_type_of (A(L(p)).rel, col_item);
            param_list = fun_param (A(L(p)).rel, param_list, schema);

            /* Collect all result types */
            schema.items[2].type = PFalg_type (ty);

            /* Construct the complete function call */
            fun_call = fun_call (LOOP,                 /* loop relation */
                                 param_list,           /* parameter list */
                                 schema,               /* result schema */
                                 alg_fun_call_xrpc,    /* function call kind */
                                 R(p)->sem.fun->qname, /* function name */
                                 R(p),                 /* context info */
                                 col_iter,             /* loop column */
                                 PFalg_type_occ (ty)); /* occurrence
                                                          indicator */

            /* To correctly reference the fragment information of
               resulting items of kind node we introduce an additional
               frag_extract operator that refers to column item */
            if (schema.items[2].type & aat_node)
                A(p) = (struct  PFla_pair_t) {
                         .rel = fun_call,
                         .frag = PFla_set (frag_extract (fun_call, 2)) };
            else
                A(p) = (struct  PFla_pair_t) {
                         .rel = fun_call,
                         .frag = PFla_empty_set () };

            /* (4) Restore variable and function parameter environments. */
            ENV = old_env;
            FUN_ARGS = old_fun_args;
        } break;

        /* FunctionArgs:       nil */
        case 500:
            break;

        /* FunctionArgs:       arg (FunctionArg, FunctionArgs) */
        case 501:
        {   /* TOPDOWN */

            /* translate the argument itself */
            reduce (ctx, kids[0], nts[0]);

            /* Append the new argument to function argument list */
            *((PFla_pair_t *) PFarray_add (FUN_ARGS)) = A(L(p));

            /* go on to next arguments */
            reduce (ctx, kids[1], nts[1]);

        } break;

        /* FunctionArg:        CoreExpr */
        case 502:
            break;

        /* CoreExpr:           recursion (var, seed (CoreExpr, CoreExpr)) */
        case 72:
        {   /* TOPDOWN */
            /*
             * with $x seeded by e1 return e2
             *
             * There are two approaches to translate the above pattern:
             *  * a delta based approach
             *  * an approach that uses the result of the current recursion
             *    step as input for next one
             *  * an approach that uses the overall result as input for the
             *    next recursion step
             *
             * We choose to translate the recursion with the third approach
             * as XQuery allows positional access as well as aggregates inside
             * the recursion body -- a delta approach would thus return the
             * wrong results. Whenever all the operators inside the recursion
             * body do not rely on the result size and positions we can choose
             * the (probably cheaper) delta approach.
             * The delta and the last result approach both need to change
             * the environment as well as the loop relation as less iterations
             * may be required in the next recursive call.
             *
             * The recursion is translated with the help of the following
             * algebra nodes:
             *  * rec_fix:   the head of the recursion referring
             *               to the overall result
             *  * rec_param: one item of a variable length parameter list
             *               (thus coping with UDFs that have an arbitrary
             *                number or arguments)
             *  * nil:       the end of the parameter list
             *  * rec_arg:   the operator that manages the connections
             *               between seed argument, the recursive call, and
             *               both its input to the next recursion (base)
             *  * rec_base:  a dummy operator representing the algebraic
             *               expression representing the input of the recursion
             *               (either seed or recursive call)
             *
             * The recursion (translated based on the more general approach)
             * will be mapped into the following DAG (e1 -> q1; e2 -> q2;
             * child edges: '---'; 'semantical' edges: '- -')
             *
             *          rank_(pos:<item>)
             *            |
             *         distinct
             *            |
             *         rec_fix
             *            |  \_____________________________
             *        rec_param                            \
             *        /       \________________             \
             *    rec_arg                      \            |
             *    /  |  \                  rec_param        |
             *    |      \                  /      \        |
             *   / \  \   \             rec_arg    nil      /
             *  /q1 \      \            /  \  \___   ______/
             * /_____\ |    |     iter|item       \ /
             *              |     ----|----  \     U (2)
             *         |    |         |           / \
             *              |           (base)|  /  diff (1)
             *         |  rank_                  |   | \
             *          (pos:<item>)          |  | __|__\
             *         |    |                    |/  |
             *           (use (1), (2), or    \  |   |
             *         |  (3) as input)     rec_base |
             *   (base)     | ______________________/
             *         |    |/
             *           distinct (3)
             *         |    |
             *           pi_(iter, item)
             *         |    |
             *             / \
             *         |  /q1 \
             *           /_____\
             *          \   |
             *             /
             *         rec_base
             *
             */

/* different strategies to process the recursion */
#define DELTA 1
#define TC 2
#define IFP 3
#define SQL 4
#define TC_OR_DELTA 5
#define IFP_OR_DELTA 6
/* different strategies to include the seed */
#define STAR 7
#define PLUS 8

/* check whether variable strategy is allowed or not */
#define VAR_STRATEGY(i) ((i) >= TC_OR_DELTA)

/* choose strategy */
#define STRATEGY IFP_OR_DELTA
#define RESULT STAR

            unsigned int   i;
            int            strategy = (PFoutput_format == PFoutput_format_sql)
                                      ? SQL
                                      : STRATEGY;
            /* recursion strategy depending on the output format */
            rec_strategy_t *recursion_strategy = (strategy == SQL)
                                                ? recursion_sql
                                                : recursion_mil;

            bool           x_used, loop_used;
            PFla_env_t     e;
            PFarray_t     *old_env = NULL;
            PFalg_schema_t schema, res_schema;
            PFla_op_t     *base_x, *base_res;
            PFla_op_t     *seed, *res_seed;
            PFla_op_t     *new_map;
            PFla_op_t     *old_loop, *base_loop;
            PFla_op_t     *old_side_effects;

            /* initiate translation of e1 */
            reduce (ctx, kids[0], nts[0]);

            /* We know that the order of the result is only required
               outside the recursive function. Thus we throw away the
               pos column. */
            res_schema.count = 2;
            res_schema.items = PFmalloc (2 * sizeof (PFalg_schema_t));

            schema = A(RL(p)).rel->schema;
            assert (schema.count == 3);
            for (i = 0; i < 3; i++) {
                if (schema.items[i].name == col_iter)
                    res_schema.items[0] = schema.items[i];
                else if (schema.items[i].name == col_item)
                    res_schema.items[1] = schema.items[i];
                else if (schema.items[i].name == col_pos)
                    /* do nothing */;
                else
                    PFoops (OOPS_FATAL,
                            "Input schema contains other "
                            "columns than iter, pos, item");
            }

            seed = distinct (
                       project (A(RL(p)).rel,
                                proj (col_iter,
                                      col_iter),
                                proj (col_item,
                                      col_item)));

            /* create a new base for variable $x */
            base_x = rec_base (schema);

            /* create a new result base */
            base_res = rec_base (res_schema);

            /* create a new base_loop relation */
            base_loop = rec_base (LOOP->schema);

            /* save old loop operator */
            old_loop = LOOP;
            /* and overwrite it with the new one */
            LOOP = base_loop;

            /* for strategy IFP we do not need to introduce
               new map relations */
            if (strategy != IFP) {
                /* save old enviroment */
                old_env = ENV;

                /* create new environment */
                ENV = PFarray (sizeof (PFla_env_t), 50);

                /* update all variable bindings in old environment and put
                 * them into new environment */
                for (i = 0; i < PFarray_last (old_env); i++) {
                    e = *((PFla_env_t *) PFarray_at (old_env, i));

                    if (!e.map)
                        new_map = project (
                                      LOOP,
                                      proj (col_outer, col_iter),
                                      proj (col_inner, col_iter));
                    else
                        new_map = project (
                                      eqjoin (
                                          e.map,
                                          LOOP,
                                          col_inner,
                                          col_iter),
                                      proj (col_outer, col_outer),
                                      proj (col_inner, col_inner));

                    *((PFla_env_t *) PFarray_add (ENV))
                        = enventry (e.var, e.rel, new_map, e.frag);
                }
            }

            /* insert $x and "its document" into the NEW environment */
            *((PFla_env_t *) PFarray_add (ENV))
                = enventry (L(p)->sem.var, base_x, NULL, A(RL(p)).frag);

            /* save old side effects list ... */
            old_side_effects = SIDE_EFFECTS;
            /* ... and prepare a new side effects list */
            SIDE_EFFECTS = nil ();

            /* translate e2 under the specified conditions
             * (updated environment, updated loop)
             */
            reduce (ctx, kids[1], nts[1]);

            /* check whether $x and loop are used
               (the result of the checks are used later
               to discard recursion parameters if possible) */
            PFla_dag_mark (A(RR(p)).rel);
            PFla_dag_mark (SIDE_EFFECTS);
            x_used = SEEN(base_x);
            loop_used = SEEN(base_loop);
            PFla_dag_reset (A(RR(p)).rel);
            PFla_dag_reset (SIDE_EFFECTS);

#if RESULT == STAR
    res_seed = seed;
#else /* PLUS */
    /* create a new result seed */
    res_seed = PFla_empty_tbl_ (res_schema);
#endif

            A(p) = (struct PFla_pair_t) {
                        .rel  = recursion_strategy (strategy,
                                                    A(RR(p)).rel,
                                                    seed,
                                                    res_seed,
                                                    base_x,
                                                    base_res,
                                                    x_used,
                                                    loop_used,
                                                    old_loop,
                                                    base_loop,
                                                    SIDE_EFFECTS),
                        .frag = A(RR(p)).frag
                   };

            SIDE_EFFECTS = old_side_effects;

            /* clean up environment and loop relation */
            if (strategy != IFP) {
                ENV = old_env;
            }
            LOOP = old_loop;
        } break;

        default:
            PFoops (OOPS_FATAL, "untranslated expression (rule %i)", rule);
            break;
    }

    /* check consistency of our iter|pos|item interface */
    switch (rule) {
        /* result: pos|item */
        /* Query:              main (FunctionDecls, CoreExpr) */
        case 1:

        /* flwr intermediates */
        /* OptBindExpr:        for_ (forbind (forvars (var, nil),
                                              CoreExpr), CoreExpr) */
        case 6:
        /* OptBindExpr:        let (letbind (var, CoreExpr), CoreExpr) */
        case 7:
        /* OptBindExpr:        nil */
        case 8:

        /* order by */
        /* OrderSpecs:         orderspecs (CoreExpr, nil) */
        case 300:
        /* OrderSpecs:         orderspecs (CoreExpr, OrderSpecs) */
        case 301:

        /* twig constructors */
        /* TwigExpr:           twig_seq (TwigExpr, TwigSeq) */
        case 46:
        /* TwigSeq:            TwigExpr: */
        case 47:
        /* TwigExpr:           empty */
        case 48:
        /* TwigExpr:           CoreExpr */
        case 49:
        /* TwigExpr:           doc (TwigSeq) */
        case 50:
        /* TwigExpr:           elem (TagName, TwigSeq) */
        case 51:
        /* TwigExpr:           attr (TagName, CoreExpr) */
        case 52:
        /* TwigExpr:           text (CoreExpr) */
        case 53:
        /* TwigExpr:           comment (CoreExpr) */
        case 54:
        /* TwigExpr:           pi (CoreExpr, CoreExpr) */
        case 55:

        /* function application */
        /* FunctionArgs:       nil */
        case 500:
        /* FunctionArgs:       arg (FunctionArg, FunctionArgs) */
        case 501:
            break;

        default:
        {
            unsigned int count = 0;
            for (unsigned int i = 0; i < A(p).rel->schema.count; i++)
                if (A(p).rel->schema.items[i].name == col_iter ||
                    A(p).rel->schema.items[i].name == col_pos  ||
                    A(p).rel->schema.items[i].name == col_item)
                    count++;
            if (A(p).rel->schema.count != 3 && count !=3)
                PFoops (OOPS_FATAL,
                        "We require each core construct (also %i) to "
                        "return a relation with an iter|pos|item schema.",
                        p->kind);
        }
    }

    /* In case we recursively generate the algebra plan
       we need to record the mappings that have changed
       to ensure that we are able to clean up the side
       effects again. */
    if (CORE2ALG_MAP && (rel != A(p).rel || frag != A(p).frag))
        /* Add the mappings in bottom up order to ensure that we
           can consistently patch the changes again. */
        *((core2alg_map_t *) PFarray_add (CORE2ALG_MAP))
            = (core2alg_map_t) { .core = p, .rel = rel, .frag = frag};
}

/* recursion strategy for SQL */
static PFla_op_t *
recursion_sql (int strategy,
               PFla_op_t *body,
               PFla_op_t *seed,
               PFla_op_t *res_seed,
               PFla_op_t *base,
               PFla_op_t *base_res,
               bool x_used,
               bool loop_used,
               PFla_op_t *old_loop,
               PFla_op_t *base_loop,
               PFla_op_t *side_effects)
{
    (void)strategy;
    (void)base_res;
    (void)x_used;
    (void)res_seed;
    assert (strategy == SQL);


    /* check whether we may modify the strategy and
       if the DELTA approach is allowed */
    if (!PFprop_check_rec_delta (body) ||
        !PFprop_check_rec_delta (side_effects))
        PFoops (OOPS_FATAL, "SQL cannot cope with this query");

    PFla_op_t *res_body = NULL;
    PFla_op_t *res_rec_param = NULL;
    PFla_op_t *loop_rec_param = NULL;

    /* the result of the recursion body */
    res_body = distinct (
                   project (body,
                       proj (col_iter, col_iter),
                       proj (col_item, col_item)));

    /* ------------------- BODY ----------------- */

    res_rec_param = rec_param (
                        rec_arg (
                            rowid (seed, col_pos),
                            rowid (res_body, col_pos),
                            base
                        ),
                        nil ());

    /* ------------------ LOOP ------------------ */

    if (loop_used)
        /* for SQL the LOOP doesn't change */
        loop_rec_param = rec_param (
                            rec_arg (old_loop,
                                     base_loop,
                                     base_loop),
                            res_rec_param);
    else
        loop_rec_param = res_rec_param;

    /* ---------------RECURSION ---------------- */
    return rank (
               project (
                   rec_fix (
                       PFla_side_effects (
                           side_effects,
                           loop_rec_param),
                       res_body),
                   proj (col_iter, col_iter),
                   proj (col_item, col_item)),
               col_pos,
               sortby (col_item));
}

/* recursion strategy for Monet */
static PFla_op_t *
recursion_mil (int strategy,
               PFla_op_t *body,
               PFla_op_t *seed,
               PFla_op_t *res_seed,
               PFla_op_t *base,
               PFla_op_t *base_res,
               bool x_used,
               bool loop_used,
               PFla_op_t *old_loop,
               PFla_op_t *base_loop,
               PFla_op_t *side_effects)
{
    PFla_op_t  *res_body,
               *delta,
               *res;
    PFla_op_t  *res_rec_param,
               *loop_rec_param,
               *x_rec_param;
    PFla_op_t  *updated_loop;

    (void)strategy;
    assert (strategy == DELTA       ||
            strategy == TC          ||
            strategy == IFP         ||
            strategy == TC_OR_DELTA ||
            strategy == IFP_OR_DELTA);

    /* check whether we may modify the strategy and
       if the DELTA approach is allowed */
    if (VAR_STRATEGY(strategy) &&
        PFprop_check_rec_delta (body) &&
        PFprop_check_rec_delta (side_effects))
        strategy = DELTA;

    /* the result of the recursion body */
    res_body = distinct (project (body,
                                  proj (col_iter, col_iter),
                                  proj (col_item, col_item)));

    /* get the really new nodes */
    delta = difference (res_body,
                        project (base_res,
                                 proj (col_iter, col_iter),
                                 proj (col_item, col_item)));

    /* add the new nodes (of this recursion step)
       to our already collected result */
    res = disjunion (delta,
                     project (base_res,
                              proj (col_iter, col_iter),
                              proj (col_item, col_item)));

    /* ------------------- BODY ------------------- */

    /* using 'distinct (delta)' or 'distinct (res_body)'
       instead of 'res' changes the evaluation strategy:
        - 'delta': only the really new nodes are the input
          for the next recursion
        - 'res_body': the result of the current recursion
          is the input for the next recursion
        - 'res': the whole result collected until now
          is input to the next recurstion step */
    if (strategy == DELTA)
        body = delta;
    else if (strategy == TC ||
        strategy == TC_OR_DELTA)
        body = res_body;
    else if (strategy == IFP ||
        strategy == IFP_OR_DELTA)
        body = res;
    else
        PFoops (OOPS_FATAL,
                "unknown strategy in algebra translation "
                "of the recursion primitive");

    /* ------------------ RESULT ------------------ */
    res_rec_param = rec_param (
                        rec_arg (
                            res_seed,
                            res,
                            base_res),
                        nil ());

    /* ------------------- LOOP ------------------- */

    /* In case the loop relation was not used
       we don't need the recursion parameter */
    if (!loop_used) {
        loop_rec_param = res_rec_param;
    } else if (strategy == IFP || strategy == IFP_OR_DELTA) {
        /* for IFP the loop doesn't change */
        loop_rec_param = rec_param (rec_arg (old_loop,
                                             base_loop,
                                             base_loop),
                                    res_rec_param);
    } else {
        /* update the loop relation after the recursion body
           has been processed ... */
        updated_loop = project (eqjoin (distinct (
                                            project (delta,
                                                     proj (col_iter1,
                                                           col_iter))),
                                        base_loop,
                                        col_iter1,
                                        col_iter),
                                proj (col_iter, col_iter));

        /* ... and integrate the loop maintenance in the recursion */
        loop_rec_param = rec_param (rec_arg (old_loop,
                                             updated_loop,
                                             base_loop),
                                    res_rec_param);
    }

    /* -------------------- $x -------------------- */
    if (x_used)
        x_rec_param = rec_param (
                          rec_arg (
                              rank (
                                  seed,
                                  col_pos,
                                  sortby (col_item)),
                              rank (
                                  body,
                                  col_pos,
                                  sortby (col_item)),
                              base),
                          loop_rec_param);
    else
        x_rec_param = loop_rec_param;

    /* ---------------- RECURSION ----------------- */
    return rank (
                rec_fix (PFla_side_effects (side_effects, x_rec_param), res),
                col_pos, sortby (col_item));
}

static PFalg_step_spec_t
locstep_spec (PFalg_axis_t axis, PFty_t ty)
{
    PFalg_step_spec_t spec;

    spec.axis = axis;
    /* missing QName */
    spec.qname = PFqname (PFns_wild, NULL);

    if (PFty_subtype (ty, PFty_xs_anyAttribute ())) {
        /* This is a test for attribute nodes */
        spec.kind = node_kind_attr;
        spec.qname = PFty_name (ty);
    }
    else if (PFty_subtype (ty, PFty_xs_anyElement ())) {
        /* This is a test for element nodes */
        spec.kind = node_kind_elem;
        spec.qname = PFty_name (ty);
    }
    else if (PFty_subtype (ty, PFty_doc (PFty_xs_anyType ()))) {
        /* This is a test for document nodes */
        spec.kind = node_kind_doc;
    }
    else if (PFty_subtype (ty, PFty_text ())) {
        /* This is a test for text nodes */
        spec.kind = node_kind_text;
    }
    else if (PFty_subtype (ty, PFty_comm ())) {
        /* This is a test for comment nodes */
        spec.kind = node_kind_comm;
    }
    else if (PFty_subtype (ty, PFty_pi (NULL))) {
        /* This is a test for processing-instruction nodes */
        spec.kind = node_kind_pi;
        spec.qname = PFty_name (ty);
    }
    else if (PFty_subtype (PFty_xs_anyNode (), ty)) {
        /* If all these cases did not apply, it is probably a node() test. */
        spec.kind = node_kind_node;
    }
    /* If we still couldn't find out, we probably need to give up. */
    else {
        PFoops (OOPS_FATAL,
                "Problem with an XPath step: cannot evaluate "
                "node test `%s'", PFty_str (ty));
        spec.kind = node_kind_node;
    }

    return spec;
}

/**
 * Construct a relational expression for a path step
 */
static struct PFla_pair_t
locstep (core2alg_ctx_t *ctx,
         PFalg_axis_t axis, PFty_t ty,
         struct PFla_pair_t p)
{
    if (PFprop_type_of (p.rel, col_item) == aat_error)
        return p;
    else if (!(PFprop_type_of (p.rel, col_item) & aat_node))
        PFoops (OOPS_FATAL,
                "err:XP0019: Argument to location step must be a node sequence.");

    /*
     *                  env, loop: e => (q(e), delta)
     * ------------------------------------------------------------
     *                       env, loop: e/a::n =>
     * (row_pos<item>/iter (SCJ (proj_iter,item (q(e)), delta)), delta)
     *
     * A(L(p)).rel contains a axis node with information on the
     * location step. Will be read out in PFla_step().
     */
    PFla_op_t *step = PFla_project (
                          PFla_step_join_simple (
                              PFla_set_to_la (p.frag),
                              project (p.rel,
                                       proj (col_iter, col_iter),
                                       proj (col_item, col_item)),
                              locstep_spec (axis, ty),
                              col_item,
                              col_item1),
                          PFalg_proj (col_iter, col_iter),
                          PFalg_proj (col_item, col_item1));

    if (ORDERING)
        return (struct  PFla_pair_t) {
                   .rel = rank (step, col_pos, sortby (col_item)),
                   .frag = p.frag };
    else
        return (struct  PFla_pair_t) {
                   .rel = rowid (step, col_pos),
                   .frag = p.frag };
}

/**
 * Construct a new entry to be inserted into the variable environment.
 * Called whenever a new variable is declared.
 */
static PFla_env_t
enventry (PFvar_t *var, PFla_op_t *rel, PFla_op_t *map, PFarray_t *doc)
{
    return (PFla_env_t) { .var = var, .rel = rel, .map = map, .frag = doc };
}

/**
 * Given an XQuery type @a ty, an algebra expression @a e, and the
 * loop relation @a loop, return an algebra expression that returns
 * the relation with schema (iter, subty), so that for each iter value
 * in @a loop there exists one tuple, with the subty column set to
 * true, if @a e has a subtype of @a ty, and false otherwise.
 */
static PFla_op_t *
type_test (PFty_t ty, PFla_pair_t e, PFla_op_t *loop)
{
    PFalg_aggr_t aggr_item;
    PFla_op_t   *itemty,
                *aggr;

    /*
     * Collect algebra expression with schema (iter,pos,itemty)
     * so that itemty is true for any item that is a subtype of
     * ty, and false otherwise.
     *
     * The surface language only allows QNames for predefined
     * types, or node kind tests. Fortunately, only few atomic
     * types are predefined: xs:integer, xs:decimal, xs:double,
     * xs:boolean, xs:string. For all of them we have an algebra
     * correspondance.
     *
     * We first consider the case that ty is the empty sequence.
     * (This cannot be entered on the surface language. But it
     * may be introduced during core generation/optimization.
     * And we want to avoid nasty bugs here, when that case would
     * be caught in the following cases.)
     *
     *        /                        subty \
     *       | dist (proj_iter (e)) X ------- |       (non-empty iters)
     *        \                        false /
     *                           U
     *    /                                 subty \
     *   | (loop \ dist (proj_iter (e))) X ------- |  (empty iters)
     *    \                                 false /
     *
     */
    if (PFty_subtype (ty, PFty_empty ()))
        return
            disjunion (
                attach (
                    distinct (project (e.rel, proj (col_iter, col_iter))),
                    col_subty, lit_bln (false)),
                attach (
                    difference (
                        loop,
                        distinct (project (e.rel, proj (col_iter, col_iter)))),
                    col_subty, lit_bln (true)));
    /*
     * To test, e.g., for integer values, use
     *
     *   proj_iter,pos,itemty (type_itemty:item/int (e))
     *
     */
    else if (PFty_subtype (ty, PFty_star (PFty_xs_integer ())))
        itemty = type (e.rel, col_itemty, col_item, aat_int);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_decimal ())))
        /* xs:integer is a subtype of xs:decimal.
         * Test for both types. The `type' operator merely adds a boolean
         * column. We OR them after testing for for both types.
         */
        itemty = or (type (type (e.rel, col_item2, col_item, aat_int),
                           col_item3, col_item, aat_dec),
                     col_itemty, col_item2, col_item3);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_double ())))
        itemty = type (e.rel, col_itemty, col_item, aat_dbl);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_boolean ())))
        itemty = type (e.rel, col_itemty, col_item, aat_bln);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_string ())))
        itemty = type (e.rel, col_itemty, col_item, aat_str);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_datetime ())))
        itemty = type (e.rel, col_itemty, col_item, aat_dtime);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_date ())))
        itemty = type (e.rel, col_itemty, col_item, aat_date);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_time ())))
        itemty = type (e.rel, col_itemty, col_item, aat_time);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_gyearmonth ())))
        itemty = type (e.rel, col_itemty, col_item, aat_gymonth);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_gyear ())))
        itemty = type (e.rel, col_itemty, col_item, aat_gyear);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_gmonthday ())))
        itemty = type (e.rel, col_itemty, col_item, aat_gmday);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_gmonth ())))
        itemty = type (e.rel, col_itemty, col_item, aat_gmonth);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_gday ())))
        itemty = type (e.rel, col_itemty, col_item, aat_gday);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_yearmonthduration ())))
        itemty = type (e.rel, col_itemty, col_item, aat_ymduration);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_daytimeduration ())))
        itemty = type (e.rel, col_itemty, col_item, aat_dtduration);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_duration ())))
       itemty = or (type (or (type (type (e.rel, col_iter2,
                                          col_item, aat_ymduration),
                                    col_iter3,
                                    col_item,
                                    aat_dtduration),
                              col_iter4, col_iter2, col_iter3),
                          col_iter5, col_item, aat_duration),
                    col_itemty, col_iter4, col_iter5);
    else if (PFty_subtype (ty, PFty_star (PFty_untypedAtomic ())))
        itemty = type (e.rel, col_itemty, col_item, aat_uA);
    else if (PFty_subtype (ty, PFty_star (PFty_xs_anyNode ()))) {
        PFla_op_t *filter, *number, *in_loop;

        /* create a key for all rows */
        number  = rowid (e.rel, col_inner);
        /* use this key as inner loop relation */
        in_loop = project (number, proj (col_iter1, col_inner));
        /* evaluate for all nodes a self step that filters the correct
           kind and name */
        filter  = project (
                      step_join (
                          PFla_set_to_la (e.frag),
                          type_assert_pos (
                              select_ (
                                  type (number, col_itemty, col_item, aat_node),
                                  col_itemty),
                              col_item, aat_node),
                          locstep_spec (alg_self, PFty_prime (ty)), -1,
                          col_item, col_item2),
                      proj (col_iter1, col_inner));

        /* Attach the Boolean value true for all rows that matched the
           self step filter and the value false for all other rows.
           Map back the old iter values to the new Boolean item column */
        itemty = eqjoin (number,
                         disjunion (attach (filter,
                                            col_itemty,
                                            lit_bln (true)),
                                    attach (difference (in_loop, filter),
                                            col_itemty,
                                            lit_bln (false))),
                         col_inner,
                         col_iter1);
    }
    else
        PFoops (OOPS_FATAL,
                "Sorry, I cannot translate the test for type `%s'",
                PFty_str (ty));

    itemty = project (itemty,
                      proj (col_iter, col_iter),
                      proj (col_itemty, col_itemty));

    /*
     * Second part is the test for the occurence indicator.
     */

    /* build a seqty1 aggregate */
    aggr_item = PFalg_aggr (alg_aggr_seqty1, col_subty, col_itemty);
    aggr      = aggr (itemty, col_iter, 1, &aggr_item);

    /*
     * Ocurrence indicator `1' (exactly one item).
     *
     * seqty1_subty:item/iter (proj_iter,item:itemty (itemty))
     *                    U
     *  /                              subty\
     * | (loop \ proj_iter (itemty)) X ----- |
     *  \                              false/
     *
     * (First part considers all iterations with length of at
     * least one: The itemty expression contains true/false values
     * as determined above. The seqty1 operator sets true for all
     * those `iter' groups, where there is exactly one tuple with
     * value `true', and false otherwise. The second part of the
     * union considers all the empty sequences. They do not match
     * the occurrence indicator and are thus set to false.)
     */
    if (PFty_subtype (ty, PFty_item ()))
        return
            disjunion (
                aggr,
                attach (
                    difference (
                        loop,
                        project (itemty, proj (col_iter, col_iter))),
                    col_subty, lit_bln (false)));

    /*
     * Ocurrence indicator `?' (zero or one item).
     *
     * seqty1_subty:item/iter (proj_iter,item:itemty (itemty))
     *                    U
     *  /                              subty\
     * | (loop \ proj_iter (itemty)) X ----- |
     *  \                              true /
     *
     * In contrast to `1', we return true for all empty sequences.
     */
    if (PFty_subtype (ty, PFty_opt (PFty_item ())))
        return
            disjunion (
                aggr,
                attach (
                    difference (
                        loop,
                        project (itemty, proj (col_iter, col_iter))),
                    col_subty, lit_bln (true)));

    /* turn the seqty1 aggregate into an all aggregate */
    aggr->sem.aggr.aggr[0].kind = alg_aggr_all;

    /*
     * Ocurrence indicator `+' (one or more items).
     *
     * all_subty:item/iter (proj_iter,item:itemty (itemty))
     *                    U
     *  /                              subty \
     * | (loop \ proj_iter (itemty)) X -----  |
     *  \                              false /
     *
     * Groupwise test if all tuples in itemty carry a `true'.
     * This makes all iterations true that contain only items
     * that satisfy the type test, and false all those that
     * contain at least one item that does not satisfy the
     * type test. We are left with considering the empty sequences
     * that do not qualify for the name test. We return false for
     * them.
     */
    if (PFty_subtype (ty, PFty_plus (PFty_item ())))
        return
            disjunion (
                aggr,
                attach (
                    difference (
                        loop,
                        project (itemty, proj (col_iter, col_iter))),
                    col_subty, lit_bln (false)));

    /*
     * Ocurrence indicator `*' (zero or more items).
     *
     * all_subty:item/iter (proj_iter,item:itemty (itemty))
     *                    U
     *  /                              subty\
     * | (loop \ proj_iter (itemty)) X ----  |
     *  \                              true /
     *
     * Almost the same as `+', but return true for empty sequences.
     */
    if (PFty_subtype (ty, PFty_star (PFty_item ())))
        return
            disjunion (
                aggr,
                attach (
                    difference (
                        loop,
                        project (itemty, proj (col_iter, col_iter))),
                    col_subty, lit_bln (true)));

    /*
     * We should never reach this point.
     */
    PFoops (OOPS_FATAL, "Error in type_test().");
    assert(0); /* we should never come here! */
    return NULL; /* pacify picky compilers */
}

/**
 * Extract all possible algebra types from the XQuery type.
 */
static PFalg_simple_type_t
PFalg_type (PFty_t ty)
{
    PFalg_simple_type_t alg_ty = 0;

    ty = PFty_prime (PFty_defn (ty));

    if (!PFty_disjoint (ty, PFty_xs_integer ()))
        alg_ty |= aat_int;
    if (!PFty_disjoint (ty, PFty_xs_string ()))
        alg_ty |= aat_str;
    if (!PFty_disjoint (ty, PFty_xs_double ()))
        alg_ty |= aat_dbl;
    if (!PFty_disjoint (ty, PFty_xs_decimal ()))
        alg_ty |= aat_dec;
    if (!PFty_disjoint (ty, PFty_xs_boolean ()))
        alg_ty |= aat_bln;
    if (!PFty_disjoint (ty, PFty_xs_QName ()))
        alg_ty |= aat_qname;
    if (!PFty_disjoint (ty, PFty_untypedAtomic ()))
        alg_ty |= aat_uA;
    if (!PFty_disjoint (ty, PFty_xs_anyAttribute ()))
        alg_ty |= aat_anode;
    if (!PFty_disjoint (ty, PFty_xs_anyElement ()) ||
        !PFty_disjoint (ty, PFty_doc (PFty_xs_anyNode ())) ||
        !PFty_disjoint (ty, PFty_pi (NULL)) ||
        !PFty_disjoint (ty, PFty_comm ()) ||
        !PFty_disjoint (ty, PFty_text ()))
        alg_ty |= aat_pnode;
    if (!PFty_disjoint (ty, PFty_stmt ())) {
        alg_ty |= aat_update;
        alg_ty |= aat_node;
        alg_ty |= aat_node1;
        alg_ty |= aat_uA;
        alg_ty |= aat_qname;
    }
    if (!PFty_disjoint (ty, PFty_docmgmt ())) {
        alg_ty |= aat_docmgmt;
        alg_ty |= aat_path;
        alg_ty |= aat_docnm;
        alg_ty |= aat_colnm;
    }
    if (!PFty_disjoint (ty, PFty_xs_datetime ()))
        alg_ty |= aat_dtime;
    if (!PFty_disjoint (ty, PFty_xs_date ()))
        alg_ty |= aat_date;
    if (!PFty_disjoint (ty, PFty_xs_time ()))
        alg_ty |= aat_time;
    if (!PFty_disjoint (ty, PFty_xs_gyearmonth ()))
        alg_ty |= aat_gymonth;
    if (!PFty_disjoint (ty, PFty_xs_gyear ()))
        alg_ty |= aat_gyear;
    if (!PFty_disjoint (ty, PFty_xs_gmonthday ()))
        alg_ty |= aat_gmday;
    if (!PFty_disjoint (ty, PFty_xs_gmonth ()))
        alg_ty |= aat_gmonth;
    if (!PFty_disjoint (ty, PFty_xs_gday ()))
        alg_ty |= aat_gday;
    if (!PFty_disjoint (ty, PFty_xs_duration ()))
        alg_ty |= aat_duration;
    if (!PFty_disjoint (ty, PFty_xs_yearmonthduration ()))
        alg_ty |= aat_ymduration;
    if (!PFty_disjoint (ty, PFty_xs_daytimeduration ()))
        alg_ty |= aat_dtduration;
    return alg_ty;
}

/**
 * Extract occurrence indicator from the XQuery type.
 */
static PFalg_occ_ind_t
PFalg_type_occ (PFty_t ty)
{
    if (PFty_subtype (ty, PFty_item ()))
        return alg_occ_exactly_one;
    else if (PFty_subtype (ty, PFty_plus (PFty_item ())))
        return alg_occ_one_or_more;
    else if (PFty_subtype (ty, PFty_opt(PFty_item ())))
        return alg_occ_zero_or_one;
    else
        return alg_occ_unknown;
}


/**
 * Compile XQuery Core tree into relational algebra tree.
 *
 * @param r root of the Core tree.
 * @return the algebra equivalent of @a r
 */
PFla_op_t *
PFcore2alg (PFcnode_t *r, PFquery_t *query,
            enum PFoutput_format_t output_format)
{
    PFarray_t *options = NULL;

    /* create a new context */
    core2alg_ctx_t ctx;

    assert (r);

    /* label the core tree bottom up */
    PFcore2alg_label (r);

    /* get empty environment */
    ctx.env  = PFarray (sizeof (PFla_env_t), 50);
    /* loop is initially a table with just one tuple */
    ctx.loop = lit_tbl (collist (col_iter), tuple (lit_nat (1)));
    /* side_effects is initally an empty list */
    ctx.side_effects = nil ();
    /* Create a stack for the map relation information */
    ctx.mapping = PFarray (sizeof (map_rel_info_t), 50);
    /* set ordering mode */
    ctx.ordering = query->ordering;
    /* initialize the sequence count with a dummy value */
    ctx.seq_count = 0;

    /* Pointer to array of function parameter values */
    ctx.fun_args = NULL;

    /* Read recursion depth information as option */
    options = PFenv_lookup (PFoptions, PFqname (PFns_lib, "recursion-depth"));
    if (!options)
        ctx.recursion_depth = 0;
    else {
        if (PFarray_last (options) > 1)
            PFoops (OOPS_WARNING,
                    "Only the last recursion depth option is used.");

        ctx.recursion_depth = atoi (*((char **) PFarray_top (options)));
    }

    /* Initialize stack recording the active user-defined functions */
    ctx.fun_active = PFarray (sizeof (fun_active_t), 50);

    /* initially do not memorize algebra translations */
    ctx.core2alg_map = NULL;

    /* depending on the output format we choose a different
     * recursion strategy */
    PFoutput_format = output_format;

    /* invoke compilation */
    reduce (&ctx, r, 1);

    return A(r).rel;
}

/* vim:set shiftwidth=4 expandtab filetype=c: */
