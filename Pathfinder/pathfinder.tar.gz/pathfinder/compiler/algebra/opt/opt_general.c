#line 1 "opt_general.brg"


/**
 * @file
 *
 * Optimize relational algebra expression DAG
 * based on general patterns.
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 * $Id$
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"
#include <assert.h>
#include <stdio.h>

#include "algopt.h"
#include "properties.h"
#include "alg_dag.h"
#include "oops.h"         /* PFoops() */
#include "mem.h"          /* PFmalloc() */

/* mnemonic column list accessors */
#include "alg_cl_mnemonic.h"

/* Easily access subtree-parts */
#include "child_mnemonic.h"

/*
 * Accessors for the burg matcher
 */
typedef struct PFla_op_t *NODEPTR_TYPE;

/* accessor to the node kind */
#define OP_LABEL(p) ((p)->kind)

/* accessors to left and right child node */
#define LEFT_CHILD(p)  ((p)->child[0])
#define RIGHT_CHILD(p) ((p)->child[1])

/* the state determined during bottom-up labeling is stored here */
#define STATE_LABEL(p) ((p)->state_label)

/* the state of the children determined during
   bottom-up labeling is backed up here */
#define CHILD_STATE_LABEL(p,i) ((p)->child_state_label[i])

/* If something goes wrong, call PFoops */
#define PANIC(...) PFoops (OOPS_BURG, __VA_ARGS__)

#ifndef PFopt_general_PANIC
#define PFopt_general_PANIC	PANIC
#endif /* PFopt_general_PANIC */
#include <stdlib.h> /* for abort() */
#ifdef NDEBUG
#define PFopt_general_assert(x,y)	;
#else
#define PFopt_general_assert(x,y)	if(!(x)) {y; abort();}
#endif
static short PFopt_general_r1_nts[] ={ 6, 13, 2, 0 };
static short PFopt_general_r2_nts[] ={ 6, 2, 0 };
static short PFopt_general_r3_nts[] ={ 0 };
static short PFopt_general_r5_nts[] ={ 2, 0 };
static short PFopt_general_r7_nts[] ={ 2, 2, 0 };
static short PFopt_general_r26_nts[] ={ 14, 2, 0 };
static short PFopt_general_r27_nts[] ={ 2, 14, 0 };
static short PFopt_general_r33_nts[] ={ 13, 2, 0 };
static short PFopt_general_r62_nts[] ={ 3, 0 };
static short PFopt_general_r64_nts[] ={ 13, 3, 0 };
static short PFopt_general_r75_nts[] ={ 4, 0 };
static short PFopt_general_r77_nts[] ={ 2, 5, 0 };
static short PFopt_general_r78_nts[] ={ 2, 13, 14, 0 };
static short PFopt_general_r87_nts[] ={ 4, 5, 0 };
static short PFopt_general_r88_nts[] ={ 13, 14, 5, 0 };
static short PFopt_general_r94_nts[] ={ 6, 7, 0 };
static short PFopt_general_r95_nts[] ={ 2, 8, 0 };
static short PFopt_general_r96_nts[] ={ 2, 9, 0 };
static short PFopt_general_r99_nts[] ={ 6, 10, 2, 0 };
static short PFopt_general_r101_nts[] ={ 11, 10, 0 };
static short PFopt_general_r105_nts[] ={ 2, 12, 0 };
static short PFopt_general_r107_nts[] ={ 13, 12, 0 };
static short PFopt_general_r112_nts[] ={ 14, 0 };
static short PFopt_general_r118_nts[] ={ 13, 13, 0 };
static short PFopt_general_r134_nts[] ={ 14, 14, 0 };
static short PFopt_general_r170_nts[] ={ 13, 14, 0 };
static short PFopt_general_r181_nts[] ={ 14, 5, 0 };
static short PFopt_general_r190_nts[] ={ 14, 12, 0 };
static short PFopt_general_r193_nts[] ={ 6, 14, 13, 2, 0 };
static short PFopt_general_r194_nts[] ={ 6, 14, 2, 0 };
static short PFopt_general_r196_nts[] ={ 6, 14, 7, 0 };
static short PFopt_general_r197_nts[] ={ 6, 14, 10, 2, 0 };
short *PFopt_general_nts[] = {
	0,
	PFopt_general_r1_nts,
	PFopt_general_r2_nts,
	PFopt_general_r3_nts,
	PFopt_general_r3_nts,
	PFopt_general_r5_nts,
	PFopt_general_r3_nts,
	PFopt_general_r7_nts,
	PFopt_general_r3_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r7_nts,
	PFopt_general_r3_nts,
	PFopt_general_r7_nts,
	PFopt_general_r7_nts,
	PFopt_general_r7_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r3_nts,
	PFopt_general_r5_nts,
	0,
	0,
	PFopt_general_r5_nts,
	PFopt_general_r7_nts,
	PFopt_general_r3_nts,
	PFopt_general_r26_nts,
	PFopt_general_r27_nts,
	PFopt_general_r7_nts,
	PFopt_general_r7_nts,
	PFopt_general_r27_nts,
	0,
	PFopt_general_r5_nts,
	PFopt_general_r33_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	0,
	0,
	0,
	0,
	PFopt_general_r5_nts,
	0,
	PFopt_general_r5_nts,
	PFopt_general_r3_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r3_nts,
	PFopt_general_r5_nts,
	0,
	0,
	PFopt_general_r62_nts,
	PFopt_general_r33_nts,
	PFopt_general_r64_nts,
	PFopt_general_r33_nts,
	PFopt_general_r33_nts,
	PFopt_general_r33_nts,
	PFopt_general_r33_nts,
	PFopt_general_r33_nts,
	PFopt_general_r33_nts,
	0,
	0,
	0,
	PFopt_general_r5_nts,
	PFopt_general_r75_nts,
	PFopt_general_r33_nts,
	PFopt_general_r77_nts,
	PFopt_general_r78_nts,
	PFopt_general_r77_nts,
	PFopt_general_r78_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r5_nts,
	PFopt_general_r33_nts,
	PFopt_general_r3_nts,
	PFopt_general_r87_nts,
	PFopt_general_r88_nts,
	PFopt_general_r3_nts,
	PFopt_general_r3_nts,
	PFopt_general_r2_nts,
	PFopt_general_r3_nts,
	PFopt_general_r2_nts,
	PFopt_general_r94_nts,
	PFopt_general_r95_nts,
	PFopt_general_r96_nts,
	PFopt_general_r96_nts,
	PFopt_general_r3_nts,
	PFopt_general_r99_nts,
	PFopt_general_r3_nts,
	PFopt_general_r101_nts,
	PFopt_general_r3_nts,
	PFopt_general_r7_nts,
	0,
	PFopt_general_r105_nts,
	PFopt_general_r105_nts,
	PFopt_general_r107_nts,
	PFopt_general_r3_nts,
	0,
	PFopt_general_r7_nts,
	PFopt_general_r5_nts,
	PFopt_general_r112_nts,
	0,
	PFopt_general_r5_nts,
	PFopt_general_r75_nts,
	PFopt_general_r33_nts,
	PFopt_general_r5_nts,
	PFopt_general_r118_nts,
	PFopt_general_r3_nts,
	PFopt_general_r3_nts,
	PFopt_general_r112_nts,
	PFopt_general_r26_nts,
	PFopt_general_r27_nts,
	PFopt_general_r26_nts,
	PFopt_general_r27_nts,
	PFopt_general_r26_nts,
	PFopt_general_r27_nts,
	0,
	PFopt_general_r26_nts,
	PFopt_general_r27_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r134_nts,
	PFopt_general_r26_nts,
	PFopt_general_r27_nts,
	PFopt_general_r26_nts,
	PFopt_general_r112_nts,
	0,
	PFopt_general_r112_nts,
	0,
	0,
	0,
	0,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	0,
	0,
	0,
	0,
	PFopt_general_r112_nts,
	0,
	0,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	0,
	0,
	0,
	0,
	0,
	PFopt_general_r170_nts,
	PFopt_general_r170_nts,
	PFopt_general_r170_nts,
	PFopt_general_r170_nts,
	PFopt_general_r170_nts,
	0,
	PFopt_general_r170_nts,
	0,
	0,
	0,
	PFopt_general_r112_nts,
	PFopt_general_r181_nts,
	PFopt_general_r181_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r112_nts,
	PFopt_general_r170_nts,
	PFopt_general_r3_nts,
	PFopt_general_r170_nts,
	PFopt_general_r190_nts,
	PFopt_general_r26_nts,
	PFopt_general_r112_nts,
	PFopt_general_r193_nts,
	PFopt_general_r194_nts,
	PFopt_general_r194_nts,
	PFopt_general_r196_nts,
	PFopt_general_r197_nts,
};
static unsigned char PFopt_general_serialize_seq_transition[4][2] = {
{    0,    0}	/* row 0 */,
{    0,    2}	/* row 1 */,
{    0,    1}	/* row 2 */,
{    0,    2}	/* row 3 */
};
static unsigned char PFopt_general_serialize_rel_transition[4][2] = {
{    0,    0}	/* row 0 */,
{    0,    2}	/* row 1 */,
{    0,    1}	/* row 2 */,
{    0,    2}	/* row 3 */
};
static unsigned char PFopt_general_side_effects_transition[4][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    6}	/* row 1 */,
{    0,    3,    4}	/* row 2 */,
{    0,    5,    2}	/* row 3 */
};
static unsigned char PFopt_general_cross_transition[4][4] = {
{    0,    0,    0,    0}	/* row 0 */,
{    0,    6,    6,    6}	/* row 1 */,
{    0,    4,    5,    3}	/* row 2 */,
{    0,    4,    2,    1}	/* row 3 */
};
static unsigned char PFopt_general_eqjoin_transition[4][4] = {
{    0,    0,    0,    0}	/* row 0 */,
{    0,    4,    4,    4}	/* row 1 */,
{    0,    3,    2,    2}	/* row 2 */,
{    0,    3,    2,    1}	/* row 3 */
};
static unsigned char PFopt_general_semijoin_transition[7][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    4,    4}	/* row 1 */,
{    0,    1,    2}	/* row 2 */,
{    0,    4,    4}	/* row 3 */,
{    0,    1,    3}	/* row 4 */,
{    0,    1,    2}	/* row 5 */,
{    0,    1,    2}	/* row 6 */
};
static unsigned char PFopt_general_thetajoin_transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    3,    3}	/* row 1 */,
{    0,    1,    2}	/* row 2 */
};
static unsigned char PFopt_general_disjunion_transition[4][4] = {
{    0,    0,    0,    0}	/* row 0 */,
{    0,    5,    1,    1}	/* row 1 */,
{    0,    4,    2,    2}	/* row 2 */,
{    0,    4,    2,    3}	/* row 3 */
};
static unsigned char PFopt_general_intersect_transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    2}	/* row 1 */,
{    0,    3,    1}	/* row 2 */
};
static unsigned char PFopt_general_difference_transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    1}	/* row 1 */,
{    0,    3,    2}	/* row 2 */
};
static unsigned char PFopt_general_step_transition[2][9] = {
{    0,    0,    0,    0,    0,    0,    0,    0,    0}	/* row 0 */,
{    0,    3,    2,    3,    3,    4,    1,    2,    2}	/* row 1 */
};
static unsigned char PFopt_general_step_join_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFopt_general_guide_step_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFopt_general_guide_step_join_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFopt_general_doc_index_join_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFopt_general_doc_access_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFopt_general_fcns_transition[4][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    3}	/* row 1 */,
{    0,    3,    3}	/* row 2 */,
{    0,    2,    4}	/* row 3 */
};
static unsigned char PFopt_general_docnode_transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    4}	/* row 1 */,
{    0,    3,    1}	/* row 2 */
};
static unsigned char PFopt_general_element_transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    3}	/* row 1 */,
{    0,    1,    4}	/* row 2 */
};
static unsigned char PFopt_general_content_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFopt_general_merge_adjacent_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFopt_general_frag_union_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFopt_general_error_transition[4][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */,
{    0,    4,    3}	/* row 2 */,
{    0,    2,    1}	/* row 3 */
};
static unsigned char PFopt_general_cache_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFopt_general_trace_transition[4][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */,
{    0,    2}	/* row 2 */,
{    0,    1}	/* row 3 */
};
static unsigned char PFopt_general_trace_items_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFopt_general_trace_msg_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFopt_general_trace_map_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFopt_general_rec_fix_transition[4][2] = {
{    0,    0}	/* row 0 */,
{    0,    2}	/* row 1 */,
{    0,    1}	/* row 2 */,
{    0,    2}	/* row 3 */
};
static unsigned char PFopt_general_rec_param_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFopt_general_rec_arg_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFopt_general_fun_call_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */,
{    0,    2}	/* row 2 */
};
static unsigned char PFopt_general_fun_param_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFopt_general_fun_frag_param_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFopt_general_string_join_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */,
{    0,    2}	/* row 2 */
};
static struct {
	unsigned int f28:2;
	unsigned int f31:3;
	unsigned int f32:2;
	unsigned int f33:2;
	unsigned int f34:3;
	unsigned int f35:3;
	unsigned int f36:4;
	unsigned int f37:3;
	unsigned int f38:7;
	unsigned int f39:3;
} PFopt_general_plank_0[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  50,   0,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 2 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 3 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  25,   0,},	/* row 4 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  24,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  54,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  52,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  53,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 13 */
	{   0,   0,   0,   0,   4,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  40,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  38,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  40,   0,},	/* row 17 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  39,   0,},	/* row 18 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  39,   0,},	/* row 19 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  37,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  39,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 22 */
	{   0,   0,   0,   0,   0,   0,  10,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,  10,   0,   0,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   6,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   6,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  22,   0,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  20,   0,},	/* row 28 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  21,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 30 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  23,   0,},	/* row 31 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 32 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 33 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  61,   0,},	/* row 34 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  60,   0,},	/* row 35 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  64,   0,},	/* row 36 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   8,   0,},	/* row 37 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  65,   0,},	/* row 38 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  63,   0,},	/* row 39 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 40 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  58,   0,},	/* row 41 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 42 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  59,   0,},	/* row 43 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  58,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  31,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  32,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   4,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   5,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   5,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   4,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  18,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  19,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 66 */
	{   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   5,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   5,   0,   0,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   4,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  57,   0,},	/* row 81 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 82 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,},	/* row 83 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 84 */
	{   1,   2,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 85 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 86 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  34,   0,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  33,   0,},	/* row 88 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 89 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  62,   0,},	/* row 90 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  27,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   1,   3,   1,   1,   3,   3,   7,   0,   0,   0,},	/* row 96 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 97 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  55,   0,},	/* row 98 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 99 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  56,   0,},	/* row 100 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 101 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 102 */
	{   0,   0,   0,   0,   0,   0,   8,   0,   0,   0,},	/* row 103 */
	{   0,   0,   0,   0,   0,   0,   8,   0,   0,   0,},	/* row 104 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  14,   0,},	/* row 105 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  14,   0,},	/* row 106 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  12,   0,},	/* row 107 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  14,   0,},	/* row 108 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  14,   0,},	/* row 109 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 110 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  11,   0,},	/* row 111 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  14,   0,},	/* row 114 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  12,   0,},	/* row 115 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  13,   0,},	/* row 116 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  12,   0,},	/* row 117 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  14,   0,},	/* row 118 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  14,   0,},	/* row 119 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  46,   0,},	/* row 120 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 121 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 122 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   6,   0,},	/* row 123 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   9,   0,},	/* row 124 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   7,   0,},	/* row 125 */
	{   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,},	/* row 126 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  26,   0,},	/* row 127 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 128 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  28,   0,},	/* row 129 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 130 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 131 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 132 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 133 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 134 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 135 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  30,   0,},	/* row 136 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 137 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  29,   0,},	/* row 138 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 139 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 140 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  44,   0,},	/* row 141 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 142 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  43,   0,},	/* row 143 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  43,   0,},	/* row 144 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  45,   0,},	/* row 145 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  48,   0,},	/* row 146 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 147 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  49,   0,},	/* row 148 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  47,   0,},	/* row 149 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 150 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 151 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  10,   0,},	/* row 152 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 153 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  17,   0,},	/* row 154 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  16,   0,},	/* row 155 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 156 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,},	/* row 157 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   4,},	/* row 158 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,},	/* row 159 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 160 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 161 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 162 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 163 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 164 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 165 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 166 */
	{   0,   0,   0,   0,   0,   0,   0,   1,  36,   0,},	/* row 167 */
	{   0,   0,   0,   0,   0,   0,   0,   3,  36,   0,},	/* row 168 */
	{   0,   0,   0,   0,   0,   0,   0,   3,   2,   0,},	/* row 169 */
	{   0,   0,   0,   0,   0,   0,   0,   2,  36,   0,},	/* row 170 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 171 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  35,   0,},	/* row 172 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 173 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,},	/* row 174 */
	{   0,   0,   0,   0,   0,   0,   9,   0,   0,   0,},	/* row 175 */
	{   0,   0,   0,   0,   0,   0,   9,   0,   0,   0,},	/* row 176 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 177 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  15,   0,},	/* row 178 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 179 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 180 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  51,   0,},	/* row 181 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 182 */
	{   0,   0,   0,   0,   6,   0,   0,   0,   0,   0,},	/* row 183 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 184 */
	{   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 185 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 186 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 187 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 188 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 189 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 190 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 191 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 192 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 193 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 194 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 195 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 196 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 197 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 198 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  42,   0,},	/* row 199 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 200 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  41,   0,},	/* row 201 */
};
static struct {
	unsigned int f18:2;
	unsigned int f19:4;
	unsigned int f20:2;
	unsigned int f21:2;
	unsigned int f22:2;
	unsigned int f23:2;
	unsigned int f24:2;
	unsigned int f25:3;
	unsigned int f26:2;
	unsigned int f27:2;
	unsigned int f29:6;
	unsigned int f30:3;
} PFopt_general_plank_1[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  48,   0,},	/* row 2 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  21,   0,},	/* row 3 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 4 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  52,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  50,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  51,   0,},	/* row 13 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 18 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 19 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  41,   0,},	/* row 22 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 28 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  19,   0,},	/* row 30 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 31 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  20,   0,},	/* row 32 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   6,   0,},	/* row 33 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 34 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 35 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 36 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 37 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 38 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 39 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   9,   0,},	/* row 40 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 41 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,},	/* row 42 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 43 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  35,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  36,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   5,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   9,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  22,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  17,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  18,   0,},	/* row 66 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   5,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   4,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   6,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 81 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  24,   0,},	/* row 82 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 83 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 84 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 85 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  38,   0,},	/* row 86 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  37,   0,},	/* row 89 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 90 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   8,   0,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   7,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   8,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   2,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   1,   0,   0,   1,   0,   0,   1,   0,   0,   1,   0,   0,},	/* row 96 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,},	/* row 97 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 98 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 99 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 100 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  10,   0,},	/* row 101 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 102 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 103 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 104 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 105 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 106 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 107 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 108 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 109 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  12,   0,},	/* row 110 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 111 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  12,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  12,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 114 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 115 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 116 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 117 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 118 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 119 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 120 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  45,   0,},	/* row 121 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 122 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 123 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 124 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 125 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 126 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 127 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  33,   0,},	/* row 128 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 129 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  30,   0,},	/* row 130 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  26,   0,},	/* row 131 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  34,   0,},	/* row 132 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  31,   0,},	/* row 133 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  32,   0,},	/* row 134 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  25,   0,},	/* row 135 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 136 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  27,   0,},	/* row 137 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 138 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  28,   0,},	/* row 139 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  29,   0,},	/* row 140 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 141 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  44,   0,},	/* row 142 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 143 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 144 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 145 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 146 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  47,   0,},	/* row 147 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 148 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 149 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  46,   0,},	/* row 150 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  11,   0,},	/* row 151 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 152 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  15,   0,},	/* row 153 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 154 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 155 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  16,   0,},	/* row 156 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 157 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 158 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 159 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 160 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 161 */
	{   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   0,},	/* row 162 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 163 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 164 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 165 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 166 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 167 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 168 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  40,   0,},	/* row 169 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 170 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  39,   0,},	/* row 171 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 172 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  23,   0,},	/* row 173 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 174 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 175 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 176 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  13,   0,},	/* row 177 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 178 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  14,   0,},	/* row 179 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  49,   0,},	/* row 180 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 181 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 182 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 183 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 184 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 185 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 186 */
	{   0,   6,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 187 */
	{   0,   4,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 188 */
	{   0,   3,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 189 */
	{   0,  13,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 190 */
	{   0,  11,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 191 */
	{   0,  12,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 192 */
	{   0,  10,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 193 */
	{   0,   7,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 194 */
	{   0,   1,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 195 */
	{   0,   7,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 196 */
	{   0,   1,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 197 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  43,   0,},	/* row 198 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 199 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  42,   0,},	/* row 200 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 201 */
};
static struct {
	unsigned int f6:2;
	unsigned int f8:3;
	unsigned int f9:2;
	unsigned int f10:2;
	unsigned int f11:4;
	unsigned int f12:4;
	unsigned int f13:2;
	unsigned int f14:4;
	unsigned int f15:4;
	unsigned int f16:3;
	unsigned int f17:2;
} PFopt_general_plank_2[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 1 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 2 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 3 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 4 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   2,   0,},	/* row 7 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 8 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 9 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 10 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 11 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 12 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   2,   3,   1,   3,   5,   3,   0,   2,   0,   0,   0,},	/* row 15 */
	{   2,   3,   1,   3,   5,   3,   0,   2,   0,   0,   0,},	/* row 16 */
	{   2,   3,   1,   3,   5,   1,   0,   2,   0,   0,   0,},	/* row 17 */
	{   2,   3,   1,   3,   5,   1,   0,   2,   0,   0,   0,},	/* row 18 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 19 */
	{   2,   3,   1,   3,   5,   1,   0,   2,   0,   0,   0,},	/* row 20 */
	{   2,   3,   1,   3,   5,   3,   0,   2,   0,   0,   0,},	/* row 21 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 22 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   2,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   7,   3,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,},	/* row 26 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 27 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 28 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 29 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 30 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 31 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 32 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 33 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 34 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 35 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 36 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 37 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 38 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 39 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 40 */
	{   2,   3,   1,   3,   5,   6,   0,   7,   0,   0,   0,},	/* row 41 */
	{   1,   2,   2,   2,   2,   8,   0,   3,   0,   0,   0,},	/* row 42 */
	{   2,   3,   1,   3,   5,   6,   0,   5,   0,   0,   0,},	/* row 43 */
	{   2,   3,   1,   3,   5,   6,   0,   8,   0,   0,   0,},	/* row 44 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 45 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 46 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 47 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  11,   2,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   9,   2,   0,},	/* row 54 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 55 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   8,   2,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,  10,   2,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 61 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 62 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 63 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 64 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 65 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 79 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 80 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 81 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 82 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 83 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 84 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 85 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 86 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 87 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 88 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 89 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 90 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 91 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 92 */
	{   2,   3,   1,   1,   5,   2,   0,   2,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   1,   1,},	/* row 96 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 97 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 98 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 99 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 100 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 101 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 102 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   6,   2,   0,},	/* row 103 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,},	/* row 104 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 105 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 106 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 107 */
	{   2,   3,   1,   3,   5,   4,   0,   2,   0,   0,   0,},	/* row 108 */
	{   2,   3,   1,   3,   4,   6,   0,   2,   0,   0,   0,},	/* row 109 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 110 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 111 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 112 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 113 */
	{   2,   3,   1,   3,   5,   7,   0,   2,   0,   0,   0,},	/* row 114 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 115 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 116 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 117 */
	{   2,   3,   1,   3,   3,   6,   0,   2,   0,   0,   0,},	/* row 118 */
	{   2,   3,   1,   3,   5,   5,   0,   2,   0,   0,   0,},	/* row 119 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 120 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 121 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 122 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 123 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 124 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 125 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 126 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 127 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 128 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 129 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 130 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 131 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 132 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 133 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 134 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 135 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 136 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 137 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 138 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 139 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 140 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 141 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 142 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 143 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 144 */
	{   2,   3,   1,   3,   1,   6,   0,   2,   0,   0,   0,},	/* row 145 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 146 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 147 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 148 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 149 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 150 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 151 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 152 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 153 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 154 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 155 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 156 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 157 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 158 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 159 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 160 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 161 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 162 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 163 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 164 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 165 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 166 */
	{   2,   4,   1,   3,   5,   6,   0,   6,   0,   0,   0,},	/* row 167 */
	{   2,   1,   1,   3,   5,   6,   0,   6,   0,   0,   0,},	/* row 168 */
	{   1,   2,   2,   2,   2,   8,   0,   4,   0,   0,   0,},	/* row 169 */
	{   2,   4,   1,   3,   5,   6,   0,   6,   0,   0,   0,},	/* row 170 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 171 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 172 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 173 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 174 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,},	/* row 175 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   2,   0,},	/* row 176 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 177 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 178 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 179 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 180 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 181 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 182 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 183 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 184 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 185 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 186 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 187 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 188 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 189 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 190 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 191 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 192 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 193 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 194 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 195 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 196 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 197 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 198 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 199 */
	{   1,   2,   2,   2,   2,   8,   0,   1,   0,   0,   0,},	/* row 200 */
	{   2,   3,   1,   3,   5,   6,   0,   2,   0,   0,   0,},	/* row 201 */
};
static struct {
	unsigned int f0:3;
	unsigned int f1:2;
	unsigned int f2:3;
	unsigned int f3:2;
	unsigned int f4:3;
	unsigned int f5:3;
	unsigned int f7:5;
} PFopt_general_plank_3[] = {
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 1 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 2 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 3 */
	{   0,   1,   0,   0,   2,   2,  12,},	/* row 4 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 8 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 9 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 10 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 11 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 12 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 13 */
	{   0,   0,   1,   0,   0,   0,   0,},	/* row 14 */
	{   0,   1,   0,   0,   2,   2,  10,},	/* row 15 */
	{   0,   1,   0,   0,   2,   2,  10,},	/* row 16 */
	{   0,   1,   0,   0,   2,   2,  15,},	/* row 17 */
	{   0,   1,   0,   0,   2,   2,  15,},	/* row 18 */
	{   0,   1,   0,   0,   2,   2,   4,},	/* row 19 */
	{   0,   1,   0,   0,   2,   2,  15,},	/* row 20 */
	{   0,   1,   0,   0,   2,   2,  10,},	/* row 21 */
	{   0,   1,   0,   0,   1,   1,   9,},	/* row 22 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 27 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 28 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 29 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 30 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 31 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 32 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 33 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 34 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 35 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 36 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 37 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 38 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 39 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 40 */
	{   0,   1,   0,   0,   2,   5,   2,},	/* row 41 */
	{   0,   1,   0,   0,   1,   3,   6,},	/* row 42 */
	{   0,   1,   0,   0,   2,   4,   2,},	/* row 43 */
	{   0,   1,   0,   0,   2,   6,   2,},	/* row 44 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 45 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 46 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 47 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 55 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   0,   0,   0,   1,   0,   0,   0,},	/* row 61 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 62 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 63 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 64 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 65 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 66 */
	{   0,   0,   1,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   2,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   1,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   3,   0,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   1,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   1,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   1,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   1,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   1,   0,   0,   0,},	/* row 79 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 80 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 81 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 82 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 83 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 84 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 85 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 86 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 87 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 88 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 89 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 90 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 91 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 92 */
	{   0,   1,   0,   0,   3,   2,   7,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   0,   0,   1,   2,   0,   0,   0,},	/* row 96 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 97 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 98 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 99 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 100 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 101 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 102 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 103 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 104 */
	{   0,   1,   0,   0,   2,   2,  13,},	/* row 105 */
	{   0,   1,   0,   0,   2,   2,  13,},	/* row 106 */
	{   0,   1,   0,   0,   2,   2,  11,},	/* row 107 */
	{   0,   1,   0,   0,   2,   2,  13,},	/* row 108 */
	{   0,   1,   0,   0,   2,   2,  13,},	/* row 109 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 110 */
	{   0,   1,   0,   0,   2,   2,  11,},	/* row 111 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 112 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 113 */
	{   0,   1,   0,   0,   2,   2,  13,},	/* row 114 */
	{   0,   1,   0,   0,   2,   2,   3,},	/* row 115 */
	{   0,   1,   0,   0,   2,   2,  11,},	/* row 116 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 117 */
	{   0,   1,   0,   0,   2,   2,  13,},	/* row 118 */
	{   0,   1,   0,   0,   2,   2,  13,},	/* row 119 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 120 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 121 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 122 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 123 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 124 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 125 */
	{   0,   0,   0,   2,   0,   0,   0,},	/* row 126 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 127 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 128 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 129 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 130 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 131 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 132 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 133 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 134 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 135 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 136 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 137 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 138 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 139 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 140 */
	{   0,   1,   0,   0,   2,   2,   5,},	/* row 141 */
	{   0,   1,   0,   0,   1,   1,   8,},	/* row 142 */
	{   0,   1,   0,   0,   2,   2,   1,},	/* row 143 */
	{   0,   1,   0,   0,   2,   2,   5,},	/* row 144 */
	{   0,   1,   0,   0,   2,   2,  14,},	/* row 145 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 146 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 147 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 148 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 149 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 150 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 151 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 152 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 153 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 154 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 155 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 156 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 157 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 158 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 159 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 160 */
	{   1,   0,   0,   0,   0,   0,   0,},	/* row 161 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 162 */
	{   2,   0,   0,   0,   0,   0,   0,},	/* row 163 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 164 */
	{   3,   0,   0,   0,   0,   0,   0,},	/* row 165 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 166 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 167 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 168 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 169 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 170 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 171 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 172 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 173 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 174 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 175 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 176 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 177 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 178 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 179 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 180 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 181 */
	{   0,   0,   1,   0,   0,   0,   0,},	/* row 182 */
	{   0,   0,   1,   0,   0,   0,   0,},	/* row 183 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 184 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 185 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 186 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 187 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 188 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 189 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 190 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 191 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 192 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 193 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 194 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 195 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 196 */
	{   0,   0,   0,   0,   0,   0,   0,},	/* row 197 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 198 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 199 */
	{   0,   1,   0,   0,   1,   1,   6,},	/* row 200 */
	{   0,   1,   0,   0,   2,   2,   2,},	/* row 201 */
};
static short PFopt_general_eruleMap[] = {
    0,  103,    0,  120,  146,  145,  140,  138,  137,  136,	/* 0-9 */
  135,  134,  133,  132,  131,  130,  129,  127,  126,  125,	/* 10-19 */
  124,  123,  122,  121,  192,  191,  190,  189,  188,  187,	/* 20-29 */
  186,  185,  184,  183,  182,  181,  180,  176,  174,  173,	/* 30-39 */
  172,  171,  170,  164,  163,  162,  161,  160,  159,  158,	/* 40-49 */
  155,  150,  149,  148,  147,    0,   88,   89,   90,   87,	/* 50-59 */
    0,  115,  119,  114,  118,  117,  116,    0,   98,   97,	/* 60-69 */
    0,   96,    0,  107,  106,  108,    0,    1,  193,  194,	/* 70-79 */
    2,    0,  102,  101,    0,   23,  112,  111,  110,  105,	/* 80-89 */
  100,   99,   24,  197,   20,   19,   18,   17,   16,   15,	/* 90-99 */
   14,   13,   12,   11,   10,    9,    8,    7,    6,    5,	/* 100-109 */
    4,    3,   76,   75,   74,   70,   69,   68,   67,   66,	/* 110-119 */
   62,   59,   58,   57,   56,   55,   54,   53,   52,   51,	/* 120-129 */
   50,   49,   48,   47,   45,   40,   39,   38,   37,   36,	/* 130-139 */
   35,   34,   33,   32,   30,   29,   28,   27,   26,   25,	/* 140-149 */
    0,   64,   65,   63,    0,   94,   91,   92,   93,  195,	/* 150-159 */
  196,    0,   95,    0,   81,   80,   79,   78,   77,   85,	/* 160-169 */
   86,   84,   82,   83
};
#define PFopt_general_Query_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_0[state].f39 +76]
#define PFopt_general_Rel_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_0[state].f38 +84]
#define PFopt_general_ScjRel_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_0[state].f37 +150]
#define PFopt_general_Twig_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_0[state].f36 +163]
#define PFopt_general_Fcns_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_0[state].f35 +55]
#define PFopt_general_Side_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_0[state].f34 +154]
#define PFopt_general_Trc_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_1[state].f22 +161]
#define PFopt_general_Msg_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_1[state].f23 +70]
#define PFopt_general_Map_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_0[state].f33 +67]
#define PFopt_general_Rec_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_0[state].f32 +81]
#define PFopt_general_Arg_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_1[state].f26 +0]
#define PFopt_general_Param_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_0[state].f31 +72]
#define PFopt_general_Frag_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_1[state].f30 +60]
#define PFopt_general_EmptyRel_rule(state)	PFopt_general_eruleMap[PFopt_general_plank_1[state].f29 +2]

#ifdef __STDC__
int PFopt_general_rule(int state, int goalnt) {
#else
int PFopt_general_rule(state, goalnt) int state; int goalnt; {
#endif
	PFopt_general_assert(state >= 0 && state < 202, PFopt_general_PANIC("Bad state %d passed to PFopt_general_rule\n", state));
	switch(goalnt) {
	case 1:
		return PFopt_general_Query_rule(state);
	case 2:
		return PFopt_general_Rel_rule(state);
	case 3:
		return PFopt_general_ScjRel_rule(state);
	case 4:
		return PFopt_general_Twig_rule(state);
	case 5:
		return PFopt_general_Fcns_rule(state);
	case 6:
		return PFopt_general_Side_rule(state);
	case 7:
		return PFopt_general_Trc_rule(state);
	case 8:
		return PFopt_general_Msg_rule(state);
	case 9:
		return PFopt_general_Map_rule(state);
	case 10:
		return PFopt_general_Rec_rule(state);
	case 11:
		return PFopt_general_Arg_rule(state);
	case 12:
		return PFopt_general_Param_rule(state);
	case 13:
		return PFopt_general_Frag_rule(state);
	case 14:
		return PFopt_general_EmptyRel_rule(state);
	default:
		PFopt_general_PANIC("Unknown nonterminal %d in PFopt_general_rule;\n", goalnt);
		abort();
		return 0;
	}
}

int PFopt_general_TEMP;
#define PFopt_general_serialize_seq_state(l,r)	( (PFopt_general_TEMP = PFopt_general_serialize_seq_transition[PFopt_general_plank_3[l].f0][PFopt_general_plank_3[r].f1]) ? PFopt_general_TEMP + 158 : 0 )
#define PFopt_general_serialize_rel_state(l,r)	( (PFopt_general_TEMP = PFopt_general_serialize_rel_transition[PFopt_general_plank_3[l].f2][PFopt_general_plank_3[r].f1]) ? PFopt_general_TEMP + 156 : 0 )
#define PFopt_general_side_effects_state(l,r)	( (PFopt_general_TEMP = PFopt_general_side_effects_transition[PFopt_general_plank_3[l].f2][PFopt_general_plank_3[r].f3]) ? PFopt_general_TEMP + 160 : 0 )
#define PFopt_general_lit_tbl_state	93
#define PFopt_general_empty_tbl_state	62
#define PFopt_general_ref_tbl_state	127
#define PFopt_general_attach_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_3[l].f4) ? PFopt_general_TEMP + 2 : 0 )
#define PFopt_general_cross_state(l,r)	( (PFopt_general_TEMP = PFopt_general_cross_transition[PFopt_general_plank_3[l].f4][PFopt_general_plank_3[r].f4]) ? PFopt_general_TEMP + 26 : 0 )
#define PFopt_general_eqjoin_state(l,r)	( (PFopt_general_TEMP = PFopt_general_eqjoin_transition[PFopt_general_plank_3[l].f4][PFopt_general_plank_3[r].f4]) ? PFopt_general_TEMP + 62 : 0 )
#define PFopt_general_semijoin_state(l,r)	( (PFopt_general_TEMP = PFopt_general_semijoin_transition[PFopt_general_plank_3[l].f5][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 152 : 0 )
#define PFopt_general_thetajoin_state(l,r)	( (PFopt_general_TEMP = PFopt_general_thetajoin_transition[PFopt_general_plank_2[l].f6][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 176 : 0 )
#define PFopt_general_project_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_3[l].f7) ? PFopt_general_TEMP + 104 : 0 )
#define PFopt_general_select__state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 150 : 0 )
#define PFopt_general_pos_select_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 100 : 0 )
#define PFopt_general_disjunion_state(l,r)	( (PFopt_general_TEMP = PFopt_general_disjunion_transition[PFopt_general_plank_3[l].f4][PFopt_general_plank_3[r].f4]) ? PFopt_general_TEMP + 35 : 0 )
#define PFopt_general_intersect_state(l,r)	( (PFopt_general_TEMP = PFopt_general_intersect_transition[PFopt_general_plank_2[l].f6][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 89 : 0 )
#define PFopt_general_difference_state(l,r)	( (PFopt_general_TEMP = PFopt_general_difference_transition[PFopt_general_plank_2[l].f6][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 32 : 0 )
#define PFopt_general_distinct_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f8) ? PFopt_general_TEMP + 40 : 0 )
#define PFopt_general_fun_1to1_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 79 : 0 )
#define PFopt_general_num_eq_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 96 : 0 )
#define PFopt_general_num_gt_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 98 : 0 )
#define PFopt_general_bool_and_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 7 : 0 )
#define PFopt_general_bool_or_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f9) ? PFopt_general_TEMP + 11 : 0 )
#define PFopt_general_bool_not_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f9) ? PFopt_general_TEMP + 9 : 0 )
#define PFopt_general_to_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 179 : 0 )
#define PFopt_general_aggr_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f9) ? PFopt_general_TEMP + 0 : 0 )
#define PFopt_general_rownum_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f10) ? PFopt_general_TEMP + 145 : 0 )
#define PFopt_general_rowrank_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f9) ? PFopt_general_TEMP + 148 : 0 )
#define PFopt_general_rank_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f9) ? PFopt_general_TEMP + 119 : 0 )
#define PFopt_general_rowid_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f11) ? PFopt_general_TEMP + 140 : 0 )
#define PFopt_general_type_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 197 : 0 )
#define PFopt_general_type_assert_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 199 : 0 )
#define PFopt_general_cast_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f12) ? PFopt_general_TEMP + 14 : 0 )
#define PFopt_general_step_state(l,r)	( (PFopt_general_TEMP = PFopt_general_step_transition[PFopt_general_plank_2[l].f13][PFopt_general_plank_2[r].f14]) ? PFopt_general_TEMP + 166 : 0 )
#define PFopt_general_step_join_state(l,r)	( (PFopt_general_TEMP = PFopt_general_step_join_transition[PFopt_general_plank_2[l].f13][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 170 : 0 )
#define PFopt_general_guide_step_state(l,r)	( (PFopt_general_TEMP = PFopt_general_guide_step_transition[PFopt_general_plank_2[l].f13][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 85 : 0 )
#define PFopt_general_guide_step_join_state(l,r)	( (PFopt_general_TEMP = PFopt_general_guide_step_join_transition[PFopt_general_plank_2[l].f13][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 87 : 0 )
#define PFopt_general_doc_index_join_state(l,r)	( (PFopt_general_TEMP = PFopt_general_doc_index_join_transition[PFopt_general_plank_2[l].f13][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 46 : 0 )
#define PFopt_general_doc_tbl_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 48 : 0 )
#define PFopt_general_doc_access_state(l,r)	( (PFopt_general_TEMP = PFopt_general_doc_access_transition[PFopt_general_plank_2[l].f13][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 44 : 0 )
#define PFopt_general_twig_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f15) ? PFopt_general_TEMP + 186 : 0 )
#define PFopt_general_fcns_state(l,r)	( (PFopt_general_TEMP = PFopt_general_fcns_transition[PFopt_general_plank_2[l].f16][PFopt_general_plank_2[r].f17]) ? PFopt_general_TEMP + 70 : 0 )
#define PFopt_general_docnode_state(l,r)	( (PFopt_general_TEMP = PFopt_general_docnode_transition[PFopt_general_plank_2[l].f6][PFopt_general_plank_1[r].f18]) ? PFopt_general_TEMP + 50 : 0 )
#define PFopt_general_element_state(l,r)	( (PFopt_general_TEMP = PFopt_general_element_transition[PFopt_general_plank_2[l].f6][PFopt_general_plank_1[r].f18]) ? PFopt_general_TEMP + 56 : 0 )
#define PFopt_general_attribute_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f9) ? PFopt_general_TEMP + 5 : 0 )
#define PFopt_general_textnode_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f9) ? PFopt_general_TEMP + 174 : 0 )
#define PFopt_general_comment_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f9) ? PFopt_general_TEMP + 22 : 0 )
#define PFopt_general_processi_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f6) ? PFopt_general_TEMP + 102 : 0 )
#define PFopt_general_content_state(l,r)	( (PFopt_general_TEMP = PFopt_general_content_transition[PFopt_general_plank_2[l].f13][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 24 : 0 )
#define PFopt_general_merge_adjacent_state(l,r)	( (PFopt_general_TEMP = PFopt_general_merge_adjacent_transition[PFopt_general_plank_2[l].f13][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 93 : 0 )
#define PFopt_general_roots__state(l)	( (PFopt_general_TEMP = PFopt_general_plank_1[l].f19) ? PFopt_general_TEMP + 127 : 0 )
#define PFopt_general_fragment_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_1[l].f20) ? PFopt_general_TEMP + 76 : 0 )
#define PFopt_general_frag_extract_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_3[l].f1) ? PFopt_general_TEMP + 74 : 0 )
#define PFopt_general_frag_union_state(l,r)	( (PFopt_general_TEMP = PFopt_general_frag_union_transition[PFopt_general_plank_2[l].f13][PFopt_general_plank_2[r].f13]) ? PFopt_general_TEMP + 75 : 0 )
#define PFopt_general_empty_frag_state	61
#define PFopt_general_error_state(l,r)	( (PFopt_general_TEMP = PFopt_general_error_transition[PFopt_general_plank_3[l].f2][PFopt_general_plank_2[r].f6]) ? PFopt_general_TEMP + 66 : 0 )
#define PFopt_general_nil_state	96
#define PFopt_general_cache_state(l,r)	( (PFopt_general_TEMP = PFopt_general_cache_transition[PFopt_general_plank_1[l].f21][PFopt_general_plank_3[r].f1]) ? PFopt_general_TEMP + 13 : 0 )
#define PFopt_general_trace_state(l,r)	( (PFopt_general_TEMP = PFopt_general_trace_transition[PFopt_general_plank_3[l].f2][PFopt_general_plank_1[r].f22]) ? PFopt_general_TEMP + 181 : 0 )
#define PFopt_general_trace_items_state(l,r)	( (PFopt_general_TEMP = PFopt_general_trace_items_transition[PFopt_general_plank_3[l].f1][PFopt_general_plank_1[r].f23]) ? PFopt_general_TEMP + 183 : 0 )
#define PFopt_general_trace_msg_state(l,r)	( (PFopt_general_TEMP = PFopt_general_trace_msg_transition[PFopt_general_plank_3[l].f1][PFopt_general_plank_1[r].f24]) ? PFopt_general_TEMP + 185 : 0 )
#define PFopt_general_trace_map_state(l,r)	( (PFopt_general_TEMP = PFopt_general_trace_map_transition[PFopt_general_plank_3[l].f1][PFopt_general_plank_1[r].f24]) ? PFopt_general_TEMP + 184 : 0 )
#define PFopt_general_rec_fix_state(l,r)	( (PFopt_general_TEMP = PFopt_general_rec_fix_transition[PFopt_general_plank_1[l].f25][PFopt_general_plank_3[r].f1]) ? PFopt_general_TEMP + 123 : 0 )
#define PFopt_general_rec_param_state(l,r)	( (PFopt_general_TEMP = PFopt_general_rec_param_transition[PFopt_general_plank_1[l].f26][PFopt_general_plank_1[r].f27]) ? PFopt_general_TEMP + 125 : 0 )
#define PFopt_general_rec_arg_state(l,r)	( (PFopt_general_TEMP = PFopt_general_rec_arg_transition[PFopt_general_plank_3[l].f1][PFopt_general_plank_3[r].f1]) ? PFopt_general_TEMP + 121 : 0 )
#define PFopt_general_rec_base_state	123
#define PFopt_general_fun_call_state(l,r)	( (PFopt_general_TEMP = PFopt_general_fun_call_transition[PFopt_general_plank_2[l].f6][PFopt_general_plank_0[r].f28]) ? PFopt_general_TEMP + 81 : 0 )
#define PFopt_general_fun_param_state(l,r)	( (PFopt_general_TEMP = PFopt_general_fun_param_transition[PFopt_general_plank_3[l].f1][PFopt_general_plank_0[r].f28]) ? PFopt_general_TEMP + 84 : 0 )
#define PFopt_general_fun_frag_param_state(l,r)	( (PFopt_general_TEMP = PFopt_general_fun_frag_param_transition[PFopt_general_plank_2[l].f13][PFopt_general_plank_0[r].f28]) ? PFopt_general_TEMP + 83 : 0 )
#define PFopt_general_string_join_state(l,r)	( (PFopt_general_TEMP = PFopt_general_string_join_transition[PFopt_general_plank_2[l].f6][PFopt_general_plank_3[r].f1]) ? PFopt_general_TEMP + 172 : 0 )
#define PFopt_general_dummy_state(l)	( (PFopt_general_TEMP = PFopt_general_plank_2[l].f9) ? PFopt_general_TEMP + 54 : 0 )

#ifdef __STDC__
int PFopt_general_state(int op, int l, int r) {
#else
int PFopt_general_state(op, l, r) int op; int l; int r; {
#endif
	register int PFopt_general_TEMP;
#ifndef NDEBUG
	switch (op) {
	case 1:
	case 2:
	case 3:
	case 8:
	case 9:
	case 10:
	case 11:
	case 16:
	case 17:
	case 18:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 56:
	case 61:
	case 62:
	case 63:
	case 68:
	case 69:
	case 73:
	case 78:
	case 80:
	case 81:
	case 82:
	case 83:
	case 84:
	case 85:
	case 86:
	case 87:
	case 90:
	case 91:
	case 92:
	case 102:
		PFopt_general_assert(r >= 0 && r < 202, PFopt_general_PANIC("Bad state %d passed to PFopt_general_state\n", r));
		/*FALLTHROUGH*/
	case 7:
	case 12:
	case 13:
	case 14:
	case 19:
	case 20:
	case 25:
	case 26:
	case 28:
	case 29:
	case 30:
	case 31:
	case 32:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
	case 55:
	case 60:
	case 64:
	case 65:
	case 66:
	case 67:
	case 70:
	case 71:
	case 72:
	case 120:
		PFopt_general_assert(l >= 0 && l < 202, PFopt_general_PANIC("Bad state %d passed to PFopt_general_state\n", l));
		/*FALLTHROUGH*/
	case 4:
	case 5:
	case 6:
	case 74:
	case 79:
	case 88:
		break;
	}
#endif
	switch (op) {
	default: PFopt_general_PANIC("Unknown op %d in PFopt_general_state\n", op); abort(); return 0;
	case 1:
		return PFopt_general_serialize_seq_state(l,r);
	case 2:
		return PFopt_general_serialize_rel_state(l,r);
	case 3:
		return PFopt_general_side_effects_state(l,r);
	case 4:
		return PFopt_general_lit_tbl_state;
	case 5:
		return PFopt_general_empty_tbl_state;
	case 6:
		return PFopt_general_ref_tbl_state;
	case 7:
		return PFopt_general_attach_state(l);
	case 8:
		return PFopt_general_cross_state(l,r);
	case 9:
		return PFopt_general_eqjoin_state(l,r);
	case 10:
		return PFopt_general_semijoin_state(l,r);
	case 11:
		return PFopt_general_thetajoin_state(l,r);
	case 12:
		return PFopt_general_project_state(l);
	case 13:
		return PFopt_general_select__state(l);
	case 14:
		return PFopt_general_pos_select_state(l);
	case 16:
		return PFopt_general_disjunion_state(l,r);
	case 17:
		return PFopt_general_intersect_state(l,r);
	case 18:
		return PFopt_general_difference_state(l,r);
	case 19:
		return PFopt_general_distinct_state(l);
	case 20:
		return PFopt_general_fun_1to1_state(l);
	case 25:
		return PFopt_general_num_eq_state(l);
	case 26:
		return PFopt_general_num_gt_state(l);
	case 28:
		return PFopt_general_bool_and_state(l);
	case 29:
		return PFopt_general_bool_or_state(l);
	case 30:
		return PFopt_general_bool_not_state(l);
	case 31:
		return PFopt_general_to_state(l);
	case 32:
		return PFopt_general_aggr_state(l);
	case 37:
		return PFopt_general_rownum_state(l);
	case 38:
		return PFopt_general_rowrank_state(l);
	case 39:
		return PFopt_general_rank_state(l);
	case 40:
		return PFopt_general_rowid_state(l);
	case 41:
		return PFopt_general_type_state(l);
	case 42:
		return PFopt_general_type_assert_state(l);
	case 43:
		return PFopt_general_cast_state(l);
	case 50:
		return PFopt_general_step_state(l,r);
	case 51:
		return PFopt_general_step_join_state(l,r);
	case 52:
		return PFopt_general_guide_step_state(l,r);
	case 53:
		return PFopt_general_guide_step_join_state(l,r);
	case 54:
		return PFopt_general_doc_index_join_state(l,r);
	case 55:
		return PFopt_general_doc_tbl_state(l);
	case 56:
		return PFopt_general_doc_access_state(l,r);
	case 60:
		return PFopt_general_twig_state(l);
	case 61:
		return PFopt_general_fcns_state(l,r);
	case 62:
		return PFopt_general_docnode_state(l,r);
	case 63:
		return PFopt_general_element_state(l,r);
	case 64:
		return PFopt_general_attribute_state(l);
	case 65:
		return PFopt_general_textnode_state(l);
	case 66:
		return PFopt_general_comment_state(l);
	case 67:
		return PFopt_general_processi_state(l);
	case 68:
		return PFopt_general_content_state(l,r);
	case 69:
		return PFopt_general_merge_adjacent_state(l,r);
	case 70:
		return PFopt_general_roots__state(l);
	case 71:
		return PFopt_general_fragment_state(l);
	case 72:
		return PFopt_general_frag_extract_state(l);
	case 73:
		return PFopt_general_frag_union_state(l,r);
	case 74:
		return PFopt_general_empty_frag_state;
	case 78:
		return PFopt_general_error_state(l,r);
	case 79:
		return PFopt_general_nil_state;
	case 80:
		return PFopt_general_cache_state(l,r);
	case 81:
		return PFopt_general_trace_state(l,r);
	case 82:
		return PFopt_general_trace_items_state(l,r);
	case 83:
		return PFopt_general_trace_msg_state(l,r);
	case 84:
		return PFopt_general_trace_map_state(l,r);
	case 85:
		return PFopt_general_rec_fix_state(l,r);
	case 86:
		return PFopt_general_rec_param_state(l,r);
	case 87:
		return PFopt_general_rec_arg_state(l,r);
	case 88:
		return PFopt_general_rec_base_state;
	case 90:
		return PFopt_general_fun_call_state(l,r);
	case 91:
		return PFopt_general_fun_param_state(l,r);
	case 92:
		return PFopt_general_fun_frag_param_state(l,r);
	case 102:
		return PFopt_general_string_join_state(l,r);
	case 120:
		return PFopt_general_dummy_state(l);
	}
}
#ifdef PFopt_general_STATE_LABEL
#define PFopt_general_INCLUDE_EXTRA
#else
#ifdef STATE_LABEL
#define PFopt_general_INCLUDE_EXTRA
#define PFopt_general_STATE_LABEL 	STATE_LABEL
#define PFopt_general_NODEPTR_TYPE	NODEPTR_TYPE
#define PFopt_general_LEFT_CHILD  	LEFT_CHILD
#define PFopt_general_OP_LABEL    	OP_LABEL
#define PFopt_general_RIGHT_CHILD 	RIGHT_CHILD
#endif /* STATE_LABEL */
#endif /* PFopt_general_STATE_LABEL */

#ifdef PFopt_general_INCLUDE_EXTRA

#ifdef __STDC__
int PFopt_general_label(PFopt_general_NODEPTR_TYPE n) {
#else
int PFopt_general_label(n) PFopt_general_NODEPTR_TYPE n; {
#endif
	PFopt_general_assert(n, PFopt_general_PANIC("NULL pointer passed to PFopt_general_label\n"));
	switch (PFopt_general_OP_LABEL(n)) {
	default: PFopt_general_PANIC("Bad op %d in PFopt_general_label\n", PFopt_general_OP_LABEL(n)); abort(); return 0;
	case 4:
	case 5:
	case 6:
	case 74:
	case 79:
	case 88:
		return PFopt_general_STATE_LABEL(n) = PFopt_general_state(PFopt_general_OP_LABEL(n), 0, 0);
	case 7:
	case 12:
	case 13:
	case 14:
	case 19:
	case 20:
	case 25:
	case 26:
	case 28:
	case 29:
	case 30:
	case 31:
	case 32:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
	case 55:
	case 60:
	case 64:
	case 65:
	case 66:
	case 67:
	case 70:
	case 71:
	case 72:
	case 120:
		return PFopt_general_STATE_LABEL(n) = PFopt_general_state(PFopt_general_OP_LABEL(n), PFopt_general_label(PFopt_general_LEFT_CHILD(n)), 0);
	case 1:
	case 2:
	case 3:
	case 8:
	case 9:
	case 10:
	case 11:
	case 16:
	case 17:
	case 18:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 56:
	case 61:
	case 62:
	case 63:
	case 68:
	case 69:
	case 73:
	case 78:
	case 80:
	case 81:
	case 82:
	case 83:
	case 84:
	case 85:
	case 86:
	case 87:
	case 90:
	case 91:
	case 92:
	case 102:
		return PFopt_general_STATE_LABEL(n) = PFopt_general_state(PFopt_general_OP_LABEL(n), PFopt_general_label(PFopt_general_LEFT_CHILD(n)), PFopt_general_label(PFopt_general_RIGHT_CHILD(n)));
	}
}
#ifdef __STDC__
PFopt_general_NODEPTR_TYPE * PFopt_general_kids(PFopt_general_NODEPTR_TYPE p, int rulenumber, PFopt_general_NODEPTR_TYPE *kids) {
#else
PFopt_general_NODEPTR_TYPE * PFopt_general_kids(p, rulenumber, kids) PFopt_general_NODEPTR_TYPE p; int rulenumber; PFopt_general_NODEPTR_TYPE *kids; {
#endif
	PFopt_general_assert(p, PFopt_general_PANIC("NULL node pointer passed to PFopt_general_kids\n"));
	PFopt_general_assert(kids, PFopt_general_PANIC("NULL kids pointer passed to PFopt_general_kids\n"));
	switch (rulenumber) {
	default:
		PFopt_general_PANIC("Unknown Rule %d in PFopt_general_kids;\n", rulenumber);
		abort();
		/* NOTREACHED */
	case 10:
		kids[0] = PFopt_general_RIGHT_CHILD(p);
		break;
	case 14:
		kids[0] = PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(p));
		kids[1] = PFopt_general_RIGHT_CHILD(p);
		break;
	case 65:
		kids[0] = PFopt_general_LEFT_CHILD(p);
		kids[1] = PFopt_general_LEFT_CHILD(PFopt_general_RIGHT_CHILD(p));
		break;
	case 78:
	case 80:
		kids[0] = PFopt_general_LEFT_CHILD(p);
		kids[1] = PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(PFopt_general_RIGHT_CHILD(p)));
		kids[2] = PFopt_general_RIGHT_CHILD(PFopt_general_LEFT_CHILD(PFopt_general_RIGHT_CHILD(p)));
		break;
	case 62:
	case 112:
		kids[0] = p;
		break;
	case 17:
	case 18:
	case 52:
	case 56:
	case 74:
	case 75:
	case 114:
	case 115:
	case 180:
		kids[0] = PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(p));
		break;
	case 53:
	case 57:
	case 183:
	case 184:
	case 185:
	case 186:
		kids[0] = PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(p)));
		break;
	case 181:
	case 182:
	case 187:
		kids[0] = PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(p)));
		kids[1] = PFopt_general_RIGHT_CHILD(PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(p)));
		break;
	case 3:
	case 4:
	case 6:
	case 8:
	case 12:
	case 19:
	case 25:
	case 48:
	case 58:
	case 86:
	case 89:
	case 90:
	case 92:
	case 98:
	case 100:
	case 102:
	case 108:
	case 119:
	case 120:
	case 188:
		break;
	case 33:
	case 76:
	case 116:
	case 189:
		kids[0] = PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(p));
		kids[1] = PFopt_general_RIGHT_CHILD(PFopt_general_LEFT_CHILD(p));
		break;
	case 2:
	case 7:
	case 11:
	case 13:
	case 15:
	case 24:
	case 26:
	case 27:
	case 28:
	case 29:
	case 30:
	case 63:
	case 64:
	case 66:
	case 67:
	case 68:
	case 69:
	case 70:
	case 77:
	case 79:
	case 85:
	case 87:
	case 91:
	case 93:
	case 94:
	case 95:
	case 96:
	case 97:
	case 101:
	case 103:
	case 105:
	case 106:
	case 107:
	case 110:
	case 118:
	case 122:
	case 123:
	case 124:
	case 125:
	case 126:
	case 127:
	case 129:
	case 130:
	case 134:
	case 135:
	case 136:
	case 137:
	case 170:
	case 171:
	case 172:
	case 173:
	case 174:
	case 176:
	case 190:
	case 191:
		kids[0] = PFopt_general_LEFT_CHILD(p);
		kids[1] = PFopt_general_RIGHT_CHILD(p);
		break;
	case 5:
	case 9:
	case 16:
	case 20:
	case 23:
	case 32:
	case 34:
	case 35:
	case 36:
	case 37:
	case 38:
	case 39:
	case 40:
	case 45:
	case 47:
	case 49:
	case 50:
	case 51:
	case 54:
	case 55:
	case 59:
	case 81:
	case 82:
	case 83:
	case 84:
	case 111:
	case 117:
	case 121:
	case 131:
	case 132:
	case 133:
	case 138:
	case 140:
	case 145:
	case 146:
	case 147:
	case 148:
	case 149:
	case 150:
	case 155:
	case 158:
	case 159:
	case 160:
	case 161:
	case 162:
	case 163:
	case 164:
	case 192:
		kids[0] = PFopt_general_LEFT_CHILD(p);
		break;
	case 1:
	case 88:
	case 99:
	case 194:
	case 195:
	case 196:
		kids[0] = PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(p));
		kids[1] = PFopt_general_RIGHT_CHILD(PFopt_general_LEFT_CHILD(p));
		kids[2] = PFopt_general_RIGHT_CHILD(p);
		break;
	case 193:
	case 197:
		kids[0] = PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(p)));
		kids[1] = PFopt_general_RIGHT_CHILD(PFopt_general_LEFT_CHILD(PFopt_general_LEFT_CHILD(p)));
		kids[2] = PFopt_general_RIGHT_CHILD(PFopt_general_LEFT_CHILD(p));
		kids[3] = PFopt_general_RIGHT_CHILD(p);
		break;
	}
	return kids;
}
#ifdef __STDC__
PFopt_general_NODEPTR_TYPE PFopt_general_child(PFopt_general_NODEPTR_TYPE p, int index) {
#else
PFopt_general_NODEPTR_TYPE PFopt_general_child(p, index) PFopt_general_NODEPTR_TYPE p; int index; {
#endif
	PFopt_general_assert(p, PFopt_general_PANIC("NULL pointer passed to PFopt_general_child\n"));
	switch (index) {
	case 0:
		return PFopt_general_LEFT_CHILD(p);
	case 1:
		return PFopt_general_RIGHT_CHILD(p);
	}
	PFopt_general_PANIC("Bad index %d in PFopt_general_child;\n", index);
	abort();
	return 0;
}
#ifdef __STDC__
int PFopt_general_op_label(PFopt_general_NODEPTR_TYPE p) {
#else
int PFopt_general_op_label(p) PFopt_general_NODEPTR_TYPE p; {
#endif
	PFopt_general_assert(p, PFopt_general_PANIC("NULL pointer passed to PFopt_general_op_label\n"));
	return PFopt_general_OP_LABEL(p);
}
#ifdef __STDC__
int PFopt_general_state_label(PFopt_general_NODEPTR_TYPE p) {
#else
int PFopt_general_state_label(p) PFopt_general_NODEPTR_TYPE p; {
#endif
	PFopt_general_assert(p, PFopt_general_PANIC("NULL pointer passed to PFopt_general_state_label\n"));
	return PFopt_general_STATE_LABEL(p);
}
#endif /* PFopt_general_INCLUDE_EXTRA */
#define PFopt_general_EmptyRel_NT 14
#define PFopt_general_Frag_NT 13
#define PFopt_general_Param_NT 12
#define PFopt_general_Arg_NT 11
#define PFopt_general_Rec_NT 10
#define PFopt_general_Map_NT 9
#define PFopt_general_Msg_NT 8
#define PFopt_general_Trc_NT 7
#define PFopt_general_Side_NT 6
#define PFopt_general_Fcns_NT 5
#define PFopt_general_Twig_NT 4
#define PFopt_general_ScjRel_NT 3
#define PFopt_general_Rel_NT 2
#define PFopt_general_Query_NT 1
#define PFopt_general_NT 14
char * PFopt_general_opname[] = {
	0, /* 0 */
	"serialize_seq", /* 1 */
	"serialize_rel", /* 2 */
	"side_effects", /* 3 */
	"lit_tbl", /* 4 */
	"empty_tbl", /* 5 */
	"ref_tbl", /* 6 */
	"attach", /* 7 */
	"cross", /* 8 */
	"eqjoin", /* 9 */
	"semijoin", /* 10 */
	"thetajoin", /* 11 */
	"project", /* 12 */
	"select_", /* 13 */
	"pos_select", /* 14 */
	0, /* 15 */
	"disjunion", /* 16 */
	"intersect", /* 17 */
	"difference", /* 18 */
	"distinct", /* 19 */
	"fun_1to1", /* 20 */
	0, /* 21 */
	0, /* 22 */
	0, /* 23 */
	0, /* 24 */
	"num_eq", /* 25 */
	"num_gt", /* 26 */
	0, /* 27 */
	"bool_and", /* 28 */
	"bool_or", /* 29 */
	"bool_not", /* 30 */
	"to", /* 31 */
	"aggr", /* 32 */
	0, /* 33 */
	0, /* 34 */
	0, /* 35 */
	0, /* 36 */
	"rownum", /* 37 */
	"rowrank", /* 38 */
	"rank", /* 39 */
	"rowid", /* 40 */
	"type", /* 41 */
	"type_assert", /* 42 */
	"cast", /* 43 */
	0, /* 44 */
	0, /* 45 */
	0, /* 46 */
	0, /* 47 */
	0, /* 48 */
	0, /* 49 */
	"step", /* 50 */
	"step_join", /* 51 */
	"guide_step", /* 52 */
	"guide_step_join", /* 53 */
	"doc_index_join", /* 54 */
	"doc_tbl", /* 55 */
	"doc_access", /* 56 */
	0, /* 57 */
	0, /* 58 */
	0, /* 59 */
	"twig", /* 60 */
	"fcns", /* 61 */
	"docnode", /* 62 */
	"element", /* 63 */
	"attribute", /* 64 */
	"textnode", /* 65 */
	"comment", /* 66 */
	"processi", /* 67 */
	"content", /* 68 */
	"merge_adjacent", /* 69 */
	"roots_", /* 70 */
	"fragment", /* 71 */
	"frag_extract", /* 72 */
	"frag_union", /* 73 */
	"empty_frag", /* 74 */
	0, /* 75 */
	0, /* 76 */
	0, /* 77 */
	"error", /* 78 */
	"nil", /* 79 */
	"cache", /* 80 */
	"trace", /* 81 */
	"trace_items", /* 82 */
	"trace_msg", /* 83 */
	"trace_map", /* 84 */
	"rec_fix", /* 85 */
	"rec_param", /* 86 */
	"rec_arg", /* 87 */
	"rec_base", /* 88 */
	0, /* 89 */
	"fun_call", /* 90 */
	"fun_param", /* 91 */
	"fun_frag_param", /* 92 */
	0, /* 93 */
	0, /* 94 */
	0, /* 95 */
	0, /* 96 */
	0, /* 97 */
	0, /* 98 */
	0, /* 99 */
	0, /* 100 */
	0, /* 101 */
	"string_join", /* 102 */
	0, /* 103 */
	0, /* 104 */
	0, /* 105 */
	0, /* 106 */
	0, /* 107 */
	0, /* 108 */
	0, /* 109 */
	0, /* 110 */
	0, /* 111 */
	0, /* 112 */
	0, /* 113 */
	0, /* 114 */
	0, /* 115 */
	0, /* 116 */
	0, /* 117 */
	0, /* 118 */
	0, /* 119 */
	"dummy"
};
char PFopt_general_arity[] = {
	-1, /* 0 */
	2, /* 1 */
	2, /* 2 */
	2, /* 3 */
	0, /* 4 */
	0, /* 5 */
	0, /* 6 */
	1, /* 7 */
	2, /* 8 */
	2, /* 9 */
	2, /* 10 */
	2, /* 11 */
	1, /* 12 */
	1, /* 13 */
	1, /* 14 */
	-1, /* 15 */
	2, /* 16 */
	2, /* 17 */
	2, /* 18 */
	1, /* 19 */
	1, /* 20 */
	-1, /* 21 */
	-1, /* 22 */
	-1, /* 23 */
	-1, /* 24 */
	1, /* 25 */
	1, /* 26 */
	-1, /* 27 */
	1, /* 28 */
	1, /* 29 */
	1, /* 30 */
	1, /* 31 */
	1, /* 32 */
	-1, /* 33 */
	-1, /* 34 */
	-1, /* 35 */
	-1, /* 36 */
	1, /* 37 */
	1, /* 38 */
	1, /* 39 */
	1, /* 40 */
	1, /* 41 */
	1, /* 42 */
	1, /* 43 */
	-1, /* 44 */
	-1, /* 45 */
	-1, /* 46 */
	-1, /* 47 */
	-1, /* 48 */
	-1, /* 49 */
	2, /* 50 */
	2, /* 51 */
	2, /* 52 */
	2, /* 53 */
	2, /* 54 */
	1, /* 55 */
	2, /* 56 */
	-1, /* 57 */
	-1, /* 58 */
	-1, /* 59 */
	1, /* 60 */
	2, /* 61 */
	2, /* 62 */
	2, /* 63 */
	1, /* 64 */
	1, /* 65 */
	1, /* 66 */
	1, /* 67 */
	2, /* 68 */
	2, /* 69 */
	1, /* 70 */
	1, /* 71 */
	1, /* 72 */
	2, /* 73 */
	0, /* 74 */
	-1, /* 75 */
	-1, /* 76 */
	-1, /* 77 */
	2, /* 78 */
	0, /* 79 */
	2, /* 80 */
	2, /* 81 */
	2, /* 82 */
	2, /* 83 */
	2, /* 84 */
	2, /* 85 */
	2, /* 86 */
	2, /* 87 */
	0, /* 88 */
	-1, /* 89 */
	2, /* 90 */
	2, /* 91 */
	2, /* 92 */
	-1, /* 93 */
	-1, /* 94 */
	-1, /* 95 */
	-1, /* 96 */
	-1, /* 97 */
	-1, /* 98 */
	-1, /* 99 */
	-1, /* 100 */
	-1, /* 101 */
	2, /* 102 */
	-1, /* 103 */
	-1, /* 104 */
	-1, /* 105 */
	-1, /* 106 */
	-1, /* 107 */
	-1, /* 108 */
	-1, /* 109 */
	-1, /* 110 */
	-1, /* 111 */
	-1, /* 112 */
	-1, /* 113 */
	-1, /* 114 */
	-1, /* 115 */
	-1, /* 116 */
	-1, /* 117 */
	-1, /* 118 */
	-1, /* 119 */
	1
};
int PFopt_general_max_op = 120;
int PFopt_general_max_state = 201;
#define PFopt_general_Max_state 201
char *PFopt_general_string[] = {
	0,
	"Query: serialize_seq(side_effects(Side, Frag), Rel)",
	"Query: serialize_rel(Side, Rel)",
	"Rel: lit_tbl",
	"Rel: ref_tbl",
	"Rel: attach(Rel)",
	"Rel: attach(lit_tbl)",
	"Rel: cross(Rel, Rel)",
	"Rel: cross(lit_tbl, lit_tbl)",
	"Rel: cross(Rel, lit_tbl)",
	"Rel: cross(lit_tbl, Rel)",
	"Rel: eqjoin(Rel, Rel)",
	"Rel: eqjoin(lit_tbl, lit_tbl)",
	"Rel: semijoin(Rel, Rel)",
	"Rel: semijoin(distinct(Rel), Rel)",
	"Rel: thetajoin(Rel, Rel)",
	"Rel: project(Rel)",
	"Rel: project(attach(Rel))",
	"Rel: project(project(Rel))",
	"Rel: project(lit_tbl)",
	"Rel: select_(Rel)",
	0,
	0,
	"Rel: pos_select(Rel)",
	"Rel: disjunion(Rel, Rel)",
	"Rel: disjunion(lit_tbl, lit_tbl)",
	"Rel: disjunion(EmptyRel, Rel)",
	"Rel: disjunion(Rel, EmptyRel)",
	"Rel: intersect(Rel, Rel)",
	"Rel: difference(Rel, Rel)",
	"Rel: difference(Rel, EmptyRel)",
	0,
	"Rel: distinct(Rel)",
	"Rel: distinct(step(Frag, Rel))",
	"Rel: fun_1to1(Rel)",
	"Rel: num_gt(Rel)",
	"Rel: num_eq(Rel)",
	"Rel: bool_and(Rel)",
	"Rel: bool_or(Rel)",
	"Rel: bool_not(Rel)",
	"Rel: to(Rel)",
	0,
	0,
	0,
	0,
	"Rel: aggr(Rel)",
	0,
	"Rel: rownum(Rel)",
	"Rel: rownum(lit_tbl)",
	"Rel: rowrank(Rel)",
	"Rel: rank(Rel)",
	"Rel: rowid(Rel)",
	"Rel: rowid(rowid(Rel))",
	"Rel: rowid(project(rowid(Rel)))",
	"Rel: type(Rel)",
	"Rel: type_assert(Rel)",
	"Rel: cast(cast(Rel))",
	"Rel: cast(project(cast(Rel)))",
	"Rel: cast(lit_tbl)",
	"Rel: cast(Rel)",
	0,
	0,
	"Rel: ScjRel",
	"ScjRel: step(Frag, Rel)",
	"ScjRel: step(Frag, ScjRel)",
	"ScjRel: step(Frag, distinct(Rel))",
	"Rel: step_join(Frag, Rel)",
	"Rel: guide_step(Frag, Rel)",
	"Rel: guide_step_join(Frag, Rel)",
	"Rel: doc_index_join(Frag, Rel)",
	"Rel: doc_access(Frag, Rel)",
	0,
	0,
	0,
	"Rel: roots_(doc_tbl(Rel))",
	"Rel: roots_(twig(Twig))",
	"Rel: roots_(merge_adjacent(Frag, Rel))",
	"Twig: docnode(Rel, Fcns)",
	"Twig: docnode(Rel, fcns(content(Frag, EmptyRel), nil))",
	"Twig: element(Rel, Fcns)",
	"Twig: element(Rel, fcns(content(Frag, EmptyRel), nil))",
	"Twig: attribute(Rel)",
	"Twig: textnode(Rel)",
	"Twig: comment(Rel)",
	"Twig: processi(Rel)",
	"Twig: content(Frag, Rel)",
	"Twig: nil",
	"Fcns: fcns(Twig, Fcns)",
	"Fcns: fcns(content(Frag, EmptyRel), Fcns)",
	"Fcns: fcns(nil, nil)",
	"Fcns: nil",
	"Side: error(Side, Rel)",
	"Side: nil",
	"Side: cache(Side, Rel)",
	"Side: trace(Side, Trc)",
	"Trc: trace_items(Rel, Msg)",
	"Msg: trace_msg(Rel, Map)",
	"Map: trace_map(Rel, Map)",
	"Map: nil",
	"Rel: rec_fix(side_effects(Side, Rec), Rel)",
	"Rel: rec_base",
	"Rec: rec_param(Arg, Rec)",
	"Rec: nil",
	"Arg: rec_arg(Rel, Rel)",
	0,
	"Rel: fun_call(Rel, Param)",
	"Param: fun_param(Rel, Param)",
	"Param: fun_frag_param(Frag, Param)",
	"Param: nil",
	0,
	"Rel: string_join(Rel, Rel)",
	"Rel: dummy(Rel)",
	"Rel: EmptyRel",
	0,
	"Frag: fragment(doc_tbl(Rel))",
	"Frag: fragment(twig(Twig))",
	"Frag: fragment(merge_adjacent(Frag, Rel))",
	"Frag: frag_extract(Rel)",
	"Frag: frag_union(Frag, Frag)",
	"Frag: empty_frag",
	"EmptyRel: empty_tbl",
	"EmptyRel: attach(EmptyRel)",
	"EmptyRel: cross(EmptyRel, Rel)",
	"EmptyRel: cross(Rel, EmptyRel)",
	"EmptyRel: eqjoin(EmptyRel, Rel)",
	"EmptyRel: eqjoin(Rel, EmptyRel)",
	"EmptyRel: semijoin(EmptyRel, Rel)",
	"EmptyRel: semijoin(Rel, EmptyRel)",
	0,
	"EmptyRel: thetajoin(EmptyRel, Rel)",
	"EmptyRel: thetajoin(Rel, EmptyRel)",
	"EmptyRel: project(EmptyRel)",
	"EmptyRel: select_(EmptyRel)",
	"EmptyRel: pos_select(EmptyRel)",
	"EmptyRel: disjunion(EmptyRel, EmptyRel)",
	"EmptyRel: intersect(EmptyRel, Rel)",
	"EmptyRel: intersect(Rel, EmptyRel)",
	"EmptyRel: difference(EmptyRel, Rel)",
	"EmptyRel: distinct(EmptyRel)",
	0,
	"EmptyRel: fun_1to1(EmptyRel)",
	0,
	0,
	0,
	0,
	"EmptyRel: num_gt(EmptyRel)",
	"EmptyRel: num_eq(EmptyRel)",
	"EmptyRel: bool_and(EmptyRel)",
	"EmptyRel: bool_or(EmptyRel)",
	"EmptyRel: bool_not(EmptyRel)",
	"EmptyRel: to(EmptyRel)",
	0,
	0,
	0,
	0,
	"EmptyRel: aggr(EmptyRel)",
	0,
	0,
	"EmptyRel: rownum(EmptyRel)",
	"EmptyRel: rowrank(EmptyRel)",
	"EmptyRel: rank(EmptyRel)",
	"EmptyRel: rowid(EmptyRel)",
	"EmptyRel: type(EmptyRel)",
	"EmptyRel: type_assert(EmptyRel)",
	"EmptyRel: cast(EmptyRel)",
	0,
	0,
	0,
	0,
	0,
	"EmptyRel: step(Frag, EmptyRel)",
	"EmptyRel: step_join(Frag, EmptyRel)",
	"EmptyRel: guide_step(Frag, EmptyRel)",
	"EmptyRel: guide_step_join(Frag, EmptyRel)",
	"EmptyRel: doc_index_join(Frag, EmptyRel)",
	0,
	"EmptyRel: doc_access(Frag, EmptyRel)",
	0,
	0,
	0,
	"EmptyRel: roots_(doc_tbl(EmptyRel))",
	"EmptyRel: roots_(twig(docnode(EmptyRel, Fcns)))",
	"EmptyRel: roots_(twig(element(EmptyRel, Fcns)))",
	"EmptyRel: roots_(twig(attribute(EmptyRel)))",
	"EmptyRel: roots_(twig(textnode(EmptyRel)))",
	"EmptyRel: roots_(twig(comment(EmptyRel)))",
	"EmptyRel: roots_(twig(processi(EmptyRel)))",
	"EmptyRel: roots_(twig(content(Frag, EmptyRel)))",
	"EmptyRel: roots_(twig(nil))",
	"EmptyRel: roots_(merge_adjacent(Frag, EmptyRel))",
	"EmptyRel: fun_call(EmptyRel, Param)",
	"EmptyRel: string_join(EmptyRel, Rel)",
	"EmptyRel: dummy(EmptyRel)",
	"Query: serialize_seq(side_effects(error(Side, EmptyRel), Frag), Rel)",
	"Query: serialize_rel(error(Side, EmptyRel), Rel)",
	"Side: error(error(Side, EmptyRel), Rel)",
	"Side: trace(error(Side, EmptyRel), Trc)",
	"Rel: rec_fix(side_effects(error(Side, EmptyRel), Rec), Rel)",
};
int PFopt_general_max_rule = 197;
#define PFopt_general_Max_rule 197
short PFopt_general_rule_descriptor_0[] = { 0, 0 };
short PFopt_general_rule_descriptor_1[] = {   -1,    1,    3,   -6,  -13,   -2, };
short PFopt_general_rule_descriptor_2[] = {   -1,    2,   -6,   -2, };
short PFopt_general_rule_descriptor_3[] = {   -2,    4, };
short PFopt_general_rule_descriptor_4[] = {   -2,    6, };
short PFopt_general_rule_descriptor_5[] = {   -2,    7,   -2, };
short PFopt_general_rule_descriptor_6[] = {   -2,    7,    4, };
short PFopt_general_rule_descriptor_7[] = {   -2,    8,   -2,   -2, };
short PFopt_general_rule_descriptor_8[] = {   -2,    8,    4,    4, };
short PFopt_general_rule_descriptor_9[] = {   -2,    8,   -2,    4, };
short PFopt_general_rule_descriptor_10[] = {   -2,    8,    4,   -2, };
short PFopt_general_rule_descriptor_11[] = {   -2,    9,   -2,   -2, };
short PFopt_general_rule_descriptor_12[] = {   -2,    9,    4,    4, };
short PFopt_general_rule_descriptor_13[] = {   -2,   10,   -2,   -2, };
short PFopt_general_rule_descriptor_14[] = {   -2,   10,   19,   -2,   -2, };
short PFopt_general_rule_descriptor_15[] = {   -2,   11,   -2,   -2, };
short PFopt_general_rule_descriptor_16[] = {   -2,   12,   -2, };
short PFopt_general_rule_descriptor_17[] = {   -2,   12,    7,   -2, };
short PFopt_general_rule_descriptor_18[] = {   -2,   12,   12,   -2, };
short PFopt_general_rule_descriptor_19[] = {   -2,   12,    4, };
short PFopt_general_rule_descriptor_20[] = {   -2,   13,   -2, };
short PFopt_general_rule_descriptor_23[] = {   -2,   14,   -2, };
short PFopt_general_rule_descriptor_24[] = {   -2,   16,   -2,   -2, };
short PFopt_general_rule_descriptor_25[] = {   -2,   16,    4,    4, };
short PFopt_general_rule_descriptor_26[] = {   -2,   16,  -14,   -2, };
short PFopt_general_rule_descriptor_27[] = {   -2,   16,   -2,  -14, };
short PFopt_general_rule_descriptor_28[] = {   -2,   17,   -2,   -2, };
short PFopt_general_rule_descriptor_29[] = {   -2,   18,   -2,   -2, };
short PFopt_general_rule_descriptor_30[] = {   -2,   18,   -2,  -14, };
short PFopt_general_rule_descriptor_32[] = {   -2,   19,   -2, };
short PFopt_general_rule_descriptor_33[] = {   -2,   19,   50,  -13,   -2, };
short PFopt_general_rule_descriptor_34[] = {   -2,   20,   -2, };
short PFopt_general_rule_descriptor_35[] = {   -2,   26,   -2, };
short PFopt_general_rule_descriptor_36[] = {   -2,   25,   -2, };
short PFopt_general_rule_descriptor_37[] = {   -2,   28,   -2, };
short PFopt_general_rule_descriptor_38[] = {   -2,   29,   -2, };
short PFopt_general_rule_descriptor_39[] = {   -2,   30,   -2, };
short PFopt_general_rule_descriptor_40[] = {   -2,   31,   -2, };
short PFopt_general_rule_descriptor_45[] = {   -2,   32,   -2, };
short PFopt_general_rule_descriptor_47[] = {   -2,   37,   -2, };
short PFopt_general_rule_descriptor_48[] = {   -2,   37,    4, };
short PFopt_general_rule_descriptor_49[] = {   -2,   38,   -2, };
short PFopt_general_rule_descriptor_50[] = {   -2,   39,   -2, };
short PFopt_general_rule_descriptor_51[] = {   -2,   40,   -2, };
short PFopt_general_rule_descriptor_52[] = {   -2,   40,   40,   -2, };
short PFopt_general_rule_descriptor_53[] = {   -2,   40,   12,   40,   -2, };
short PFopt_general_rule_descriptor_54[] = {   -2,   41,   -2, };
short PFopt_general_rule_descriptor_55[] = {   -2,   42,   -2, };
short PFopt_general_rule_descriptor_56[] = {   -2,   43,   43,   -2, };
short PFopt_general_rule_descriptor_57[] = {   -2,   43,   12,   43,   -2, };
short PFopt_general_rule_descriptor_58[] = {   -2,   43,    4, };
short PFopt_general_rule_descriptor_59[] = {   -2,   43,   -2, };
short PFopt_general_rule_descriptor_62[] = {   -2,   -3, };
short PFopt_general_rule_descriptor_63[] = {   -3,   50,  -13,   -2, };
short PFopt_general_rule_descriptor_64[] = {   -3,   50,  -13,   -3, };
short PFopt_general_rule_descriptor_65[] = {   -3,   50,  -13,   19,   -2, };
short PFopt_general_rule_descriptor_66[] = {   -2,   51,  -13,   -2, };
short PFopt_general_rule_descriptor_67[] = {   -2,   52,  -13,   -2, };
short PFopt_general_rule_descriptor_68[] = {   -2,   53,  -13,   -2, };
short PFopt_general_rule_descriptor_69[] = {   -2,   54,  -13,   -2, };
short PFopt_general_rule_descriptor_70[] = {   -2,   56,  -13,   -2, };
short PFopt_general_rule_descriptor_74[] = {   -2,   70,   55,   -2, };
short PFopt_general_rule_descriptor_75[] = {   -2,   70,   60,   -4, };
short PFopt_general_rule_descriptor_76[] = {   -2,   70,   69,  -13,   -2, };
short PFopt_general_rule_descriptor_77[] = {   -4,   62,   -2,   -5, };
short PFopt_general_rule_descriptor_78[] = {   -4,   62,   -2,   61,   68,  -13,  -14,   79, };
short PFopt_general_rule_descriptor_79[] = {   -4,   63,   -2,   -5, };
short PFopt_general_rule_descriptor_80[] = {   -4,   63,   -2,   61,   68,  -13,  -14,   79, };
short PFopt_general_rule_descriptor_81[] = {   -4,   64,   -2, };
short PFopt_general_rule_descriptor_82[] = {   -4,   65,   -2, };
short PFopt_general_rule_descriptor_83[] = {   -4,   66,   -2, };
short PFopt_general_rule_descriptor_84[] = {   -4,   67,   -2, };
short PFopt_general_rule_descriptor_85[] = {   -4,   68,  -13,   -2, };
short PFopt_general_rule_descriptor_86[] = {   -4,   79, };
short PFopt_general_rule_descriptor_87[] = {   -5,   61,   -4,   -5, };
short PFopt_general_rule_descriptor_88[] = {   -5,   61,   68,  -13,  -14,   -5, };
short PFopt_general_rule_descriptor_89[] = {   -5,   61,   79,   79, };
short PFopt_general_rule_descriptor_90[] = {   -5,   79, };
short PFopt_general_rule_descriptor_91[] = {   -6,   78,   -6,   -2, };
short PFopt_general_rule_descriptor_92[] = {   -6,   79, };
short PFopt_general_rule_descriptor_93[] = {   -6,   80,   -6,   -2, };
short PFopt_general_rule_descriptor_94[] = {   -6,   81,   -6,   -7, };
short PFopt_general_rule_descriptor_95[] = {   -7,   82,   -2,   -8, };
short PFopt_general_rule_descriptor_96[] = {   -8,   83,   -2,   -9, };
short PFopt_general_rule_descriptor_97[] = {   -9,   84,   -2,   -9, };
short PFopt_general_rule_descriptor_98[] = {   -9,   79, };
short PFopt_general_rule_descriptor_99[] = {   -2,   85,    3,   -6,  -10,   -2, };
short PFopt_general_rule_descriptor_100[] = {   -2,   88, };
short PFopt_general_rule_descriptor_101[] = {  -10,   86,  -11,  -10, };
short PFopt_general_rule_descriptor_102[] = {  -10,   79, };
short PFopt_general_rule_descriptor_103[] = {  -11,   87,   -2,   -2, };
short PFopt_general_rule_descriptor_105[] = {   -2,   90,   -2,  -12, };
short PFopt_general_rule_descriptor_106[] = {  -12,   91,   -2,  -12, };
short PFopt_general_rule_descriptor_107[] = {  -12,   92,  -13,  -12, };
short PFopt_general_rule_descriptor_108[] = {  -12,   79, };
short PFopt_general_rule_descriptor_110[] = {   -2,  102,   -2,   -2, };
short PFopt_general_rule_descriptor_111[] = {   -2,  120,   -2, };
short PFopt_general_rule_descriptor_112[] = {   -2,  -14, };
short PFopt_general_rule_descriptor_114[] = {  -13,   71,   55,   -2, };
short PFopt_general_rule_descriptor_115[] = {  -13,   71,   60,   -4, };
short PFopt_general_rule_descriptor_116[] = {  -13,   71,   69,  -13,   -2, };
short PFopt_general_rule_descriptor_117[] = {  -13,   72,   -2, };
short PFopt_general_rule_descriptor_118[] = {  -13,   73,  -13,  -13, };
short PFopt_general_rule_descriptor_119[] = {  -13,   74, };
short PFopt_general_rule_descriptor_120[] = {  -14,    5, };
short PFopt_general_rule_descriptor_121[] = {  -14,    7,  -14, };
short PFopt_general_rule_descriptor_122[] = {  -14,    8,  -14,   -2, };
short PFopt_general_rule_descriptor_123[] = {  -14,    8,   -2,  -14, };
short PFopt_general_rule_descriptor_124[] = {  -14,    9,  -14,   -2, };
short PFopt_general_rule_descriptor_125[] = {  -14,    9,   -2,  -14, };
short PFopt_general_rule_descriptor_126[] = {  -14,   10,  -14,   -2, };
short PFopt_general_rule_descriptor_127[] = {  -14,   10,   -2,  -14, };
short PFopt_general_rule_descriptor_129[] = {  -14,   11,  -14,   -2, };
short PFopt_general_rule_descriptor_130[] = {  -14,   11,   -2,  -14, };
short PFopt_general_rule_descriptor_131[] = {  -14,   12,  -14, };
short PFopt_general_rule_descriptor_132[] = {  -14,   13,  -14, };
short PFopt_general_rule_descriptor_133[] = {  -14,   14,  -14, };
short PFopt_general_rule_descriptor_134[] = {  -14,   16,  -14,  -14, };
short PFopt_general_rule_descriptor_135[] = {  -14,   17,  -14,   -2, };
short PFopt_general_rule_descriptor_136[] = {  -14,   17,   -2,  -14, };
short PFopt_general_rule_descriptor_137[] = {  -14,   18,  -14,   -2, };
short PFopt_general_rule_descriptor_138[] = {  -14,   19,  -14, };
short PFopt_general_rule_descriptor_140[] = {  -14,   20,  -14, };
short PFopt_general_rule_descriptor_145[] = {  -14,   26,  -14, };
short PFopt_general_rule_descriptor_146[] = {  -14,   25,  -14, };
short PFopt_general_rule_descriptor_147[] = {  -14,   28,  -14, };
short PFopt_general_rule_descriptor_148[] = {  -14,   29,  -14, };
short PFopt_general_rule_descriptor_149[] = {  -14,   30,  -14, };
short PFopt_general_rule_descriptor_150[] = {  -14,   31,  -14, };
short PFopt_general_rule_descriptor_155[] = {  -14,   32,  -14, };
short PFopt_general_rule_descriptor_158[] = {  -14,   37,  -14, };
short PFopt_general_rule_descriptor_159[] = {  -14,   38,  -14, };
short PFopt_general_rule_descriptor_160[] = {  -14,   39,  -14, };
short PFopt_general_rule_descriptor_161[] = {  -14,   40,  -14, };
short PFopt_general_rule_descriptor_162[] = {  -14,   41,  -14, };
short PFopt_general_rule_descriptor_163[] = {  -14,   42,  -14, };
short PFopt_general_rule_descriptor_164[] = {  -14,   43,  -14, };
short PFopt_general_rule_descriptor_170[] = {  -14,   50,  -13,  -14, };
short PFopt_general_rule_descriptor_171[] = {  -14,   51,  -13,  -14, };
short PFopt_general_rule_descriptor_172[] = {  -14,   52,  -13,  -14, };
short PFopt_general_rule_descriptor_173[] = {  -14,   53,  -13,  -14, };
short PFopt_general_rule_descriptor_174[] = {  -14,   54,  -13,  -14, };
short PFopt_general_rule_descriptor_176[] = {  -14,   56,  -13,  -14, };
short PFopt_general_rule_descriptor_180[] = {  -14,   70,   55,  -14, };
short PFopt_general_rule_descriptor_181[] = {  -14,   70,   60,   62,  -14,   -5, };
short PFopt_general_rule_descriptor_182[] = {  -14,   70,   60,   63,  -14,   -5, };
short PFopt_general_rule_descriptor_183[] = {  -14,   70,   60,   64,  -14, };
short PFopt_general_rule_descriptor_184[] = {  -14,   70,   60,   65,  -14, };
short PFopt_general_rule_descriptor_185[] = {  -14,   70,   60,   66,  -14, };
short PFopt_general_rule_descriptor_186[] = {  -14,   70,   60,   67,  -14, };
short PFopt_general_rule_descriptor_187[] = {  -14,   70,   60,   68,  -13,  -14, };
short PFopt_general_rule_descriptor_188[] = {  -14,   70,   60,   79, };
short PFopt_general_rule_descriptor_189[] = {  -14,   70,   69,  -13,  -14, };
short PFopt_general_rule_descriptor_190[] = {  -14,   90,  -14,  -12, };
short PFopt_general_rule_descriptor_191[] = {  -14,  102,  -14,   -2, };
short PFopt_general_rule_descriptor_192[] = {  -14,  120,  -14, };
short PFopt_general_rule_descriptor_193[] = {   -1,    1,    3,   78,   -6,  -14,  -13,   -2, };
short PFopt_general_rule_descriptor_194[] = {   -1,    2,   78,   -6,  -14,   -2, };
short PFopt_general_rule_descriptor_195[] = {   -6,   78,   78,   -6,  -14,   -2, };
short PFopt_general_rule_descriptor_196[] = {   -6,   81,   78,   -6,  -14,   -7, };
short PFopt_general_rule_descriptor_197[] = {   -2,   85,    3,   78,   -6,  -14,  -10,   -2, };
/* PFopt_general_rule_descriptors[0][1] = 1 iff grammar is normal form. */
short * PFopt_general_rule_descriptors[] = {
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_1,
	PFopt_general_rule_descriptor_2,
	PFopt_general_rule_descriptor_3,
	PFopt_general_rule_descriptor_4,
	PFopt_general_rule_descriptor_5,
	PFopt_general_rule_descriptor_6,
	PFopt_general_rule_descriptor_7,
	PFopt_general_rule_descriptor_8,
	PFopt_general_rule_descriptor_9,
	PFopt_general_rule_descriptor_10,
	PFopt_general_rule_descriptor_11,
	PFopt_general_rule_descriptor_12,
	PFopt_general_rule_descriptor_13,
	PFopt_general_rule_descriptor_14,
	PFopt_general_rule_descriptor_15,
	PFopt_general_rule_descriptor_16,
	PFopt_general_rule_descriptor_17,
	PFopt_general_rule_descriptor_18,
	PFopt_general_rule_descriptor_19,
	PFopt_general_rule_descriptor_20,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_23,
	PFopt_general_rule_descriptor_24,
	PFopt_general_rule_descriptor_25,
	PFopt_general_rule_descriptor_26,
	PFopt_general_rule_descriptor_27,
	PFopt_general_rule_descriptor_28,
	PFopt_general_rule_descriptor_29,
	PFopt_general_rule_descriptor_30,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_32,
	PFopt_general_rule_descriptor_33,
	PFopt_general_rule_descriptor_34,
	PFopt_general_rule_descriptor_35,
	PFopt_general_rule_descriptor_36,
	PFopt_general_rule_descriptor_37,
	PFopt_general_rule_descriptor_38,
	PFopt_general_rule_descriptor_39,
	PFopt_general_rule_descriptor_40,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_45,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_47,
	PFopt_general_rule_descriptor_48,
	PFopt_general_rule_descriptor_49,
	PFopt_general_rule_descriptor_50,
	PFopt_general_rule_descriptor_51,
	PFopt_general_rule_descriptor_52,
	PFopt_general_rule_descriptor_53,
	PFopt_general_rule_descriptor_54,
	PFopt_general_rule_descriptor_55,
	PFopt_general_rule_descriptor_56,
	PFopt_general_rule_descriptor_57,
	PFopt_general_rule_descriptor_58,
	PFopt_general_rule_descriptor_59,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_62,
	PFopt_general_rule_descriptor_63,
	PFopt_general_rule_descriptor_64,
	PFopt_general_rule_descriptor_65,
	PFopt_general_rule_descriptor_66,
	PFopt_general_rule_descriptor_67,
	PFopt_general_rule_descriptor_68,
	PFopt_general_rule_descriptor_69,
	PFopt_general_rule_descriptor_70,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_74,
	PFopt_general_rule_descriptor_75,
	PFopt_general_rule_descriptor_76,
	PFopt_general_rule_descriptor_77,
	PFopt_general_rule_descriptor_78,
	PFopt_general_rule_descriptor_79,
	PFopt_general_rule_descriptor_80,
	PFopt_general_rule_descriptor_81,
	PFopt_general_rule_descriptor_82,
	PFopt_general_rule_descriptor_83,
	PFopt_general_rule_descriptor_84,
	PFopt_general_rule_descriptor_85,
	PFopt_general_rule_descriptor_86,
	PFopt_general_rule_descriptor_87,
	PFopt_general_rule_descriptor_88,
	PFopt_general_rule_descriptor_89,
	PFopt_general_rule_descriptor_90,
	PFopt_general_rule_descriptor_91,
	PFopt_general_rule_descriptor_92,
	PFopt_general_rule_descriptor_93,
	PFopt_general_rule_descriptor_94,
	PFopt_general_rule_descriptor_95,
	PFopt_general_rule_descriptor_96,
	PFopt_general_rule_descriptor_97,
	PFopt_general_rule_descriptor_98,
	PFopt_general_rule_descriptor_99,
	PFopt_general_rule_descriptor_100,
	PFopt_general_rule_descriptor_101,
	PFopt_general_rule_descriptor_102,
	PFopt_general_rule_descriptor_103,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_105,
	PFopt_general_rule_descriptor_106,
	PFopt_general_rule_descriptor_107,
	PFopt_general_rule_descriptor_108,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_110,
	PFopt_general_rule_descriptor_111,
	PFopt_general_rule_descriptor_112,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_114,
	PFopt_general_rule_descriptor_115,
	PFopt_general_rule_descriptor_116,
	PFopt_general_rule_descriptor_117,
	PFopt_general_rule_descriptor_118,
	PFopt_general_rule_descriptor_119,
	PFopt_general_rule_descriptor_120,
	PFopt_general_rule_descriptor_121,
	PFopt_general_rule_descriptor_122,
	PFopt_general_rule_descriptor_123,
	PFopt_general_rule_descriptor_124,
	PFopt_general_rule_descriptor_125,
	PFopt_general_rule_descriptor_126,
	PFopt_general_rule_descriptor_127,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_129,
	PFopt_general_rule_descriptor_130,
	PFopt_general_rule_descriptor_131,
	PFopt_general_rule_descriptor_132,
	PFopt_general_rule_descriptor_133,
	PFopt_general_rule_descriptor_134,
	PFopt_general_rule_descriptor_135,
	PFopt_general_rule_descriptor_136,
	PFopt_general_rule_descriptor_137,
	PFopt_general_rule_descriptor_138,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_140,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_145,
	PFopt_general_rule_descriptor_146,
	PFopt_general_rule_descriptor_147,
	PFopt_general_rule_descriptor_148,
	PFopt_general_rule_descriptor_149,
	PFopt_general_rule_descriptor_150,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_155,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_158,
	PFopt_general_rule_descriptor_159,
	PFopt_general_rule_descriptor_160,
	PFopt_general_rule_descriptor_161,
	PFopt_general_rule_descriptor_162,
	PFopt_general_rule_descriptor_163,
	PFopt_general_rule_descriptor_164,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_170,
	PFopt_general_rule_descriptor_171,
	PFopt_general_rule_descriptor_172,
	PFopt_general_rule_descriptor_173,
	PFopt_general_rule_descriptor_174,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_176,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_0,
	PFopt_general_rule_descriptor_180,
	PFopt_general_rule_descriptor_181,
	PFopt_general_rule_descriptor_182,
	PFopt_general_rule_descriptor_183,
	PFopt_general_rule_descriptor_184,
	PFopt_general_rule_descriptor_185,
	PFopt_general_rule_descriptor_186,
	PFopt_general_rule_descriptor_187,
	PFopt_general_rule_descriptor_188,
	PFopt_general_rule_descriptor_189,
	PFopt_general_rule_descriptor_190,
	PFopt_general_rule_descriptor_191,
	PFopt_general_rule_descriptor_192,
	PFopt_general_rule_descriptor_193,
	PFopt_general_rule_descriptor_194,
	PFopt_general_rule_descriptor_195,
	PFopt_general_rule_descriptor_196,
	PFopt_general_rule_descriptor_197,
};
short PFopt_general_cost[][4] = {
	{    0,    0,    0,    0}, /* (none) = 0 */
	{   10,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), Rel) = 1 */
	{   10,    0,    0,    0}, /* Query: serialize_rel(Side, Rel) = 2 */
	{   10,    0,    0,    0}, /* Rel: lit_tbl = 3 */
	{   10,    0,    0,    0}, /* Rel: ref_tbl = 4 */
	{   10,    0,    0,    0}, /* Rel: attach(Rel) = 5 */
	{   10,    0,    0,    0}, /* Rel: attach(lit_tbl) = 6 */
	{   10,    0,    0,    0}, /* Rel: cross(Rel, Rel) = 7 */
	{   10,    0,    0,    0}, /* Rel: cross(lit_tbl, lit_tbl) = 8 */
	{   10,    0,    0,    0}, /* Rel: cross(Rel, lit_tbl) = 9 */
	{   10,    0,    0,    0}, /* Rel: cross(lit_tbl, Rel) = 10 */
	{   10,    0,    0,    0}, /* Rel: eqjoin(Rel, Rel) = 11 */
	{   10,    0,    0,    0}, /* Rel: eqjoin(lit_tbl, lit_tbl) = 12 */
	{   10,    0,    0,    0}, /* Rel: semijoin(Rel, Rel) = 13 */
	{   10,    0,    0,    0}, /* Rel: semijoin(distinct(Rel), Rel) = 14 */
	{   10,    0,    0,    0}, /* Rel: thetajoin(Rel, Rel) = 15 */
	{   10,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{   10,    0,    0,    0}, /* Rel: project(attach(Rel)) = 17 */
	{    1,    0,    0,    0}, /* Rel: project(project(Rel)) = 18 */
	{   10,    0,    0,    0}, /* Rel: project(lit_tbl) = 19 */
	{   10,    0,    0,    0}, /* Rel: select_(Rel) = 20 */
	{    0,    0,    0,    0}, /* (none) = 21 */
	{    0,    0,    0,    0}, /* (none) = 22 */
	{   10,    0,    0,    0}, /* Rel: pos_select(Rel) = 23 */
	{   10,    0,    0,    0}, /* Rel: disjunion(Rel, Rel) = 24 */
	{   10,    0,    0,    0}, /* Rel: disjunion(lit_tbl, lit_tbl) = 25 */
	{    5,    0,    0,    0}, /* Rel: disjunion(EmptyRel, Rel) = 26 */
	{    5,    0,    0,    0}, /* Rel: disjunion(Rel, EmptyRel) = 27 */
	{   10,    0,    0,    0}, /* Rel: intersect(Rel, Rel) = 28 */
	{   10,    0,    0,    0}, /* Rel: difference(Rel, Rel) = 29 */
	{    5,    0,    0,    0}, /* Rel: difference(Rel, EmptyRel) = 30 */
	{    0,    0,    0,    0}, /* (none) = 31 */
	{   10,    0,    0,    0}, /* Rel: distinct(Rel) = 32 */
	{    5,    0,    0,    0}, /* Rel: distinct(step(Frag, Rel)) = 33 */
	{   10,    0,    0,    0}, /* Rel: fun_1to1(Rel) = 34 */
	{   10,    0,    0,    0}, /* Rel: num_gt(Rel) = 35 */
	{   10,    0,    0,    0}, /* Rel: num_eq(Rel) = 36 */
	{   10,    0,    0,    0}, /* Rel: bool_and(Rel) = 37 */
	{   10,    0,    0,    0}, /* Rel: bool_or(Rel) = 38 */
	{   10,    0,    0,    0}, /* Rel: bool_not(Rel) = 39 */
	{   10,    0,    0,    0}, /* Rel: to(Rel) = 40 */
	{    0,    0,    0,    0}, /* (none) = 41 */
	{    0,    0,    0,    0}, /* (none) = 42 */
	{    0,    0,    0,    0}, /* (none) = 43 */
	{    0,    0,    0,    0}, /* (none) = 44 */
	{   10,    0,    0,    0}, /* Rel: aggr(Rel) = 45 */
	{    0,    0,    0,    0}, /* (none) = 46 */
	{   10,    0,    0,    0}, /* Rel: rownum(Rel) = 47 */
	{   10,    0,    0,    0}, /* Rel: rownum(lit_tbl) = 48 */
	{   10,    0,    0,    0}, /* Rel: rowrank(Rel) = 49 */
	{   10,    0,    0,    0}, /* Rel: rank(Rel) = 50 */
	{   10,    0,    0,    0}, /* Rel: rowid(Rel) = 51 */
	{   10,    0,    0,    0}, /* Rel: rowid(rowid(Rel)) = 52 */
	{   10,    0,    0,    0}, /* Rel: rowid(project(rowid(Rel))) = 53 */
	{   10,    0,    0,    0}, /* Rel: type(Rel) = 54 */
	{   10,    0,    0,    0}, /* Rel: type_assert(Rel) = 55 */
	{   10,    0,    0,    0}, /* Rel: cast(cast(Rel)) = 56 */
	{   10,    0,    0,    0}, /* Rel: cast(project(cast(Rel))) = 57 */
	{   10,    0,    0,    0}, /* Rel: cast(lit_tbl) = 58 */
	{   10,    0,    0,    0}, /* Rel: cast(Rel) = 59 */
	{    0,    0,    0,    0}, /* (none) = 60 */
	{    0,    0,    0,    0}, /* (none) = 61 */
	{   10,    0,    0,    0}, /* Rel: ScjRel = 62 */
	{   10,    0,    0,    0}, /* ScjRel: step(Frag, Rel) = 63 */
	{   10,    0,    0,    0}, /* ScjRel: step(Frag, ScjRel) = 64 */
	{   10,    0,    0,    0}, /* ScjRel: step(Frag, distinct(Rel)) = 65 */
	{   10,    0,    0,    0}, /* Rel: step_join(Frag, Rel) = 66 */
	{   10,    0,    0,    0}, /* Rel: guide_step(Frag, Rel) = 67 */
	{   10,    0,    0,    0}, /* Rel: guide_step_join(Frag, Rel) = 68 */
	{   10,    0,    0,    0}, /* Rel: doc_index_join(Frag, Rel) = 69 */
	{   10,    0,    0,    0}, /* Rel: doc_access(Frag, Rel) = 70 */
	{    0,    0,    0,    0}, /* (none) = 71 */
	{    0,    0,    0,    0}, /* (none) = 72 */
	{    0,    0,    0,    0}, /* (none) = 73 */
	{   10,    0,    0,    0}, /* Rel: roots_(doc_tbl(Rel)) = 74 */
	{   10,    0,    0,    0}, /* Rel: roots_(twig(Twig)) = 75 */
	{   10,    0,    0,    0}, /* Rel: roots_(merge_adjacent(Frag, Rel)) = 76 */
	{   10,    0,    0,    0}, /* Twig: docnode(Rel, Fcns) = 77 */
	{   10,    0,    0,    0}, /* Twig: docnode(Rel, fcns(content(Frag, EmptyRel), nil)) = 78 */
	{   10,    0,    0,    0}, /* Twig: element(Rel, Fcns) = 79 */
	{   10,    0,    0,    0}, /* Twig: element(Rel, fcns(content(Frag, EmptyRel), nil)) = 80 */
	{   10,    0,    0,    0}, /* Twig: attribute(Rel) = 81 */
	{   10,    0,    0,    0}, /* Twig: textnode(Rel) = 82 */
	{   10,    0,    0,    0}, /* Twig: comment(Rel) = 83 */
	{   10,    0,    0,    0}, /* Twig: processi(Rel) = 84 */
	{   10,    0,    0,    0}, /* Twig: content(Frag, Rel) = 85 */
	{   10,    0,    0,    0}, /* Twig: nil = 86 */
	{   10,    0,    0,    0}, /* Fcns: fcns(Twig, Fcns) = 87 */
	{   10,    0,    0,    0}, /* Fcns: fcns(content(Frag, EmptyRel), Fcns) = 88 */
	{   10,    0,    0,    0}, /* Fcns: fcns(nil, nil) = 89 */
	{   10,    0,    0,    0}, /* Fcns: nil = 90 */
	{   10,    0,    0,    0}, /* Side: error(Side, Rel) = 91 */
	{   10,    0,    0,    0}, /* Side: nil = 92 */
	{   10,    0,    0,    0}, /* Side: cache(Side, Rel) = 93 */
	{   10,    0,    0,    0}, /* Side: trace(Side, Trc) = 94 */
	{   10,    0,    0,    0}, /* Trc: trace_items(Rel, Msg) = 95 */
	{   10,    0,    0,    0}, /* Msg: trace_msg(Rel, Map) = 96 */
	{   10,    0,    0,    0}, /* Map: trace_map(Rel, Map) = 97 */
	{   10,    0,    0,    0}, /* Map: nil = 98 */
	{   10,    0,    0,    0}, /* Rel: rec_fix(side_effects(Side, Rec), Rel) = 99 */
	{   10,    0,    0,    0}, /* Rel: rec_base = 100 */
	{   10,    0,    0,    0}, /* Rec: rec_param(Arg, Rec) = 101 */
	{   10,    0,    0,    0}, /* Rec: nil = 102 */
	{   10,    0,    0,    0}, /* Arg: rec_arg(Rel, Rel) = 103 */
	{    0,    0,    0,    0}, /* (none) = 104 */
	{   10,    0,    0,    0}, /* Rel: fun_call(Rel, Param) = 105 */
	{   10,    0,    0,    0}, /* Param: fun_param(Rel, Param) = 106 */
	{   10,    0,    0,    0}, /* Param: fun_frag_param(Frag, Param) = 107 */
	{   10,    0,    0,    0}, /* Param: nil = 108 */
	{    0,    0,    0,    0}, /* (none) = 109 */
	{   10,    0,    0,    0}, /* Rel: string_join(Rel, Rel) = 110 */
	{   10,    0,    0,    0}, /* Rel: dummy(Rel) = 111 */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) = 113 */
	{   10,    0,    0,    0}, /* Frag: fragment(doc_tbl(Rel)) = 114 */
	{   10,    0,    0,    0}, /* Frag: fragment(twig(Twig)) = 115 */
	{   10,    0,    0,    0}, /* Frag: fragment(merge_adjacent(Frag, Rel)) = 116 */
	{   10,    0,    0,    0}, /* Frag: frag_extract(Rel) = 117 */
	{   10,    0,    0,    0}, /* Frag: frag_union(Frag, Frag) = 118 */
	{   10,    0,    0,    0}, /* Frag: empty_frag = 119 */
	{    0,    0,    0,    0}, /* EmptyRel: empty_tbl = 120 */
	{    0,    0,    0,    0}, /* EmptyRel: attach(EmptyRel) = 121 */
	{    0,    0,    0,    0}, /* EmptyRel: cross(EmptyRel, Rel) = 122 */
	{    0,    0,    0,    0}, /* EmptyRel: cross(Rel, EmptyRel) = 123 */
	{    0,    0,    0,    0}, /* EmptyRel: eqjoin(EmptyRel, Rel) = 124 */
	{    0,    0,    0,    0}, /* EmptyRel: eqjoin(Rel, EmptyRel) = 125 */
	{    0,    0,    0,    0}, /* EmptyRel: semijoin(EmptyRel, Rel) = 126 */
	{    0,    0,    0,    0}, /* EmptyRel: semijoin(Rel, EmptyRel) = 127 */
	{    0,    0,    0,    0}, /* (none) = 128 */
	{    0,    0,    0,    0}, /* EmptyRel: thetajoin(EmptyRel, Rel) = 129 */
	{    0,    0,    0,    0}, /* EmptyRel: thetajoin(Rel, EmptyRel) = 130 */
	{    0,    0,    0,    0}, /* EmptyRel: project(EmptyRel) = 131 */
	{    0,    0,    0,    0}, /* EmptyRel: select_(EmptyRel) = 132 */
	{   10,    0,    0,    0}, /* EmptyRel: pos_select(EmptyRel) = 133 */
	{    0,    0,    0,    0}, /* EmptyRel: disjunion(EmptyRel, EmptyRel) = 134 */
	{    0,    0,    0,    0}, /* EmptyRel: intersect(EmptyRel, Rel) = 135 */
	{    0,    0,    0,    0}, /* EmptyRel: intersect(Rel, EmptyRel) = 136 */
	{    0,    0,    0,    0}, /* EmptyRel: difference(EmptyRel, Rel) = 137 */
	{    0,    0,    0,    0}, /* EmptyRel: distinct(EmptyRel) = 138 */
	{    0,    0,    0,    0}, /* (none) = 139 */
	{    0,    0,    0,    0}, /* EmptyRel: fun_1to1(EmptyRel) = 140 */
	{    0,    0,    0,    0}, /* (none) = 141 */
	{    0,    0,    0,    0}, /* (none) = 142 */
	{    0,    0,    0,    0}, /* (none) = 143 */
	{    0,    0,    0,    0}, /* (none) = 144 */
	{    0,    0,    0,    0}, /* EmptyRel: num_gt(EmptyRel) = 145 */
	{    0,    0,    0,    0}, /* EmptyRel: num_eq(EmptyRel) = 146 */
	{    0,    0,    0,    0}, /* EmptyRel: bool_and(EmptyRel) = 147 */
	{    0,    0,    0,    0}, /* EmptyRel: bool_or(EmptyRel) = 148 */
	{    0,    0,    0,    0}, /* EmptyRel: bool_not(EmptyRel) = 149 */
	{    0,    0,    0,    0}, /* EmptyRel: to(EmptyRel) = 150 */
	{    0,    0,    0,    0}, /* (none) = 151 */
	{    0,    0,    0,    0}, /* (none) = 152 */
	{    0,    0,    0,    0}, /* (none) = 153 */
	{    0,    0,    0,    0}, /* (none) = 154 */
	{    0,    0,    0,    0}, /* EmptyRel: aggr(EmptyRel) = 155 */
	{    0,    0,    0,    0}, /* (none) = 156 */
	{    0,    0,    0,    0}, /* (none) = 157 */
	{    0,    0,    0,    0}, /* EmptyRel: rownum(EmptyRel) = 158 */
	{    0,    0,    0,    0}, /* EmptyRel: rowrank(EmptyRel) = 159 */
	{    0,    0,    0,    0}, /* EmptyRel: rank(EmptyRel) = 160 */
	{    0,    0,    0,    0}, /* EmptyRel: rowid(EmptyRel) = 161 */
	{    0,    0,    0,    0}, /* EmptyRel: type(EmptyRel) = 162 */
	{    0,    0,    0,    0}, /* EmptyRel: type_assert(EmptyRel) = 163 */
	{    0,    0,    0,    0}, /* EmptyRel: cast(EmptyRel) = 164 */
	{    0,    0,    0,    0}, /* (none) = 165 */
	{    0,    0,    0,    0}, /* (none) = 166 */
	{    0,    0,    0,    0}, /* (none) = 167 */
	{    0,    0,    0,    0}, /* (none) = 168 */
	{    0,    0,    0,    0}, /* (none) = 169 */
	{    0,    0,    0,    0}, /* EmptyRel: step(Frag, EmptyRel) = 170 */
	{    0,    0,    0,    0}, /* EmptyRel: step_join(Frag, EmptyRel) = 171 */
	{    0,    0,    0,    0}, /* EmptyRel: guide_step(Frag, EmptyRel) = 172 */
	{    0,    0,    0,    0}, /* EmptyRel: guide_step_join(Frag, EmptyRel) = 173 */
	{    0,    0,    0,    0}, /* EmptyRel: doc_index_join(Frag, EmptyRel) = 174 */
	{    0,    0,    0,    0}, /* (none) = 175 */
	{    0,    0,    0,    0}, /* EmptyRel: doc_access(Frag, EmptyRel) = 176 */
	{    0,    0,    0,    0}, /* (none) = 177 */
	{    0,    0,    0,    0}, /* (none) = 178 */
	{    0,    0,    0,    0}, /* (none) = 179 */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(doc_tbl(EmptyRel)) = 180 */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(docnode(EmptyRel, Fcns))) = 181 */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(element(EmptyRel, Fcns))) = 182 */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(attribute(EmptyRel))) = 183 */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(textnode(EmptyRel))) = 184 */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(comment(EmptyRel))) = 185 */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(processi(EmptyRel))) = 186 */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(content(Frag, EmptyRel))) = 187 */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(nil)) = 188 */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(merge_adjacent(Frag, EmptyRel)) = 189 */
	{    0,    0,    0,    0}, /* EmptyRel: fun_call(EmptyRel, Param) = 190 */
	{    0,    0,    0,    0}, /* EmptyRel: string_join(EmptyRel, Rel) = 191 */
	{    0,    0,    0,    0}, /* EmptyRel: dummy(EmptyRel) = 192 */
	{    0,    0,    0,    0}, /* Query: serialize_seq(side_effects(error(Side, EmptyRel), Frag), Rel) = 193 */
	{    0,    0,    0,    0}, /* Query: serialize_rel(error(Side, EmptyRel), Rel) = 194 */
	{    0,    0,    0,    0}, /* Side: error(error(Side, EmptyRel), Rel) = 195 */
	{    0,    0,    0,    0}, /* Side: trace(error(Side, EmptyRel), Trc) = 196 */
	{    0,    0,    0,    0}, /* Rel: rec_fix(side_effects(error(Side, EmptyRel), Rec), Rel) = 197 */
};

short PFopt_general_delta_cost[202][15][4] = {
{{0}}, /* state 0 */
{ /* state #1: aggr(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: aggr(Rel) = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #2: aggr(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: aggr(EmptyRel) = 155 */
},
{ /* state #3: attach(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: attach(EmptyRel) = 121 */
},
{ /* state #4: attach(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: attach(Rel) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #5: attach(lit_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: attach(lit_tbl) = 6 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #6: attribute(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: attribute(Rel) = 81 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #7: attribute(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: attribute(Rel) = 81 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #8: bool_and(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: bool_and(EmptyRel) = 147 */
},
{ /* state #9: bool_and(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: bool_and(Rel) = 37 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #10: bool_not(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: bool_not(Rel) = 39 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #11: bool_not(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: bool_not(EmptyRel) = 149 */
},
{ /* state #12: bool_or(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: bool_or(Rel) = 38 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #13: bool_or(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: bool_or(EmptyRel) = 148 */
},
{ /* state #14: cache(nil, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: cache(Side, Rel) = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #15: cast(cast(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cast(cast(Rel)) = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #16: cast(lit_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cast(lit_tbl) = 58 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #17: cast(cast(lit_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: cast(cast(Rel)) = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #18: cast(project(cast(project(cast(rec_base))))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: cast(project(cast(Rel))) = 57 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #19: cast(project(cast(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cast(project(cast(Rel))) = 57 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #20: cast(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: cast(Rel) = 59 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #21: cast(project(cast(lit_tbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cast(project(cast(Rel))) = 57 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #22: cast(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: cast(EmptyRel) = 164 */
},
{ /* state #23: comment(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: comment(Rel) = 83 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #24: comment(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: comment(Rel) = 83 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #25: content(empty_frag, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: content(Frag, Rel) = 85 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #26: content(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: content(Frag, Rel) = 85 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #27: cross(lit_tbl, lit_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cross(lit_tbl, lit_tbl) = 8 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #28: cross(lit_tbl, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cross(lit_tbl, Rel) = 10 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #29: cross(rec_base, lit_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cross(Rel, lit_tbl) = 9 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #30: cross(rec_base, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: cross(Rel, EmptyRel) = 123 */
},
{ /* state #31: cross(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: cross(Rel, Rel) = 7 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #32: cross(empty_tbl, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: cross(EmptyRel, Rel) = 122 */
},
{ /* state #33: difference(empty_tbl, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: difference(EmptyRel, Rel) = 137 */
},
{ /* state #34: difference(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: difference(Rel, Rel) = 29 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #35: difference(rec_base, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: difference(Rel, EmptyRel) = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #36: disjunion(empty_tbl, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: disjunion(EmptyRel, Rel) = 26 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #37: disjunion(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: disjunion(Rel, Rel) = 24 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #38: disjunion(lit_tbl, lit_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: disjunion(lit_tbl, lit_tbl) = 25 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #39: disjunion(rec_base, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: disjunion(Rel, EmptyRel) = 27 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #40: disjunion(empty_tbl, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: disjunion(EmptyRel, EmptyRel) = 134 */
},
{ /* state #41: distinct(step(empty_frag, rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: distinct(step(Frag, Rel)) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #42: distinct(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: distinct(EmptyRel) = 138 */
},
{ /* state #43: distinct(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: distinct(Rel) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #44: distinct(step(empty_frag, distinct(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: distinct(step(Frag, Rel)) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #45: doc_access(empty_frag, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: doc_access(Frag, EmptyRel) = 176 */
},
{ /* state #46: doc_access(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: doc_access(Frag, Rel) = 70 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #47: doc_index_join(empty_frag, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: doc_index_join(Frag, EmptyRel) = 174 */
},
{ /* state #48: doc_index_join(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: doc_index_join(Frag, Rel) = 69 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #49: doc_tbl(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #50: doc_tbl(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #51: docnode(rec_base, fcns(content(empty_frag, empty_tbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: docnode(Rel, fcns(content(Frag, EmptyRel), nil)) = 78 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #52: docnode(empty_tbl, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: docnode(Rel, Fcns) = 77 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #53: docnode(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: docnode(Rel, Fcns) = 77 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #54: docnode(empty_tbl, fcns(content(empty_frag, empty_tbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: docnode(Rel, fcns(content(Frag, EmptyRel), nil)) = 78 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #55: dummy(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: dummy(Rel) = 111 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #56: dummy(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: dummy(EmptyRel) = 192 */
},
{ /* state #57: element(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: element(Rel, Fcns) = 79 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #58: element(empty_tbl, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: element(Rel, Fcns) = 79 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #59: element(empty_tbl, fcns(content(empty_frag, empty_tbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: element(Rel, fcns(content(Frag, EmptyRel), nil)) = 80 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #60: element(rec_base, fcns(content(empty_frag, empty_tbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: element(Rel, fcns(content(Frag, EmptyRel), nil)) = 80 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #61: empty_frag */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Frag: empty_frag = 119 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #62: empty_tbl */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: empty_tbl = 120 */
},
{ /* state #63: eqjoin(lit_tbl, lit_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: eqjoin(lit_tbl, lit_tbl) = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #64: eqjoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: eqjoin(Rel, Rel) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #65: eqjoin(rec_base, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: eqjoin(Rel, EmptyRel) = 125 */
},
{ /* state #66: eqjoin(empty_tbl, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: eqjoin(EmptyRel, Rel) = 124 */
},
{ /* state #67: error(nil, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: error(Side, Rel) = 91 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #68: error(nil, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Side: error(Side, Rel) = 91 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #69: error(error(nil, empty_tbl), rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: error(error(Side, EmptyRel), Rel) = 195 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #70: error(error(nil, empty_tbl), empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: error(error(Side, EmptyRel), Rel) = 195 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #71: fcns(nil, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Fcns: fcns(nil, nil) = 89 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #72: fcns(content(empty_frag, empty_tbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Fcns: fcns(content(Frag, EmptyRel), Fcns) = 88 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #73: fcns(attribute(empty_tbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Fcns: fcns(Twig, Fcns) = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #74: fcns(content(empty_frag, empty_tbl), fcns(nil, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Fcns: fcns(content(Frag, EmptyRel), Fcns) = 88 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #75: frag_extract(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Frag: frag_extract(Rel) = 117 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #76: frag_union(empty_frag, empty_frag) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Frag: frag_union(Frag, Frag) = 118 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #77: fragment(merge_adjacent(empty_frag, empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Frag: fragment(merge_adjacent(Frag, Rel)) = 116 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #78: fragment(doc_tbl(empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Frag: fragment(doc_tbl(Rel)) = 114 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #79: fragment(twig(nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Frag: fragment(twig(Twig)) = 115 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #80: fun_1to1(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: fun_1to1(EmptyRel) = 140 */
},
{ /* state #81: fun_1to1(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: fun_1to1(Rel) = 34 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #82: fun_call(empty_tbl, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: fun_call(EmptyRel, Param) = 190 */
},
{ /* state #83: fun_call(rec_base, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: fun_call(Rel, Param) = 105 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #84: fun_frag_param(empty_frag, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Param: fun_frag_param(Frag, Param) = 107 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #85: fun_param(empty_tbl, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Param: fun_param(Rel, Param) = 106 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #86: guide_step(empty_frag, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: guide_step(Frag, EmptyRel) = 172 */
},
{ /* state #87: guide_step(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: guide_step(Frag, Rel) = 67 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #88: guide_step_join(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: guide_step_join(Frag, Rel) = 68 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #89: guide_step_join(empty_frag, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: guide_step_join(Frag, EmptyRel) = 173 */
},
{ /* state #90: intersect(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: intersect(Rel, Rel) = 28 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #91: intersect(empty_tbl, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: intersect(EmptyRel, Rel) = 135 */
},
{ /* state #92: intersect(rec_base, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: intersect(Rel, EmptyRel) = 136 */
},
{ /* state #93: lit_tbl */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: lit_tbl = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #94: merge_adjacent(empty_frag, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #95: merge_adjacent(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #96: nil */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: nil = 86 */
	{   10,    0,    0,    0}, /* Fcns: nil = 90 */
	{   10,    0,    0,    0}, /* Side: nil = 92 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Map: nil = 98 */
	{   10,    0,    0,    0}, /* Rec: nil = 102 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Param: nil = 108 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #97: num_eq(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: num_eq(EmptyRel) = 146 */
},
{ /* state #98: num_eq(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: num_eq(Rel) = 36 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #99: num_gt(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: num_gt(EmptyRel) = 145 */
},
{ /* state #100: num_gt(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: num_gt(Rel) = 35 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #101: pos_select(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: pos_select(EmptyRel) = 133 */
},
{ /* state #102: pos_select(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: pos_select(Rel) = 23 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #103: processi(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: processi(Rel) = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #104: processi(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: processi(Rel) = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #105: project(rowid(project(rowid(rec_base)))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #106: project(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #107: project(project(project(lit_tbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: project(project(Rel)) = 18 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #108: project(cast(project(cast(rec_base)))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #109: project(rowid(rowid(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #110: project(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: project(EmptyRel) = 131 */
},
{ /* state #111: project(lit_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: project(lit_tbl) = 19 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #112: project(rowid(empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: project(EmptyRel) = 131 */
},
{ /* state #113: project(cast(empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: project(EmptyRel) = 131 */
},
{ /* state #114: project(cast(lit_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #115: project(project(lit_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    1,    0,    0,    0}, /* Rel: project(project(Rel)) = 18 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #116: project(attach(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: project(attach(Rel)) = 17 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #117: project(project(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: project(project(Rel)) = 18 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #118: project(rowid(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #119: project(cast(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Rel: project(Rel) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #120: rank(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rank(Rel) = 50 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #121: rank(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: rank(EmptyRel) = 160 */
},
{ /* state #122: rec_arg(empty_tbl, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Arg: rec_arg(Rel, Rel) = 103 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #123: rec_base */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rec_base = 100 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #124: rec_fix(side_effects(error(nil, empty_tbl), nil), empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rec_fix(side_effects(error(Side, EmptyRel), Rec), Rel) = 197 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #125: rec_fix(side_effects(nil, nil), empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rec_fix(side_effects(Side, Rec), Rel) = 99 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #126: rec_param(rec_arg(empty_tbl, empty_tbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rec: rec_param(Arg, Rec) = 101 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #127: ref_tbl */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: ref_tbl = 4 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #128: roots_(twig(docnode(empty_tbl, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(docnode(EmptyRel, Fcns))) = 181 */
},
{ /* state #129: roots_(merge_adjacent(empty_frag, rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: roots_(merge_adjacent(Frag, Rel)) = 76 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #130: roots_(twig(textnode(empty_tbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(textnode(EmptyRel))) = 184 */
},
{ /* state #131: roots_(twig(nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(nil)) = 188 */
},
{ /* state #132: roots_(doc_tbl(empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(doc_tbl(EmptyRel)) = 180 */
},
{ /* state #133: roots_(twig(attribute(empty_tbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(attribute(EmptyRel))) = 183 */
},
{ /* state #134: roots_(twig(element(empty_tbl, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(element(EmptyRel, Fcns))) = 182 */
},
{ /* state #135: roots_(merge_adjacent(empty_frag, empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(merge_adjacent(Frag, EmptyRel)) = 189 */
},
{ /* state #136: roots_(doc_tbl(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: roots_(doc_tbl(Rel)) = 74 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #137: roots_(twig(content(empty_frag, empty_tbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(content(Frag, EmptyRel))) = 187 */
},
{ /* state #138: roots_(twig(attribute(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: roots_(twig(Twig)) = 75 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #139: roots_(twig(processi(empty_tbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(processi(EmptyRel))) = 186 */
},
{ /* state #140: roots_(twig(comment(empty_tbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: roots_(twig(comment(EmptyRel))) = 185 */
},
{ /* state #141: rowid(rowid(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rowid(rowid(Rel)) = 52 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #142: rowid(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: rowid(EmptyRel) = 161 */
},
{ /* state #143: rowid(project(rowid(rec_base))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rowid(project(rowid(Rel))) = 53 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #144: rowid(project(rowid(rowid(rec_base)))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rowid(project(rowid(Rel))) = 53 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #145: rowid(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: rowid(Rel) = 51 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #146: rownum(lit_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rownum(lit_tbl) = 48 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #147: rownum(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: rownum(EmptyRel) = 158 */
},
{ /* state #148: rownum(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rownum(Rel) = 47 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #149: rowrank(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: rowrank(Rel) = 49 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #150: rowrank(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: rowrank(EmptyRel) = 159 */
},
{ /* state #151: select_(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: select_(EmptyRel) = 132 */
},
{ /* state #152: select_(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: select_(Rel) = 20 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #153: semijoin(rec_base, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: semijoin(Rel, EmptyRel) = 127 */
},
{ /* state #154: semijoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: semijoin(Rel, Rel) = 13 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #155: semijoin(distinct(rec_base), rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: semijoin(distinct(Rel), Rel) = 14 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #156: semijoin(empty_tbl, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: semijoin(EmptyRel, Rel) = 126 */
},
{ /* state #157: serialize_rel(error(nil, empty_tbl), empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_rel(error(Side, EmptyRel), Rel) = 194 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #158: serialize_rel(nil, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_rel(Side, Rel) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #159: serialize_seq(side_effects(error(nil, empty_tbl), empty_frag), empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_seq(side_effects(error(Side, EmptyRel), Frag), Rel) = 193 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #160: serialize_seq(side_effects(nil, empty_frag), empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* Query: serialize_seq(side_effects(Side, Frag), Rel) = 1 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #161: side_effects(nil, empty_frag) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #162: side_effects(error(error(nil, empty_tbl), empty_tbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #163: side_effects(error(nil, empty_tbl), empty_frag) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #164: side_effects(error(nil, empty_tbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #165: side_effects(error(error(nil, empty_tbl), empty_tbl), empty_frag) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #166: side_effects(nil, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #167: step(empty_frag, step(empty_frag, rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: ScjRel = 62 */
	{    0,    0,    0,    0}, /* ScjRel: step(Frag, ScjRel) = 64 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #168: step(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Rel: ScjRel = 62 */
	{   10,    0,    0,    0}, /* ScjRel: step(Frag, Rel) = 63 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #169: step(empty_frag, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{   10,    0,    0,    0}, /* ScjRel: step(Frag, Rel) = 63 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: step(Frag, EmptyRel) = 170 */
},
{ /* state #170: step(empty_frag, distinct(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Rel: ScjRel = 62 */
	{    0,    0,    0,    0}, /* ScjRel: step(Frag, distinct(Rel)) = 65 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #171: step_join(empty_frag, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: step_join(Frag, EmptyRel) = 171 */
},
{ /* state #172: step_join(empty_frag, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: step_join(Frag, Rel) = 66 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #173: string_join(empty_tbl, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: string_join(EmptyRel, Rel) = 191 */
},
{ /* state #174: string_join(rec_base, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: string_join(Rel, Rel) = 110 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #175: textnode(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Twig: textnode(Rel) = 82 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #176: textnode(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Twig: textnode(Rel) = 82 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #177: thetajoin(rec_base, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: thetajoin(Rel, EmptyRel) = 130 */
},
{ /* state #178: thetajoin(rec_base, rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: thetajoin(Rel, Rel) = 15 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #179: thetajoin(empty_tbl, empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: thetajoin(EmptyRel, Rel) = 129 */
},
{ /* state #180: to(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: to(EmptyRel) = 150 */
},
{ /* state #181: to(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: to(Rel) = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #182: trace(nil, trace_items(empty_tbl, trace_msg(empty_tbl, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: trace(Side, Trc) = 94 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #183: trace(error(nil, empty_tbl), trace_items(empty_tbl, trace_msg(empty_tbl, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Side: trace(error(Side, EmptyRel), Trc) = 196 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #184: trace_items(empty_tbl, trace_msg(empty_tbl, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Trc: trace_items(Rel, Msg) = 95 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #185: trace_map(empty_tbl, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Map: trace_map(Rel, Map) = 97 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #186: trace_msg(empty_tbl, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Msg: trace_msg(Rel, Map) = 96 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #187: twig(attribute(empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #188: twig(nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #189: twig(textnode(empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #190: twig(comment(empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #191: twig(attribute(rec_base)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #192: twig(processi(empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #193: twig(content(empty_frag, empty_tbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #194: twig(element(empty_tbl, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #195: twig(docnode(empty_tbl, fcns(content(empty_frag, empty_tbl), nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #196: twig(element(empty_tbl, fcns(content(empty_frag, empty_tbl), nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #197: twig(docnode(empty_tbl, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #198: type(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: type(EmptyRel) = 162 */
},
{ /* state #199: type(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: type(Rel) = 54 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #200: type_assert(empty_tbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: EmptyRel = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* EmptyRel: type_assert(EmptyRel) = 163 */
},
{ /* state #201: type_assert(rec_base) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* Rel: type_assert(Rel) = 55 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
};

char * PFopt_general_state_string[] = {
" not a state", /* state 0 */
	"aggr(rec_base)", /* state #1 */
	"aggr(empty_tbl)", /* state #2 */
	"attach(empty_tbl)", /* state #3 */
	"attach(rec_base)", /* state #4 */
	"attach(lit_tbl)", /* state #5 */
	"attribute(rec_base)", /* state #6 */
	"attribute(empty_tbl)", /* state #7 */
	"bool_and(empty_tbl)", /* state #8 */
	"bool_and(rec_base)", /* state #9 */
	"bool_not(rec_base)", /* state #10 */
	"bool_not(empty_tbl)", /* state #11 */
	"bool_or(rec_base)", /* state #12 */
	"bool_or(empty_tbl)", /* state #13 */
	"cache(nil, empty_tbl)", /* state #14 */
	"cast(cast(rec_base))", /* state #15 */
	"cast(lit_tbl)", /* state #16 */
	"cast(cast(lit_tbl))", /* state #17 */
	"cast(project(cast(project(cast(rec_base)))))", /* state #18 */
	"cast(project(cast(rec_base)))", /* state #19 */
	"cast(rec_base)", /* state #20 */
	"cast(project(cast(lit_tbl)))", /* state #21 */
	"cast(empty_tbl)", /* state #22 */
	"comment(rec_base)", /* state #23 */
	"comment(empty_tbl)", /* state #24 */
	"content(empty_frag, empty_tbl)", /* state #25 */
	"content(empty_frag, rec_base)", /* state #26 */
	"cross(lit_tbl, lit_tbl)", /* state #27 */
	"cross(lit_tbl, rec_base)", /* state #28 */
	"cross(rec_base, lit_tbl)", /* state #29 */
	"cross(rec_base, empty_tbl)", /* state #30 */
	"cross(rec_base, rec_base)", /* state #31 */
	"cross(empty_tbl, empty_tbl)", /* state #32 */
	"difference(empty_tbl, empty_tbl)", /* state #33 */
	"difference(rec_base, rec_base)", /* state #34 */
	"difference(rec_base, empty_tbl)", /* state #35 */
	"disjunion(empty_tbl, rec_base)", /* state #36 */
	"disjunion(rec_base, rec_base)", /* state #37 */
	"disjunion(lit_tbl, lit_tbl)", /* state #38 */
	"disjunion(rec_base, empty_tbl)", /* state #39 */
	"disjunion(empty_tbl, empty_tbl)", /* state #40 */
	"distinct(step(empty_frag, rec_base))", /* state #41 */
	"distinct(empty_tbl)", /* state #42 */
	"distinct(rec_base)", /* state #43 */
	"distinct(step(empty_frag, distinct(rec_base)))", /* state #44 */
	"doc_access(empty_frag, empty_tbl)", /* state #45 */
	"doc_access(empty_frag, rec_base)", /* state #46 */
	"doc_index_join(empty_frag, empty_tbl)", /* state #47 */
	"doc_index_join(empty_frag, rec_base)", /* state #48 */
	"doc_tbl(empty_tbl)", /* state #49 */
	"doc_tbl(rec_base)", /* state #50 */
	"docnode(rec_base, fcns(content(empty_frag, empty_tbl), nil))", /* state #51 */
	"docnode(empty_tbl, nil)", /* state #52 */
	"docnode(rec_base, nil)", /* state #53 */
	"docnode(empty_tbl, fcns(content(empty_frag, empty_tbl), nil))", /* state #54 */
	"dummy(rec_base)", /* state #55 */
	"dummy(empty_tbl)", /* state #56 */
	"element(rec_base, nil)", /* state #57 */
	"element(empty_tbl, nil)", /* state #58 */
	"element(empty_tbl, fcns(content(empty_frag, empty_tbl), nil))", /* state #59 */
	"element(rec_base, fcns(content(empty_frag, empty_tbl), nil))", /* state #60 */
	"empty_frag", /* state #61 */
	"empty_tbl", /* state #62 */
	"eqjoin(lit_tbl, lit_tbl)", /* state #63 */
	"eqjoin(rec_base, rec_base)", /* state #64 */
	"eqjoin(rec_base, empty_tbl)", /* state #65 */
	"eqjoin(empty_tbl, empty_tbl)", /* state #66 */
	"error(nil, rec_base)", /* state #67 */
	"error(nil, empty_tbl)", /* state #68 */
	"error(error(nil, empty_tbl), rec_base)", /* state #69 */
	"error(error(nil, empty_tbl), empty_tbl)", /* state #70 */
	"fcns(nil, nil)", /* state #71 */
	"fcns(content(empty_frag, empty_tbl), nil)", /* state #72 */
	"fcns(attribute(empty_tbl), nil)", /* state #73 */
	"fcns(content(empty_frag, empty_tbl), fcns(nil, nil))", /* state #74 */
	"frag_extract(empty_tbl)", /* state #75 */
	"frag_union(empty_frag, empty_frag)", /* state #76 */
	"fragment(merge_adjacent(empty_frag, empty_tbl))", /* state #77 */
	"fragment(doc_tbl(empty_tbl))", /* state #78 */
	"fragment(twig(nil))", /* state #79 */
	"fun_1to1(empty_tbl)", /* state #80 */
	"fun_1to1(rec_base)", /* state #81 */
	"fun_call(empty_tbl, nil)", /* state #82 */
	"fun_call(rec_base, nil)", /* state #83 */
	"fun_frag_param(empty_frag, nil)", /* state #84 */
	"fun_param(empty_tbl, nil)", /* state #85 */
	"guide_step(empty_frag, empty_tbl)", /* state #86 */
	"guide_step(empty_frag, rec_base)", /* state #87 */
	"guide_step_join(empty_frag, rec_base)", /* state #88 */
	"guide_step_join(empty_frag, empty_tbl)", /* state #89 */
	"intersect(rec_base, rec_base)", /* state #90 */
	"intersect(empty_tbl, empty_tbl)", /* state #91 */
	"intersect(rec_base, empty_tbl)", /* state #92 */
	"lit_tbl", /* state #93 */
	"merge_adjacent(empty_frag, empty_tbl)", /* state #94 */
	"merge_adjacent(empty_frag, rec_base)", /* state #95 */
	"nil", /* state #96 */
	"num_eq(empty_tbl)", /* state #97 */
	"num_eq(rec_base)", /* state #98 */
	"num_gt(empty_tbl)", /* state #99 */
	"num_gt(rec_base)", /* state #100 */
	"pos_select(empty_tbl)", /* state #101 */
	"pos_select(rec_base)", /* state #102 */
	"processi(empty_tbl)", /* state #103 */
	"processi(rec_base)", /* state #104 */
	"project(rowid(project(rowid(rec_base))))", /* state #105 */
	"project(rec_base)", /* state #106 */
	"project(project(project(lit_tbl)))", /* state #107 */
	"project(cast(project(cast(rec_base))))", /* state #108 */
	"project(rowid(rowid(rec_base)))", /* state #109 */
	"project(empty_tbl)", /* state #110 */
	"project(lit_tbl)", /* state #111 */
	"project(rowid(empty_tbl))", /* state #112 */
	"project(cast(empty_tbl))", /* state #113 */
	"project(cast(lit_tbl))", /* state #114 */
	"project(project(lit_tbl))", /* state #115 */
	"project(attach(rec_base))", /* state #116 */
	"project(project(rec_base))", /* state #117 */
	"project(rowid(rec_base))", /* state #118 */
	"project(cast(rec_base))", /* state #119 */
	"rank(rec_base)", /* state #120 */
	"rank(empty_tbl)", /* state #121 */
	"rec_arg(empty_tbl, empty_tbl)", /* state #122 */
	"rec_base", /* state #123 */
	"rec_fix(side_effects(error(nil, empty_tbl), nil), empty_tbl)", /* state #124 */
	"rec_fix(side_effects(nil, nil), empty_tbl)", /* state #125 */
	"rec_param(rec_arg(empty_tbl, empty_tbl), nil)", /* state #126 */
	"ref_tbl", /* state #127 */
	"roots_(twig(docnode(empty_tbl, nil)))", /* state #128 */
	"roots_(merge_adjacent(empty_frag, rec_base))", /* state #129 */
	"roots_(twig(textnode(empty_tbl)))", /* state #130 */
	"roots_(twig(nil))", /* state #131 */
	"roots_(doc_tbl(empty_tbl))", /* state #132 */
	"roots_(twig(attribute(empty_tbl)))", /* state #133 */
	"roots_(twig(element(empty_tbl, nil)))", /* state #134 */
	"roots_(merge_adjacent(empty_frag, empty_tbl))", /* state #135 */
	"roots_(doc_tbl(rec_base))", /* state #136 */
	"roots_(twig(content(empty_frag, empty_tbl)))", /* state #137 */
	"roots_(twig(attribute(rec_base)))", /* state #138 */
	"roots_(twig(processi(empty_tbl)))", /* state #139 */
	"roots_(twig(comment(empty_tbl)))", /* state #140 */
	"rowid(rowid(rec_base))", /* state #141 */
	"rowid(empty_tbl)", /* state #142 */
	"rowid(project(rowid(rec_base)))", /* state #143 */
	"rowid(project(rowid(rowid(rec_base))))", /* state #144 */
	"rowid(rec_base)", /* state #145 */
	"rownum(lit_tbl)", /* state #146 */
	"rownum(empty_tbl)", /* state #147 */
	"rownum(rec_base)", /* state #148 */
	"rowrank(rec_base)", /* state #149 */
	"rowrank(empty_tbl)", /* state #150 */
	"select_(empty_tbl)", /* state #151 */
	"select_(rec_base)", /* state #152 */
	"semijoin(rec_base, empty_tbl)", /* state #153 */
	"semijoin(rec_base, rec_base)", /* state #154 */
	"semijoin(distinct(rec_base), rec_base)", /* state #155 */
	"semijoin(empty_tbl, empty_tbl)", /* state #156 */
	"serialize_rel(error(nil, empty_tbl), empty_tbl)", /* state #157 */
	"serialize_rel(nil, empty_tbl)", /* state #158 */
	"serialize_seq(side_effects(error(nil, empty_tbl), empty_frag), empty_tbl)", /* state #159 */
	"serialize_seq(side_effects(nil, empty_frag), empty_tbl)", /* state #160 */
	"side_effects(nil, empty_frag)", /* state #161 */
	"side_effects(error(error(nil, empty_tbl), empty_tbl), nil)", /* state #162 */
	"side_effects(error(nil, empty_tbl), empty_frag)", /* state #163 */
	"side_effects(error(nil, empty_tbl), nil)", /* state #164 */
	"side_effects(error(error(nil, empty_tbl), empty_tbl), empty_frag)", /* state #165 */
	"side_effects(nil, nil)", /* state #166 */
	"step(empty_frag, step(empty_frag, rec_base))", /* state #167 */
	"step(empty_frag, rec_base)", /* state #168 */
	"step(empty_frag, empty_tbl)", /* state #169 */
	"step(empty_frag, distinct(rec_base))", /* state #170 */
	"step_join(empty_frag, empty_tbl)", /* state #171 */
	"step_join(empty_frag, rec_base)", /* state #172 */
	"string_join(empty_tbl, empty_tbl)", /* state #173 */
	"string_join(rec_base, empty_tbl)", /* state #174 */
	"textnode(rec_base)", /* state #175 */
	"textnode(empty_tbl)", /* state #176 */
	"thetajoin(rec_base, empty_tbl)", /* state #177 */
	"thetajoin(rec_base, rec_base)", /* state #178 */
	"thetajoin(empty_tbl, empty_tbl)", /* state #179 */
	"to(empty_tbl)", /* state #180 */
	"to(rec_base)", /* state #181 */
	"trace(nil, trace_items(empty_tbl, trace_msg(empty_tbl, nil)))", /* state #182 */
	"trace(error(nil, empty_tbl), trace_items(empty_tbl, trace_msg(empty_tbl, nil)))", /* state #183 */
	"trace_items(empty_tbl, trace_msg(empty_tbl, nil))", /* state #184 */
	"trace_map(empty_tbl, nil)", /* state #185 */
	"trace_msg(empty_tbl, nil)", /* state #186 */
	"twig(attribute(empty_tbl))", /* state #187 */
	"twig(nil)", /* state #188 */
	"twig(textnode(empty_tbl))", /* state #189 */
	"twig(comment(empty_tbl))", /* state #190 */
	"twig(attribute(rec_base))", /* state #191 */
	"twig(processi(empty_tbl))", /* state #192 */
	"twig(content(empty_frag, empty_tbl))", /* state #193 */
	"twig(element(empty_tbl, nil))", /* state #194 */
	"twig(docnode(empty_tbl, fcns(content(empty_frag, empty_tbl), nil)))", /* state #195 */
	"twig(element(empty_tbl, fcns(content(empty_frag, empty_tbl), nil)))", /* state #196 */
	"twig(docnode(empty_tbl, nil))", /* state #197 */
	"type(empty_tbl)", /* state #198 */
	"type(rec_base)", /* state #199 */
	"type_assert(empty_tbl)", /* state #200 */
	"type_assert(rec_base)", /* state #201 */
};
char *PFopt_general_ntname[] = {
	"Error: Nonterminals are > 0",
	"Query",
	"Rel",
	"ScjRel",
	"Twig",
	"Fcns",
	"Side",
	"Trc",
	"Msg",
	"Map",
	"Rec",
	"Arg",
	"Param",
	"Frag",
	"EmptyRel",
	0
};

short PFopt_general_closure[15][15] = {
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,   62,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,  112,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,},
};
#line 355 "opt_general.brg"


#include "algebra_mnemonic.h"

#define MAX_KIDS 10

#define SEEN(p) ((p)->bit_dag)

/* mark all nodes in the pattern of node p as seen
   if it is not contained in kids. */
static void mark_pattern_SEEN (PFla_op_t *p,  PFla_op_t **kids);

/* Check consistency of the state label in the pattern rooted in p */
static bool changed_label (PFla_op_t *p,  PFla_op_t **kids);

/* Relabel node p if it is not contained in kids. */
static void relabel (PFla_op_t *p,  PFla_op_t **kids);

static void
label (PFla_op_t *p);
/**
 * Reducer function. This is the heart of this source file. It
 * contains all the action code for the above burg patterns.
 */
static bool
reduce (PFla_op_t *p, int goalnt)
{
    int              rule;       /* rule number that matches for this node */
    short           *nts;        /* target non-terminals for the leaf nodes of
                                    the current rule */
    PFla_op_t       *kids[MAX_KIDS];   /* leaf nodes of this rule */
    bool             rewritten = false;

    short            old_state_label;
    unsigned short   i;

    /* guard against too dep recursion */
    PFrecursion_fence();

    do {
        assert (STATE_LABEL (p));

        /* determine rule that matches for this non-terminal */
        rule = PFopt_general_rule (STATE_LABEL (p), goalnt);

        assert (rule);

        /* initialize the kids[] vector */
        for (unsigned short i = 0; i < MAX_KIDS; i++)
            kids[i] = NULL;

        /*
         * prepare recursive traversal: get information on leaf nodes of
         * this rule
         */
        nts = PFopt_general_nts[rule];
        PFopt_general_kids (p, rule, kids);

        /* check consistency of pattern labels */
        rewritten = changed_label (p, kids);

        /*
         * prune already optimized branch of the tree
         * (we try to treat the tree plan as DAG)
         */
        if (!SEEN(p) && !rewritten)
            /* recursively translate all leaf expressions */
            for (i = 0; nts[i]; i++)
                if ((rewritten = reduce (kids[i], nts[i])))
                    break;  /* abort if a subtree was rewritten */

        if (rewritten) {

            /*
             * If a subtree has been rewritten, we have to
             *  - re-label that part of the tree, and
             *  - possibly propagate the `rewritten' information upwards.
             */

            /* remember our old state_label (so we know if it has changed) */
            old_state_label = STATE_LABEL(p);

            /*
             * Re-label current tree pattern.
             * (at most down to the pattern leaves, as they should already be
             * correctly labeled by the above reduce() call)
             */
            relabel (p, kids);

            /* If our own state_label has changed, notify our caller. */
            if (old_state_label != STATE_LABEL(p)) {
                SEEN(p)= false;
                return true;
            }
        }
    } while (rewritten);

    /* save old_state_label to detect structural changes introduced
       by the following action code */
    old_state_label = STATE_LABEL(p);

    /* mark all nodes in the current pattern as visited
       to avoid tree traversals */
    mark_pattern_SEEN (p, kids);

    /* action code */
    switch (rule) {
        /* Rel:    lit_tbl */
        case 3:
            if (p->sem.lit_tbl.count == 0) {
                *p = *PFla_empty_tbl_ (p->schema);
                SEEN(p) = false;
                label (p);
            }
            break;

        /* Rel:    attach (lit_tbl) */
        case 6:
        {
            unsigned int     i, j,
                             acount  = p->schema.count,
                             tcount  = L(p)->sem.lit_tbl.count;
            PFalg_collist_t *collist = PFalg_collist (acount);
            PFalg_tuple_t   *tuples  = PFmalloc (tcount * sizeof (PFalg_tuple_t));
            PFalg_tuple_t    tuple;
            PFalg_atom_t     value   = p->sem.attach.value;

            /* copy the tuples and attach the value
               of the new column to every tuple */
            for (i = 0; i < tcount; i++) {
                tuple = L(p)->sem.lit_tbl.tuples[i];
                tuples[i].count = acount;
                tuples[i].atoms = PFmalloc (acount * sizeof (PFalg_atom_t));
                for (j = 0; j < acount - 1; j++)
                    tuples[i].atoms[j] = tuple.atoms[j];
                tuples[i].atoms[j] = value;
            }
            /* copy the aligned column names */
            for (j = 0; j < acount - 1; j++)
                cladd (collist) = L(p)->schema.items[j].name;
            cladd (collist) = p->sem.attach.res;

            *p = *PFla_lit_tbl_ (collist, tcount, tuples);
            SEEN(p) = false;
            label (p);
        }   break;

        /* Rel:    cross (lit_tbl, lit_tbl) */
        case 8:

        /* Rel:    cross (Rel, lit_tbl) */
        case 9:
            /* replace cross product with a literal table that contains
               only one row by a number of attach operators (one for each
               tuple). */
            if (R(p)->sem.lit_tbl.count == 1) {
                PFla_op_t *ret = L(p);
                SEEN(ret) = false;
                for (unsigned int i = 0; i < R(p)->schema.count; i++)
                    ret = PFla_attach (ret, R(p)->schema.items[i].name,
                                       R(p)->sem.lit_tbl.tuples[0].atoms[i]);
                *p = *(ret);
                SEEN(p) = false;
                relabel (p, kids);
                break;
            }
            /* continue for rule 8 */
            if (rule != 8)
                break;
        /* Rel:    cross (lit_tbl, lit_tbl) */

        /* Rel:    cross (lit_tbl, Rel) */
        case 10:
            /* replace cross product with a literal table that contains
               only one row by a number of attach operators (one for each
               tuple). */
            if (L(p)->sem.lit_tbl.count == 1) {
                PFla_op_t *ret = R(p);
                SEEN(ret) = false;
                for (unsigned int i = 0; i < L(p)->schema.count; i++)
                    ret = PFla_attach (ret, L(p)->schema.items[i].name,
                                       L(p)->sem.lit_tbl.tuples[0].atoms[i]);
                *p = *(ret);
                SEEN(p) = false;
                relabel (p, kids);
                break;
            }
            break;

        /* Rel:    eqjoin (lit_tbl, lit_tbl) */
        case 12:
            if (PFprop_type_of (p, p->sem.eqjoin.col1) == aat_nat &&
                L(p)->sem.lit_tbl.count == R(p)->sem.lit_tbl.count) {
                unsigned int     i, j,
                                 count   = p->schema.count,
                                 lcount  = L(p)->schema.count,
                                 rcount  = R(p)->schema.count,
                                 tcount  = L(p)->sem.lit_tbl.count,
                                 lidx,
                                 ridx;
                PFalg_collist_t *collist = PFalg_collist (count);
                PFalg_tuple_t   *tuples  = PFmalloc (tcount * sizeof (PFalg_tuple_t));
                PFalg_tuple_t    ltuple,
                                 rtuple;

                /* lookup the column index where the join columns reside */
                lidx = lcount+1;
                ridx = rcount+1;
                for (i = 0; i < lcount; i++)
                    if (L(p)->schema.items[i].name == p->sem.eqjoin.col1) {
                        lidx = i;
                        break;
                    }
                assert (lidx != lcount+1);
                for (i = 0; i < rcount; i++)
                    if (R(p)->schema.items[i].name == p->sem.eqjoin.col2) {
                        ridx = i;
                        break;
                    }
                assert (ridx != rcount+1);

                /* copy the tuples and apply a merge the columns */
                for (i = 0; i < tcount; i++) {
                    ltuple = L(p)->sem.lit_tbl.tuples[i];
                    rtuple = R(p)->sem.lit_tbl.tuples[i];

                    /* check if the value in this line has the correct value */
                    if (ltuple.atoms[lidx].is_null ||
                        rtuple.atoms[ridx].is_null ||
                        ltuple.atoms[lidx].val.nat_ != i+1 ||
                        rtuple.atoms[ridx].val.nat_ != i+1)
                        break;

                    tuples[i].count = count;
                    tuples[i].atoms = PFmalloc (count * sizeof (PFalg_atom_t));

                    for (j = 0; j < lcount; j++)
                        tuples[i].atoms[j] = ltuple.atoms[j];
                    for (j = 0; j < rcount; j++)
                        tuples[i].atoms[j+lcount] = rtuple.atoms[j];
                }
                /* abort if the values were not already dense and sorted */
                if (i < tcount)
                    break;

                /* copy the aligned column names */
                for (j = 0; j < lcount; j++)
                    cladd (collist) = L(p)->schema.items[j].name;
                for (j = 0; j < rcount; j++)
                    cladd (collist) = R(p)->schema.items[j].name;

                *p = *PFla_lit_tbl_ (collist, tcount, tuples);
                SEEN(p) = false;
                label (p);
            }
            break;

        /* Rel:    semijoin (distinct (Rel), Rel) */
        case 14:
            /* push down semijoin operator
               underneath the distinct operator as
               the semijoin hopefully is more selective
               than the distinct operator */
            *p = *PFla_distinct (
                      PFla_semijoin (
                          LL(p), R(p),
                          p->sem.eqjoin.col1,
                          p->sem.eqjoin.col2));
            SEEN(L(p)) = false;
            SEEN(p) = false;
            /* relabeling will be expensive
               if there is no real dummy node */
            relabel (p, kids);
            break;

        /* Rel:    project (Rel) */
        case 16:
        {   /**
             * we can skip every project operator that is not needed.
             * Therefore it has to fulfill two conditions:
             * 1. no column is renamed
             * 2. the number of columns does not change
             * (The first condition also ensures that no
             *  column is referenced twice thus allowing us to
             *  avoid a 1:1 column check.)
             */
            bool renamed = false;

            for (unsigned int i = 0; i < p->schema.count; i++)
                renamed = renamed ||
                          (p->sem.proj.items[i].new !=
                           p->sem.proj.items[i].old);

            if (!renamed && L(p)->schema.count == p->schema.count) {
                *p = *PFla_dummy (L(p));
                SEEN(p) = false;
                /* relabeling will be expensive
                   if there is no real dummy node */
                relabel (p, kids);
                break;
            }
        }   break;

        /* Rel:    project (attach (Rel)) */
        case 17:
            /* only rewrite if there are more than one columns */
            if (p->schema.count > 1) {
                bool found = false, rewrite = true;
                for (unsigned int i = 0; i < p->schema.count; i++)
                    if (p->sem.proj.items[i].old == L(p)->sem.attach.res) {
                        found = true;
                        rewrite = rewrite &&
                                  (p->sem.proj.items[i].old
                                   == p->sem.proj.items[i].new);
                    }

                /* if the projection neither discards nor renames
                   the attach result we can switch both operands  */
                if (found && rewrite) {
                    PFalg_proj_t *proj = PFmalloc ((p->schema.count - 1) *
                                                   sizeof (PFalg_proj_t));
                    unsigned int count = 0;

                    for (unsigned int j = 0; j < p->schema.count; j++)
                        if (L(p)->sem.attach.res
                            != p->sem.proj.items[j].old)
                            proj[count++] = p->sem.proj.items[j];

                    *p = *PFla_attach (PFla_project_ (LL(p), count, proj),
                                       L(p)->sem.attach.res,
                                       L(p)->sem.attach.value);
                    SEEN(L(p)) = false;
                    SEEN(p) = false;
                    relabel (p, kids);
                    break;
                }
            }
            break;

        /* Rel:    project (project (Rel)) */
        case 18:
            /* combine two projections */
            *p = *PFla_project_ (LL(p),
                                 p->schema.count,
                                 PFalg_proj_merge (
                                     p->sem.proj.items,
                                     p->sem.proj.count,
                                     L(p)->sem.proj.items,
                                     L(p)->sem.proj.count));

            SEEN(p) = false;
            relabel (p, kids);
            break;

        /* Rel:    project (lit_tbl) */
        case 19:
        {
            unsigned int     i, j, index,
                             acount  = p->schema.count,
                             tcount  = L(p)->sem.lit_tbl.count;
            PFalg_collist_t *collist = PFalg_collist (acount);
            PFalg_tuple_t   *tuples  = PFmalloc (tcount * sizeof (PFalg_tuple_t)),
                            *ltuples = L(p)->sem.lit_tbl.tuples;

            /* allocate memory for the tuples */
            for (j = 0; j < tcount; j++) {
                tuples[j].count = acount;
                tuples[j].atoms = PFmalloc (acount * sizeof (PFalg_atom_t));
            }

            /* iterate over all columns */
            for (i = 0; i < acount; i++) {
                /* copy the column names */
                cladd (collist) = p->sem.proj.items[i].new;

                /* find the corresponding column index in the table */
                for (j = 0; j < L(p)->schema.count; j++)
                    if (p->sem.proj.items[i].old == L(p)->schema.items[j].name)
                        break;
                assert (j < L(p)->schema.count);
                index = j;

                /* copy all values from the table */
                for (j = 0; j < tcount; j++)
                    tuples[j].atoms[i] = ltuples[j].atoms[index];
            }

            *p = *PFla_lit_tbl_ (collist, tcount, tuples);
            SEEN(p) = false;
            label (p);
        }   break;

        /* Rel:    select_ (Rel) */
        case 20:
        {
            /**
             *  introduce thetajoin based on
             *  one of the following patterns:
             *
             *    sel (res)    sel (res)   sel (res)   sel (res)
             *     |            |           |           |
             *   eq,gt       project      eq,gt      project
             *     |            |           |           |
             *     X          eq,gt      project      eq,gt
             *    / \           |           |           |
               rel1 rel2     project        X           X
             *                  |          / \         / \
             *                  X       rel1 rel2   rel1 rel2
             *                 / \
             *              rel1 rel2
             *
             * The result will be either:
             *
             *     @ (res, true)
             *     |
             *    |X| (eq|gt, rel.col1, rel.col2)
             *    / \
             * rel1 rel2
             *
             * or:
             *
             *     @ (res, true)
             *     |
             *  project
             *     |
             *    |X| (eq|gt, rel.col1, rel.col2)
             *    / \
             * rel1 rel2
             *
             */
            PFla_op_t *node;
            PFla_op_t *left = NULL;
            PFla_op_t *right = NULL;
            PFla_op_t *proj = NULL;
            PFla_op_t *proj2 = NULL;

            PFalg_col_t sel = p->sem.select.col;
            PFalg_col_t item1, item2;
            PFalg_comp_t comp;
            unsigned int i;

            node = L(p);

            if (node->kind == la_project) {
                proj = node;
                /* update the name of the selection */
                for (i = 0; i < node->sem.proj.count; i++)
                    if (sel == node->sem.proj.items[i].new) {
                        sel = node->sem.proj.items[i].old;
                        break;
                    }
                node = L(node);
            }

            /* the selection column has to match the
               result column of the comparison operator */
            if ((node->kind != la_num_eq && node->kind != la_num_gt) ||
                node->sem.binary.res != sel)
                break;

            if (node->kind == la_num_eq)
                comp = alg_comp_eq;
            else
                comp = alg_comp_gt;
            item1 = node->sem.binary.col1;
            item2 = node->sem.binary.col2;
            node = L(node);

            if (node->kind == la_project) {
                proj2 = node;
                /* update the names of the comparison input */
                for (i = 0; i < node->sem.proj.count; i++) {
                    if (item1 == node->sem.proj.items[i].new)
                        item1 = node->sem.proj.items[i].old;
                    if (item2 == node->sem.proj.items[i].new)
                        item2 = node->sem.proj.items[i].old;
                }
                node = L(node);
            }

            /* match the pattern */
            if (node->kind != la_cross)
                break;

            /* lookup the corresponding subtrees for the
               comparison inputs */
            for (i = 0; i < L(node)->schema.count; i++)
                if (L(node)->schema.items[i].name == item1)
                    left = L(node);
                else if (L(node)->schema.items[i].name == item2)
                    right = L(node);

            for (i = 0; i < R(node)->schema.count; i++)
                if (R(node)->schema.items[i].name == item1)
                    left = R(node);
                else if (R(node)->schema.items[i].name == item2)
                    right = R(node);

            /* the two comparison inputs are from the same relation
               -- multi-value dependency analysis will thus move the
               cross product up */
            if (!left || !right || left == right)
                break;

            /* Now all constraints are checked and the pattern
               can be replaced by an theta-join and an attach operator
               that adds the missing res column */
            if (!proj && !proj2) {
                PFalg_sel_t *pred = PFmalloc (sizeof (PFalg_sel_t));
                pred[0] = PFalg_sel (comp, item1, item2);
                *p = *PFla_attach (
                          PFla_thetajoin (left, right, 1, pred),
                          p->sem.select.col, PFalg_lit_bln (true));
                SEEN(p) = false;
                SEEN(L(p)) = false;
                /* relabel does not know that left and right are already
                   labeled correctly and thus would relabel the *complete*
                   subTREE! To avoid this make sure that kids contains the
                   references to left and right */
                kids[0] = left;
                kids[1] = right;
                relabel (p, kids);
                break;
            } else {
                PFla_op_t *res;
                PFalg_sel_t *pred = PFmalloc (sizeof (PFalg_sel_t));
                pred[0] = PFalg_sel (comp, item1, item2);

                res = PFla_thetajoin (left, right, 1, pred);
                if (proj2)
                    res = PFla_project_ (res,
                                         proj2->sem.proj.count,
                                         proj2->sem.proj.items);

                res = PFla_attach (res, sel, PFalg_lit_bln (true));

                if (proj)
                    res = PFla_project_ (res,
                                         proj->sem.proj.count,
                                         proj->sem.proj.items);

                *p = *res;

                SEEN(p) = false;
                SEEN(L(p)) = false;
                SEEN(LL(p)) = false;
                /* relabel does not know that left and right are already
                   labeled correctly and thus would relabel the *complete*
                   subTREE! To avoid this make sure that kids contains the
                   references to left and right */
                kids[0] = left;
                kids[1] = right;
                relabel (p, kids);
                break;
            }
        }   break;

        /* Rel:    disjunion (lit_tbl, lit_tbl) */
        case 25:
        {
            unsigned int     i, j, index,
                             acount  = p->schema.count,
                             lcount  = L(p)->sem.lit_tbl.count,
                             rcount  = R(p)->sem.lit_tbl.count,
                             tcount  = lcount + rcount;
            PFalg_collist_t *collist = PFalg_collist (acount);
            PFalg_tuple_t   *tuples  = PFmalloc (tcount * sizeof (PFalg_tuple_t)),
                            *ltuples = L(p)->sem.lit_tbl.tuples,
                            *rtuples = R(p)->sem.lit_tbl.tuples;

            /* allocate memory for the tuples */
            for (j = 0; j < tcount; j++) {
                tuples[j].count = acount;
                tuples[j].atoms = PFmalloc (acount * sizeof (PFalg_atom_t));
            }

            /* iterate over all columns */
            for (i = 0; i < acount; i++) {
                /* copy the column names */
                cladd (collist) = p->schema.items[i].name;

                /* find the corresponding column index in the left table */
                for (j = 0; j < acount; j++)
                    if (clat (collist, i) == L(p)->schema.items[j].name)
                        break;
                assert (j < acount);
                index = j;

                /* copy all values from the left table */
                for (j = 0; j < lcount; j++)
                    tuples[j].atoms[i] = ltuples[j].atoms[index];

                /* find the corresponding column index in the right table */
                for (j = 0; j < acount; j++)
                    if (clat (collist, i) == R(p)->schema.items[j].name)
                        break;
                assert (j < acount);
                index = j;

                /* copy all values from the right table */
                for (j = 0; j < rcount; j++)
                    tuples[j+lcount].atoms[i] = rtuples[j].atoms[index];
            }

            *p = *PFla_lit_tbl_ (collist, tcount, tuples);
            SEEN(p) = false;
            label (p);
        }   break;

        /* Rel:    disjunion (EmptyRel, Rel) */
        case 26:
            /* return right child */
            *p = *PFla_dummy (R(p));
            SEEN(p) = false;
            /* relabeling will be expensive
               if there is no real dummy node */
            relabel (p, kids);
            break;

        /* Rel:    disjunion (Rel, EmptyRel) */
        case 27:
        /* Rel:    difference (Rel, EmptyRel) */
        case 30:
            /* return left child */
            *p = *PFla_dummy (L(p));
            SEEN(p) = false;
            /* relabeling will be expensive
               if there is no real dummy node */
            relabel (p, kids);
            break;

        /* Rel:    intersect (Rel, Rel) */
        case 28:
            for (unsigned int i = 0; i < p->schema.count; i++)
                if (!p->schema.items[i].type) {
                    *p = *PFla_empty_tbl_ (p->schema);
                    SEEN(p) = false;
                    label (p);
                    break;
                }
            break;

        /* Rel:    difference (Rel, Rel) */
        case 29:
            for (unsigned int i = 0; i < p->schema.count; i++)
                /* return lhs argument in case of
                   a complete column type mismatch */
                if (!(PFprop_type_of (L(p), p->schema.items[i].name) &
                      PFprop_type_of (R(p), p->schema.items[i].name))) {
                    /* return left child */
                    *p = *PFla_dummy (L(p));
                    SEEN(p) = false;
                    /* relabeling will be expensive
                       if there is no real dummy node */
                    relabel (p, kids);
                    break;
                }
            break;

        /* Rel:    distinct (step (Frag, Rel)) */
        case 33:
            /* return left child */
            *p = *PFla_dummy (L(p));
            SEEN(p) = false;
            /* relabeling will be expensive
               if there is no real dummy node */
            relabel (p, kids);
            break;

        /* Rel:    num_eq (Rel) */
        case 36:
            /* merge back operators that were splitted
               due to a join push down */
            if (L(p)->kind == la_num_eq &&
                p->sem.binary.col1 == L(p)->sem.binary.col1 &&
                p->sem.binary.col2 == L(p)->sem.binary.col2) {
                PFalg_proj_t *proj;
                /* replace upper equality operator by a projection */
                proj = PFmalloc (p->schema.count * sizeof (PFalg_proj_t));
                for (unsigned int i = 0; i < p->schema.count; i++)
                    if (p->sem.binary.res == p->schema.items[i].name)
                        proj[i] = PFalg_proj (p->sem.binary.res,
                                              L(p)->sem.binary.res);
                    else
                        proj[i] = PFalg_proj (p->schema.items[i].name,
                                              p->schema.items[i].name);

                *p = *PFla_project_ (L(p), p->schema.count, proj);
                SEEN(p) = false;
                relabel (p, kids);
            }
            break;

        /* Rel:    aggr (Rel) */
        case 45:
        {
            unsigned int  i,
                          count;
            bool          rewrite = false;
            PFalg_proj_t *proj;

            for (i = 0; i < p->sem.aggr.count; i++)
                if (p->sem.aggr.aggr[i].kind != alg_aggr_dist)
                    break;

            /* Turn an aggregate into a simple distinct operator
               if all aggregates are 'distinct' operations. */
            if (p->sem.aggr.part &&
                i == p->sem.aggr.count) {
                PFalg_proj_t *proj;
                proj = PFmalloc (p->schema.count * sizeof (PFalg_proj_t));
                for (i = 0; i < p->sem.aggr.count; i++)
                    proj[i] = PFalg_proj (p->sem.aggr.aggr[i].res,
                                          p->sem.aggr.aggr[i].col);
                proj[i] = PFalg_proj (p->sem.aggr.part, p->sem.aggr.part);

                *p = *PFla_distinct (
                          PFla_project_ (L(p), p->schema.count, proj));
                SEEN(p) = false;
                relabel (p, kids);
                break;
            }

            /* Get rid of superfluos aggregates that operate on the grouping
               column. Add the missing columns by a projection on top of the
               aggregate. */
            proj  = PFmalloc (p->schema.count * sizeof (PFalg_proj_t));
            count = 0;
            i     = 0;
            
            /* get rid of superfluous aggregates */
            while (i < p->sem.aggr.count) {
                if ((p->sem.aggr.aggr[i].kind == alg_aggr_dist ||
                     p->sem.aggr.aggr[i].kind == alg_aggr_min ||
                     p->sem.aggr.aggr[i].kind == alg_aggr_max) &&
                    p->sem.aggr.aggr[i].col == p->sem.aggr.part) {
                    proj[count++] = PFalg_proj (p->sem.aggr.aggr[i].res,
                                                p->sem.aggr.part);
                    p->sem.aggr.count--;
                    p->sem.aggr.aggr[i] = p->sem.aggr.aggr[p->sem.aggr.count];
                    rewrite = true;
                }
                else {
                    proj[count++] = PFalg_proj (p->sem.aggr.aggr[i].res,
                                                p->sem.aggr.aggr[i].res);
                    i++;
                }
            }
            /* complete projection list by adding grouping column */
            proj[count++] = PFalg_proj (p->sem.aggr.part, p->sem.aggr.part);

            if (rewrite) {
                *p = *PFla_project_ (
                          p->sem.aggr.count
                          ? PFla_aggr (
                                L(p),
                                p->sem.aggr.part,
                                p->sem.aggr.count,
                                p->sem.aggr.aggr)
                          /* skip aggregate if only the grouping
                             column is needed */
                          : PFla_distinct (
                                PFla_project (
                                    L(p), 
                                    PFalg_proj (p->sem.aggr.part,
                                                p->sem.aggr.part))),
                          count,
                          proj);
                SEEN(p) = false;
                relabel (p, kids);
            }

        }   break;

        /* Rel:    rownum (Rel) */
        case 47:
        {
            /**
             * row#_a<b>/   Throw away a key-generating rownum operator
             *   |          that numbers its output based on a single
             *  pi*         order criterion stemming from a key-generating
             *   |          rownum operator below the superfluous rownum.
             * row#_b<...>/
             */
            PFalg_col_t   col;
            PFla_op_t    *op;
            PFalg_proj_t *proj;

            /* check for key-generation, single order criterion, and
               ascending order */
            if (p->sem.sort.part ||
                PFord_count (p->sem.sort.sortby) != 1 ||
                PFord_order_dir_at (p->sem.sort.sortby, 0) != DIR_ASC)
                break;

            op = L(p);
            col = PFord_order_col_at (p->sem.sort.sortby, 0);

            /* ignore intermediate project operators */
            while (op->kind == la_project) {
                for (unsigned int i = 0; i < op->schema.count; i++)
                    if (op->sem.proj.items[i].new == col) {
                        col = op->sem.proj.items[i].old;
                        op = L(op);
                        break;
                    }
            }

            /* check for rownum operator that generates key values
               and provides the sort criterion for the upper rownum */
            if (op->kind != la_rownum ||
                op->sem.sort.part ||
                col != op->sem.sort.res)
                break;

            /* replace rownum operator by a projection */
            proj = PFmalloc (p->schema.count * sizeof (PFalg_proj_t));
            for (unsigned int i = 0; i < p->schema.count; i++)
                if (p->sem.sort.res == p->schema.items[i].name)
                    proj[i] = PFalg_proj (p->sem.sort.res,
                                          PFord_order_col_at (
                                              p->sem.sort.sortby,
                                              0));
                else
                    proj[i] = PFalg_proj (p->schema.items[i].name,
                                          p->schema.items[i].name);

            *p = *PFla_project_ (L(p), p->schema.count, proj);
            SEEN(p) = false;
            relabel (p, kids);
        }   break;

        /* Rel:    rownum (lit_tbl) */
        case 48:
            /* for a rownum operator with a single order column of type
               nat we check whether the order column is already identical
               to the result (under the assumption that the table is
               ordered). */
            if (!p->sem.sort.part &&
                L(p)->sem.lit_tbl.count &&
                PFord_count (p->sem.sort.sortby) == 1 &&
                PFord_order_dir_at (p->sem.sort.sortby, 0) == DIR_ASC &&
                PFprop_type_of (p, PFord_order_col_at (p->sem.sort.sortby, 0))
                    == aat_nat) {
                PFalg_col_t      sort_col;
                unsigned int     i,
                                 tcount  = L(p)->sem.lit_tbl.count,
                                 idx;
                PFalg_proj_t *proj = PFmalloc (
                                         p->schema.count
                                         * sizeof (PFalg_proj_t));

                /* lookup the column index where the sort column resides */
                sort_col = PFord_order_col_at (p->sem.sort.sortby, 0);
                idx = p->schema.count;
                for (i = 0; i < L(p)->schema.count; i++)
                    if (L(p)->schema.items[i].name == sort_col) {
                        idx = i;
                        break;
                    }
                assert (idx != p->schema.count);

                /* check for the correct values in the order column */
                for (i = 0; i < tcount; i++)
                    /* check if the value in this line has the correct value */
                    if (L(p)->sem.lit_tbl.tuples[i].atoms[idx].is_null ||
                        L(p)->sem.lit_tbl.tuples[i].atoms[idx].val.nat_ != i+1)
                        break;
                /* abort if the values were not already sorted */
                if (i < tcount)
                    break;

                /* copy projection list */
                for (unsigned int i = 0; i < p->schema.count; i++)
                    if (p->sem.sort.res == p->schema.items[i].name)
                        proj[i] = PFalg_proj (p->sem.sort.res,
                                              sort_col);
                    else
                        proj[i] = PFalg_proj (p->schema.items[i].name,
                                              p->schema.items[i].name);

                *p = *PFla_project_ (L(p), p->schema.count, proj);
                SEEN(p) = false;
                relabel (p, kids);
            }
            break;

        /* Rel:    rowrank (Rel) */
        case 49:
        /* Rel:    rank (Rel) */
        case 50:
            if (L(p)->kind == la_rank || L(p)->kind == la_rowrank) {
                PFalg_proj_t    *proj;
                PFord_ordering_t upper = p->sem.sort.sortby,
                                 lower = L(p)->sem.sort.sortby;
                unsigned int     i;

                /* check for identical orderings */                
                if (PFord_count (upper) != PFord_count (lower))
                    break;

                for (i = 0; i < PFord_count (upper); i++)
                    if (PFord_order_col_at (upper, i) !=
                        PFord_order_col_at (lower, i) ||
                        PFord_order_dir_at (upper, i) !=
                        PFord_order_dir_at (lower, i))
                        break;
                if (i < PFord_count (upper))
                    break;

                /* we found an identical ordering
                   and can combine both operators */
                proj = PFmalloc (p->schema.count * sizeof (PFalg_proj_t));
                for (i = 0; i < L(p)->schema.count; i++)
                    proj[i] = PFalg_proj (L(p)->schema.items[i].name,
                                          L(p)->schema.items[i].name);
                proj[L(p)->schema.count] = PFalg_proj (p->sem.sort.res,
                                                       L(p)->sem.sort.res);

                *p = *PFla_project_ (
                          PFla_rowrank (LL(p), L(p)->sem.sort.res, lower),
                          p->schema.count, proj);
                /* if both inputs are rank operators they will eventually
                   become rank operators again */

                SEEN(p) = false;
                /* relabel does not know that the left and the right children
                   are already labeled correctly and thus would relabel
                   the *complete* subTREE! To avoid this make sure that kids
                   contains the correct references */
                kids[0] = LL(p);
                relabel (p, kids);
            }
            break;

        /* Rel:    rowid (rowid (Rel)) */
        case 52:
        {
            PFalg_proj_t *proj = PFmalloc (
                                     p->schema.count
                                     * sizeof (PFalg_proj_t));
            /* copy property list */
            for (unsigned int i = 0; i < p->schema.count; i++)
                if (p->sem.rowid.res == p->schema.items[i].name)
                    proj[i] = PFalg_proj (p->sem.rowid.res,
                                          L(p)->sem.rowid.res);
                else
                    proj[i] = PFalg_proj (p->schema.items[i].name,
                                          p->schema.items[i].name);

            *p = *PFla_project_ (L(p), p->schema.count, proj);
            SEEN(p) = false;
            relabel (p, kids);
        }   break;

        /* Rel:    rowid (project (rowid (Rel))) */
        case 53:
        {
            unsigned int count = L(p)->sem.proj.count;
            PFalg_proj_t *proj = PFmalloc (
                                     (count + 1)
                                     * sizeof (PFalg_proj_t));
            /* copy property list */
            for (unsigned int i = 0; i < count; i++)
                proj[i] = L(p)->sem.proj.items[i];

            proj[count] = PFalg_proj (p->sem.rowid.res,
                                      LL(p)->sem.rowid.res);

            *p = *PFla_project_ (LL(p), count + 1, proj);
            SEEN(p) = false;
            relabel (p, kids);
        }   break;

        /* Rel:    type_assert (Rel) */
        case 55:
            /* if we statically know that the type assertion would yield
               an empty type we can replace it by an empty table */
            if (!(PFprop_type_of (L(p), p->sem.type.col) & p->sem.type.ty)) {
                *p = *PFla_empty_tbl_ (p->schema);
                SEEN(p) = false;
                label (p);
                break;
            }
            /* throw out type_assert if it is not needed anymore */
            for (unsigned int i = 0; i < L(p)->schema.count; i++)
                if (p->sem.type.col == L(p)->schema.items[i].name) {
                    if (p->sem.type.ty == L(p)->schema.items[i].type) {
                        *p = *PFla_dummy (L(p));
                        SEEN(p) = false;
                        /* relabeling will be expensive
                           if there is no real dummy node */
                        relabel (p, kids);
                    }
                    break;
                }
            break;

        /* Rel:    cast (cast (Rel)) */
        case 56:
        /* Rel:    cast (project (cast (Rel))) */
        case 57:
            /* Discard the casts if the cast maps from string
               to untypedAtomic and back to string. */
        {
            PFla_op_t *cast;
            bool proj = false, found = false;
            unsigned int i;
            PFalg_col_t col = p->sem.type.col;

            /* check for a projection in between and update
               the name of the outer cast input */
            if (L(p)->kind == la_project) {
                proj = true;
                for (i = 0; i < L(p)->sem.proj.count; i++)
                    if (col == L(p)->sem.proj.items[i].new) {
                        col = L(p)->sem.proj.items[i].old;
                        break;
                    }
                cast = LL(p);
            }
            else
                cast = L(p);

            /* make sure the input of the first cast
               is of type string */
            for (i = 0; i < cast->schema.count; i++)
                if (cast->schema.items[i].name == cast->sem.type.col &&
                    cast->schema.items[i].type == aat_str) {
                    found = true;
                    break;
                }

            /* enforce the constraints: child node is a cast,
               the output of the nested cast and the input of
               the outer cast match, the inner cast applies a
               cast to untypedAtomic, and the outer to string */
            if (found &&
                col == cast->sem.type.res &&
                cast->sem.type.ty == aat_uA &&
                p->sem.type.ty == aat_str) {

                PFalg_proj_t *proj_list;
                /* create projection list */
                proj_list = PFmalloc (p->schema.count *
                                      sizeof (*(proj_list)));

                if (proj) {
                    /* if there was already a projection keep that
                       one and extend it with the result column of the
                       outer cast that refers to the orginal input column */
                    for (i = 0; i < L(p)->sem.proj.count; i++)
                        proj_list[i] = L(p)->sem.proj.items[i];

                    proj_list[i] = PFalg_proj (p->sem.type.res,
                                               cast->sem.type.col);
                }
                else
                    /* keep all column and link the result column of the
                       outer cast to the input column of the nested cast */
                    for (i = 0; i < p->schema.count; i++)
                        if (p->schema.items[i].name == p->sem.type.res)
                            proj_list[i] = PFalg_proj (p->sem.type.res,
                                                       cast->sem.type.col);
                        else
                            proj_list[i] = PFalg_proj (p->schema.items[i].name,
                                                       p->schema.items[i].name);

                /* Replace the outer cast (and the project) by a new project
                   that avoids the unnecessary casts. (The second cast will
                   be removed by an icols optimization phase.) */
                *p = *PFla_project_ (cast, p->schema.count, proj_list);
                SEEN(p) = false;
                relabel (p, kids);
                break;
            }
        } /* fall trough otherwise */

        /* Rel:    cast (lit_tbl) */
        case 58:
            /* apply the cast in the literal table */
            if (L(p)->kind == la_lit_tbl &&
                p->sem.type.ty == aat_int &&
                PFprop_type_of (p, p->sem.type.col) == aat_nat) {
                unsigned int     i, j,
                                 count  = p->schema.count,
                                 tcount  = L(p)->sem.lit_tbl.count,
                                 idx;
                PFalg_collist_t *collist = PFalg_collist (count);
                PFalg_tuple_t   *tuples  = PFmalloc (tcount * sizeof (PFalg_tuple_t));
                PFalg_tuple_t    tuple;

                idx = p->schema.count;
                for (i = 0; i < L(p)->schema.count; i++)
                    if (L(p)->schema.items[i].name == p->sem.type.col) {
                        idx = i;
                        break;
                    }
                assert (idx != p->schema.count);

                /* copy the tuples and cast the value
                   of the input column in every tuple */
                for (i = 0; i < tcount; i++) {
                    tuple = L(p)->sem.lit_tbl.tuples[i];
                    tuples[i].count = count;
                    tuples[i].atoms = PFmalloc (count * sizeof (PFalg_atom_t));
                    for (j = 0; j < count - 1; j++)
                        tuples[i].atoms[j] = tuple.atoms[j];
                    /* cast the value to integer */
                    tuples[i].atoms[j]
                        = PFalg_lit_int (tuple.atoms[idx].val.nat_);
                }
                /* copy the aligned column names */
                for (j = 0; j < count - 1; j++)
                    cladd (collist) = L(p)->schema.items[j].name;
                cladd (collist) = p->sem.type.res;

                *p = *PFla_lit_tbl_ (collist, tcount, tuples);
                SEEN(p) = false;
                label (p);
            }
            /* fall trough otherwise */

        /* Rel:    cast (Rel) */
        case 59:
        {
            /*
             * If an algebra expression already has the requested
             * type, replace it by a projection.
             */
            bool cast_req = true;
            for (unsigned int i = 0; i < p->schema.count; i++)
                if (p->sem.type.col == p->schema.items[i].name &&
                    p->sem.type.ty == p->schema.items[i].type) {
                    cast_req = false;
                    break;
                }

            if (!cast_req) {
                PFalg_proj_t *proj = PFmalloc (p->schema.count
                                               * sizeof (PFalg_proj_t));

                for (unsigned int j = 0; j < p->schema.count; j++)
                    if (p->schema.items[j].name != p->sem.type.res) {
                        proj[j] = PFalg_proj (p->schema.items[j].name,
                                              p->schema.items[j].name);
                    } else {
                        proj[j] = PFalg_proj (p->sem.type.res,
                                              p->sem.type.col);
                    }

                *p = *PFla_project_ (L(p), p->schema.count, proj);
                SEEN(p) = false;
                relabel (p, kids);
                break;
            }
        }   break;

        /* ScjRel: step (Frag, ScjRel) */
        case 64:
            /* combine steps if they are of the form:
               ``/descandent-or-self::node()/child::element()'' */
            if (R(p)->sem.step.spec.axis == alg_desc_s &&
                R(p)->sem.step.spec.kind == node_kind_node &&
                p->sem.step.spec.axis == alg_chld) {
                PFalg_step_spec_t spec = p->sem.step.spec;
                spec.axis = alg_desc,
                /* rewrite child into descendant
                   and discard descendant-or-self step */
                *p = *PFla_step_simple (
                          L(p), RR(p), spec,
                          p->sem.step.iter, R(p)->sem.step.item,
                          p->sem.step.item_res);
                SEEN(p) = false;
                /* relabel does not know that the left and the right children
                   are already labeled correctly and thus would relabel
                   the *complete* subTREE! To avoid this make sure that kids
                   contains the correct references */
                kids[0] = L(p);
                kids[1] = R(p);
                relabel (p, kids);
                break;
            }
            break;

        /* ScjRel: step (Frag, distinct (Rel)) */
        case 65:
            R(p) = L(R(p));
            SEEN(p) = false;
            relabel (p, kids);
            break;

        /* Twig:   docnode (Rel,
                            fcns (content (Frag, EmptyRel),
                                  nil)) */
        case 78:
        /* Twig:   element (Rel,
                            fcns (content (Frag, EmptyRel),
                                  nil)) */
        case 80:
            RL(p) = PFla_nil();
            SEEN(p) = false;
            relabel (p, kids);
            break;

        /* Fcns:   fcns (content (Frag, EmptyRel), Fcns) */
        case 88:
        /* Fcns:   fcns (nil, nil) */
        case 89:
            /* This rewrite splits up the R(p) operator... */
            *p = *R(p);
            /* ... and we at least have to create a new property to avoid
               inconsistencies (see also definition for PFla_dummy()). */
            p->prop = PFprop ();

            SEEN(p) = false;
            /* relabel won't work because we have a copy of R(p) now */
            label (p);
            break;

        /* Rel:    EmptyRel */
        case 112:
        {
            /*
             * Replace any sub-tree that we determined empty with these
             * rules by the literal empty table.
             */
            *p = *PFla_empty_tbl_ (p->schema);
            SEEN(p) = true;
            label (p);
        } break;

        /* Query:  serialize_seq (
                       side_effects (error (Side, EmptyRel), Frag),
                       Rel) */
        case 193:
        /* Rel:    rec_fix (side_effects (error (Side, EmptyRel), Rec), Rel) */
        case 197:
            LL(p) = LLL(p);
            SEEN(p) = false;
            relabel (p, kids);
            break;

        /* Query:  serialize_rel (error (Side, EmptyRel), Rel) */
        case 194:
        /* Side:   error (error (Side, EmptyRel), Rel) */
        case 195:
        /* Side:   trace (error (Side, EmptyRel), Trc) */
        case 196:
            L(p) = LL(p);
            SEEN(p) = false;
            relabel (p, kids);
            break;
        case 199:
	    /* INCOMPLETE, GENERATE A CONSTANT '1' HERE */
	    /* fall through */

        default:
            /* every occurrence of EmptyRel already copes with
               the empty relation - we therefore need no special
               translation and use the default branch (the rules
               are pruned anyway) */
            break;
    }

    /* if we introduced a structural change the state labels
       will differ (before != after). Therefore the caller will
       start matching once more */
    return old_state_label != STATE_LABEL(p);
}

/* mark all nodes in the pattern of node p as seen
   if it is not contained in kids. */
static void
mark_pattern_SEEN (PFla_op_t *p,  PFla_op_t **kids)
{
    unsigned int i;

    for (i = 0; i < MAX_KIDS; i++) {
        if (kids[i] && p == kids[i])
            return;
    }

    for (i = 0; i < PFLA_OP_MAXCHILD; i++)
        if (p->child[i])
            mark_pattern_SEEN (p->child[i], kids);

    SEEN (p) = true;
}

/**
 * Check label of pattern rooted in p.
 * (Every change in the state labels is reported)
 */
static bool
changed_label (PFla_op_t *p,  PFla_op_t **kids)
{
    unsigned int i;
    bool res = false;

    for (i = 0; i < MAX_KIDS; i++)
        if (kids[i] && p == kids[i])
            return false;

    for (i = 0; i < PFLA_OP_MAXCHILD; i++)
        if (p->child[i])
            res = res ||
                  CHILD_STATE_LABEL(p, i) != STATE_LABEL(p->child[i]) ||
                  changed_label (p->child[i], kids);
    return res;
}

/* Relabel node p if it is not contained in kids. */
static unsigned int
relabel_worker (PFla_op_t *p,  PFla_op_t **kids, unsigned int counter)
{
    unsigned int i;

    for (i = 0; i < MAX_KIDS; i++) {
        if (kids[i] && p == kids[i] && STATE_LABEL(p))
            return counter;
    }

    /* Relabel p's children. */
    if (!L(p) && !R(p)) {
        STATE_LABEL(p) = PFopt_general_state (OP_LABEL(p), 0, 0);
    }
    else if (L(p) && !R(p)) {
        counter = relabel_worker (L(p), kids, counter);
        STATE_LABEL(p) = PFopt_general_state (OP_LABEL(p),
                                         STATE_LABEL(L(p)),
                                         0);
        /* update also control reference */
        CHILD_STATE_LABEL(p, 0) = STATE_LABEL(L(p));
    }
    else if (!L(p) && R(p)) {
        counter = relabel_worker (R(p), kids, counter);
        STATE_LABEL(p) = PFopt_general_state (OP_LABEL(p),
                                         STATE_LABEL(R(p)),
                                         0);
        /* update also control reference */
        CHILD_STATE_LABEL(p, 1) = STATE_LABEL(R(p));
    }
    else {
        counter = relabel_worker (L(p), kids, counter);
        counter = relabel_worker (R(p), kids, counter);
        STATE_LABEL(p) = PFopt_general_state (OP_LABEL(p),
                                         STATE_LABEL(L(p)),
                                         STATE_LABEL(R(p)));
        /* update also control reference */
        CHILD_STATE_LABEL(p, 0) = STATE_LABEL(L(p));
        CHILD_STATE_LABEL(p, 1) = STATE_LABEL(R(p));
    }

    assert (STATE_LABEL (p));
    assert (0 <= STATE_LABEL (p) && STATE_LABEL (p) <= PFopt_general_Max_state);

    assert (counter <= 50 &&
            "tree relabeling in general optimization phase " &&
            "might escape pattern boundaries");

    return counter + 1;
}

static void
relabel (PFla_op_t *p,  PFla_op_t **kids)
{
    unsigned int counter = 0;

    counter = relabel_worker (p, kids, counter);

    /* relabel might relabel the complete DAG (looking at it as
       a tree) if it does not stop at the kids. Here we assume
       that no rewritten pattern has more than 50 nodes. If this
       warning occurs make sure that every relabel call finds the
       boundaries stored in kids. */
    if (counter > 50)
        PFinfo (OOPS_WARNING,
                "tree relabeling in general optimization phase "
                "might escape pattern boundaries");
}

/* Attach node labels in a DAG walk bottom-up */
static void
label (PFla_op_t *p)
{
    if (!L(p) && !R(p)) {
        STATE_LABEL(p) = PFopt_general_state (OP_LABEL(p), 0, 0);
    }
    else if (L(p) && !R(p)) {
        if (!SEEN(L(p))) label (L(p));
        STATE_LABEL(p) = PFopt_general_state (OP_LABEL(p),
                                         STATE_LABEL(L(p)),
                                         0);
        /* update also control reference */
        CHILD_STATE_LABEL(p, 0) = STATE_LABEL(L(p));
    }
    else if (!L(p) && R(p)) {
        if (!SEEN(R(p))) label (R(p));
        STATE_LABEL(p) = PFopt_general_state (OP_LABEL(p),
                                         STATE_LABEL(R(p)),
                                         0);
        /* update also control reference */
        CHILD_STATE_LABEL(p, 1) = STATE_LABEL(R(p));
    }
    else {
        if (!SEEN(L(p))) label (L(p));
        if (!SEEN(R(p))) label (R(p));
        STATE_LABEL(p) = PFopt_general_state (OP_LABEL(p),
                                         STATE_LABEL(L(p)),
                                         STATE_LABEL(R(p)));
        /* update also control reference */
        CHILD_STATE_LABEL(p, 0) = STATE_LABEL(L(p));
        CHILD_STATE_LABEL(p, 1) = STATE_LABEL(R(p));
    }
    SEEN(p) = true;

    assert (STATE_LABEL (p));
    assert (0 <= STATE_LABEL (p) && STATE_LABEL (p) <= PFopt_general_Max_state);
}

/**
 * Invoke algebra optimization.
 */
PFla_op_t *
PFalgopt_general (PFla_op_t *root)
{
    /* Attach node labels in a DAG walk bottom-up */
    label (root);
    PFla_dag_reset (root);

    /* Optimize algebra tree */
    while (reduce (root, 1));
    PFla_dag_reset (root);

    return root;
}

/* vim:set shiftwidth=4 expandtab filetype=c: */
