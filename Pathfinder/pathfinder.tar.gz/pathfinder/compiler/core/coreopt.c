#line 1 "coreopt.brg"


/**
 * @file
 *
 * Optimize XQuery Core tree (with static type information available).
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *
 * $Id$
 */


#include "pf_config.h"
#include "pathfinder.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

#include "oops.h"
#include "core.h"
#include "qname.h"
#include "mem.h"
#include "subtyping.h"
#include "typecheck.h"

/* Easily access subtree-parts */
#include "child_mnemonic.h"

/*
 * Accessors for the burg matcher
 */
typedef struct PFcnode_t *NODEPTR_TYPE;

/* accessor to the node kind */
#define OP_LABEL(p)    ((p)->kind)

/* accessors to left and right child node */
#define LEFT_CHILD(p)  ((p)->child[0])
#define RIGHT_CHILD(p) ((p)->child[1])

/* the state determined during bottom-up labeling is stored here */
#define STATE_LABEL(p) ((p)->state_label)

/* If something goes wrong, call PFoops */
#define PANIC(...) PFoops (OOPS_BURG, __VA_ARGS__)

/** We hash variable replacement bindings into 8 buckets */
#define HASH_BUCKETS 8
/** hash function for the variable replacement environment */
#define hash(v) ((unsigned int) ((v) - (PFvar_t *) NULL) % HASH_BUCKETS)

/** a binding in the variable replacement environment */
typedef struct {
    PFvar_t    *var;
    PFcnode_t  *atom;
    char        child;
} bind_t;

/**
 * Variable replacement environment.
 *
 * In order to unfold let-bound variables which are bound to some
 * other atom, we proceed as follows:
 *
 * First, we process the binding sequence (the atom).  If it is
 * a variable itself, there may be a replacement for it, so we do
 * that first.  Then, add an entry to the environment var_env
 * (a hash table with HASH_BUCKETS buckets) and process the return
 * part (which will replace every occurrence of the variable).
 * When we're back, we replace the let clause by its return part.
 *
 * Whenever we process the usage of a variable, look into the
 * environment if there is a replacement for it.  In that case,
 * do the replacement.
 *
 * Note that we do *not* remove the binding from the environment
 * when we're back from the return part.  The Core expression
 * tree may contain "global" variables (i.e., ones that were
 * bound in the query prolog).  Such variables may be used in
 * functions as well.  Therefore, we process the query first
 * (the start rule for our grammar is top-down) in order to have
 * globals be added to the environment.  As we leave all the
 * variables in the environment, they will be available when we
 * process the function bodies.  Hence, they will be replaced
 * there as well.
 */
static PFarray_t *var_env[HASH_BUCKETS];

/**
 * Variable environment that collects the usage of variable bindings.
 */
static PFarray_t *unused_var_env;
/**
 * Variable environment that collects the variable references.
 */
static PFarray_t *used_var_env;

#ifndef PFcoreopt_PANIC
#define PFcoreopt_PANIC	PANIC
#endif /* PFcoreopt_PANIC */
#include <stdlib.h> /* for abort() */
#ifdef NDEBUG
#define PFcoreopt_assert(x,y)	;
#else
#define PFcoreopt_assert(x,y)	if(!(x)) {y; abort();}
#endif
static short PFcoreopt_r1_nts[] ={ 16, 2, 0 };
static short PFcoreopt_r2_nts[] ={ 3, 5, 0 };
static short PFcoreopt_r3_nts[] ={ 2, 0 };
static short PFcoreopt_r5_nts[] ={ 4, 2, 3, 0 };
static short PFcoreopt_r10_nts[] ={ 14, 3, 0 };
static short PFcoreopt_r11_nts[] ={ 2, 5, 3, 0 };
static short PFcoreopt_r12_nts[] ={ 2, 3, 5, 3, 0 };
static short PFcoreopt_r13_nts[] ={ 2, 7, 2, 2, 0 };
static short PFcoreopt_r15_nts[] ={ 2, 2, 2, 0 };
static short PFcoreopt_r22_nts[] ={ 11, 2, 2, 0 };
static short PFcoreopt_r23_nts[] ={ 2, 2, 0 };
static short PFcoreopt_r24_nts[] ={ 7, 2, 0 };
static short PFcoreopt_r28_nts[] ={ 0 };
static short PFcoreopt_r29_nts[] ={ 10, 0 };
static short PFcoreopt_r30_nts[] ={ 11, 2, 0 };
static short PFcoreopt_r32_nts[] ={ 9, 2, 0 };
static short PFcoreopt_r33_nts[] ={ 5, 0 };
static short PFcoreopt_r34_nts[] ={ 2, 5, 0 };
static short PFcoreopt_r40_nts[] ={ 14, 0 };
static short PFcoreopt_r41_nts[] ={ 8, 0 };
static short PFcoreopt_r44_nts[] ={ 2, 3, 0 };
static short PFcoreopt_r48_nts[] ={ 2, 7, 2, 0 };
static short PFcoreopt_r56_nts[] ={ 9, 0 };
static short PFcoreopt_r57_nts[] ={ 7, 0 };
static short PFcoreopt_r75_nts[] ={ 9, 10, 0 };
static short PFcoreopt_r85_nts[] ={ 12, 0 };
static short PFcoreopt_r86_nts[] ={ 13, 0 };
static short PFcoreopt_r87_nts[] ={ 2, 13, 0 };
static short PFcoreopt_r88_nts[] ={ 8, 13, 0 };
static short PFcoreopt_r92_nts[] ={ 6, 2, 0 };
static short PFcoreopt_r95_nts[] ={ 2, 6, 0 };
static short PFcoreopt_r97_nts[] ={ 15, 0 };
static short PFcoreopt_r107_nts[] ={ 17, 16, 0 };
static short PFcoreopt_r110_nts[] ={ 18, 19, 0 };
static short PFcoreopt_r112_nts[] ={ 20, 18, 0 };
static short PFcoreopt_r116_nts[] ={ 2, 12, 0 };
short *PFcoreopt_nts[] = {
	0,
	PFcoreopt_r1_nts,
	PFcoreopt_r2_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r5_nts,
	0,
	0,
	0,
	0,
	PFcoreopt_r10_nts,
	PFcoreopt_r11_nts,
	PFcoreopt_r12_nts,
	PFcoreopt_r13_nts,
	0,
	PFcoreopt_r15_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r15_nts,
	PFcoreopt_r15_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r22_nts,
	PFcoreopt_r23_nts,
	PFcoreopt_r24_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r23_nts,
	PFcoreopt_r24_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r29_nts,
	PFcoreopt_r30_nts,
	PFcoreopt_r23_nts,
	PFcoreopt_r32_nts,
	PFcoreopt_r33_nts,
	PFcoreopt_r34_nts,
	PFcoreopt_r15_nts,
	0,
	0,
	0,
	0,
	PFcoreopt_r40_nts,
	PFcoreopt_r41_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r44_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r48_nts,
	0,
	PFcoreopt_r23_nts,
	PFcoreopt_r23_nts,
	0,
	0,
	0,
	0,
	PFcoreopt_r56_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r57_nts,
	0,
	0,
	0,
	0,
	PFcoreopt_r75_nts,
	0,
	0,
	PFcoreopt_r30_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r23_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r85_nts,
	PFcoreopt_r86_nts,
	PFcoreopt_r87_nts,
	PFcoreopt_r88_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r92_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r95_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r97_nts,
	0,
	0,
	PFcoreopt_r28_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r107_nts,
	0,
	0,
	PFcoreopt_r110_nts,
	PFcoreopt_r28_nts,
	PFcoreopt_r112_nts,
	PFcoreopt_r3_nts,
	PFcoreopt_r57_nts,
	PFcoreopt_r23_nts,
	PFcoreopt_r116_nts,
};
static unsigned char PFcoreopt_seq_transition[6][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    4}	/* row 1 */,
{    0,    5,    5}	/* row 2 */,
{    0,    3,    4}	/* row 3 */,
{    0,    2,    4}	/* row 4 */,
{    0,    1,    4}	/* row 5 */
};
static unsigned char PFcoreopt_twig_seq_transition[6][6] = {
{    0,    0,    0,    0,    0,    0}	/* row 0 */,
{    0,    3,    5,    1,    3,    1}	/* row 1 */,
{    0,    4,    4,    4,    4,    4}	/* row 2 */,
{    0,    2,    5,    1,    2,    2}	/* row 3 */,
{    0,    3,    5,    1,    3,    1}	/* row 4 */,
{    0,    2,    5,    1,    2,    1}	/* row 5 */
};
static unsigned char PFcoreopt_flwr_transition[11][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    5,    5}	/* row 1 */,
{    0,    9,    8}	/* row 2 */,
{    0,    3,    8}	/* row 3 */,
{    0,    1,    1}	/* row 4 */,
{    0,   11,   11}	/* row 5 */,
{    0,    5,    2}	/* row 6 */,
{    0,    4,    8}	/* row 7 */,
{    0,   10,   10}	/* row 8 */,
{    0,    6,    8}	/* row 9 */,
{    0,    7,    7}	/* row 10 */
};
static unsigned char PFcoreopt_let_transition[12][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,   13,    4}	/* row 1 */,
{    0,    7,   17}	/* row 2 */,
{    0,   18,    2}	/* row 3 */,
{    0,    7,   17}	/* row 4 */,
{    0,    8,   14}	/* row 5 */,
{    0,   12,   10}	/* row 6 */,
{    0,   11,    9}	/* row 7 */,
{    0,   16,    6}	/* row 8 */,
{    0,    5,    3}	/* row 9 */,
{    0,    1,   15}	/* row 10 */,
{    0,    7,   17}	/* row 11 */
};
static unsigned char PFcoreopt_letbind_transition[2][12] = {
{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,	/* row 0, cols 0-9*/
    0,    0}	/* row 0 */,
{    0,    3,    7,   11,   10,    1,    9,    8,    6,    5,	/* row 1, cols 0-9*/
    4,    2}	/* row 1 */
};
static unsigned char PFcoreopt_for__transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */,
{    0,    2,    2}	/* row 2 */
};
static unsigned char PFcoreopt_forbind_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    2}	/* row 1 */,
{    0,    1}	/* row 2 */
};
static unsigned char PFcoreopt_forvars_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFcoreopt_where_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    2}	/* row 1 */,
{    0,    1}	/* row 2 */
};
static unsigned char PFcoreopt_orderby_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_orderspecs_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFcoreopt_arg_transition[3][5] = {
{    0,    0,    0,    0,    0}	/* row 0 */,
{    0,    1,    4,    8,    3}	/* row 1 */,
{    0,    2,    5,    6,    7}	/* row 2 */
};
static unsigned char PFcoreopt_typesw_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_cases_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_case__transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_seqcast_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_proof_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_subty_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_if__transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFcoreopt_then_else_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFcoreopt_locsteps_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFcoreopt_elem_transition[2][5] = {
{    0,    0,    0,    0,    0}	/* row 0 */,
{    0,    2,    1,    2,    2}	/* row 1 */
};
static unsigned char PFcoreopt_attr_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_pi_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_main_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_fun_decls_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_fun_decl_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_params_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_param_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_cast_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_recursion_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_seed_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFcoreopt_xrpc_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static struct {
	unsigned int f41:3;
	unsigned int f42:2;
	unsigned int f43:2;
	unsigned int f44:4;
	unsigned int f45:2;
	unsigned int f46:2;
	unsigned int f47:2;
	unsigned int f48:3;
	unsigned int f49:3;
	unsigned int f50:6;
	unsigned int f51:2;
} PFcoreopt_plank_0[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   2,   0,  14,   0,   0,   0,   3,   0,  20,   0,},	/* row 1 */
	{   0,   2,   0,  13,   0,   0,   0,   3,   0,  20,   0,},	/* row 2 */
	{   1,   2,   0,   0,   0,   0,   0,   3,   0,  25,   0,},	/* row 3 */
	{   3,   2,   0,   0,   0,   0,   0,   3,   0,  25,   0,},	/* row 4 */
	{   2,   2,   0,   0,   0,   0,   0,   3,   0,  25,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  33,   0,},	/* row 14 */
	{   0,   2,   0,  12,   0,   0,   0,   3,   0,  20,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  13,   0,},	/* row 18 */
	{   0,   2,   0,  11,   0,   0,   0,   3,   0,  20,   0,},	/* row 19 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  29,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   2,   0,  10,   0,   0,   0,   3,   0,  20,   0,},	/* row 22 */
	{   0,   2,   0,   9,   0,   0,   0,   3,   0,  20,   0,},	/* row 23 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  31,   0,},	/* row 24 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  30,   0,},	/* row 25 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  34,   0,},	/* row 26 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  21,   0,},	/* row 27 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   1,   0,},	/* row 28 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   1,   0,},	/* row 29 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   3,   0,},	/* row 30 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   4,   0,},	/* row 31 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   3,   0,},	/* row 32 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   3,   0,},	/* row 33 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   3,   0,},	/* row 34 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   3,   0,},	/* row 35 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   3,   0,},	/* row 36 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   5,   0,},	/* row 37 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   3,   0,},	/* row 38 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   3,   0,},	/* row 39 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   3,   0,},	/* row 40 */
	{   0,   2,   0,   8,   0,   0,   0,   3,   0,  20,   0,},	/* row 41 */
	{   0,   2,   0,   7,   0,   0,   0,   3,   0,  20,   0,},	/* row 42 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   6,   0,   0,},	/* row 43 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   6,   0,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   9,   0,},	/* row 51 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   8,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 81 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   1,   0,},	/* row 82 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   1,   0,},	/* row 83 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   1,   0,},	/* row 84 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   1,   0,},	/* row 85 */
	{   0,   2,   2,   0,   0,   0,   0,   3,   0,  19,   0,},	/* row 86 */
	{   0,   2,   1,   0,   0,   0,   0,   3,   0,  19,   0,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 88 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 89 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 90 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  15,   0,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   0,   2,   0,   6,   0,   0,   0,   3,   0,  20,   0,},	/* row 96 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  28,   0,},	/* row 97 */
	{   0,   2,   0,   5,   0,   0,   0,   3,   0,  20,   0,},	/* row 98 */
	{   0,   2,   0,   1,   0,   0,   0,   3,   0,  20,   0,},	/* row 99 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   7,   0,},	/* row 100 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  16,   0,},	/* row 101 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 102 */
	{   0,   2,   0,   3,   0,   0,   0,   3,   0,  20,   0,},	/* row 103 */
	{   0,   2,   0,   4,   0,   0,   0,   3,   0,  20,   0,},	/* row 104 */
	{   0,   2,   0,   2,   0,   0,   0,   3,   0,  20,   0,},	/* row 105 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  10,   0,},	/* row 106 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  11,   0,},	/* row 107 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  10,   0,},	/* row 108 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  26,   0,},	/* row 109 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  12,   0,},	/* row 110 */
	{   0,   2,   0,   0,   1,   0,   0,   3,   0,   2,   0,},	/* row 111 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 114 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 115 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  32,   0,},	/* row 116 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 117 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 118 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   1,   0,},	/* row 119 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  27,   0,},	/* row 120 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  22,   0,},	/* row 121 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  23,   0,},	/* row 122 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  18,   0,},	/* row 123 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  24,   0,},	/* row 124 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   6,   0,},	/* row 125 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  14,   0,},	/* row 126 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,   1,   0,},	/* row 127 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,},	/* row 128 */
	{   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,   0,},	/* row 129 */
	{   0,   2,   0,   0,   0,   0,   0,   3,   0,  17,   0,},	/* row 130 */
};
static struct {
	unsigned int f28:3;
	unsigned int f29:3;
	unsigned int f30:2;
	unsigned int f31:2;
	unsigned int f32:2;
	unsigned int f33:2;
	unsigned int f34:2;
	unsigned int f35:2;
	unsigned int f36:2;
	unsigned int f37:2;
	unsigned int f38:3;
	unsigned int f39:3;
	unsigned int f40:3;
} PFcoreopt_plank_1[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   1,   1,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 3 */
	{   1,   1,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 4 */
	{   1,   1,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,},	/* row 13 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 18 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 19 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 28 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   3,   2,   0,},	/* row 29 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 31 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 32 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 33 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 34 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 35 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 36 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 37 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 38 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 39 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 40 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 41 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 42 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 43 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 50 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 81 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   2,   0,},	/* row 82 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   6,   2,   0,},	/* row 83 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,},	/* row 84 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   4,   2,   0,},	/* row 85 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 86 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   0,   1,   0,   1,   0,   0,   0,   1,   2,   0,   0,   2,},	/* row 89 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 90 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 95 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 96 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 97 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 98 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 99 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 100 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 101 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 102 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 103 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 104 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 105 */
	{   2,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 106 */
	{   2,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 107 */
	{   4,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 108 */
	{   3,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 109 */
	{   3,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 110 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 111 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 114 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 115 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 116 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 117 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 118 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   2,   2,   0,},	/* row 119 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 120 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 121 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 122 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 123 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 124 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 125 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 126 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 127 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 128 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 129 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 130 */
};
static struct {
	unsigned int f13:2;
	unsigned int f14:2;
	unsigned int f15:2;
	unsigned int f16:3;
	unsigned int f17:2;
	unsigned int f18:3;
	unsigned int f19:2;
	unsigned int f20:2;
	unsigned int f21:2;
	unsigned int f22:2;
	unsigned int f23:2;
	unsigned int f24:2;
	unsigned int f25:2;
	unsigned int f26:2;
	unsigned int f27:2;
} PFcoreopt_plank_2[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 1 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 2 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 3 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 4 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 5 */
	{   0,   0,   0,   3,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   3,   0,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   2,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   1,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   1,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   1,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   2,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   1,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 14 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 18 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 19 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 22 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 23 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 24 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 25 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 26 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 27 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 28 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 29 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 30 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 31 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 32 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 33 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 34 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 35 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 36 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 37 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 38 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 39 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 40 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 41 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 42 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 43 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 51 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 81 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 82 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 83 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 84 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 85 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   2,   1,},	/* row 86 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   2,   1,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   0,   1,   2,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 89 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 90 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 91 */
	{   0,   1,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 92 */
	{   0,   1,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 96 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 97 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 98 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 99 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 100 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 101 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 102 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 103 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 104 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,},	/* row 105 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 106 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 107 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 108 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 109 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 110 */
	{   1,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 111 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 114 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 115 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 116 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 117 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,},	/* row 118 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 119 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 120 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 121 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 122 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 123 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 124 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 125 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 126 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 127 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 128 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 129 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,},	/* row 130 */
};
static struct {
	unsigned int f1:2;
	unsigned int f2:2;
	unsigned int f3:4;
	unsigned int f4:2;
	unsigned int f5:4;
	unsigned int f6:2;
	unsigned int f7:2;
	unsigned int f8:4;
	unsigned int f9:2;
	unsigned int f10:2;
	unsigned int f11:2;
	unsigned int f12:2;
} PFcoreopt_plank_3[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 1 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 2 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 3 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 4 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 14 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 18 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 19 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 22 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 23 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 24 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 25 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 26 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 27 */
	{   2,   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,},	/* row 28 */
	{   1,   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,},	/* row 29 */
	{   1,   1,   0,   1,   0,   0,   0,   6,   0,   0,   0,   1,},	/* row 30 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 31 */
	{   1,   1,   0,   1,   0,   0,   0,   5,   0,   0,   0,   1,},	/* row 32 */
	{   1,   1,   0,   1,   0,   0,   0,   8,   0,   0,   0,   1,},	/* row 33 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 34 */
	{   1,   1,   0,   1,   0,   0,   0,  10,   0,   0,   0,   1,},	/* row 35 */
	{   1,   1,   0,   1,   0,   0,   0,  11,   0,   0,   0,   1,},	/* row 36 */
	{   1,   1,   0,   1,   0,   0,   0,   4,   0,   0,   0,   1,},	/* row 37 */
	{   1,   1,   0,   1,   0,   0,   0,   3,   0,   0,   0,   1,},	/* row 38 */
	{   1,   1,   0,   1,   0,   0,   0,   9,   0,   0,   0,   1,},	/* row 39 */
	{   1,   1,   0,   1,   0,   0,   0,   7,   0,   0,   0,   1,},	/* row 40 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 41 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 42 */
	{   0,   0,   6,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 43 */
	{   0,   0,   1,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 51 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 52 */
	{   0,   0,   3,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   8,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   5,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   4,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   3,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   4,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   0,   3,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   9,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   0,   0,   8,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 61 */
	{   0,   0,   4,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   7,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   2,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   0,   2,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   0,   0,  10,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 66 */
	{   0,   0,   5,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   2,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   5,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   7,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   5,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,  11,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,  10,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   9,   0,   0,   0,   0,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   8,   0,   0,   0,   0,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   7,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   6,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   4,   0,   0,   0,   0,   0,   0,   0,},	/* row 80 */
	{   0,   0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0,},	/* row 81 */
	{   1,   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,},	/* row 82 */
	{   1,   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,},	/* row 83 */
	{   1,   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,},	/* row 84 */
	{   1,   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,},	/* row 85 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 86 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   0,   1,   0,   0,   1,   0,   0,   0,   0,   1,   0,},	/* row 89 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 90 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 96 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 97 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 98 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 99 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 100 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 101 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 102 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 103 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 104 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 105 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 106 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 107 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 108 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 109 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 110 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 111 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 114 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 115 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 116 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 117 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 118 */
	{   1,   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   2,},	/* row 119 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 120 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 121 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 122 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 123 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 124 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 125 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 126 */
	{   1,   1,   0,   2,   0,   0,   1,   1,   0,   0,   2,   1,},	/* row 127 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 128 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 129 */
	{   1,   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   1,},	/* row 130 */
};
static struct {
	unsigned int f0:3;
} PFcoreopt_plank_4[] = {
	{   0,},	/* row 0 */
	{   1,},	/* row 1 */
	{   1,},	/* row 2 */
	{   1,},	/* row 3 */
	{   1,},	/* row 4 */
	{   1,},	/* row 5 */
	{   0,},	/* row 6 */
	{   0,},	/* row 7 */
	{   0,},	/* row 8 */
	{   0,},	/* row 9 */
	{   0,},	/* row 10 */
	{   0,},	/* row 11 */
	{   0,},	/* row 12 */
	{   0,},	/* row 13 */
	{   1,},	/* row 14 */
	{   1,},	/* row 15 */
	{   0,},	/* row 16 */
	{   0,},	/* row 17 */
	{   1,},	/* row 18 */
	{   1,},	/* row 19 */
	{   1,},	/* row 20 */
	{   0,},	/* row 21 */
	{   1,},	/* row 22 */
	{   1,},	/* row 23 */
	{   1,},	/* row 24 */
	{   1,},	/* row 25 */
	{   1,},	/* row 26 */
	{   1,},	/* row 27 */
	{   2,},	/* row 28 */
	{   1,},	/* row 29 */
	{   1,},	/* row 30 */
	{   1,},	/* row 31 */
	{   1,},	/* row 32 */
	{   1,},	/* row 33 */
	{   1,},	/* row 34 */
	{   1,},	/* row 35 */
	{   1,},	/* row 36 */
	{   1,},	/* row 37 */
	{   1,},	/* row 38 */
	{   1,},	/* row 39 */
	{   1,},	/* row 40 */
	{   1,},	/* row 41 */
	{   1,},	/* row 42 */
	{   0,},	/* row 43 */
	{   0,},	/* row 44 */
	{   0,},	/* row 45 */
	{   0,},	/* row 46 */
	{   0,},	/* row 47 */
	{   0,},	/* row 48 */
	{   0,},	/* row 49 */
	{   0,},	/* row 50 */
	{   1,},	/* row 51 */
	{   1,},	/* row 52 */
	{   0,},	/* row 53 */
	{   0,},	/* row 54 */
	{   0,},	/* row 55 */
	{   0,},	/* row 56 */
	{   0,},	/* row 57 */
	{   0,},	/* row 58 */
	{   0,},	/* row 59 */
	{   0,},	/* row 60 */
	{   0,},	/* row 61 */
	{   0,},	/* row 62 */
	{   0,},	/* row 63 */
	{   0,},	/* row 64 */
	{   0,},	/* row 65 */
	{   0,},	/* row 66 */
	{   0,},	/* row 67 */
	{   0,},	/* row 68 */
	{   0,},	/* row 69 */
	{   0,},	/* row 70 */
	{   0,},	/* row 71 */
	{   0,},	/* row 72 */
	{   0,},	/* row 73 */
	{   0,},	/* row 74 */
	{   0,},	/* row 75 */
	{   0,},	/* row 76 */
	{   0,},	/* row 77 */
	{   0,},	/* row 78 */
	{   0,},	/* row 79 */
	{   0,},	/* row 80 */
	{   0,},	/* row 81 */
	{   1,},	/* row 82 */
	{   1,},	/* row 83 */
	{   1,},	/* row 84 */
	{   1,},	/* row 85 */
	{   1,},	/* row 86 */
	{   1,},	/* row 87 */
	{   0,},	/* row 88 */
	{   0,},	/* row 89 */
	{   0,},	/* row 90 */
	{   1,},	/* row 91 */
	{   0,},	/* row 92 */
	{   0,},	/* row 93 */
	{   0,},	/* row 94 */
	{   0,},	/* row 95 */
	{   1,},	/* row 96 */
	{   1,},	/* row 97 */
	{   1,},	/* row 98 */
	{   1,},	/* row 99 */
	{   1,},	/* row 100 */
	{   1,},	/* row 101 */
	{   0,},	/* row 102 */
	{   1,},	/* row 103 */
	{   1,},	/* row 104 */
	{   1,},	/* row 105 */
	{   3,},	/* row 106 */
	{   3,},	/* row 107 */
	{   5,},	/* row 108 */
	{   4,},	/* row 109 */
	{   4,},	/* row 110 */
	{   1,},	/* row 111 */
	{   0,},	/* row 112 */
	{   0,},	/* row 113 */
	{   0,},	/* row 114 */
	{   0,},	/* row 115 */
	{   1,},	/* row 116 */
	{   0,},	/* row 117 */
	{   0,},	/* row 118 */
	{   1,},	/* row 119 */
	{   1,},	/* row 120 */
	{   1,},	/* row 121 */
	{   1,},	/* row 122 */
	{   1,},	/* row 123 */
	{   1,},	/* row 124 */
	{   1,},	/* row 125 */
	{   1,},	/* row 126 */
	{   1,},	/* row 127 */
	{   0,},	/* row 128 */
	{   0,},	/* row 129 */
	{   1,},	/* row 130 */
};
static short PFcoreopt_eruleMap[] = {
    0,   28,   97,   96,    0,   40,   41,    2,    3,    4,	/* 0-9 */
   13,   48,   35,   31,   15,   50,   16,   27,   91,   90,	/* 10-19 */
  115,  116,   20,   29,   56,   30,   19,   51,   21,   85,	/* 20-29 */
   17,   18,   82,   81,   23,   80,   79,   78,   22,    0,	/* 30-39 */
   26,   25,   86,    0,  114,    0,   88,   89,   87,    0,	/* 40-49 */
  113,    0,  110,    0,  107,  106,    0,  103,  104,  105,	/* 50-59 */
  100,  101,  102,    0,   67,   68,   69,   70,   66,   65,	/* 60-69 */
   64,   63,   62,   61,   60,   59,   58,   57,    0,   32,	/* 70-79 */
   75,    0,   44,   45,   12,   11,   10,    5,    0,   42,	/* 80-89 */
   43,    0,   94,   95,    0,  111,  112,    0,    1,    0,	/* 90-99 */
   46,   47,    0,   24,    0,   83,   84,    0,   92,   33,	/* 100-109 */
   93,   34
};
#define PFcoreopt_Query_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f51 +97]
#define PFcoreopt_CoreExpr_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f50 +4]
#define PFcoreopt_OptBindExpr_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f49 +81]
#define PFcoreopt_OptVar_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_3[state].f11 +88]
#define PFcoreopt_WhereExpr_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f48 +107]
#define PFcoreopt_OrderSpecs_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f47 +91]
#define PFcoreopt_SequenceType_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f46 +99]
#define PFcoreopt_SequenceTypeCast_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f45 +102]
#define PFcoreopt_LocationStep_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f44 +63]
#define PFcoreopt_LocationSteps_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f43 +78]
#define PFcoreopt_TagName_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f42 +104]
#define PFcoreopt_FunExpr_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_0[state].f41 +39]
#define PFcoreopt_FunctionArgs_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_1[state].f40 +45]
#define PFcoreopt_Atom_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_1[state].f39 +0]
#define PFcoreopt_LiteralValue_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_1[state].f38 +56]
#define PFcoreopt_FunctionDecls_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_1[state].f37 +53]
#define PFcoreopt_FunctionDecl_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_1[state].f31 +51]
#define PFcoreopt_ParamList_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_1[state].f36 +94]
#define PFcoreopt_FunctionBody_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_3[state].f2 +49]
#define PFcoreopt_FunParam_rule(state)	PFcoreopt_eruleMap[PFcoreopt_plank_1[state].f33 +43]

#ifdef __STDC__
int PFcoreopt_rule(int state, int goalnt) {
#else
int PFcoreopt_rule(state, goalnt) int state; int goalnt; {
#endif
	PFcoreopt_assert(state >= 0 && state < 131, PFcoreopt_PANIC("Bad state %d passed to PFcoreopt_rule\n", state));
	switch(goalnt) {
	case 1:
		return PFcoreopt_Query_rule(state);
	case 2:
		return PFcoreopt_CoreExpr_rule(state);
	case 3:
		return PFcoreopt_OptBindExpr_rule(state);
	case 4:
		return PFcoreopt_OptVar_rule(state);
	case 5:
		return PFcoreopt_WhereExpr_rule(state);
	case 6:
		return PFcoreopt_OrderSpecs_rule(state);
	case 7:
		return PFcoreopt_SequenceType_rule(state);
	case 8:
		return PFcoreopt_SequenceTypeCast_rule(state);
	case 9:
		return PFcoreopt_LocationStep_rule(state);
	case 10:
		return PFcoreopt_LocationSteps_rule(state);
	case 11:
		return PFcoreopt_TagName_rule(state);
	case 12:
		return PFcoreopt_FunExpr_rule(state);
	case 13:
		return PFcoreopt_FunctionArgs_rule(state);
	case 14:
		return PFcoreopt_Atom_rule(state);
	case 15:
		return PFcoreopt_LiteralValue_rule(state);
	case 16:
		return PFcoreopt_FunctionDecls_rule(state);
	case 17:
		return PFcoreopt_FunctionDecl_rule(state);
	case 18:
		return PFcoreopt_ParamList_rule(state);
	case 19:
		return PFcoreopt_FunctionBody_rule(state);
	case 20:
		return PFcoreopt_FunParam_rule(state);
	default:
		PFcoreopt_PANIC("Unknown nonterminal %d in PFcoreopt_rule;\n", goalnt);
		abort();
		return 0;
	}
}

int PFcoreopt_TEMP;
#define PFcoreopt_var_state	127
#define PFcoreopt_lit_str_state	85
#define PFcoreopt_lit_int_state	84
#define PFcoreopt_lit_dec_state	83
#define PFcoreopt_lit_dbl_state	82
#define PFcoreopt_nil_state	89
#define PFcoreopt_seq_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_seq_transition[PFcoreopt_plank_4[l].f0][PFcoreopt_plank_3[r].f1]) ? PFcoreopt_TEMP + 105 : 0 )
#define PFcoreopt_twig_seq_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_twig_seq_transition[PFcoreopt_plank_4[l].f0][PFcoreopt_plank_4[r].f0]) ? PFcoreopt_TEMP + 119 : 0 )
#define PFcoreopt_ordered_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_3[l].f2) ? PFcoreopt_TEMP + 90 : 0 )
#define PFcoreopt_unordered_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_3[l].f2) ? PFcoreopt_TEMP + 125 : 0 )
#define PFcoreopt_flwr_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_flwr_transition[PFcoreopt_plank_3[l].f3][PFcoreopt_plank_3[r].f4]) ? PFcoreopt_TEMP + 29 : 0 )
#define PFcoreopt_let_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_let_transition[PFcoreopt_plank_3[l].f5][PFcoreopt_plank_3[r].f6]) ? PFcoreopt_TEMP + 52 : 0 )
#define PFcoreopt_letbind_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_letbind_transition[PFcoreopt_plank_3[l].f7][PFcoreopt_plank_3[r].f8]) ? PFcoreopt_TEMP + 70 : 0 )
#define PFcoreopt_for__state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_for__transition[PFcoreopt_plank_3[l].f9][PFcoreopt_plank_3[r].f6]) ? PFcoreopt_TEMP + 42 : 0 )
#define PFcoreopt_forbind_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_forbind_transition[PFcoreopt_plank_3[l].f10][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 44 : 0 )
#define PFcoreopt_forvars_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_forvars_transition[PFcoreopt_plank_3[l].f7][PFcoreopt_plank_3[r].f11]) ? PFcoreopt_TEMP + 46 : 0 )
#define PFcoreopt_where_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_where_transition[PFcoreopt_plank_3[l].f12][PFcoreopt_plank_2[r].f13]) ? PFcoreopt_TEMP + 127 : 0 )
#define PFcoreopt_orderby_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_orderby_transition[PFcoreopt_plank_2[l].f14][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 89 : 0 )
#define PFcoreopt_orderspecs_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_orderspecs_transition[PFcoreopt_plank_3[l].f2][PFcoreopt_plank_2[r].f15]) ? PFcoreopt_TEMP + 91 : 0 )
#define PFcoreopt_apply_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f16) ? PFcoreopt_TEMP + 2 : 0 )
#define PFcoreopt_arg_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_arg_transition[PFcoreopt_plank_2[l].f17][PFcoreopt_plank_2[r].f18]) ? PFcoreopt_TEMP + 5 : 0 )
#define PFcoreopt_typesw_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_typesw_transition[PFcoreopt_plank_3[l].f2][PFcoreopt_plank_2[r].f19]) ? PFcoreopt_TEMP + 124 : 0 )
#define PFcoreopt_cases_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_cases_transition[PFcoreopt_plank_2[l].f20][PFcoreopt_plank_2[r].f21]) ? PFcoreopt_TEMP + 16 : 0 )
#define PFcoreopt_case__state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_case__transition[PFcoreopt_plank_2[l].f22][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 15 : 0 )
#define PFcoreopt_default__state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_3[l].f2) ? PFcoreopt_TEMP + 20 : 0 )
#define PFcoreopt_seqtype_state	112
#define PFcoreopt_seqcast_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_seqcast_transition[PFcoreopt_plank_2[l].f22][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 110 : 0 )
#define PFcoreopt_proof_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_proof_transition[PFcoreopt_plank_2[l].f23][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 99 : 0 )
#define PFcoreopt_subty_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_subty_transition[PFcoreopt_plank_3[l].f2][PFcoreopt_plank_2[r].f22]) ? PFcoreopt_TEMP + 113 : 0 )
#define PFcoreopt_stattype_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_3[l].f2) ? PFcoreopt_TEMP + 112 : 0 )
#define PFcoreopt_if__state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_if__transition[PFcoreopt_plank_3[l].f2][PFcoreopt_plank_2[r].f24]) ? PFcoreopt_TEMP + 50 : 0 )
#define PFcoreopt_then_else_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_then_else_transition[PFcoreopt_plank_3[l].f2][PFcoreopt_plank_3[r].f1]) ? PFcoreopt_TEMP + 116 : 0 )
#define PFcoreopt_locsteps_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_locsteps_transition[PFcoreopt_plank_2[l].f25][PFcoreopt_plank_2[r].f26]) ? PFcoreopt_TEMP + 85 : 0 )
#define PFcoreopt_ancestor_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 0 : 0 )
#define PFcoreopt_ancestor_or_self_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 1 : 0 )
#define PFcoreopt_attribute_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 14 : 0 )
#define PFcoreopt_child_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 18 : 0 )
#define PFcoreopt_descendant_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 21 : 0 )
#define PFcoreopt_descendant_or_self_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 22 : 0 )
#define PFcoreopt_following_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 40 : 0 )
#define PFcoreopt_following_sibling_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 41 : 0 )
#define PFcoreopt_parent_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 95 : 0 )
#define PFcoreopt_preceding_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 97 : 0 )
#define PFcoreopt_preceding_sibling_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 98 : 0 )
#define PFcoreopt_self_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 104 : 0 )
#define PFcoreopt_select_narrow_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 102 : 0 )
#define PFcoreopt_select_wide_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_2[l].f22) ? PFcoreopt_TEMP + 103 : 0 )
#define PFcoreopt_elem_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_elem_transition[PFcoreopt_plank_2[l].f27][PFcoreopt_plank_1[r].f28]) ? PFcoreopt_TEMP + 25 : 0 )
#define PFcoreopt_attr_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_attr_transition[PFcoreopt_plank_2[l].f27][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 13 : 0 )
#define PFcoreopt_text_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_3[l].f2) ? PFcoreopt_TEMP + 115 : 0 )
#define PFcoreopt_doc_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_1[l].f29) ? PFcoreopt_TEMP + 23 : 0 )
#define PFcoreopt_comment_state(l)	( (PFcoreopt_TEMP = PFcoreopt_plank_3[l].f2) ? PFcoreopt_TEMP + 19 : 0 )
#define PFcoreopt_pi_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_pi_transition[PFcoreopt_plank_3[l].f2][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 96 : 0 )
#define PFcoreopt_tag_state	115
#define PFcoreopt_true__state	119
#define PFcoreopt_false__state	29
#define PFcoreopt_empty_state	28
#define PFcoreopt_main_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_main_transition[PFcoreopt_plank_1[l].f30][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 87 : 0 )
#define PFcoreopt_fun_decls_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_fun_decls_transition[PFcoreopt_plank_1[l].f31][PFcoreopt_plank_1[r].f30]) ? PFcoreopt_TEMP + 49 : 0 )
#define PFcoreopt_fun_decl_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_fun_decl_transition[PFcoreopt_plank_1[l].f32][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 48 : 0 )
#define PFcoreopt_params_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_params_transition[PFcoreopt_plank_1[l].f33][PFcoreopt_plank_1[r].f32]) ? PFcoreopt_TEMP + 94 : 0 )
#define PFcoreopt_param_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_param_transition[PFcoreopt_plank_2[l].f22][PFcoreopt_plank_3[r].f7]) ? PFcoreopt_TEMP + 93 : 0 )
#define PFcoreopt_cast_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_cast_transition[PFcoreopt_plank_2[l].f22][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 17 : 0 )
#define PFcoreopt_recursion_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_recursion_transition[PFcoreopt_plank_3[l].f7][PFcoreopt_plank_1[r].f34]) ? PFcoreopt_TEMP + 100 : 0 )
#define PFcoreopt_seed_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_seed_transition[PFcoreopt_plank_3[l].f2][PFcoreopt_plank_3[r].f2]) ? PFcoreopt_TEMP + 101 : 0 )
#define PFcoreopt_xrpc_state(l,r)	( (PFcoreopt_TEMP = PFcoreopt_xrpc_transition[PFcoreopt_plank_3[l].f2][PFcoreopt_plank_1[r].f35]) ? PFcoreopt_TEMP + 129 : 0 )

#ifdef __STDC__
int PFcoreopt_state(int op, int l, int r) {
#else
int PFcoreopt_state(op, l, r) int op; int l; int r; {
#endif
	register int PFcoreopt_TEMP;
#ifndef NDEBUG
	switch (op) {
	case 7:
	case 8:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 24:
	case 25:
	case 26:
	case 27:
	case 30:
	case 31:
	case 32:
	case 34:
	case 35:
	case 40:
	case 55:
	case 56:
	case 60:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
		PFcoreopt_assert(r >= 0 && r < 131, PFcoreopt_PANIC("Bad state %d passed to PFcoreopt_state\n", r));
		/*FALLTHROUGH*/
	case 9:
	case 10:
	case 23:
	case 28:
	case 33:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 57:
	case 58:
	case 59:
		PFcoreopt_assert(l >= 0 && l < 131, PFcoreopt_PANIC("Bad state %d passed to PFcoreopt_state\n", l));
		/*FALLTHROUGH*/
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 29:
	case 61:
	case 65:
	case 66:
	case 67:
		break;
	}
#endif
	switch (op) {
	default: PFcoreopt_PANIC("Unknown op %d in PFcoreopt_state\n", op); abort(); return 0;
	case 1:
		return PFcoreopt_var_state;
	case 2:
		return PFcoreopt_lit_str_state;
	case 3:
		return PFcoreopt_lit_int_state;
	case 4:
		return PFcoreopt_lit_dec_state;
	case 5:
		return PFcoreopt_lit_dbl_state;
	case 6:
		return PFcoreopt_nil_state;
	case 7:
		return PFcoreopt_seq_state(l,r);
	case 8:
		return PFcoreopt_twig_seq_state(l,r);
	case 9:
		return PFcoreopt_ordered_state(l);
	case 10:
		return PFcoreopt_unordered_state(l);
	case 14:
		return PFcoreopt_flwr_state(l,r);
	case 15:
		return PFcoreopt_let_state(l,r);
	case 16:
		return PFcoreopt_letbind_state(l,r);
	case 17:
		return PFcoreopt_for__state(l,r);
	case 18:
		return PFcoreopt_forbind_state(l,r);
	case 19:
		return PFcoreopt_forvars_state(l,r);
	case 20:
		return PFcoreopt_where_state(l,r);
	case 21:
		return PFcoreopt_orderby_state(l,r);
	case 22:
		return PFcoreopt_orderspecs_state(l,r);
	case 23:
		return PFcoreopt_apply_state(l);
	case 24:
		return PFcoreopt_arg_state(l,r);
	case 25:
		return PFcoreopt_typesw_state(l,r);
	case 26:
		return PFcoreopt_cases_state(l,r);
	case 27:
		return PFcoreopt_case__state(l,r);
	case 28:
		return PFcoreopt_default__state(l);
	case 29:
		return PFcoreopt_seqtype_state;
	case 30:
		return PFcoreopt_seqcast_state(l,r);
	case 31:
		return PFcoreopt_proof_state(l,r);
	case 32:
		return PFcoreopt_subty_state(l,r);
	case 33:
		return PFcoreopt_stattype_state(l);
	case 34:
		return PFcoreopt_if__state(l,r);
	case 35:
		return PFcoreopt_then_else_state(l,r);
	case 40:
		return PFcoreopt_locsteps_state(l,r);
	case 41:
		return PFcoreopt_ancestor_state(l);
	case 42:
		return PFcoreopt_ancestor_or_self_state(l);
	case 43:
		return PFcoreopt_attribute_state(l);
	case 44:
		return PFcoreopt_child_state(l);
	case 45:
		return PFcoreopt_descendant_state(l);
	case 46:
		return PFcoreopt_descendant_or_self_state(l);
	case 47:
		return PFcoreopt_following_state(l);
	case 48:
		return PFcoreopt_following_sibling_state(l);
	case 49:
		return PFcoreopt_parent_state(l);
	case 50:
		return PFcoreopt_preceding_state(l);
	case 51:
		return PFcoreopt_preceding_sibling_state(l);
	case 52:
		return PFcoreopt_self_state(l);
	case 53:
		return PFcoreopt_select_narrow_state(l);
	case 54:
		return PFcoreopt_select_wide_state(l);
	case 55:
		return PFcoreopt_elem_state(l,r);
	case 56:
		return PFcoreopt_attr_state(l,r);
	case 57:
		return PFcoreopt_text_state(l);
	case 58:
		return PFcoreopt_doc_state(l);
	case 59:
		return PFcoreopt_comment_state(l);
	case 60:
		return PFcoreopt_pi_state(l,r);
	case 61:
		return PFcoreopt_tag_state;
	case 65:
		return PFcoreopt_true__state;
	case 66:
		return PFcoreopt_false__state;
	case 67:
		return PFcoreopt_empty_state;
	case 68:
		return PFcoreopt_main_state(l,r);
	case 69:
		return PFcoreopt_fun_decls_state(l,r);
	case 70:
		return PFcoreopt_fun_decl_state(l,r);
	case 71:
		return PFcoreopt_params_state(l,r);
	case 72:
		return PFcoreopt_param_state(l,r);
	case 73:
		return PFcoreopt_cast_state(l,r);
	case 74:
		return PFcoreopt_recursion_state(l,r);
	case 75:
		return PFcoreopt_seed_state(l,r);
	case 76:
		return PFcoreopt_xrpc_state(l,r);
	}
}
#ifdef PFcoreopt_STATE_LABEL
#define PFcoreopt_INCLUDE_EXTRA
#else
#ifdef STATE_LABEL
#define PFcoreopt_INCLUDE_EXTRA
#define PFcoreopt_STATE_LABEL 	STATE_LABEL
#define PFcoreopt_NODEPTR_TYPE	NODEPTR_TYPE
#define PFcoreopt_LEFT_CHILD  	LEFT_CHILD
#define PFcoreopt_OP_LABEL    	OP_LABEL
#define PFcoreopt_RIGHT_CHILD 	RIGHT_CHILD
#endif /* STATE_LABEL */
#endif /* PFcoreopt_STATE_LABEL */

#ifdef PFcoreopt_INCLUDE_EXTRA

#ifdef __STDC__
int PFcoreopt_label(PFcoreopt_NODEPTR_TYPE n) {
#else
int PFcoreopt_label(n) PFcoreopt_NODEPTR_TYPE n; {
#endif
	PFcoreopt_assert(n, PFcoreopt_PANIC("NULL pointer passed to PFcoreopt_label\n"));
	switch (PFcoreopt_OP_LABEL(n)) {
	default: PFcoreopt_PANIC("Bad op %d in PFcoreopt_label\n", PFcoreopt_OP_LABEL(n)); abort(); return 0;
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 29:
	case 61:
	case 65:
	case 66:
	case 67:
		return PFcoreopt_STATE_LABEL(n) = PFcoreopt_state(PFcoreopt_OP_LABEL(n), 0, 0);
	case 9:
	case 10:
	case 23:
	case 28:
	case 33:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 57:
	case 58:
	case 59:
		return PFcoreopt_STATE_LABEL(n) = PFcoreopt_state(PFcoreopt_OP_LABEL(n), PFcoreopt_label(PFcoreopt_LEFT_CHILD(n)), 0);
	case 7:
	case 8:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 24:
	case 25:
	case 26:
	case 27:
	case 30:
	case 31:
	case 32:
	case 34:
	case 35:
	case 40:
	case 55:
	case 56:
	case 60:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
		return PFcoreopt_STATE_LABEL(n) = PFcoreopt_state(PFcoreopt_OP_LABEL(n), PFcoreopt_label(PFcoreopt_LEFT_CHILD(n)), PFcoreopt_label(PFcoreopt_RIGHT_CHILD(n)));
	}
}
#ifdef __STDC__
PFcoreopt_NODEPTR_TYPE * PFcoreopt_kids(PFcoreopt_NODEPTR_TYPE p, int rulenumber, PFcoreopt_NODEPTR_TYPE *kids) {
#else
PFcoreopt_NODEPTR_TYPE * PFcoreopt_kids(p, rulenumber, kids) PFcoreopt_NODEPTR_TYPE p; int rulenumber; PFcoreopt_NODEPTR_TYPE *kids; {
#endif
	PFcoreopt_assert(p, PFcoreopt_PANIC("NULL node pointer passed to PFcoreopt_kids\n"));
	PFcoreopt_assert(kids, PFcoreopt_PANIC("NULL kids pointer passed to PFcoreopt_kids\n"));
	switch (rulenumber) {
	default:
		PFcoreopt_PANIC("Unknown Rule %d in PFcoreopt_kids;\n", rulenumber);
		abort();
		/* NOTREACHED */
	case 3:
	case 4:
		kids[0] = PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(PFcoreopt_LEFT_CHILD(p)));
		break;
	case 5:
		kids[0] = PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(PFcoreopt_LEFT_CHILD(p)));
		kids[1] = PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(p));
		kids[2] = PFcoreopt_RIGHT_CHILD(p);
		break;
	case 11:
		kids[0] = PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(PFcoreopt_LEFT_CHILD(PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(p)))));
		kids[1] = PFcoreopt_RIGHT_CHILD(PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(p)));
		kids[2] = PFcoreopt_RIGHT_CHILD(p);
		break;
	case 12:
		kids[0] = PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(PFcoreopt_LEFT_CHILD(PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(p)))));
		kids[1] = PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(p))));
		kids[2] = PFcoreopt_RIGHT_CHILD(PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(p)));
		kids[3] = PFcoreopt_RIGHT_CHILD(p);
		break;
	case 10:
	case 44:
		kids[0] = PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(p));
		kids[1] = PFcoreopt_RIGHT_CHILD(p);
		break;
	case 13:
		kids[0] = PFcoreopt_LEFT_CHILD(p);
		kids[1] = PFcoreopt_LEFT_CHILD(PFcoreopt_LEFT_CHILD(PFcoreopt_RIGHT_CHILD(p)));
		kids[2] = PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(PFcoreopt_RIGHT_CHILD(p)));
		kids[3] = PFcoreopt_LEFT_CHILD(PFcoreopt_RIGHT_CHILD(PFcoreopt_RIGHT_CHILD(p)));
		break;
	case 31:
		kids[0] = PFcoreopt_LEFT_CHILD(p);
		kids[1] = PFcoreopt_LEFT_CHILD(PFcoreopt_RIGHT_CHILD(p));
		break;
	case 48:
	case 15:
	case 19:
		kids[0] = PFcoreopt_LEFT_CHILD(PFcoreopt_LEFT_CHILD(p));
		kids[1] = PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(p));
		kids[2] = PFcoreopt_RIGHT_CHILD(p);
		break;
	case 33:
	case 16:
	case 20:
		kids[0] = PFcoreopt_RIGHT_CHILD(p);
		break;
	case 35:
	case 18:
	case 22:
		kids[0] = PFcoreopt_LEFT_CHILD(p);
		kids[1] = PFcoreopt_LEFT_CHILD(PFcoreopt_RIGHT_CHILD(p));
		kids[2] = PFcoreopt_RIGHT_CHILD(PFcoreopt_RIGHT_CHILD(p));
		break;
	case 23:
		kids[0] = PFcoreopt_LEFT_CHILD(PFcoreopt_LEFT_CHILD(p));
		kids[1] = PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(p));
		break;
	case 25:
		kids[0] = PFcoreopt_LEFT_CHILD(PFcoreopt_LEFT_CHILD(p));
		break;
	case 26:
		kids[0] = PFcoreopt_LEFT_CHILD(PFcoreopt_LEFT_CHILD(p));
		kids[1] = PFcoreopt_LEFT_CHILD(PFcoreopt_RIGHT_CHILD(PFcoreopt_LEFT_CHILD(p)));
		break;
	case 42:
	case 43:
	case 45:
	case 46:
	case 83:
	case 89:
	case 28:
	case 96:
	case 100:
	case 101:
	case 102:
	case 103:
	case 104:
	case 105:
	case 106:
	case 111:
		break;
	case 40:
	case 41:
	case 93:
	case 29:
	case 56:
	case 84:
	case 85:
	case 97:
	case 113:
		kids[0] = p;
		break;
	case 94:
	case 47:
	case 17:
	case 21:
	case 57:
	case 58:
	case 59:
	case 60:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 66:
	case 67:
	case 68:
	case 69:
	case 70:
	case 79:
	case 80:
	case 81:
	case 86:
	case 90:
	case 91:
	case 114:
		kids[0] = PFcoreopt_LEFT_CHILD(p);
		break;
	case 115:
		kids[0] = PFcoreopt_LEFT_CHILD(PFcoreopt_RIGHT_CHILD(p));
		kids[1] = PFcoreopt_RIGHT_CHILD(PFcoreopt_RIGHT_CHILD(p));
		break;
	case 1:
	case 2:
	case 34:
	case 92:
	case 95:
	case 24:
	case 50:
	case 51:
	case 75:
	case 32:
	case 30:
	case 78:
	case 82:
	case 87:
	case 88:
	case 27:
	case 107:
	case 110:
	case 112:
	case 116:
		kids[0] = PFcoreopt_LEFT_CHILD(p);
		kids[1] = PFcoreopt_RIGHT_CHILD(p);
		break;
	}
	return kids;
}
#ifdef __STDC__
PFcoreopt_NODEPTR_TYPE PFcoreopt_child(PFcoreopt_NODEPTR_TYPE p, int index) {
#else
PFcoreopt_NODEPTR_TYPE PFcoreopt_child(p, index) PFcoreopt_NODEPTR_TYPE p; int index; {
#endif
	PFcoreopt_assert(p, PFcoreopt_PANIC("NULL pointer passed to PFcoreopt_child\n"));
	switch (index) {
	case 0:
		return PFcoreopt_LEFT_CHILD(p);
	case 1:
		return PFcoreopt_RIGHT_CHILD(p);
	}
	PFcoreopt_PANIC("Bad index %d in PFcoreopt_child;\n", index);
	abort();
	return 0;
}
#ifdef __STDC__
int PFcoreopt_op_label(PFcoreopt_NODEPTR_TYPE p) {
#else
int PFcoreopt_op_label(p) PFcoreopt_NODEPTR_TYPE p; {
#endif
	PFcoreopt_assert(p, PFcoreopt_PANIC("NULL pointer passed to PFcoreopt_op_label\n"));
	return PFcoreopt_OP_LABEL(p);
}
#ifdef __STDC__
int PFcoreopt_state_label(PFcoreopt_NODEPTR_TYPE p) {
#else
int PFcoreopt_state_label(p) PFcoreopt_NODEPTR_TYPE p; {
#endif
	PFcoreopt_assert(p, PFcoreopt_PANIC("NULL pointer passed to PFcoreopt_state_label\n"));
	return PFcoreopt_STATE_LABEL(p);
}
#endif /* PFcoreopt_INCLUDE_EXTRA */
#define PFcoreopt_FunParam_NT 20
#define PFcoreopt_FunctionBody_NT 19
#define PFcoreopt_ParamList_NT 18
#define PFcoreopt_FunctionDecl_NT 17
#define PFcoreopt_FunctionDecls_NT 16
#define PFcoreopt_LiteralValue_NT 15
#define PFcoreopt_Atom_NT 14
#define PFcoreopt_FunctionArgs_NT 13
#define PFcoreopt_FunExpr_NT 12
#define PFcoreopt_TagName_NT 11
#define PFcoreopt_LocationSteps_NT 10
#define PFcoreopt_LocationStep_NT 9
#define PFcoreopt_SequenceTypeCast_NT 8
#define PFcoreopt_SequenceType_NT 7
#define PFcoreopt_OrderSpecs_NT 6
#define PFcoreopt_WhereExpr_NT 5
#define PFcoreopt_OptVar_NT 4
#define PFcoreopt_OptBindExpr_NT 3
#define PFcoreopt_CoreExpr_NT 2
#define PFcoreopt_Query_NT 1
#define PFcoreopt_NT 20
char * PFcoreopt_opname[] = {
	0, /* 0 */
	"var", /* 1 */
	"lit_str", /* 2 */
	"lit_int", /* 3 */
	"lit_dec", /* 4 */
	"lit_dbl", /* 5 */
	"nil", /* 6 */
	"seq", /* 7 */
	"twig_seq", /* 8 */
	"ordered", /* 9 */
	"unordered", /* 10 */
	0, /* 11 */
	0, /* 12 */
	0, /* 13 */
	"flwr", /* 14 */
	"let", /* 15 */
	"letbind", /* 16 */
	"for_", /* 17 */
	"forbind", /* 18 */
	"forvars", /* 19 */
	"where", /* 20 */
	"orderby", /* 21 */
	"orderspecs", /* 22 */
	"apply", /* 23 */
	"arg", /* 24 */
	"typesw", /* 25 */
	"cases", /* 26 */
	"case_", /* 27 */
	"default_", /* 28 */
	"seqtype", /* 29 */
	"seqcast", /* 30 */
	"proof", /* 31 */
	"subty", /* 32 */
	"stattype", /* 33 */
	"if_", /* 34 */
	"then_else", /* 35 */
	0, /* 36 */
	0, /* 37 */
	0, /* 38 */
	0, /* 39 */
	"locsteps", /* 40 */
	"ancestor", /* 41 */
	"ancestor_or_self", /* 42 */
	"attribute", /* 43 */
	"child", /* 44 */
	"descendant", /* 45 */
	"descendant_or_self", /* 46 */
	"following", /* 47 */
	"following_sibling", /* 48 */
	"parent", /* 49 */
	"preceding", /* 50 */
	"preceding_sibling", /* 51 */
	"self", /* 52 */
	"select_narrow", /* 53 */
	"select_wide", /* 54 */
	"elem", /* 55 */
	"attr", /* 56 */
	"text", /* 57 */
	"doc", /* 58 */
	"comment", /* 59 */
	"pi", /* 60 */
	"tag", /* 61 */
	0, /* 62 */
	0, /* 63 */
	0, /* 64 */
	"true_", /* 65 */
	"false_", /* 66 */
	"empty", /* 67 */
	"main", /* 68 */
	"fun_decls", /* 69 */
	"fun_decl", /* 70 */
	"params", /* 71 */
	"param", /* 72 */
	"cast", /* 73 */
	"recursion", /* 74 */
	"seed", /* 75 */
	"xrpc"
};
char PFcoreopt_arity[] = {
	-1, /* 0 */
	0, /* 1 */
	0, /* 2 */
	0, /* 3 */
	0, /* 4 */
	0, /* 5 */
	0, /* 6 */
	2, /* 7 */
	2, /* 8 */
	1, /* 9 */
	1, /* 10 */
	-1, /* 11 */
	-1, /* 12 */
	-1, /* 13 */
	2, /* 14 */
	2, /* 15 */
	2, /* 16 */
	2, /* 17 */
	2, /* 18 */
	2, /* 19 */
	2, /* 20 */
	2, /* 21 */
	2, /* 22 */
	1, /* 23 */
	2, /* 24 */
	2, /* 25 */
	2, /* 26 */
	2, /* 27 */
	1, /* 28 */
	0, /* 29 */
	2, /* 30 */
	2, /* 31 */
	2, /* 32 */
	1, /* 33 */
	2, /* 34 */
	2, /* 35 */
	-1, /* 36 */
	-1, /* 37 */
	-1, /* 38 */
	-1, /* 39 */
	2, /* 40 */
	1, /* 41 */
	1, /* 42 */
	1, /* 43 */
	1, /* 44 */
	1, /* 45 */
	1, /* 46 */
	1, /* 47 */
	1, /* 48 */
	1, /* 49 */
	1, /* 50 */
	1, /* 51 */
	1, /* 52 */
	1, /* 53 */
	1, /* 54 */
	2, /* 55 */
	2, /* 56 */
	1, /* 57 */
	1, /* 58 */
	1, /* 59 */
	2, /* 60 */
	0, /* 61 */
	-1, /* 62 */
	-1, /* 63 */
	-1, /* 64 */
	0, /* 65 */
	0, /* 66 */
	0, /* 67 */
	2, /* 68 */
	2, /* 69 */
	2, /* 70 */
	2, /* 71 */
	2, /* 72 */
	2, /* 73 */
	2, /* 74 */
	2, /* 75 */
	2
};
int PFcoreopt_max_op = 76;
int PFcoreopt_max_state = 130;
#define PFcoreopt_Max_state 130
char *PFcoreopt_string[] = {
	0,
	"Query: main(FunctionDecls, CoreExpr)",
	"CoreExpr: flwr(OptBindExpr, WhereExpr)",
	"CoreExpr: flwr(for_(forbind(forvars(var, nil), CoreExpr), nil), var)",
	"CoreExpr: flwr(let(letbind(var, CoreExpr), nil), var)",
	"OptBindExpr: for_(forbind(forvars(var, OptVar), CoreExpr), OptBindExpr)",
	0,
	0,
	0,
	0,
	"OptBindExpr: let(letbind(var, Atom), OptBindExpr)",
	"OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr)",
	"OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr)",
	"CoreExpr: typesw(CoreExpr, cases(case_(SequenceType, CoreExpr), default_(CoreExpr)))",
	0,
	"CoreExpr: seq(seq(CoreExpr, CoreExpr), CoreExpr)",
	"CoreExpr: seq(empty, CoreExpr)",
	"CoreExpr: seq(CoreExpr, empty)",
	"CoreExpr: twig_seq(CoreExpr, seq(CoreExpr, CoreExpr))",
	"CoreExpr: twig_seq(seq(CoreExpr, CoreExpr), CoreExpr)",
	"CoreExpr: twig_seq(empty, CoreExpr)",
	"CoreExpr: twig_seq(CoreExpr, empty)",
	"CoreExpr: elem(TagName, seq(CoreExpr, CoreExpr))",
	"CoreExpr: doc(seq(CoreExpr, CoreExpr))",
	"SequenceTypeCast: seqcast(SequenceType, CoreExpr)",
	"FunExpr: apply(arg(CoreExpr, nil))",
	"FunExpr: apply(arg(CoreExpr, arg(CoreExpr, nil)))",
	"CoreExpr: cast(SequenceType, CoreExpr)",
	"Atom: var",
	"CoreExpr: LocationSteps",
	"CoreExpr: elem(TagName, CoreExpr)",
	"CoreExpr: if_(CoreExpr, then_else(CoreExpr, empty))",
	"LocationSteps: locsteps(LocationStep, CoreExpr)",
	"WhereExpr: where(true_, WhereExpr)",
	"WhereExpr: where(CoreExpr, WhereExpr)",
	"CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr))",
	0,
	0,
	0,
	0,
	"CoreExpr: Atom",
	"CoreExpr: SequenceTypeCast",
	"OptVar: nil",
	"OptVar: var",
	"OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr)",
	"OptBindExpr: nil",
	"SequenceType: seqtype",
	"SequenceType: stattype(CoreExpr)",
	"CoreExpr: proof(subty(CoreExpr, SequenceType), CoreExpr)",
	0,
	"CoreExpr: seq(CoreExpr, CoreExpr)",
	"CoreExpr: twig_seq(CoreExpr, CoreExpr)",
	0,
	0,
	0,
	0,
	"CoreExpr: LocationStep",
	"LocationStep: ancestor(SequenceType)",
	"LocationStep: ancestor_or_self(SequenceType)",
	"LocationStep: attribute(SequenceType)",
	"LocationStep: child(SequenceType)",
	"LocationStep: descendant(SequenceType)",
	"LocationStep: descendant_or_self(SequenceType)",
	"LocationStep: following(SequenceType)",
	"LocationStep: following_sibling(SequenceType)",
	"LocationStep: parent(SequenceType)",
	"LocationStep: preceding(SequenceType)",
	"LocationStep: preceding_sibling(SequenceType)",
	"LocationStep: self(SequenceType)",
	"LocationStep: select_narrow(SequenceType)",
	"LocationStep: select_wide(SequenceType)",
	0,
	0,
	0,
	0,
	"LocationSteps: locsteps(LocationStep, LocationSteps)",
	0,
	0,
	"CoreExpr: attr(TagName, CoreExpr)",
	"CoreExpr: text(CoreExpr)",
	"CoreExpr: doc(CoreExpr)",
	"CoreExpr: comment(CoreExpr)",
	"CoreExpr: pi(CoreExpr, CoreExpr)",
	"TagName: tag",
	"TagName: CoreExpr",
	"CoreExpr: FunExpr",
	"FunExpr: apply(FunctionArgs)",
	"FunctionArgs: arg(CoreExpr, FunctionArgs)",
	"FunctionArgs: arg(SequenceTypeCast, FunctionArgs)",
	"FunctionArgs: nil",
	"CoreExpr: ordered(CoreExpr)",
	"CoreExpr: unordered(CoreExpr)",
	"WhereExpr: orderby(OrderSpecs, CoreExpr)",
	"WhereExpr: CoreExpr",
	"OrderSpecs: orderspecs(CoreExpr, nil)",
	"OrderSpecs: orderspecs(CoreExpr, OrderSpecs)",
	"Atom: empty",
	"Atom: LiteralValue",
	0,
	0,
	"LiteralValue: lit_str",
	"LiteralValue: lit_int",
	"LiteralValue: lit_dec",
	"LiteralValue: lit_dbl",
	"LiteralValue: true_",
	"LiteralValue: false_",
	"FunctionDecls: nil",
	"FunctionDecls: fun_decls(FunctionDecl, FunctionDecls)",
	0,
	0,
	"FunctionDecl: fun_decl(ParamList, FunctionBody)",
	"ParamList: nil",
	"ParamList: params(FunParam, ParamList)",
	"FunctionBody: CoreExpr",
	"FunParam: param(SequenceType, var)",
	"CoreExpr: recursion(var, seed(CoreExpr, CoreExpr))",
	"CoreExpr: xrpc(CoreExpr, FunExpr)",
};
int PFcoreopt_max_rule = 116;
#define PFcoreopt_Max_rule 116
short PFcoreopt_rule_descriptor_0[] = { 0, 0 };
short PFcoreopt_rule_descriptor_1[] = {   -1,   68,  -16,   -2, };
short PFcoreopt_rule_descriptor_2[] = {   -2,   14,   -3,   -5, };
short PFcoreopt_rule_descriptor_3[] = {   -2,   14,   17,   18,   19,    1,    6,   -2,    6,    1, };
short PFcoreopt_rule_descriptor_4[] = {   -2,   14,   15,   16,    1,   -2,    6,    1, };
short PFcoreopt_rule_descriptor_5[] = {   -3,   17,   18,   19,    1,   -4,   -2,   -3, };
short PFcoreopt_rule_descriptor_10[] = {   -3,   15,   16,    1,  -14,   -3, };
short PFcoreopt_rule_descriptor_11[] = {   -3,   15,   16,    1,   14,   15,   16,    1,   -2,    6,   -5,   -3, };
short PFcoreopt_rule_descriptor_12[] = {   -3,   15,   16,    1,   14,   15,   16,    1,   -2,   -3,   -5,   -3, };
short PFcoreopt_rule_descriptor_13[] = {   -2,   25,   -2,   26,   27,   -7,   -2,   28,   -2, };
short PFcoreopt_rule_descriptor_15[] = {   -2,    7,    7,   -2,   -2,   -2, };
short PFcoreopt_rule_descriptor_16[] = {   -2,    7,   67,   -2, };
short PFcoreopt_rule_descriptor_17[] = {   -2,    7,   -2,   67, };
short PFcoreopt_rule_descriptor_18[] = {   -2,    8,   -2,    7,   -2,   -2, };
short PFcoreopt_rule_descriptor_19[] = {   -2,    8,    7,   -2,   -2,   -2, };
short PFcoreopt_rule_descriptor_20[] = {   -2,    8,   67,   -2, };
short PFcoreopt_rule_descriptor_21[] = {   -2,    8,   -2,   67, };
short PFcoreopt_rule_descriptor_22[] = {   -2,   55,  -11,    7,   -2,   -2, };
short PFcoreopt_rule_descriptor_23[] = {   -2,   58,    7,   -2,   -2, };
short PFcoreopt_rule_descriptor_24[] = {   -8,   30,   -7,   -2, };
short PFcoreopt_rule_descriptor_25[] = {  -12,   23,   24,   -2,    6, };
short PFcoreopt_rule_descriptor_26[] = {  -12,   23,   24,   -2,   24,   -2,    6, };
short PFcoreopt_rule_descriptor_27[] = {   -2,   73,   -7,   -2, };
short PFcoreopt_rule_descriptor_28[] = {  -14,    1, };
short PFcoreopt_rule_descriptor_29[] = {   -2,  -10, };
short PFcoreopt_rule_descriptor_30[] = {   -2,   55,  -11,   -2, };
short PFcoreopt_rule_descriptor_31[] = {   -2,   34,   -2,   35,   -2,   67, };
short PFcoreopt_rule_descriptor_32[] = {  -10,   40,   -9,   -2, };
short PFcoreopt_rule_descriptor_33[] = {   -5,   20,   65,   -5, };
short PFcoreopt_rule_descriptor_34[] = {   -5,   20,   -2,   -5, };
short PFcoreopt_rule_descriptor_35[] = {   -2,   34,   -2,   35,   -2,   -2, };
short PFcoreopt_rule_descriptor_40[] = {   -2,  -14, };
short PFcoreopt_rule_descriptor_41[] = {   -2,   -8, };
short PFcoreopt_rule_descriptor_42[] = {   -4,    6, };
short PFcoreopt_rule_descriptor_43[] = {   -4,    1, };
short PFcoreopt_rule_descriptor_44[] = {   -3,   15,   16,    1,   -2,   -3, };
short PFcoreopt_rule_descriptor_45[] = {   -3,    6, };
short PFcoreopt_rule_descriptor_46[] = {   -7,   29, };
short PFcoreopt_rule_descriptor_47[] = {   -7,   33,   -2, };
short PFcoreopt_rule_descriptor_48[] = {   -2,   31,   32,   -2,   -7,   -2, };
short PFcoreopt_rule_descriptor_50[] = {   -2,    7,   -2,   -2, };
short PFcoreopt_rule_descriptor_51[] = {   -2,    8,   -2,   -2, };
short PFcoreopt_rule_descriptor_56[] = {   -2,   -9, };
short PFcoreopt_rule_descriptor_57[] = {   -9,   41,   -7, };
short PFcoreopt_rule_descriptor_58[] = {   -9,   42,   -7, };
short PFcoreopt_rule_descriptor_59[] = {   -9,   43,   -7, };
short PFcoreopt_rule_descriptor_60[] = {   -9,   44,   -7, };
short PFcoreopt_rule_descriptor_61[] = {   -9,   45,   -7, };
short PFcoreopt_rule_descriptor_62[] = {   -9,   46,   -7, };
short PFcoreopt_rule_descriptor_63[] = {   -9,   47,   -7, };
short PFcoreopt_rule_descriptor_64[] = {   -9,   48,   -7, };
short PFcoreopt_rule_descriptor_65[] = {   -9,   49,   -7, };
short PFcoreopt_rule_descriptor_66[] = {   -9,   50,   -7, };
short PFcoreopt_rule_descriptor_67[] = {   -9,   51,   -7, };
short PFcoreopt_rule_descriptor_68[] = {   -9,   52,   -7, };
short PFcoreopt_rule_descriptor_69[] = {   -9,   53,   -7, };
short PFcoreopt_rule_descriptor_70[] = {   -9,   54,   -7, };
short PFcoreopt_rule_descriptor_75[] = {  -10,   40,   -9,  -10, };
short PFcoreopt_rule_descriptor_78[] = {   -2,   56,  -11,   -2, };
short PFcoreopt_rule_descriptor_79[] = {   -2,   57,   -2, };
short PFcoreopt_rule_descriptor_80[] = {   -2,   58,   -2, };
short PFcoreopt_rule_descriptor_81[] = {   -2,   59,   -2, };
short PFcoreopt_rule_descriptor_82[] = {   -2,   60,   -2,   -2, };
short PFcoreopt_rule_descriptor_83[] = {  -11,   61, };
short PFcoreopt_rule_descriptor_84[] = {  -11,   -2, };
short PFcoreopt_rule_descriptor_85[] = {   -2,  -12, };
short PFcoreopt_rule_descriptor_86[] = {  -12,   23,  -13, };
short PFcoreopt_rule_descriptor_87[] = {  -13,   24,   -2,  -13, };
short PFcoreopt_rule_descriptor_88[] = {  -13,   24,   -8,  -13, };
short PFcoreopt_rule_descriptor_89[] = {  -13,    6, };
short PFcoreopt_rule_descriptor_90[] = {   -2,    9,   -2, };
short PFcoreopt_rule_descriptor_91[] = {   -2,   10,   -2, };
short PFcoreopt_rule_descriptor_92[] = {   -5,   21,   -6,   -2, };
short PFcoreopt_rule_descriptor_93[] = {   -5,   -2, };
short PFcoreopt_rule_descriptor_94[] = {   -6,   22,   -2,    6, };
short PFcoreopt_rule_descriptor_95[] = {   -6,   22,   -2,   -6, };
short PFcoreopt_rule_descriptor_96[] = {  -14,   67, };
short PFcoreopt_rule_descriptor_97[] = {  -14,  -15, };
short PFcoreopt_rule_descriptor_100[] = {  -15,    2, };
short PFcoreopt_rule_descriptor_101[] = {  -15,    3, };
short PFcoreopt_rule_descriptor_102[] = {  -15,    4, };
short PFcoreopt_rule_descriptor_103[] = {  -15,    5, };
short PFcoreopt_rule_descriptor_104[] = {  -15,   65, };
short PFcoreopt_rule_descriptor_105[] = {  -15,   66, };
short PFcoreopt_rule_descriptor_106[] = {  -16,    6, };
short PFcoreopt_rule_descriptor_107[] = {  -16,   69,  -17,  -16, };
short PFcoreopt_rule_descriptor_110[] = {  -17,   70,  -18,  -19, };
short PFcoreopt_rule_descriptor_111[] = {  -18,    6, };
short PFcoreopt_rule_descriptor_112[] = {  -18,   71,  -20,  -18, };
short PFcoreopt_rule_descriptor_113[] = {  -19,   -2, };
short PFcoreopt_rule_descriptor_114[] = {  -20,   72,   -7,    1, };
short PFcoreopt_rule_descriptor_115[] = {   -2,   74,    1,   75,   -2,   -2, };
short PFcoreopt_rule_descriptor_116[] = {   -2,   76,   -2,  -12, };
/* PFcoreopt_rule_descriptors[0][1] = 1 iff grammar is normal form. */
short * PFcoreopt_rule_descriptors[] = {
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_1,
	PFcoreopt_rule_descriptor_2,
	PFcoreopt_rule_descriptor_3,
	PFcoreopt_rule_descriptor_4,
	PFcoreopt_rule_descriptor_5,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_10,
	PFcoreopt_rule_descriptor_11,
	PFcoreopt_rule_descriptor_12,
	PFcoreopt_rule_descriptor_13,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_15,
	PFcoreopt_rule_descriptor_16,
	PFcoreopt_rule_descriptor_17,
	PFcoreopt_rule_descriptor_18,
	PFcoreopt_rule_descriptor_19,
	PFcoreopt_rule_descriptor_20,
	PFcoreopt_rule_descriptor_21,
	PFcoreopt_rule_descriptor_22,
	PFcoreopt_rule_descriptor_23,
	PFcoreopt_rule_descriptor_24,
	PFcoreopt_rule_descriptor_25,
	PFcoreopt_rule_descriptor_26,
	PFcoreopt_rule_descriptor_27,
	PFcoreopt_rule_descriptor_28,
	PFcoreopt_rule_descriptor_29,
	PFcoreopt_rule_descriptor_30,
	PFcoreopt_rule_descriptor_31,
	PFcoreopt_rule_descriptor_32,
	PFcoreopt_rule_descriptor_33,
	PFcoreopt_rule_descriptor_34,
	PFcoreopt_rule_descriptor_35,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_40,
	PFcoreopt_rule_descriptor_41,
	PFcoreopt_rule_descriptor_42,
	PFcoreopt_rule_descriptor_43,
	PFcoreopt_rule_descriptor_44,
	PFcoreopt_rule_descriptor_45,
	PFcoreopt_rule_descriptor_46,
	PFcoreopt_rule_descriptor_47,
	PFcoreopt_rule_descriptor_48,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_50,
	PFcoreopt_rule_descriptor_51,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_56,
	PFcoreopt_rule_descriptor_57,
	PFcoreopt_rule_descriptor_58,
	PFcoreopt_rule_descriptor_59,
	PFcoreopt_rule_descriptor_60,
	PFcoreopt_rule_descriptor_61,
	PFcoreopt_rule_descriptor_62,
	PFcoreopt_rule_descriptor_63,
	PFcoreopt_rule_descriptor_64,
	PFcoreopt_rule_descriptor_65,
	PFcoreopt_rule_descriptor_66,
	PFcoreopt_rule_descriptor_67,
	PFcoreopt_rule_descriptor_68,
	PFcoreopt_rule_descriptor_69,
	PFcoreopt_rule_descriptor_70,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_75,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_78,
	PFcoreopt_rule_descriptor_79,
	PFcoreopt_rule_descriptor_80,
	PFcoreopt_rule_descriptor_81,
	PFcoreopt_rule_descriptor_82,
	PFcoreopt_rule_descriptor_83,
	PFcoreopt_rule_descriptor_84,
	PFcoreopt_rule_descriptor_85,
	PFcoreopt_rule_descriptor_86,
	PFcoreopt_rule_descriptor_87,
	PFcoreopt_rule_descriptor_88,
	PFcoreopt_rule_descriptor_89,
	PFcoreopt_rule_descriptor_90,
	PFcoreopt_rule_descriptor_91,
	PFcoreopt_rule_descriptor_92,
	PFcoreopt_rule_descriptor_93,
	PFcoreopt_rule_descriptor_94,
	PFcoreopt_rule_descriptor_95,
	PFcoreopt_rule_descriptor_96,
	PFcoreopt_rule_descriptor_97,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_100,
	PFcoreopt_rule_descriptor_101,
	PFcoreopt_rule_descriptor_102,
	PFcoreopt_rule_descriptor_103,
	PFcoreopt_rule_descriptor_104,
	PFcoreopt_rule_descriptor_105,
	PFcoreopt_rule_descriptor_106,
	PFcoreopt_rule_descriptor_107,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_0,
	PFcoreopt_rule_descriptor_110,
	PFcoreopt_rule_descriptor_111,
	PFcoreopt_rule_descriptor_112,
	PFcoreopt_rule_descriptor_113,
	PFcoreopt_rule_descriptor_114,
	PFcoreopt_rule_descriptor_115,
	PFcoreopt_rule_descriptor_116,
};
short PFcoreopt_cost[][4] = {
	{    0,    0,    0,    0}, /* (none) = 0 */
	{   10,    0,    0,    0}, /* Query: main(FunctionDecls, CoreExpr) = 1 */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 2 */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(for_(forbind(forvars(var, nil), CoreExpr), nil), var) = 3 */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(let(letbind(var, CoreExpr), nil), var) = 4 */
	{   10,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, OptVar), CoreExpr), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) = 6 */
	{    0,    0,    0,    0}, /* (none) = 7 */
	{    0,    0,    0,    0}, /* (none) = 8 */
	{    0,    0,    0,    0}, /* (none) = 9 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, Atom), OptBindExpr) = 10 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 11 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 12 */
	{   10,    0,    0,    0}, /* CoreExpr: typesw(CoreExpr, cases(case_(SequenceType, CoreExpr), default_(CoreExpr))) = 13 */
	{    0,    0,    0,    0}, /* (none) = 14 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(seq(CoreExpr, CoreExpr), CoreExpr) = 15 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(empty, CoreExpr) = 16 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, empty) = 17 */
	{   10,    0,    0,    0}, /* CoreExpr: twig_seq(CoreExpr, seq(CoreExpr, CoreExpr)) = 18 */
	{   10,    0,    0,    0}, /* CoreExpr: twig_seq(seq(CoreExpr, CoreExpr), CoreExpr) = 19 */
	{   10,    0,    0,    0}, /* CoreExpr: twig_seq(empty, CoreExpr) = 20 */
	{   10,    0,    0,    0}, /* CoreExpr: twig_seq(CoreExpr, empty) = 21 */
	{   10,    0,    0,    0}, /* CoreExpr: elem(TagName, seq(CoreExpr, CoreExpr)) = 22 */
	{   10,    0,    0,    0}, /* CoreExpr: doc(seq(CoreExpr, CoreExpr)) = 23 */
	{   10,    0,    0,    0}, /* SequenceTypeCast: seqcast(SequenceType, CoreExpr) = 24 */
	{   10,    0,    0,    0}, /* FunExpr: apply(arg(CoreExpr, nil)) = 25 */
	{   10,    0,    0,    0}, /* FunExpr: apply(arg(CoreExpr, arg(CoreExpr, nil))) = 26 */
	{   10,    0,    0,    0}, /* CoreExpr: cast(SequenceType, CoreExpr) = 27 */
	{   10,    0,    0,    0}, /* Atom: var = 28 */
	{   10,    0,    0,    0}, /* CoreExpr: LocationSteps = 29 */
	{   10,    0,    0,    0}, /* CoreExpr: elem(TagName, CoreExpr) = 30 */
	{   10,    0,    0,    0}, /* CoreExpr: if_(CoreExpr, then_else(CoreExpr, empty)) = 31 */
	{   10,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, CoreExpr) = 32 */
	{   10,    0,    0,    0}, /* WhereExpr: where(true_, WhereExpr) = 33 */
	{   10,    0,    0,    0}, /* WhereExpr: where(CoreExpr, WhereExpr) = 34 */
	{   10,    0,    0,    0}, /* CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr)) = 35 */
	{    0,    0,    0,    0}, /* (none) = 36 */
	{    0,    0,    0,    0}, /* (none) = 37 */
	{    0,    0,    0,    0}, /* (none) = 38 */
	{    0,    0,    0,    0}, /* (none) = 39 */
	{   10,    0,    0,    0}, /* CoreExpr: Atom = 40 */
	{   10,    0,    0,    0}, /* CoreExpr: SequenceTypeCast = 41 */
	{   10,    0,    0,    0}, /* OptVar: nil = 42 */
	{   10,    0,    0,    0}, /* OptVar: var = 43 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr) = 44 */
	{   10,    0,    0,    0}, /* OptBindExpr: nil = 45 */
	{   10,    0,    0,    0}, /* SequenceType: seqtype = 46 */
	{   10,    0,    0,    0}, /* SequenceType: stattype(CoreExpr) = 47 */
	{   10,    0,    0,    0}, /* CoreExpr: proof(subty(CoreExpr, SequenceType), CoreExpr) = 48 */
	{    0,    0,    0,    0}, /* (none) = 49 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, CoreExpr) = 50 */
	{   10,    0,    0,    0}, /* CoreExpr: twig_seq(CoreExpr, CoreExpr) = 51 */
	{    0,    0,    0,    0}, /* (none) = 52 */
	{    0,    0,    0,    0}, /* (none) = 53 */
	{    0,    0,    0,    0}, /* (none) = 54 */
	{    0,    0,    0,    0}, /* (none) = 55 */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{   10,    0,    0,    0}, /* LocationStep: ancestor(SequenceType) = 57 */
	{   10,    0,    0,    0}, /* LocationStep: ancestor_or_self(SequenceType) = 58 */
	{   10,    0,    0,    0}, /* LocationStep: attribute(SequenceType) = 59 */
	{   10,    0,    0,    0}, /* LocationStep: child(SequenceType) = 60 */
	{   10,    0,    0,    0}, /* LocationStep: descendant(SequenceType) = 61 */
	{   10,    0,    0,    0}, /* LocationStep: descendant_or_self(SequenceType) = 62 */
	{   10,    0,    0,    0}, /* LocationStep: following(SequenceType) = 63 */
	{   10,    0,    0,    0}, /* LocationStep: following_sibling(SequenceType) = 64 */
	{   10,    0,    0,    0}, /* LocationStep: parent(SequenceType) = 65 */
	{   10,    0,    0,    0}, /* LocationStep: preceding(SequenceType) = 66 */
	{   10,    0,    0,    0}, /* LocationStep: preceding_sibling(SequenceType) = 67 */
	{   10,    0,    0,    0}, /* LocationStep: self(SequenceType) = 68 */
	{   10,    0,    0,    0}, /* LocationStep: select_narrow(SequenceType) = 69 */
	{   10,    0,    0,    0}, /* LocationStep: select_wide(SequenceType) = 70 */
	{    0,    0,    0,    0}, /* (none) = 71 */
	{    0,    0,    0,    0}, /* (none) = 72 */
	{    0,    0,    0,    0}, /* (none) = 73 */
	{    0,    0,    0,    0}, /* (none) = 74 */
	{   10,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, LocationSteps) = 75 */
	{    0,    0,    0,    0}, /* (none) = 76 */
	{    0,    0,    0,    0}, /* (none) = 77 */
	{   10,    0,    0,    0}, /* CoreExpr: attr(TagName, CoreExpr) = 78 */
	{   10,    0,    0,    0}, /* CoreExpr: text(CoreExpr) = 79 */
	{   10,    0,    0,    0}, /* CoreExpr: doc(CoreExpr) = 80 */
	{   10,    0,    0,    0}, /* CoreExpr: comment(CoreExpr) = 81 */
	{   10,    0,    0,    0}, /* CoreExpr: pi(CoreExpr, CoreExpr) = 82 */
	{   10,    0,    0,    0}, /* TagName: tag = 83 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{   10,    0,    0,    0}, /* CoreExpr: FunExpr = 85 */
	{   10,    0,    0,    0}, /* FunExpr: apply(FunctionArgs) = 86 */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 87 */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 88 */
	{   10,    0,    0,    0}, /* FunctionArgs: nil = 89 */
	{   10,    0,    0,    0}, /* CoreExpr: ordered(CoreExpr) = 90 */
	{   10,    0,    0,    0}, /* CoreExpr: unordered(CoreExpr) = 91 */
	{   10,    0,    0,    0}, /* WhereExpr: orderby(OrderSpecs, CoreExpr) = 92 */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{   10,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, nil) = 94 */
	{   10,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, OrderSpecs) = 95 */
	{   10,    0,    0,    0}, /* Atom: empty = 96 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 97 */
	{    0,    0,    0,    0}, /* (none) = 98 */
	{    0,    0,    0,    0}, /* (none) = 99 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_str = 100 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_int = 101 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_dec = 102 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_dbl = 103 */
	{   10,    0,    0,    0}, /* LiteralValue: true_ = 104 */
	{   10,    0,    0,    0}, /* LiteralValue: false_ = 105 */
	{   10,    0,    0,    0}, /* FunctionDecls: nil = 106 */
	{   10,    0,    0,    0}, /* FunctionDecls: fun_decls(FunctionDecl, FunctionDecls) = 107 */
	{    0,    0,    0,    0}, /* (none) = 108 */
	{    0,    0,    0,    0}, /* (none) = 109 */
	{   10,    0,    0,    0}, /* FunctionDecl: fun_decl(ParamList, FunctionBody) = 110 */
	{   10,    0,    0,    0}, /* ParamList: nil = 111 */
	{   10,    0,    0,    0}, /* ParamList: params(FunParam, ParamList) = 112 */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{   10,    0,    0,    0}, /* FunParam: param(SequenceType, var) = 114 */
	{   10,    0,    0,    0}, /* CoreExpr: recursion(var, seed(CoreExpr, CoreExpr)) = 115 */
	{   10,    0,    0,    0}, /* CoreExpr: xrpc(CoreExpr, FunExpr) = 116 */
};

short PFcoreopt_delta_cost[131][21][4] = {
{{0}}, /* state 0 */
{ /* state #1: ancestor(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: ancestor(SequenceType) = 57 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #2: ancestor_or_self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: ancestor_or_self(SequenceType) = 58 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #3: apply(arg(false_, arg(false_, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: FunExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* FunExpr: apply(arg(CoreExpr, arg(CoreExpr, nil))) = 26 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #4: apply(nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: FunExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* FunExpr: apply(FunctionArgs) = 86 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #5: apply(arg(false_, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: FunExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* FunExpr: apply(arg(CoreExpr, nil)) = 25 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #6: arg(false_, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #7: arg(seqcast(seqtype, false_), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 88 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #8: arg(false_, arg(false_, arg(false_, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #9: arg(false_, arg(false_, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #10: arg(seqcast(seqtype, false_), arg(false_, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 88 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #11: arg(seqcast(seqtype, false_), arg(seqcast(seqtype, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 88 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #12: arg(seqcast(seqtype, false_), arg(false_, arg(false_, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 88 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #13: arg(false_, arg(seqcast(seqtype, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #14: attr(false_, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: attr(TagName, CoreExpr) = 78 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #15: attribute(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: attribute(SequenceType) = 59 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #16: case_(seqtype, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #17: cases(case_(seqtype, false_), default_(false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #18: cast(seqtype, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: cast(SequenceType, CoreExpr) = 27 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #19: child(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: child(SequenceType) = 60 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #20: comment(false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: comment(CoreExpr) = 81 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #21: default_(false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #22: descendant(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: descendant(SequenceType) = 61 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #23: descendant_or_self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: descendant_or_self(SequenceType) = 62 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #24: doc(false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: doc(CoreExpr) = 80 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #25: doc(seq(false_, false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: doc(seq(CoreExpr, CoreExpr)) = 23 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #26: elem(false_, seq(false_, false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: elem(TagName, seq(CoreExpr, CoreExpr)) = 22 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #27: elem(false_, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: elem(TagName, CoreExpr) = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #28: empty */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: empty = 96 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #29: false_ */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 97 */
	{    0,    0,    0,    0}, /* LiteralValue: false_ = 105 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #30: flwr(let(letbind(var, false_), let(letbind(var, false_), nil)), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #31: flwr(for_(forbind(forvars(var, nil), false_), nil), var) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(for_(forbind(forvars(var, nil), CoreExpr), nil), var) = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #32: flwr(let(letbind(var, seq(false_, false_)), nil), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #33: flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), nil), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #34: flwr(nil, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #35: flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), nil), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #36: flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), let(letbind(var, false_), nil)), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #37: flwr(let(letbind(var, false_), nil), var) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(let(letbind(var, CoreExpr), nil), var) = 4 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #38: flwr(let(letbind(var, false_), nil), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #39: flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), let(letbind(var, false_), nil)), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #40: flwr(let(letbind(var, seq(false_, false_)), let(letbind(var, false_), nil)), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #41: following(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: following(SequenceType) = 63 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #42: following_sibling(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: following_sibling(SequenceType) = 64 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #43: for_(forbind(forvars(var, nil), false_), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, OptVar), CoreExpr), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #44: for_(forbind(forvars(var, nil), false_), let(letbind(var, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, OptVar), CoreExpr), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #45: forbind(forvars(var, var), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #46: forbind(forvars(var, nil), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #47: forvars(var, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #48: forvars(var, var) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #49: fun_decl(nil, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionDecl: fun_decl(ParamList, FunctionBody) = 110 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #50: fun_decls(fun_decl(nil, false_), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionDecls: fun_decls(FunctionDecl, FunctionDecls) = 107 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #51: if_(false_, then_else(false_, empty)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: if_(CoreExpr, then_else(CoreExpr, empty)) = 31 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #52: if_(false_, then_else(false_, false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr)) = 35 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #53: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), nil), false_)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #54: let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), let(letbind(var, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #55: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), let(letbind(var, false_), nil)), false_)), let(letbind(var, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #56: let(letbind(var, false_), let(letbind(var, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, Atom), OptBindExpr) = 10 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #57: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), let(letbind(var, false_), nil)), false_)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #58: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), nil), false_)), let(letbind(var, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #59: let(letbind(var, seq(false_, false_)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr) = 44 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #60: let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #61: let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), let(letbind(var, false_), nil)), false_)), let(letbind(var, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #62: let(letbind(var, flwr(let(letbind(var, false_), let(letbind(var, false_), nil)), false_)), let(letbind(var, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #63: let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), let(letbind(var, false_), nil)), false_)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #64: let(letbind(var, flwr(let(letbind(var, false_), let(letbind(var, false_), nil)), false_)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #65: let(letbind(var, false_), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, Atom), OptBindExpr) = 10 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #66: let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), let(letbind(var, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #67: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), nil), false_)), let(letbind(var, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #68: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), nil), false_)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #69: let(letbind(var, seq(false_, false_)), let(letbind(var, false_), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr) = 44 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #70: let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #71: letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #72: letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), let(letbind(var, false_), nil)), false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #73: letbind(var, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #74: letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), nil), false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #75: letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), let(letbind(var, false_), nil)), false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #76: letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), nil), false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #77: letbind(var, seq(false_, false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #78: letbind(var, flwr(let(letbind(var, seq(false_, false_)), let(letbind(var, false_), nil)), false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #79: letbind(var, flwr(let(letbind(var, false_), let(letbind(var, false_), nil)), false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #80: letbind(var, flwr(let(letbind(var, false_), nil), var)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #81: letbind(var, flwr(let(letbind(var, false_), nil), false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #82: lit_dbl */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 97 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_dbl = 103 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #83: lit_dec */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 97 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_dec = 102 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #84: lit_int */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 97 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_int = 101 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #85: lit_str */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 97 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_str = 100 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #86: locsteps(ancestor(seqtype), locsteps(ancestor(seqtype), false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationSteps = 29 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, LocationSteps) = 75 */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #87: locsteps(ancestor(seqtype), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationSteps = 29 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, CoreExpr) = 32 */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #88: main(nil, false_) */
	{0},
	{    0,    0,    0,    0}, /* Query: main(FunctionDecls, CoreExpr) = 1 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #89: nil */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: nil = 45 */
	{   10,    0,    0,    0}, /* OptVar: nil = 42 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: nil = 89 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionDecls: nil = 106 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* ParamList: nil = 111 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #90: orderby(orderspecs(false_, nil), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* WhereExpr: orderby(OrderSpecs, CoreExpr) = 92 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #91: ordered(false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: ordered(CoreExpr) = 90 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #92: orderspecs(false_, orderspecs(false_, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, OrderSpecs) = 95 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #93: orderspecs(false_, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, nil) = 94 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #94: param(seqtype, var) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunParam: param(SequenceType, var) = 114 */
},
{ /* state #95: params(param(seqtype, var), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* ParamList: params(FunParam, ParamList) = 112 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #96: parent(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: parent(SequenceType) = 65 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #97: pi(false_, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: pi(CoreExpr, CoreExpr) = 82 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #98: preceding(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: preceding(SequenceType) = 66 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #99: preceding_sibling(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: preceding_sibling(SequenceType) = 67 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #100: proof(subty(false_, seqtype), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: proof(subty(CoreExpr, SequenceType), CoreExpr) = 48 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #101: recursion(var, seed(false_, false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: recursion(var, seed(CoreExpr, CoreExpr)) = 115 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #102: seed(false_, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #103: select_narrow(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: select_narrow(SequenceType) = 69 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #104: select_wide(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: select_wide(SequenceType) = 70 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #105: self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationStep = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: self(SequenceType) = 68 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #106: seq(seq(seq(false_, false_), false_), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: seq(seq(CoreExpr, CoreExpr), CoreExpr) = 15 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #107: seq(false_, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, CoreExpr) = 50 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #108: seq(seq(false_, false_), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: seq(seq(CoreExpr, CoreExpr), CoreExpr) = 15 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #109: seq(false_, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, empty) = 17 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #110: seq(empty, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: seq(empty, CoreExpr) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #111: seqcast(seqtype, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: SequenceTypeCast = 41 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SequenceTypeCast: seqcast(SequenceType, CoreExpr) = 24 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #112: seqtype */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SequenceType: seqtype = 46 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #113: stattype(false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SequenceType: stattype(CoreExpr) = 47 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #114: subty(false_, seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #115: tag */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* TagName: tag = 83 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #116: text(false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: text(CoreExpr) = 79 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #117: then_else(false_, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #118: then_else(false_, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #119: true_ */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* CoreExpr: Atom = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Atom: LiteralValue = 97 */
	{   10,    0,    0,    0}, /* LiteralValue: true_ = 104 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #120: twig_seq(false_, seq(false_, false_)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: twig_seq(CoreExpr, seq(CoreExpr, CoreExpr)) = 18 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #121: twig_seq(seq(false_, false_), false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: twig_seq(seq(CoreExpr, CoreExpr), CoreExpr) = 19 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #122: twig_seq(false_, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: twig_seq(CoreExpr, CoreExpr) = 51 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #123: twig_seq(empty, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: twig_seq(empty, CoreExpr) = 20 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #124: twig_seq(false_, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: twig_seq(CoreExpr, empty) = 21 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #125: typesw(false_, cases(case_(seqtype, false_), default_(false_))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: typesw(CoreExpr, cases(case_(SequenceType, CoreExpr), default_(CoreExpr))) = 13 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #126: unordered(false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: unordered(CoreExpr) = 91 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #127: var */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptVar: var = 43 */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: var = 28 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #128: where(true_, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* WhereExpr: where(true_, WhereExpr) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #129: where(false_, false_) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* WhereExpr: where(CoreExpr, WhereExpr) = 34 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #130: xrpc(false_, apply(nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: xrpc(CoreExpr, FunExpr) = 116 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 113 */
	{    0,    0,    0,    0}, /* (none) */
},
};

char * PFcoreopt_state_string[] = {
" not a state", /* state 0 */
	"ancestor(seqtype)", /* state #1 */
	"ancestor_or_self(seqtype)", /* state #2 */
	"apply(arg(false_, arg(false_, nil)))", /* state #3 */
	"apply(nil)", /* state #4 */
	"apply(arg(false_, nil))", /* state #5 */
	"arg(false_, nil)", /* state #6 */
	"arg(seqcast(seqtype, false_), nil)", /* state #7 */
	"arg(false_, arg(false_, arg(false_, nil)))", /* state #8 */
	"arg(false_, arg(false_, nil))", /* state #9 */
	"arg(seqcast(seqtype, false_), arg(false_, nil))", /* state #10 */
	"arg(seqcast(seqtype, false_), arg(seqcast(seqtype, false_), nil))", /* state #11 */
	"arg(seqcast(seqtype, false_), arg(false_, arg(false_, nil)))", /* state #12 */
	"arg(false_, arg(seqcast(seqtype, false_), nil))", /* state #13 */
	"attr(false_, false_)", /* state #14 */
	"attribute(seqtype)", /* state #15 */
	"case_(seqtype, false_)", /* state #16 */
	"cases(case_(seqtype, false_), default_(false_))", /* state #17 */
	"cast(seqtype, false_)", /* state #18 */
	"child(seqtype)", /* state #19 */
	"comment(false_)", /* state #20 */
	"default_(false_)", /* state #21 */
	"descendant(seqtype)", /* state #22 */
	"descendant_or_self(seqtype)", /* state #23 */
	"doc(false_)", /* state #24 */
	"doc(seq(false_, false_))", /* state #25 */
	"elem(false_, seq(false_, false_))", /* state #26 */
	"elem(false_, false_)", /* state #27 */
	"empty", /* state #28 */
	"false_", /* state #29 */
	"flwr(let(letbind(var, false_), let(letbind(var, false_), nil)), false_)", /* state #30 */
	"flwr(for_(forbind(forvars(var, nil), false_), nil), var)", /* state #31 */
	"flwr(let(letbind(var, seq(false_, false_)), nil), false_)", /* state #32 */
	"flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), nil), false_)", /* state #33 */
	"flwr(nil, false_)", /* state #34 */
	"flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), nil), false_)", /* state #35 */
	"flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), let(letbind(var, false_), nil)), false_)", /* state #36 */
	"flwr(let(letbind(var, false_), nil), var)", /* state #37 */
	"flwr(let(letbind(var, false_), nil), false_)", /* state #38 */
	"flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), let(letbind(var, false_), nil)), false_)", /* state #39 */
	"flwr(let(letbind(var, seq(false_, false_)), let(letbind(var, false_), nil)), false_)", /* state #40 */
	"following(seqtype)", /* state #41 */
	"following_sibling(seqtype)", /* state #42 */
	"for_(forbind(forvars(var, nil), false_), nil)", /* state #43 */
	"for_(forbind(forvars(var, nil), false_), let(letbind(var, false_), nil))", /* state #44 */
	"forbind(forvars(var, var), false_)", /* state #45 */
	"forbind(forvars(var, nil), false_)", /* state #46 */
	"forvars(var, nil)", /* state #47 */
	"forvars(var, var)", /* state #48 */
	"fun_decl(nil, false_)", /* state #49 */
	"fun_decls(fun_decl(nil, false_), nil)", /* state #50 */
	"if_(false_, then_else(false_, empty))", /* state #51 */
	"if_(false_, then_else(false_, false_))", /* state #52 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), nil), false_)), nil)", /* state #53 */
	"let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), let(letbind(var, false_), nil))", /* state #54 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), let(letbind(var, false_), nil)), false_)), let(letbind(var, false_), nil))", /* state #55 */
	"let(letbind(var, false_), let(letbind(var, false_), nil))", /* state #56 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), let(letbind(var, false_), nil)), false_)), nil)", /* state #57 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), nil), false_)), let(letbind(var, false_), nil))", /* state #58 */
	"let(letbind(var, seq(false_, false_)), nil)", /* state #59 */
	"let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), nil)", /* state #60 */
	"let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), let(letbind(var, false_), nil)), false_)), let(letbind(var, false_), nil))", /* state #61 */
	"let(letbind(var, flwr(let(letbind(var, false_), let(letbind(var, false_), nil)), false_)), let(letbind(var, false_), nil))", /* state #62 */
	"let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), let(letbind(var, false_), nil)), false_)), nil)", /* state #63 */
	"let(letbind(var, flwr(let(letbind(var, false_), let(letbind(var, false_), nil)), false_)), nil)", /* state #64 */
	"let(letbind(var, false_), nil)", /* state #65 */
	"let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), let(letbind(var, false_), nil))", /* state #66 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), nil), false_)), let(letbind(var, false_), nil))", /* state #67 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), nil), false_)), nil)", /* state #68 */
	"let(letbind(var, seq(false_, false_)), let(letbind(var, false_), nil))", /* state #69 */
	"let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), nil)", /* state #70 */
	"letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_))", /* state #71 */
	"letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), let(letbind(var, false_), nil)), false_))", /* state #72 */
	"letbind(var, false_)", /* state #73 */
	"letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(false_, false_)), nil), false_)), nil), false_))", /* state #74 */
	"letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), let(letbind(var, false_), nil)), false_))", /* state #75 */
	"letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, false_), nil), false_)), nil), false_))", /* state #76 */
	"letbind(var, seq(false_, false_))", /* state #77 */
	"letbind(var, flwr(let(letbind(var, seq(false_, false_)), let(letbind(var, false_), nil)), false_))", /* state #78 */
	"letbind(var, flwr(let(letbind(var, false_), let(letbind(var, false_), nil)), false_))", /* state #79 */
	"letbind(var, flwr(let(letbind(var, false_), nil), var))", /* state #80 */
	"letbind(var, flwr(let(letbind(var, false_), nil), false_))", /* state #81 */
	"lit_dbl", /* state #82 */
	"lit_dec", /* state #83 */
	"lit_int", /* state #84 */
	"lit_str", /* state #85 */
	"locsteps(ancestor(seqtype), locsteps(ancestor(seqtype), false_))", /* state #86 */
	"locsteps(ancestor(seqtype), false_)", /* state #87 */
	"main(nil, false_)", /* state #88 */
	"nil", /* state #89 */
	"orderby(orderspecs(false_, nil), false_)", /* state #90 */
	"ordered(false_)", /* state #91 */
	"orderspecs(false_, orderspecs(false_, nil))", /* state #92 */
	"orderspecs(false_, nil)", /* state #93 */
	"param(seqtype, var)", /* state #94 */
	"params(param(seqtype, var), nil)", /* state #95 */
	"parent(seqtype)", /* state #96 */
	"pi(false_, false_)", /* state #97 */
	"preceding(seqtype)", /* state #98 */
	"preceding_sibling(seqtype)", /* state #99 */
	"proof(subty(false_, seqtype), false_)", /* state #100 */
	"recursion(var, seed(false_, false_))", /* state #101 */
	"seed(false_, false_)", /* state #102 */
	"select_narrow(seqtype)", /* state #103 */
	"select_wide(seqtype)", /* state #104 */
	"self(seqtype)", /* state #105 */
	"seq(seq(seq(false_, false_), false_), false_)", /* state #106 */
	"seq(false_, false_)", /* state #107 */
	"seq(seq(false_, false_), false_)", /* state #108 */
	"seq(false_, empty)", /* state #109 */
	"seq(empty, false_)", /* state #110 */
	"seqcast(seqtype, false_)", /* state #111 */
	"seqtype", /* state #112 */
	"stattype(false_)", /* state #113 */
	"subty(false_, seqtype)", /* state #114 */
	"tag", /* state #115 */
	"text(false_)", /* state #116 */
	"then_else(false_, false_)", /* state #117 */
	"then_else(false_, empty)", /* state #118 */
	"true_", /* state #119 */
	"twig_seq(false_, seq(false_, false_))", /* state #120 */
	"twig_seq(seq(false_, false_), false_)", /* state #121 */
	"twig_seq(false_, false_)", /* state #122 */
	"twig_seq(empty, false_)", /* state #123 */
	"twig_seq(false_, empty)", /* state #124 */
	"typesw(false_, cases(case_(seqtype, false_), default_(false_)))", /* state #125 */
	"unordered(false_)", /* state #126 */
	"var", /* state #127 */
	"where(true_, false_)", /* state #128 */
	"where(false_, false_)", /* state #129 */
	"xrpc(false_, apply(nil))", /* state #130 */
};
char *PFcoreopt_ntname[] = {
	"Error: Nonterminals are > 0",
	"Query",
	"CoreExpr",
	"OptBindExpr",
	"OptVar",
	"WhereExpr",
	"OrderSpecs",
	"SequenceType",
	"SequenceTypeCast",
	"LocationStep",
	"LocationSteps",
	"TagName",
	"FunExpr",
	"FunctionArgs",
	"Atom",
	"LiteralValue",
	"FunctionDecls",
	"FunctionDecl",
	"ParamList",
	"FunctionBody",
	"FunParam",
	0
};

short PFcoreopt_closure[21][21] = {
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,   41,   56,
	    29,    0,   85,    0,   40,   40,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,   93,    0,    0,    0,    0,    0,   93,   93,
	    93,    0,   93,    0,   93,   93,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,   84,    0,    0,    0,    0,    0,   84,   84,
	    84,    0,   84,    0,   84,   84,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,   97,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
	{    0,    0,  113,    0,    0,    0,    0,    0,  113,  113,
	   113,    0,  113,    0,  113,  113,    0,    0,    0,    0,
	     0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,},
};
#line 386 "coreopt.brg"


/** Type of a core tree node */
#define TY(p) ((p)->type)

/** Maximum number of pattern leaves */
#define MAX_KIDS 10

static void relabel (PFcnode_t *p,  PFcnode_t **kids);

#include "core_mnemonic.h"

/* helper function that transforms where list into nested if-then-else(empty) */
static PFcnode_t *
transform_where (PFcnode_t *p)
{
    assert (p);
    switch (p->kind) {
        case c_where:
            /* replace where nodes by if-then-else constructs */
            return if_ (L(p), then_else (transform_where (R(p)), empty ()));
        case c_orderby:
            /* also remove orderby node if present
               (static typing ensures that we don't
                prune erroneous order arguments) */
            return R(p);
        default:
            return p;
    }
}

/**
 * Reducer function. This is the heart of this source file. It
 * contains all the action code for the above burg patterns.
 */
static bool
do_reduce (PFcnode_t * p, int rule, PFcnode_t *kids[]);

static bool
reduce (PFcnode_t * p, int goalnt)
{
    int           rule;           /* rule number that matches for this node */
    short        *nts;            /* target non-terminals for the leaf nodes of
                                     the current rule */
    PFcnode_t *   kids[MAX_KIDS]; /* leaf nodes of this rule */
    bool          rewritten;
    short         old_state_label;

    /* guard against too dep recursion */
    PFrecursion_fence();

    do {
        /* determine rule that matches for this non-terminal */
        rule = PFcoreopt_rule (STATE_LABEL (p), goalnt);

        assert (rule);

        /* PFinfo (OOPS_NOTICE, "match for rule %i", rule); */

        /* initialize the kids[] vector */
        for (unsigned short i = 0; i < MAX_KIDS; i++)
            kids[i] = NULL;

        /*
         * prepare recursive traversal: get information on leaf nodes of
         * this rule
         */
        nts = PFcoreopt_nts[rule];
        PFcoreopt_kids (p, rule, kids);

        rewritten = false;
        /* evaluate top-down in a number of cases */
        switch (rule) {
            /* Query:              main (FunctionDecls, CoreExpr) */
            case 1:
                /*
                 * Look at query body first, then at function declarations.
                 * This way we make sure that the expansion of let statements
                 * also considers function declarations.
                 */
                rewritten |= reduce (kids[1], nts[1]);
                rewritten |= reduce (kids[0], nts[0]);

                break;

            /* CoreExpr:           flwr (OptBindExpr, WhereExpr) */
            case 2:
                /* Make sure to collect all variables first ... */
                rewritten |= reduce (kids[0], nts[0]);
                /* ... and then fill in the replacements. */
                rewritten |= reduce (kids[1], nts[1]);

                /* remove uncessary flwr expressions */
                if (L(p)->kind == c_nil)
                {
                    /* transform where list into nested if-then-else(empty) */
                    *p = *transform_where (R(p));
                    rewritten = true;
                }
                break;

            /* OptBindExpr:        let (letbind (var, Atom), OptBindExpr) */
            case 10:
                /*
                 * Unfold atoms (a is an atom)
                 *
                 *     let $v := a return e
                 *  -->
                 *     e[a/$v]
                 *
                 * See the comment in the declaration of var_env to
                 * understand what's going on here.
                 */

                /*
                 * Handle CoreExpr first.  In case it is a variable, this
                 * will make sure that we do transitive cases of variable
                 * replacement correctly.
                 */
                reduce (kids[0], nts[0]);

                /* add mapping for this variable to the environment */
                *((bind_t *) PFarray_add (var_env[hash(LL(p)->sem.var)]))
                    = (bind_t) { .var = LL(p)->sem.var,
                                 .atom = LR(p),
                                 .child = -1 };

                if (LL(p)->sem.var->global && LR(p)->kind == c_var)
                    LR(p)->sem.var->global = true;

                /*
                 * Reduce the return part.
                 */
                reduce (kids[1], nts[1]);

                /*
                 * Do NOT remove the variable from the environment.
                 */

                /*
                 * We have now replaced every occurrence of the variable
                 * in the return part with its binding atom.  The return
                 * part now becomes the expression itself.
                 */
                *p = *R(p);


                rewritten = true;
                break;

            default:
                /*
                 * Recursively invoke compilation.
                 * This means bottom-up compilation.
                 */
                for (unsigned short i = 0; nts[i]; i++)
                    if ((rewritten = reduce (kids[i], nts[i])))
                        break;  /* abort if a subtree was rewritten */
        }

        if (rewritten) {
            /*
             * If a subtree has been rewritten, we have to
             *  - re-label that part of the tree, and
             *  - possibly propagate the `rewritten' information upwards.
             */

            /* remember our old state_label (so we know if it has changed) */
            old_state_label = STATE_LABEL(p);

            /*
             * Re-label current tree pattern.
             * (at most down to the pattern leaves, as they should already be
             * correctly labeled by the above reduce() call)
             */
            relabel (p, kids);

            /* If our own state_label has changed, notify our caller. */
            if (old_state_label != STATE_LABEL(p))
                return true;
        }
    } while (rewritten);

    return do_reduce (p, rule, kids);
}

static bool
do_reduce (PFcnode_t * p, int rule, PFcnode_t *kids[])
{
    bool          rewritten = false;

    /* guard against too dep recursion */
    PFrecursion_fence();

    switch (rule) {
        /* CoreExpr:           flwr (for_ (forbind (forvars (var, nil),
                                                    CoreExpr),
                                           nil), var) */
        case 3:
            /* replace for loops of the form
               'for $a in ... return $a' by its input '...' */
            if (LLLL(p)->sem.var == R(p)->sem.var) {
                *p = *LLR(p);
                relabel (p, kids);
                rewritten = true;
            }
            break;

        /* CoreExpr:           flwr (let (letbind (var, CoreExpr),
                                          nil), var) */
        case 4:
            /* replace unnecessary let binding
               'let $a := ... return $a' by its input '...' */
            if (LLL(p)->sem.var == R(p)->sem.var &&
                !R(p)->sem.var->global) {
                *p = *LLR(p);
                relabel (p, kids);
                rewritten = true;
            }
            break;

        /* OptBindExpr:        for_ (forbind (forvars (var, OptVar),
                                              CoreExpr),
                                     OptBindExpr) */
        case 5:
            /*
             * If we iterate over a sequence that we know (from static
             * typing) to always have length 1, replace the `for' by
             * a corresponding `let'.
             */
            if (PFty_subtype (TY(LR(p)), PFty_xs_anyItem ())) {

                PFcnode_t *c = R(p);

                if (LLR(p)->kind != c_nil)
                    c = let (letbind (LLR(p), num (1)), c);

                *p = *let (letbind (LLL(p), LR(p)), c);

                /* type-check what we just created */
                PFty_check (flwr (p, num(1)));

                rewritten = true;

                /*
                 * Re-label entire subtree. Type-checking may have
                 * modified all the state labels in the subtree, so
                 * we have to restore them.
                 */
                PFcoreopt_label (p);
                break;
            }
            break;

        /* OptBindExpr:        let (letbind (var,
                                             flwr (let (letbind (var,
                                                                 CoreExpr),
                                                        nil),
                                                   WhereExpr)),
                                    OptBindExpr) */
        case 11:
            /*
             * Remove a nested let block:
             *
             *     let $v1 := let $v2 := e return e' return e''
             *  -->
             *     let $v2 := e return
             *       let $v1 := e' return
             *         e''
             */
            /* transform where list into nested if-then-else(empty) */
            LRR(p) = transform_where (LRR(p));

            *p = *let (letbind (LL(LRL(p)), LR(LRL(p))), /* let $v2 := e ret */
                       let (letbind (LL(p), LRR(p)),     /*   let $v1 := e'  */
                            R(p)));                      /*     ret e''      */

            /* type-check what we just created */
            PFty_check (flwr (p, num(1)));

            rewritten = true;

            /*
             * Re-label entire subtree. Type-checking may have
             * modified all the state labels in the subtree, so
             * we have to restore them.
             */
            PFcoreopt_label (p);
            break;

        /* OptBindExpr:        let (letbind (var,
                                             flwr (let (letbind (var,
                                                                 CoreExpr),
                                                        OptBindExpr)),
                                                   WhereExpr),
                                    OptBindExpr) */
        case 12:
            /*
             * Remove a nested let block:
             *
             *     let $v1 := let $v2 := e return e' return e''
             *  -->
             *     let $v2 := e return
             *       let $v1 := e' return
             *         e''
             */
            *p = *let (letbind (LL(LRL(p)), LR(LRL(p))), /* let $v2 := e ret */
                     let (letbind (LL(p),                /*   let $v1 := e'  */
                                   flwr (R(LRL(p)),
                                         LRR(p))),
                          R(p)));                        /*     ret e''      */

            /* type-check what we just created */
            PFty_check (flwr (p, num (1)));

            rewritten = true;

            /*
             * Re-label entire subtree. Type-checking may have
             * modified all the state labels in the subtree, so
             * we have to restore them.
             */
            PFcoreopt_label (p);
            break;

        /* WhereExpr:          where (true_, WhereExpr) */
        case 33:
            *p = *(R(p));
            /* don't need to re-label here,
             * RL(p) should already be labeled */
            rewritten = true;
            break;

        /* WhereExpr:          where (CoreExpr, WhereExpr) */
        case 34:
            /* rewrite conjunctive selections into nested selections */
            if (L(p)->kind == c_apply &&
                !PFqname_eq (L(p)->sem.fun->qname, PFqname (PFns_op, "and"))) {
                PFcnode_t *fst_and_arg = LLL(p),
                          *snd_and_arg = LLRL(p);
                /* provide the new pattern leafs */
                kids[0] = fst_and_arg;
                kids[1] = snd_and_arg;
                kids[2] = RL(p);

                assert (PFty_subtype (TY(fst_and_arg), PFty_xs_boolean()));
                assert (PFty_subtype (TY(snd_and_arg), PFty_xs_boolean()));

                L(p)  = fst_and_arg;
                /* move the second condition into a separate where block
                   checking for the second argument of op:and */
                R(p) = where (snd_and_arg, R(p));
                TY(R(p)) = TY(p);

                relabel (p, kids);
                rewritten = true;
            }
            break;

        /* CoreExpr:           typesw (CoreExpr,
                                       cases (case_ (SequenceType,
                                                     CoreExpr),
                                              default_ (CoreExpr))) */
        case 13:
            /*
             * If we statically know that the type of an expression matches
             * a typeswitch case, we can remove the typeswitch.
             */
            if (PFty_subtype (TY(L(p)), TY(RLL(p)))) {
                *p = *RLR(p);
                rewritten = true;
            }
            /*
             * If we statically know that the type of an expression
             * can never match a typeswitch case, we can remove the
             * typeswitch.
             */
            else if (PFty_disjoint (TY(L(p)), TY(RLL(p)))) {
                *p = *RRL(p);
                rewritten = true;
            }

            /*
             * If the opt occurrence indicator is the only part
             * in the typeswitch we cannot decide statically
             * we can replace the typeswitch by a call to fn:exists ().
             */
            else if (L(p)->kind == c_var &&
                R(p)->kind == c_cases &&
                RL(p)->kind == c_case &&
                PFty_subtype (TY(RLL(p)), PFty_item ()) &&
                PFty_subtype (TY(L(p)), PFty_opt(TY(RLL(p))))) {
                PFvar_t *v = PFcore_new_var (NULL);
                PFfun_t *fn_exists
                    = PFcore_function (PFqname (PFns_fn, "exists"));

                /* if the input is not empty choose the case branch
                   else choose the default branch */
                *p = *flwr (let (letbind (
                                     var (v),
                                     apply (fn_exists, arg (L(p), nil ()))),
                                 nil ()),
                            if_ (var (v), then_else (RLR(p), RRL(p))));

                /* type-check what we just created */
                PFty_check (p);

                rewritten = true;

                /*
                 * Re-label entire subtree. Type-checking may have
                 * modified all the state labels in the subtree, so
                 * we have to restore them.
                 */
                PFcoreopt_label (p);
                break;
            }

            break;

        /* CoreExpr:           if_ (CoreExpr,
                                    then_else (CoreExpr, empty)) */
        case 31:
            /* rewrite conjunctive selections into nested selections */
            if (L(p)->kind == c_apply &&
                !PFqname_eq (L(p)->sem.fun->qname, PFqname (PFns_op, "and"))) {
                PFcnode_t *fst_and_arg = LLL(p),
                          *snd_and_arg = LLRL(p);

                assert (PFty_subtype (TY(fst_and_arg), PFty_xs_boolean()));
                assert (PFty_subtype (TY(snd_and_arg), PFty_xs_boolean()));

                L(p)  = fst_and_arg;
                /* replace then branch input by a nested if-then-else
                   checking for the second argument of op:and */
                RL(p) = if_ (snd_and_arg, then_else (RL(p), empty ()));

                /* type-check what we just created */
                PFty_check (p);

                rewritten = true;

                /*
                 * Re-label entire subtree. Type-checking may have
                 * modified all the state labels in the subtree, so
                 * we have to restore them.
                 */
                PFcoreopt_label (p);
            }
            /* fall through */

        /* CoreExpr:           if_ (CoreExpr,
                                    then_else (CoreExpr, CoreExpr)) */
        case 35:
            if (L(p)->kind == c_apply &&
                (!PFqname_eq (L(p)->sem.fun->qname, PFqname (PFns_op, "eq")) ||
                 !PFqname_eq (L(p)->sem.fun->qname, PFqname (PFns_op, "lt")) ||
                 !PFqname_eq (L(p)->sem.fun->qname, PFqname (PFns_op, "gt")))) {
                if (LLL(p)->kind == c_apply &&
                    !PFqname_eq (LLL(p)->sem.fun->qname,
                                 PFqname (PFns_fn, "number"))) {
                    LLL(p)->sem.fun
                        = PFcore_function (PFqname (PFns_pf, "number"));
                    /* don't need to re-label here,
                     * change does not affect structure */
                    rewritten = true;
                }
                if (LLRL(p)->kind == c_apply &&
                    !PFqname_eq (LLRL(p)->sem.fun->qname,
                                 PFqname (PFns_fn, "number"))) {
                    LLRL(p)->sem.fun
                        = PFcore_function (PFqname (PFns_pf, "number"));
                    /* don't need to re-label here,
                     * change does not affect structure */
                    rewritten = true;
                }
            }
            break;

        /* CoreExpr:           seq (seq (CoreExpr, CoreExpr), CoreExpr) */
        case 15:
        /* CoreExpr:           twig_seq (seq (CoreExpr, CoreExpr), CoreExpr) */
        case 19:
            *p = *seq (LL(p), seq (LR(p), R(p)));

            /* type-check what we just created */
            PFty_check (p);

            rewritten = true;

            /*
             * Re-label entire subtree. Type-checking may have
             * modified all the state labels in the subtree, so
             * we have to restore them.
             */
            PFcoreopt_label (p);
            break;

        /* CoreExpr:           seq (empty, CoreExpr) */
        case 16:
        /* CoreExpr:           twig_seq (empty, CoreExpr) */
        case 20:
            *p = *R(p);
            rewritten = true;
            break;

        /* CoreExpr:           seq (CoreExpr, empty) */
        case 17:
        /* CoreExpr:           twig_seq (CoreExpr, empty) */
        case 21:
            *p = *L(p);
            rewritten = true;
            break;

        /* CoreExpr:           elem (TagName, CoreExpr) */
        case 30:
            /* after some rewrites the local re-labeling might
               not detect bigger patterns any more */
            if (R(p)->kind != c_seq) break;
        /* CoreExpr:           twig_seq (CoreExpr, seq (CoreExpr, CoreExpr)) */
        case 18:
        /* CoreExpr:           elem (TagName, seq (CoreExpr, CoreExpr)) */
        case 22:
        {
            PFty_t ty_r = TY(R(p));
            R(p) = twig_seq (RL(p), RR(p));
            TY(R(p)) = ty_r;

            relabel (p, kids);
            rewritten = true;
        }   break;

        /* CoreExpr:           doc (seq (CoreExpr, CoreExpr)) */
        case 23:
        {
            PFty_t ty_l = TY(L(p));
            L(p) = twig_seq (LL(p), LR(p));
            TY(L(p)) = ty_l;

            relabel (p, kids);
            rewritten = true;
        }   break;

        /* CoreExpr:           apply (arg (CoreExpr, nil)) */
        case 25:
            if (! PFqname_eq (p->sem.fun->qname, PFqname (PFns_fn, "data"))) {
                /*
                 * If the argument is a subtype of atomic*, fn:data()
                 * returns the argument itself.
                 */
                if (PFty_subtype (TY(LL(p)), PFty_star (PFty_atomic ()))) {
                    *p = *LL(p);
                    rewritten = true;
                    break;
                }

                /*
                 * If the argument is a subtype of node*,
                 * fn:data() returns the typed-value of the argument.
                 */
                if (PFty_subtype (TY(LL(p)),
                                  PFty_star (PFty_node ()))) {
                    /*
                     *   fn:data(e)
                     * -->
                     *   for $v in e return
                     *     fn:typed-value ($v)
                     */
                    PFvar_t *v = new_var (NULL);
                    PFfun_t *fn_tv
                        = function (PFqname (PFns_pf, "typed-value"));

                    *p = *flwr (for_ (forbind (forvars (var (v), nil ()),
                                               LL(p)), nil ()),
                                apply (fn_tv, arg (var (v), nil ())));

                    /* type-check what we just created */
                    PFty_check (p);

                    rewritten = true;

                    /*
                     * Re-label entire subtree. Type-checking may have
                     * modified all the state labels in the subtree, so
                     * we have to restore them.
                     */
                    PFcoreopt_label (p);
                    break;
                }
            }

            /*
             * If the argument is a subtype of
             * (comment | processing-instruction),
             * fn:typed-value() returns the string-value
             * of the argument.
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_pf, "typed-value"))
                && PFty_subtype (TY(LL(p)),
                                 PFty_choice (PFty_comm (), PFty_pi (NULL)))) {
                p->sem.fun = function (PFqname (PFns_pf, "string-value"));
                rewritten = true;
                break;
            }

            /*
             * On non-validated nodes (for non-validated nodes,
             * the return type of typed-value() has been inferred
             * as untypedAtomic (via the judgement data_on)),
             * typed-value() always returns the string-value of
             * the node as xs:untypedAtomic.
             * (see also Data Model, 6.2.3)
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_pf, "typed-value"))
                && PFty_subtype (TY(p), PFty_untypedAtomic ())) {

                PFcnode_t *c = PFmalloc (sizeof (PFcnode_t));
                PFvar_t   *v = new_var (NULL);

                /* apply string-value(), not typed-value() */
                *c = *p;
                c->sem.fun = function (PFqname (PFns_pf, "string-value"));

                *p = *flwr (let (letbind (var (v), c), nil ()),
                            cast (seqtype (PFty_untypedAtomic ()),
                                  var (v)));

                /* type-check what we just created */
                PFty_check (p);

                rewritten = true;

                /*
                 * Re-label entire subtree. Type-checking may have
                 * modified all the state labels in the subtree, so
                 * we have to restore them.
                 */
                PFcoreopt_label (p);

                break;
            }

            /*
             * #pf:distinct-doc-order-or-atomic-sequence() can be replaced
             * by the function #pf:distinct-doc-order if the type is node*
             * and by the identity otherwise (type atomic*).
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (
                                  PFns_pf,
                                  "distinct-doc-order-or-atomic-sequence"))) {
                if (PFty_subtype (TY(p), PFty_star (PFty_node ()))) {
                    p->sem.fun =
                        function (
                            PFqname (
                                PFns_pf,
                                "distinct-doc-order"));
                    rewritten = true;
                    break;
                }
                else if (PFty_subtype (TY(p), PFty_star (PFty_atomic ()))) {
                    *p = *LL(p);
                    rewritten = true;
                    break;
                }
                else
                    PFoops (OOPS_FATAL,
                            "typechecking is incomplete for function "
                            "#pf:distinct-doc-order-or-atomic-sequence.");
            }

            /*
             * #pf:distinct-doc-order() or fn:reverse() underneath a call
             * of the function #pf:distinct-doc-order can be removed.
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_pf, "distinct-doc-order"))) {
                if (LL(p)->kind == c_apply &&
                    (! PFqname_eq (LL(p)->sem.fun->qname,
                                   PFqname (PFns_pf, "distinct-doc-order")) ||
                     ! PFqname_eq (LL(p)->sem.fun->qname,
                                   PFqname (PFns_fn, "reverse")))) {
                    assert (LLL(p)->kind == c_arg);

                    LL(p) = LL(LL(p));

                    /* replace kids vector by the real kid... */
                    kids[0] = LL(p);
                    /* ... and relabel the pattern */
                    relabel (p, kids);

                    rewritten = true;
                    break;
                }
                if (LL(p)->kind == c_locsteps &&
                    LLR(p)->kind == c_apply &&
                    ! PFqname_eq (LLR(p)->sem.fun->qname,
                                  PFqname (PFns_pf, "distinct-doc-order"))) {
                    LLR(p) = LL(LLR(p));

                    /* replace kids vector by the real kid... */
                    kids[0] = LLR(p);
                    /* ... and relabel the pattern */
                    relabel (p, kids);

                    rewritten = true;
                    break;
                }
            }

            /*
             * fn:zero-or-one() applied to something that is of
             * type item? returns the argument itself.
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_fn, "zero-or-one"))) {
                if (PFty_subtype (TY(LL(p)), PFty_opt (PFty_item ()))) {
                    *p = *LL(p);
                    rewritten = true;
                    break;
                }
                /**
                 * try to find a positional predicate:
                 *
                 *                flwr
                 *                /  \
                 *              for   if_________
                 *              /      \         \
                 *           forbind   apply(eq) then_else
                 *            /          \         \      \
                 *         forvars       arg      var(a)  empty
                 *          /   \       /   \
                 *       var(a) var(p)      arg
                 *                         /   \
                 *                      var(p)
                 */
                else if (LL(p)->kind == c_flwr &&
                         L(LL(p))->kind == c_for &&
                         LL(LL(p))->kind == c_forbind &&
                         LLL(LL(p))->kind == c_forvars &&
                         LLLR(LL(p))->kind == c_var &&
                         LLLL(LL(p))->kind == c_var &&
                         R(LL(p))->kind == c_if &&
                         RL(LL(p))->kind == c_apply &&
                         ! PFqname_eq (RL(LL(p))->sem.fun->qname,
                                       PFqname (PFns_op, "eq")) &&
                         RLL(LL(p))->kind == c_arg &&
                         R(RLL(LL(p)))->kind == c_arg &&
                         RL(RLL(LL(p)))->kind == c_var &&
                         LLLR(LL(p))->sem.var == RL(RLL(LL(p)))->sem.var &&
                         RR(LL(p))->kind == c_then_else &&
                         RRL(LL(p))->kind == c_var &&
                         LLLL(LL(p))->sem.var == RRL(LL(p))->sem.var &&
                         RRR(LL(p))->kind == c_empty) {
                    /* remove function and replace flwr type */
                    PFty_t ty = TY(p);
                    *p = *LL(p);
                    TY(p) = ty;
                    rewritten = true;
                    break;
                }
            }

            /*
             * fn:exactly-one() applied to something that is of
             * type empty returns an error.
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_fn, "exactly-one"))) {
                if (PFty_subtype (TY(LL(p)), PFty_empty ()))
                    PFoops (OOPS_FATAL,
                            "err:FORG0005, fn:exactly-one called with a "
                            "sequence containing zero or more than one item.");
                break;
            }

            /*
             * fn:boolean() applied to something that is already of
             * type xs:boolean returns the argument itself.
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_fn, "boolean"))) {
                if (PFty_subtype (TY(LL(p)), PFty_xs_boolean ())) {
                    *p = *LL(p);
                    rewritten = true;
                    break;
                }
            }

            /*
             * fn:ceiling(), fn:floor(), and fn:round() applied
             * to something that is of type integer returns
             * the argument itself.
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_fn, "ceiling")) ||
                ! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_fn, "floor")) ||
                ! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_fn, "round"))) {
                if (PFty_subtype (TY(LL(p)), PFty_xs_integer ())) {
                    *p = *LL(p);
                    rewritten = true;
                    break;
                }
            }

            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_fn, "string"))) {
                /*
                 * If the argument is a subtype of xs:string,
                 * fn:string returns the argument itself.
                 */
                if (PFty_subtype (TY(LL(p)), PFty_xs_string ())) {
                    *p = *LL(p);
                    rewritten = true;
                    break;
                }
                /*
                 * If the argument is a subtype of atomic, fn:string()
                 * is just a cast.
                 */
                else if (PFty_subtype (TY(LL(p)), PFty_atomic ())) {
                    PFcnode_t *c = PFmalloc (sizeof (PFcnode_t));
                    PFvar_t   *v = new_var (NULL);

                    c = flwr (let (letbind (var (v), LL(p)), nil ()),
                              cast (seqtype (PFty_xs_string ()), var (v)));

                    *p = *c;

                    /* type-check what we just created */
                    PFty_check (p);

                    rewritten = true;
                    /*
                     * Re-label entire subtree. Type-checking may have
                     * modified all the state labels in the subtree, so
                     * we have to restore them.
                     */
                    PFcoreopt_label (p);
                    break;
                }
                /*
                 * If the argument is a subtype of node,
                 * fn:string() returns the string-value
                 * of the argument.
                 */
                else if (PFty_subtype (TY(LL(p)), PFty_xs_anyNode ())) {
                    p->sem.fun
                        = function (PFqname (PFns_pf, "string-value"));
                    /* type-check what we just created */
                    PFty_check (p);

                    rewritten = true;

                    /*
                     * Re-label entire subtree. Type-checking may have
                     * modified all the state labels in the subtree, so
                     * we have to restore them.
                     */
                    PFcoreopt_label (p);
                    break;
                }
            }

            /*
             * pf:item-sequence-to-untypedAtomic () is translated into
             * fn:string for each node followed by a fn:string-join ()
             * with the seperator " "
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_pf,
                                       "item-sequence-to-untypedAtomic"))) {

                /* cope with empty sequences */
                if (PFty_subtype (TY(LL(p)), PFty_empty ())) {
                    *p = *cast (seqtype (PFty_untypedAtomic ()),
                                str (""));
                }
                else {
                    PFvar_t   *v = new_var (NULL);
                    PFfun_t   *fn_string
                        = function (PFqname (PFns_fn, "string"));
                    PFfun_t   *fn_string_join
                        = function (PFqname (PFns_fn, "string-join"));

                    *p = *cast (seqtype (PFty_untypedAtomic ()),
                                APPLY (fn_string_join,
                                       flwr (for_ (forbind (forvars (var (v),
                                                                     nil ()),
                                                            LL(p)), nil ()),
                                             APPLY (fn_string, var (v))),
                                       str (" ")));
                }

                PFty_check (p);

                rewritten = true;

                /*
                 * Re-label entire subtree. Type-checking may have
                 * modified all the state labels in the subtree, so
                 * we have to restore them.
                 */
                PFcoreopt_label (p);

                break;
            }

            /*
             * The application of pf:item-sequence-to-node-sequence ()
             * to something that contains only nodes can be discarded.
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_pf,
                                       "item-sequence-to-node-sequence"))) {
                if (PFty_subtype (TY(LL(p)),
                                  PFty_star (PFty_xs_anyNode ()))) {
                    *p = *LL(p);
                    rewritten = true;
                    break;
                }
                else if (PFty_subtype (TY(LL(p)), PFty_atomic ())) {
                    PFfun_t   *fn_string
                        = function (PFqname (PFns_fn, "string"));
                    *p = *constr(p_text, apply (fn_string,
                                                arg (LL(p), nil ())));
                    PFty_check (p);

                    rewritten = true;

                    /*
                     * Re-label entire subtree. Type-checking may have
                     * modified all the state labels in the subtree, so
                     * we have to restore them.
                     */
                    PFcoreopt_label (p);
                    break;
                }
            }

            /*
             * The application of pf:merge-adjacent-text-nodes ()
             * to something that contains at most one text node
             * can be discarded.
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_pf, "merge-adjacent-text-nodes"))) {
                    /* is empty */
                if (LL(p)->kind == c_empty ||
                    /* contains at most one text node */
                    PFty_subtype (TY(LL(p)), PFty_opt (PFty_text())) ||
                    /* contains at most one text node and some attributes*/
                    PFty_subtype (TY(LL(p)), PFty_seq (
                                                 PFty_star (
                                                     PFty_xs_anyAttribute ()),
                                                 PFty_opt (PFty_text()))) ||
                    /* contains no text nodes */
                    PFty_subtype (TY(LL(p)),
                                  PFty_star (
                                      PFty_choice (
                                          PFty_xs_anyElement (),
                                          PFty_choice (
                                              PFty_xs_anyAttribute (),
                                              PFty_choice (
                                                  PFty_doc (PFty_xs_anyType ()),
                                                  PFty_choice (
                                                      PFty_comm (),
                                                      PFty_pi (NULL)))))))) {
                    *p = *LL(p);
                    rewritten = true;
                    break;
                }
                /* Special rewrite: Push down the #pf:merge-adjacent-text-nodes
                   function if its input is a sequence where at least one
                   argument does not contain text nodes. */
                else if (LL(p)->kind == c_seq) {
                    if (!PFty_subtype (PFty_opt (PFty_text ()),
                                       PFty_opt (PFty_prime (TY(LLL(p)))))) {
                        PFfun_t *pf_matn
                            = function (
                                  PFqname (
                                      PFns_pf,
                                      "merge-adjacent-text-nodes"));

                        /* push #pf:matn into right sequence constructor input */
                        *p = *seq (LLL(p), APPLY (pf_matn, LLR(p)));
                        PFty_check (p);

                        rewritten = true;

                        /*
                         * Re-label entire subtree. Type-checking may have
                         * modified all the state labels in the subtree, so
                         * we have to restore them.
                         */
                        PFcoreopt_label (p);
                    } else if (!PFty_subtype (PFty_opt (PFty_text ()),
                                              PFty_opt (PFty_prime (TY(LLR(p)))))) {
                        PFfun_t *pf_matn
                            = function (
                                  PFqname (
                                      PFns_pf,
                                      "merge-adjacent-text-nodes"));

                        /* push #pf:matn into left sequence constructor input */
                        *p = *seq (APPLY (pf_matn, LLL(p)), LLR(p));
                        PFty_check (p);

                        rewritten = true;

                        /*
                         * Re-label entire subtree. Type-checking may have
                         * modified all the state labels in the subtree, so
                         * we have to restore them.
                         */
                        PFcoreopt_label (p);
                    }
                }
            }
            break;

        /* CoreExpr:           apply (arg (CoreExpr, arg (CoreExpr, nil))) */
        case 26:
            /*
             * fn:concat does not need to append an empty string
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_fn, "concat"))) {
                if (LRL(p)->kind == c_lit_str && !strcmp (LRL(p)->sem.str,"")) {
                    *p = *LL(p);
                    rewritten = true;
                    break;
                }
            }

            /*
             * fn:string-join() applied to an empty sequence
             * returns an empty string and applied to a singleton
             * sequence returns the singleton
             */
            if (! PFqname_eq (p->sem.fun->qname,
                              PFqname (PFns_fn, "string-join"))) {
                if (PFty_subtype (TY(LL(p)), PFty_empty ())) {
                    *p = *str ("");
                    TY(p) = PFty_xs_string ();
                    rewritten = true;

                    /* assign new node a state label */
                    PFcoreopt_label (p);
                    break;
                }
                else if (PFty_subtype (TY(LL(p)), PFty_xs_string ())) {
                    *p = *LL(p);
                    rewritten = true;
                    break;
                }
            }
            break;

        /* SequenceTypeCast:   seqcast (SequenceType, CoreExpr) */
        /* CoreExpr:           cast (SequenceType, CoreExpr) */
        case 27:
            if (PFty_subtype (TY(L(p)), TY(R(p))) &&
                PFty_subtype (TY(R(p)), TY(L(p)))) {
                *p = *R(p);
                rewritten = true;
                break;
            } else if (PFty_subtype (TY(L(p)),
                                     PFty_opt (PFty_xs_string ())) &&
                       (R(p)->kind == c_seqcast || R(p)->kind == c_cast) &&
                       PFty_subtype (TY(RL(p)),
                                     PFty_opt (PFty_untypedAtomic ())) &&
                       PFty_subtype (TY(RR(p)), PFty_xs_string ())) {
                /* remove two adjacent cast operators that cast from string
                   to untypedAtomic and back to string */
                *p = *RR(p);
                rewritten = true;
                break;
            }
            break;

        /* Atom:                var */
        case 28:
            {
                /*
                 * See the comment in the declaration of var_env and
                 * the rule that processes let-bindings to understand
                 * what's going on here.
                 */
                unsigned short h = hash (p->sem.var);

                /*
                 * Look up this variable in the variable replacement
                 * environment.  If we find it there, do the replacement.
                 */
                for (unsigned int i = 0; i < PFarray_last (var_env[h]); i++)
                    if (((bind_t *) PFarray_at (var_env[h], i))->var
                            == p->sem.var) {
                        *p = *((bind_t *) PFarray_at (var_env[h], i))->atom;
                        rewritten = true;
                        break;
                    }
            }
            break;

        /* CoreExpr:           LocationSteps */
        case 29:
            /* This rewrite ignores side effects and throws e.g. errors away.
               We thus disable this rewrite. */
            break;

#if 0 /* comment out code that is unreachable after / due to above "break;" */
            /* remove bogus steps starting from attribute nodes */
            assert (p->kind == c_locsteps);
            if (/* the typing infers that the result
                   does not provide any results */
                PFty_subtype (TY(p), PFty_empty ()) ||
                /* the axis provides no result for attribute inputs */
                ((L(p)->kind == c_attribute ||
                  L(p)->kind == c_child ||
                  L(p)->kind == c_descendant ||
                  L(p)->kind == c_following ||
                  L(p)->kind == c_following_sibling ||
                  L(p)->kind == c_preceding ||
                  L(p)->kind == c_preceding_sibling) &&
                 PFty_subtype (TY(R(p)),
                               PFty_star (PFty_xs_anyAttribute ()))) ||
                /* the kind test does not match the attribute input */
                ((L(p)->kind == c_self ||
                  L(p)->kind == c_descendant_or_self) &&
                 /* input is of type attribute()* */
                 PFty_subtype (TY(R(p)),
                               PFty_star (PFty_xs_anyAttribute ())) &&
                 /* expected is neither type node()* */
                 !PFty_subtype (PFty_xs_anyNode (),
                                TY(L(p))) &&
                 /* nor type attribute()* */
                 !PFty_subtype (TY(L(p)),
                                PFty_star (PFty_xs_anyAttribute ())))) {
                *p = *empty ();
                TY(p) = PFty_empty ();
                rewritten = true;

                /* assign new node a state label */
                PFcoreopt_label (p);
                break;
            }
            break;
#endif

        /* LocationSteps:      locsteps (LocationStep, CoreExpr) */
        case 32:
            if (PFty_subtype (TY(p), PFty_empty ()) &&
                PFty_subtype (TY(R(p)), PFty_empty ())) {
                *p = *R(p);
                rewritten = true;
                break;
            }
            break;

        default:
            break;
    }

    return rewritten;
}

/*
 * Re-label a match pattern.
 *
 * Start with node @a p and relabel the subtree below. However, stop
 * if @a p is one of the pattern leaves, passed as the argument @a kids.
 */
static void
relabel (PFcnode_t *p,  PFcnode_t **kids)
{
    unsigned int i;

    for (i = 0; i < MAX_KIDS; i++) {
        if (kids[i] && p == kids[i])
            return;
    }

    /* Relabel p's children. */
    if (!L(p) && !R(p)) {
        STATE_LABEL(p) = PFcoreopt_state (OP_LABEL(p), 0, 0);
    }
    else if (L(p) && !R(p)) {
        relabel (L(p), kids);
        STATE_LABEL(p) = PFcoreopt_state (OP_LABEL(p),
                                          STATE_LABEL(L(p)),
                                          0);
    }
    else if (!L(p) && R(p)) {
        relabel (R(p), kids);
        STATE_LABEL(p) = PFcoreopt_state (OP_LABEL(p),
                                          STATE_LABEL(R(p)),
                                          0);
    }
    else {
        relabel (L(p), kids);
        relabel (R(p), kids);
        STATE_LABEL(p) = PFcoreopt_state (OP_LABEL(p),
                                          STATE_LABEL(L(p)),
                                          STATE_LABEL(R(p)));
    }

    assert (STATE_LABEL(p));
}

/* Collect all let (and position) bound variables and additionally
   store the number of references in the same nesting depth. If the
   variables are referenced in a nested scope their counter is set to
   -1 to indicate that the may not be rewritten. */
static char
collect_var_usage (PFcnode_t *c, char base, PFcnode_t *parent, int child)
{
    switch (c->kind) {
        case c_var:
            /*
             * Look up the top-most variable in the variable environment
             * with a matching name and mark it as used.
             */
            for (unsigned int i = 0; i < PFarray_last (unused_var_env); i++)
                if (((bind_t *) PFarray_at (unused_var_env, i))->var
                        == c->sem.var) {
                    /* check if the variable was bound in the same scope */
                    if (base != c->sem.var->base)
                        c->sem.var->used = -1;
                    else if (c->sem.var->used >= 0)
                        c->sem.var->used++;

                    if (c->sem.var->used == 1)
                        /* add variable to the variable reference environment */
                        *((bind_t *) PFarray_add (used_var_env))
                            = (bind_t) { .var = c->sem.var,
                                         .atom = parent,
                                         .child = child };
                    break;
                }
            break;

        case c_flwr:
        {
            char old_base = base;
            base = collect_var_usage (L(c), base, c, 0);
            base = collect_var_usage (R(c), base, c, 1);
            /* reset all new scopes introduced by a for loop */
            base = old_base;
        } break;

        case c_let:
            assert (L(c)->kind == c_letbind);

            base = collect_var_usage (LR(c), base, L(c), 1);

            /* add variable to the environment */
            *((bind_t *) PFarray_add (unused_var_env))
                = (bind_t) { .var = LL(c)->sem.var,
                             .atom = parent,
                             .child = child };
            /* reset reference counter */
            LL(c)->sem.var->used = 0;
            /* record the current scope */
            LL(c)->sem.var->base = base;

            base = collect_var_usage (R(c), base, c, 1);
            break;

        case c_for:
            assert (L(c)->kind == c_forbind &&
                    LL(c)->kind == c_forvars &&
                    LLL(c)->kind == c_var);

            base = collect_var_usage (LR(c), base, L(c), 1);

            /* a for loop increases the nesting depth */
            base++;

            if (LLR(c)->kind == c_var) {
                /* add variable to the environment */
                *((bind_t *) PFarray_add (unused_var_env))
                    = (bind_t) { .var = LLR(c)->sem.var,
                                 .atom = parent,
                                 .child = child };
                /* reset reference counter */
                LLR(c)->sem.var->used = 0;
                /* record the current scope */
                LLR(c)->sem.var->base = base;
            }

            base = collect_var_usage (R(c), base, c, 1);
            break;

        case c_main:
            /* first collect global variables before
               analyzing user-defined functions */
            base = collect_var_usage (R(c), base, c, 1);
            base = collect_var_usage (L(c), base, c, 0);
            break;

        case c_recursion:
            /* ignore recursion variable */
            base = collect_var_usage (R(c), base, c, 1);
            break;

        case c_seed:
        {
            char old_base = base;
            base = collect_var_usage (L(c), base, c, 0);
            base++;
            /* avoid that let bindings are expanded
               into the recursion body */
            base = collect_var_usage (R(c), base, c, 1);
            /* reset all new scopes introduced by a for loop */
            base = old_base;
        }   break;

        case c_param:
            /* ignore used-defined function variables */
            base = collect_var_usage (L(c), base, c, 0);
            break;

        default:
            for (unsigned int i = 0; i < PFCNODE_MAXCHILD && c->child[i]; i++)
                base = collect_var_usage (c->child[i], base, c, i);
    }
    return base;
}

/* initialize global variables */
static void
PFcoreopt_init (void)
{
    /* set up variable replacement environment */
    for (unsigned short i = 0; i < HASH_BUCKETS; i++)
        var_env[i] = PFarray (sizeof (bind_t), 128);

    /* set up a variable environment to record unused variables */
    unused_var_env = PFarray (sizeof (bind_t), 128);
    /* set up a variable environment to record variable references */
    used_var_env = PFarray (sizeof (bind_t), HASH_BUCKETS * 128);
}


/**
 * Optimize Core tree, with static type information available.
 *
 * @param r root of the XQuery Core tree
 * @return the optimized XQuery Core tree
 */
PFcnode_t *
PFcoreopt (PFcnode_t *r)
{
    /* ensure that we at least once remove unused variables */
    bool unused_var = true;

    assert (r);

    /* initialize global variables */
    PFcoreopt_init ();

    /* label the Core tree bottom up */
    PFcoreopt_label (r);

    /* invoke rewriting (reduce) and rewrite as long as something changes */
    while (reduce (r, 1) || unused_var) {
        PFvar_t *var;
        PFcnode_t *p, *n, *up;
        int c, uc;

        /* clean up variable environment */
        for (unsigned short i = 0; i < HASH_BUCKETS; i++)
            PFarray_last (var_env[i]) = 0;

        /* clean up unused and single variable environment */
        PFarray_last (unused_var_env) = 0;
        PFarray_last (used_var_env) = 0;

        /* make sure that we stop if we do not remove unused variables */
        unused_var = false;

        /* collect the variable usage information */
        collect_var_usage (r, 0, NULL, -1);

        /* remove all unused variables and expand variables
           that are referenced only once in the same nesting depth */
        for (unsigned int i = PFarray_last (unused_var_env); i > 0; i--) {
            var = ((bind_t *) PFarray_at (unused_var_env, i-1))->var;
            p = ((bind_t *) PFarray_at (unused_var_env, i-1))->atom;
            c = ((bind_t *) PFarray_at (unused_var_env, i-1))->child;

            /* make sure that we only remove bindings if they
               are still referenced */
            if (!p->child[c]) continue;

            n = p->child[c];
            if (!var->used) {
                if (n->kind == c_let) {
                    p->child[c] = R(n);

                    /* mark n as inaccessable */
                    L(n) = NULL;
                    R(n) = NULL;

                    unused_var = true;
                } else if (n->kind == c_for) {
                    LLR(n) = nil ();
                    unused_var = true;
                }
            } else if (var->used == 1 && n->kind == c_let)
                for (unsigned int j = 0; j < PFarray_last (used_var_env); j++)
                    if (var == ((bind_t *) PFarray_at (used_var_env, j))->var) {
                        up = ((bind_t *) PFarray_at (used_var_env, j))->atom;
                        uc = ((bind_t *) PFarray_at (used_var_env, j))->child;
                        /* make sure that we only replace variables that
                           are still referenced */
                        if (up->child[uc]) {
                            /* replace variable by its corresponding
                               Core expression... */
                            up->child[uc] = LR(n);

                            /* ... and remove the variable binding */
                            p->child[c] = R(n);

                            /* mark L(n) as inaccessable */
                            LL(n) = NULL;
                            LR(n) = NULL;

                            /* mark n as inaccessable */
                            L(n) = NULL;
                            R(n) = NULL;

                            unused_var = true;
                        }
                        /* for performance reasons remove the binding
                           from the environment */
                        *((bind_t *) PFarray_at (used_var_env, j))
                            = *((bind_t *) PFarray_top (used_var_env));
                        PFarray_del (used_var_env);
                        j--;
                        break;
                    }
        }

        if (unused_var)
            /* label the Core tree bottom up */
            PFcoreopt_label (r);
    }

    return r;
}


/* vim:set shiftwidth=4 expandtab filetype=c: */
