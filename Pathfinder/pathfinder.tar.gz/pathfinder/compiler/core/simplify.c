#line 1 "simplify.brg"


/* Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.pathfinder-xquery.org/license
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2011 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *//**
 *
 * @file
 * @brief Simplify XQuery Core tree.
 *
 * This step runs right after compilation into XQuery Core. Its
 * job is not only to simplify the Core tree and bring it into
 * some normal form (e.g., unnest let clauses), but also to check
 * the Core tree structure for syntactial errors that might have
 * sneaked in in the Core compilation phase (fs.brg).
 *
 * Note that static type information is not available at this
 * step during query compilation. ``Real optimization'' will only
 * be possible after the type checking phase (typecheck.brg). See
 * coreopt.brg for this purpose.
 *
 */

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"
#include <assert.h>
#include <stdio.h>

#include "oops.h"
#include "core.h"
#include "qname.h"
#include "mem.h"

/* Easily access subtree-parts */
#include "child_mnemonic.h"

/*
 * Accessors for the burg matcher
 */
typedef struct PFcnode_t *NODEPTR_TYPE;

/* accessor to the node kind */
#define OP_LABEL(p)    ((p)->kind)

/* accessors to left and right child node */
#define LEFT_CHILD(p)  ((p)->child[0])
#define RIGHT_CHILD(p) ((p)->child[1])

/* the state determined during bottom-up labeling is stored here */
#define STATE_LABEL(p) ((p)->state_label)

/* If something goes wrong, call PFoops */
#define PANIC(...) PFoops (OOPS_BURG, __VA_ARGS__)

/** We hash variable replacement bindings into 8 buckets */
#define HASH_BUCKETS 8
/** hash function for the variable replacement environment */
#define hash(v) ((unsigned int) ((v) - (PFvar_t *) NULL) % HASH_BUCKETS)

/** a binding in the variable replacement environment */
typedef struct {
    PFvar_t    *var;
    PFcnode_t  *atom;
} bind_t;

/**
 * Variable replacement environment.
 *
 * In order to unfold let-bound variables which are bound to some
 * other atom, we proceed as follows:
 *
 * First, we process the binding sequence (the atom).  If it is
 * a variable itself, there may be a replacement for it, so we do
 * that first.  Then, add an entry to the environment var_env
 * (a hash table with HASH_BUCKETS buckets) and process the return
 * part (which will replace every occurrence of the variable).
 * When we're back, we replace the let clause by its return part.
 *
 * Whenever we process the usage of a variable, look into the
 * environment if there is a replacement for it.  In that case,
 * do the replacement.
 *
 * Note that we do *not* remove the binding from the environment
 * when we're back from the return part.  The Core expression
 * tree may contain "global" variables (i.e., ones that were
 * bound in the query prolog).  Such variables may be used in
 * functions as well.  Therefore, we process the query first
 * (the start rule for our grammar is top-down) in order to have
 * globals be added to the environment.  As we leave all the
 * variables in the environment, they will be available when we
 * process the function bodies.  Hence, they will be replaced
 * there as well.
 */
static PFarray_t *var_env[HASH_BUCKETS];

#ifndef PFsimplify_PANIC
#define PFsimplify_PANIC	PANIC
#endif /* PFsimplify_PANIC */
#include <stdlib.h> /* for abort() */
#ifdef NDEBUG
#define PFsimplify_assert(x,y)	;
#else
#define PFsimplify_assert(x,y)	if(!(x)) {y; abort();}
#endif
static short PFsimplify_r1_nts[] ={ 17, 2, 0 };
static short PFsimplify_r2_nts[] ={ 16, 3, 0 };
static short PFsimplify_r4_nts[] ={ 15, 3, 0 };
static short PFsimplify_r5_nts[] ={ 2, 5, 3, 0 };
static short PFsimplify_r6_nts[] ={ 2, 3, 5, 3, 0 };
static short PFsimplify_r7_nts[] ={ 2, 3, 6, 3, 0 };
static short PFsimplify_r8_nts[] ={ 5, 0 };
static short PFsimplify_r9_nts[] ={ 6, 0 };
static short PFsimplify_r11_nts[] ={ 2, 2, 0 };
static short PFsimplify_r13_nts[] ={ 2, 2, 2, 0 };
static short PFsimplify_r15_nts[] ={ 2, 0 };
static short PFsimplify_r18_nts[] ={ 2, 2, 2, 14, 0 };
static short PFsimplify_r19_nts[] ={ 0 };
static short PFsimplify_r20_nts[] ={ 19, 20, 0 };
static short PFsimplify_r30_nts[] ={ 15, 0 };
static short PFsimplify_r31_nts[] ={ 9, 0 };
static short PFsimplify_r32_nts[] ={ 3, 5, 0 };
static short PFsimplify_r33_nts[] ={ 3, 6, 0 };
static short PFsimplify_r34_nts[] ={ 4, 2, 3, 0 };
static short PFsimplify_r40_nts[] ={ 2, 3, 0 };
static short PFsimplify_r42_nts[] ={ 2, 5, 0 };
static short PFsimplify_r44_nts[] ={ 2, 6, 0 };
static short PFsimplify_r45_nts[] ={ 7, 2, 0 };
static short PFsimplify_r47_nts[] ={ 2, 7, 0 };
static short PFsimplify_r50_nts[] ={ 2, 8, 2, 2, 0 };
static short PFsimplify_r53_nts[] ={ 8, 2, 0 };
static short PFsimplify_r54_nts[] ={ 2, 8, 2, 0 };
static short PFsimplify_r60_nts[] ={ 11, 0 };
static short PFsimplify_r61_nts[] ={ 8, 0 };
static short PFsimplify_r75_nts[] ={ 10, 11, 0 };
static short PFsimplify_r76_nts[] ={ 10, 2, 0 };
static short PFsimplify_r80_nts[] ={ 12, 2, 0 };
static short PFsimplify_r90_nts[] ={ 13, 0 };
static short PFsimplify_r91_nts[] ={ 14, 0 };
static short PFsimplify_r92_nts[] ={ 2, 14, 0 };
static short PFsimplify_r93_nts[] ={ 9, 14, 0 };
static short PFsimplify_r102_nts[] ={ 16, 0 };
static short PFsimplify_r111_nts[] ={ 18, 17, 0 };
static short PFsimplify_r114_nts[] ={ 21, 19, 0 };
static short PFsimplify_r124_nts[] ={ 2, 13, 0 };
short *PFsimplify_nts[] = {
	0,
	PFsimplify_r1_nts,
	PFsimplify_r2_nts,
	PFsimplify_r2_nts,
	PFsimplify_r4_nts,
	PFsimplify_r5_nts,
	PFsimplify_r6_nts,
	PFsimplify_r7_nts,
	PFsimplify_r8_nts,
	PFsimplify_r9_nts,
	0,
	PFsimplify_r11_nts,
	PFsimplify_r11_nts,
	PFsimplify_r13_nts,
	0,
	PFsimplify_r15_nts,
	PFsimplify_r15_nts,
	0,
	PFsimplify_r18_nts,
	PFsimplify_r19_nts,
	PFsimplify_r20_nts,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	PFsimplify_r30_nts,
	PFsimplify_r31_nts,
	PFsimplify_r32_nts,
	PFsimplify_r33_nts,
	PFsimplify_r34_nts,
	PFsimplify_r19_nts,
	PFsimplify_r19_nts,
	0,
	0,
	0,
	PFsimplify_r40_nts,
	PFsimplify_r19_nts,
	PFsimplify_r42_nts,
	PFsimplify_r15_nts,
	PFsimplify_r44_nts,
	PFsimplify_r45_nts,
	PFsimplify_r15_nts,
	PFsimplify_r47_nts,
	0,
	0,
	PFsimplify_r50_nts,
	PFsimplify_r19_nts,
	PFsimplify_r15_nts,
	PFsimplify_r53_nts,
	PFsimplify_r54_nts,
	PFsimplify_r13_nts,
	PFsimplify_r11_nts,
	0,
	0,
	0,
	PFsimplify_r60_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r61_nts,
	PFsimplify_r75_nts,
	PFsimplify_r76_nts,
	0,
	0,
	0,
	PFsimplify_r80_nts,
	PFsimplify_r80_nts,
	PFsimplify_r15_nts,
	PFsimplify_r15_nts,
	PFsimplify_r15_nts,
	PFsimplify_r11_nts,
	PFsimplify_r19_nts,
	PFsimplify_r15_nts,
	0,
	0,
	PFsimplify_r90_nts,
	PFsimplify_r91_nts,
	PFsimplify_r92_nts,
	PFsimplify_r93_nts,
	PFsimplify_r19_nts,
	PFsimplify_r15_nts,
	PFsimplify_r15_nts,
	PFsimplify_r53_nts,
	0,
	0,
	0,
	PFsimplify_r19_nts,
	PFsimplify_r102_nts,
	0,
	PFsimplify_r19_nts,
	PFsimplify_r19_nts,
	PFsimplify_r19_nts,
	PFsimplify_r19_nts,
	PFsimplify_r19_nts,
	PFsimplify_r19_nts,
	PFsimplify_r19_nts,
	PFsimplify_r111_nts,
	0,
	PFsimplify_r19_nts,
	PFsimplify_r114_nts,
	0,
	0,
	0,
	0,
	0,
	PFsimplify_r15_nts,
	PFsimplify_r53_nts,
	0,
	PFsimplify_r11_nts,
	PFsimplify_r124_nts,
};
static unsigned char PFsimplify_seq_transition[6][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    5,    1}	/* row 1 */,
{    0,    2,    2}	/* row 2 */,
{    0,    4,    1}	/* row 3 */,
{    0,    5,    1}	/* row 4 */,
{    0,    3,    1}	/* row 5 */
};
static unsigned char PFsimplify_flwr_transition[10][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,   10,    7}	/* row 1 */,
{    0,    3,    2}	/* row 2 */,
{    0,    4,    5}	/* row 3 */,
{    0,   14,    2}	/* row 4 */,
{    0,    6,    5}	/* row 5 */,
{    0,    8,    9}	/* row 6 */,
{    0,   11,    9}	/* row 7 */,
{    0,   12,   13}	/* row 8 */,
{    0,    1,   13}	/* row 9 */
};
static unsigned char PFsimplify_let_transition[15][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    8,   17}	/* row 1 */,
{    0,   11,   18}	/* row 2 */,
{    0,   24,   23}	/* row 3 */,
{    0,   22,   21}	/* row 4 */,
{    0,   20,   19}	/* row 5 */,
{    0,    1,   16}	/* row 6 */,
{    0,   15,   14}	/* row 7 */,
{    0,   13,   12}	/* row 8 */,
{    0,   10,    9}	/* row 9 */,
{    0,    7,    6}	/* row 10 */,
{    0,    5,    4}	/* row 11 */,
{    0,    3,    2}	/* row 12 */,
{    0,   11,   18}	/* row 13 */,
{    0,   11,   18}	/* row 14 */
};
static unsigned char PFsimplify_letbind_transition[2][15] = {
{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,	/* row 0, cols 0-9*/
    0,    0,    0,    0,    0}	/* row 0 */,
{    0,    1,   12,    5,   10,   11,    2,   14,   13,    9,	/* row 1, cols 0-9*/
    8,    7,    6,    4,    3}	/* row 1 */
};
static unsigned char PFsimplify_for__transition[4][2] = {
{    0,    0}	/* row 0 */,
{    0,    3}	/* row 1 */,
{    0,    1}	/* row 2 */,
{    0,    2}	/* row 3 */
};
static unsigned char PFsimplify_forbind_transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    3}	/* row 1 */,
{    0,    2,    3}	/* row 2 */
};
static unsigned char PFsimplify_forvars_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFsimplify_where_transition[3][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    4,    2}	/* row 1 */,
{    0,    1,    3}	/* row 2 */
};
static unsigned char PFsimplify_orderby_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_orderspecs_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFsimplify_arg_transition[3][8] = {
{    0,    0,    0,    0,    0,    0,    0,    0}	/* row 0 */,
{    0,    1,   13,    2,    4,    9,   10,    7}	/* row 1 */,
{    0,   12,   14,    3,    5,   11,    8,    6}	/* row 2 */
};
static unsigned char PFsimplify_typesw_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_cases_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_case__transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_seqcast_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_proof_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_subty_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_if__transition[4][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */,
{    0,    2}	/* row 2 */,
{    0,    3}	/* row 3 */
};
static unsigned char PFsimplify_then_else_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_locsteps_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFsimplify_elem_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_attr_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_pi_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_main_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_fun_decls_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_fun_decl_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_params_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_param_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_cast_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_recursion_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_seed_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFsimplify_xrpc_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static struct {
	unsigned int f42:2;
	unsigned int f43:2;
	unsigned int f44:4;
	unsigned int f45:2;
	unsigned int f46:2;
	unsigned int f47:2;
	unsigned int f48:3;
	unsigned int f49:3;
	unsigned int f50:4;
	unsigned int f51:5;
	unsigned int f52:2;
} PFsimplify_plank_0[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   3,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  24,   0,},	/* row 3 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  24,   0,},	/* row 4 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 18 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  19,   0,},	/* row 19 */
	{   0,   0,   5,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  13,   0,},	/* row 23 */
	{   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  22,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,  14,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 28 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  18,   0,},	/* row 29 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  20,   0,},	/* row 30 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   1,   0,},	/* row 31 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   1,   0,},	/* row 32 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   3,   0,},	/* row 33 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   4,   0,},	/* row 34 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   3,   0,},	/* row 35 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   3,   0,},	/* row 36 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   4,   0,},	/* row 37 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   3,   0,},	/* row 38 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   4,   0,},	/* row 39 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   3,   0,},	/* row 40 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   4,   0,},	/* row 41 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   3,   0,},	/* row 42 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   3,   0,},	/* row 43 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   3,   0,},	/* row 44 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   4,   0,},	/* row 45 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   3,   0,},	/* row 46 */
	{   0,   0,  13,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   0,   0,  12,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   7,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   8,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   9,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   7,   0,},	/* row 59 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   9,   0,},	/* row 60 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   8,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   6,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   6,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 81 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 82 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 83 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 84 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,},	/* row 85 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 86 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 89 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 90 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 96 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 97 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 98 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 99 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   1,   0,},	/* row 100 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   1,   0,},	/* row 101 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   1,   0,},	/* row 102 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   1,   0,},	/* row 103 */
	{   2,   1,   0,   0,   0,   0,   0,   1,   0,  26,   0,},	/* row 104 */
	{   2,   2,   0,   0,   0,   0,   0,   1,   0,  26,   0,},	/* row 105 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 106 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 107 */
	{   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   0,},	/* row 108 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  15,   0,},	/* row 109 */
	{   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,},	/* row 110 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 111 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 113 */
	{   0,   0,  11,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 114 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  21,   0,},	/* row 115 */
	{   0,   0,  10,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 116 */
	{   0,   0,   9,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 117 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   6,   0,},	/* row 118 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  16,   0,},	/* row 119 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 120 */
	{   0,   0,   7,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 121 */
	{   0,   0,   6,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 122 */
	{   0,   0,   8,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 123 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  25,   0,},	/* row 124 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  12,   0,},	/* row 125 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  10,   0,},	/* row 126 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  10,   0,},	/* row 127 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  11,   0,},	/* row 128 */
	{   2,   0,   0,   1,   0,   0,   0,   1,   0,   2,   0,},	/* row 129 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 130 */
	{   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 131 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 132 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 133 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  23,   0,},	/* row 134 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 135 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   1,   0,},	/* row 136 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   5,   0,},	/* row 137 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  14,   0,},	/* row 138 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,   1,   0,},	/* row 139 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,},	/* row 140 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 141 */
	{   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 142 */
	{   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,},	/* row 143 */
	{   2,   0,   0,   0,   0,   0,   0,   1,   0,  17,   0,},	/* row 144 */
};
static struct {
	unsigned int f28:2;
	unsigned int f29:2;
	unsigned int f30:2;
	unsigned int f31:2;
	unsigned int f32:2;
	unsigned int f33:2;
	unsigned int f34:2;
	unsigned int f35:2;
	unsigned int f36:2;
	unsigned int f37:2;
	unsigned int f38:3;
	unsigned int f39:3;
	unsigned int f40:3;
	unsigned int f41:2;
} PFsimplify_plank_1[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   1,   1,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   1,},	/* row 3 */
	{   1,   1,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   2,},	/* row 4 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 13 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 14 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,},	/* row 17 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 18 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 19 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 28 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 29 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 31 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   3,   2,   0,   0,},	/* row 32 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 33 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 34 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 35 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 36 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 37 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 38 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 39 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 40 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 41 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 42 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 43 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 44 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 45 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 58 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 81 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 82 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 83 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 84 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 85 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 86 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 89 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 90 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 96 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 97 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 98 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 99 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   1,   2,   0,   0,},	/* row 100 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   6,   2,   0,   0,},	/* row 101 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   5,   2,   0,   0,},	/* row 102 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   4,   2,   0,   0,},	/* row 103 */
	{   2,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 104 */
	{   2,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 105 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 106 */
	{   0,   0,   1,   0,   1,   0,   0,   0,   1,   2,   0,   0,   2,   0,},	/* row 107 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 108 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 109 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 110 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 111 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 112 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   2,   0,   0,   0,   0,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 114 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 115 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 116 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 117 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 118 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 119 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 120 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 121 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 122 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 123 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 124 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 125 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 126 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 127 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 128 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 129 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 130 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 131 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 132 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 133 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 134 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 135 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   2,   2,   0,   0,},	/* row 136 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 137 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 138 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 139 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 140 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 141 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 142 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 143 */
	{   1,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 144 */
};
static struct {
	unsigned int f14:2;
	unsigned int f15:2;
	unsigned int f16:2;
	unsigned int f17:3;
	unsigned int f18:2;
	unsigned int f19:4;
	unsigned int f20:2;
	unsigned int f21:2;
	unsigned int f22:2;
	unsigned int f23:2;
	unsigned int f24:2;
	unsigned int f25:3;
	unsigned int f26:2;
	unsigned int f27:2;
} PFsimplify_plank_2[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 2 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 3 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 4 */
	{   0,   0,   0,   2,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 5 */
	{   0,   0,   0,   2,   0,   6,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   2,   0,   7,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   1,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   1,   0,   5,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   2,   0,   7,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   1,   0,   6,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   1,   0,   5,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   1,   0,   6,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   1,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   0,   0,   1,   0,   7,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   0,   0,   0,   2,   0,   3,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   0,   0,   2,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   0,   0,   0,   2,   0,   5,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 18 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 19 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 24 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 28 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 29 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 30 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 31 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 32 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 33 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 34 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 35 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 36 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 37 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 38 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 39 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 40 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 41 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 42 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 43 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 44 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 45 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 59 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 60 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 75 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 76 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 77 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 78 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 79 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 80 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 81 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 82 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 83 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 84 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 85 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 86 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 87 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 89 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 90 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 91 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 92 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 96 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 97 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 98 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 99 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 100 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 101 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 102 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 103 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 104 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 105 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 106 */
	{   0,   0,   1,   2,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 107 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 108 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 109 */
	{   0,   1,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 110 */
	{   0,   1,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 111 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 114 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 115 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 116 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 117 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 118 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 119 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 120 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 121 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 122 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 123 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 124 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 125 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 126 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 127 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 128 */
	{   1,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 129 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 130 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 131 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 132 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 133 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 134 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 135 */
	{   2,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 136 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 137 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 138 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 139 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 140 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 141 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 142 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 143 */
	{   1,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 144 */
};
static struct {
	unsigned int f2:2;
	unsigned int f3:4;
	unsigned int f4:2;
	unsigned int f5:4;
	unsigned int f6:2;
	unsigned int f7:2;
	unsigned int f8:4;
	unsigned int f9:3;
	unsigned int f10:2;
	unsigned int f11:2;
	unsigned int f12:2;
	unsigned int f13:2;
} PFsimplify_plank_3[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 3 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 4 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 18 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 19 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 28 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 29 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 30 */
	{   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   2,   0,},	/* row 31 */
	{   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,   0,},	/* row 32 */
	{   1,   0,   1,   0,   0,   0,  14,   0,   0,   0,   2,   0,},	/* row 33 */
	{   1,   0,   1,   0,   0,   0,   4,   0,   0,   0,   2,   0,},	/* row 34 */
	{   1,   0,   1,   0,   0,   0,   3,   0,   0,   0,   2,   0,},	/* row 35 */
	{   1,   0,   1,   0,   0,   0,   5,   0,   0,   0,   2,   0,},	/* row 36 */
	{   1,   0,   1,   0,   0,   0,   6,   0,   0,   0,   2,   0,},	/* row 37 */
	{   1,   0,   1,   0,   0,   0,   8,   0,   0,   0,   2,   0,},	/* row 38 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 39 */
	{   1,   0,   1,   0,   0,   0,   9,   0,   0,   0,   2,   0,},	/* row 40 */
	{   1,   0,   1,   0,   0,   0,  10,   0,   0,   0,   2,   0,},	/* row 41 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 42 */
	{   1,   0,   1,   0,   0,   0,  11,   0,   0,   0,   2,   0,},	/* row 43 */
	{   1,   0,   1,   0,   0,   0,  12,   0,   0,   0,   2,   0,},	/* row 44 */
	{   1,   0,   1,   0,   0,   0,  13,   0,   0,   0,   2,   0,},	/* row 45 */
	{   1,   0,   1,   0,   0,   0,   7,   0,   0,   0,   2,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   1,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 49 */
	{   0,   1,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 50 */
	{   0,   1,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 59 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 60 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 61 */
	{   0,   6,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 62 */
	{   0,   5,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 63 */
	{   0,   3,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 64 */
	{   0,   5,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 65 */
	{   0,   3,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 66 */
	{   0,   5,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 67 */
	{   0,   3,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 68 */
	{   0,   2,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 69 */
	{   0,   4,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 70 */
	{   0,   2,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 71 */
	{   0,   3,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 72 */
	{   0,   7,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 73 */
	{   0,   6,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 74 */
	{   0,   4,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 75 */
	{   0,   2,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 76 */
	{   0,   7,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 77 */
	{   0,   4,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 78 */
	{   0,   5,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 79 */
	{   0,   9,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 80 */
	{   0,   8,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 81 */
	{   0,   4,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 82 */
	{   0,   2,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 83 */
	{   0,   7,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 84 */
	{   0,   6,   0,   0,   2,   0,   0,   0,   1,   0,   0,   0,},	/* row 85 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 86 */
	{   0,   0,   0,   6,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 87 */
	{   0,   0,   0,  14,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 88 */
	{   0,   0,   0,  13,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 89 */
	{   0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 90 */
	{   0,   0,   0,  12,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 91 */
	{   0,   0,   0,  11,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 92 */
	{   0,   0,   0,  10,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 93 */
	{   0,   0,   0,   9,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 94 */
	{   0,   0,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 95 */
	{   0,   0,   0,   5,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 96 */
	{   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 97 */
	{   0,   0,   0,   8,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 98 */
	{   0,   0,   0,   7,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 99 */
	{   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,   0,},	/* row 100 */
	{   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,   0,},	/* row 101 */
	{   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,   0,},	/* row 102 */
	{   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,   0,},	/* row 103 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 104 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 105 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 106 */
	{   0,   1,   0,   0,   1,   0,   0,   0,   1,   0,   0,   1,},	/* row 107 */
	{   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 108 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 109 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 110 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 111 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 112 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 113 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 114 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 115 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 116 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 117 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 118 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 119 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 120 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 121 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 122 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 123 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 124 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 125 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 126 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 127 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 128 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 129 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 130 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 131 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 132 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 133 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 134 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 135 */
	{   1,   0,   1,   0,   0,   0,   1,   0,   0,   0,   1,   0,},	/* row 136 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 137 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 138 */
	{   1,   0,   1,   0,   0,   1,   1,   0,   0,   0,   2,   2,},	/* row 139 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 140 */
	{   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 141 */
	{   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 142 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 143 */
	{   1,   0,   1,   0,   0,   0,   2,   0,   0,   0,   2,   0,},	/* row 144 */
};
static struct {
	unsigned int f0:3;
	unsigned int f1:2;
} PFsimplify_plank_4[] = {
	{   0,   0,},	/* row 0 */
	{   0,   0,},	/* row 1 */
	{   0,   0,},	/* row 2 */
	{   1,   1,},	/* row 3 */
	{   1,   1,},	/* row 4 */
	{   0,   0,},	/* row 5 */
	{   0,   0,},	/* row 6 */
	{   0,   0,},	/* row 7 */
	{   0,   0,},	/* row 8 */
	{   0,   0,},	/* row 9 */
	{   0,   0,},	/* row 10 */
	{   0,   0,},	/* row 11 */
	{   0,   0,},	/* row 12 */
	{   0,   0,},	/* row 13 */
	{   0,   0,},	/* row 14 */
	{   0,   0,},	/* row 15 */
	{   0,   0,},	/* row 16 */
	{   0,   0,},	/* row 17 */
	{   0,   0,},	/* row 18 */
	{   1,   1,},	/* row 19 */
	{   0,   0,},	/* row 20 */
	{   0,   0,},	/* row 21 */
	{   0,   0,},	/* row 22 */
	{   1,   1,},	/* row 23 */
	{   0,   0,},	/* row 24 */
	{   1,   1,},	/* row 25 */
	{   0,   0,},	/* row 26 */
	{   0,   0,},	/* row 27 */
	{   0,   0,},	/* row 28 */
	{   1,   1,},	/* row 29 */
	{   1,   1,},	/* row 30 */
	{   2,   2,},	/* row 31 */
	{   1,   1,},	/* row 32 */
	{   1,   1,},	/* row 33 */
	{   1,   1,},	/* row 34 */
	{   1,   1,},	/* row 35 */
	{   1,   1,},	/* row 36 */
	{   1,   1,},	/* row 37 */
	{   1,   1,},	/* row 38 */
	{   1,   1,},	/* row 39 */
	{   1,   1,},	/* row 40 */
	{   1,   1,},	/* row 41 */
	{   1,   1,},	/* row 42 */
	{   1,   1,},	/* row 43 */
	{   1,   1,},	/* row 44 */
	{   1,   1,},	/* row 45 */
	{   1,   1,},	/* row 46 */
	{   0,   0,},	/* row 47 */
	{   0,   0,},	/* row 48 */
	{   0,   0,},	/* row 49 */
	{   0,   0,},	/* row 50 */
	{   0,   0,},	/* row 51 */
	{   0,   0,},	/* row 52 */
	{   0,   0,},	/* row 53 */
	{   0,   0,},	/* row 54 */
	{   0,   0,},	/* row 55 */
	{   0,   0,},	/* row 56 */
	{   0,   0,},	/* row 57 */
	{   0,   0,},	/* row 58 */
	{   1,   1,},	/* row 59 */
	{   1,   1,},	/* row 60 */
	{   1,   1,},	/* row 61 */
	{   0,   0,},	/* row 62 */
	{   0,   0,},	/* row 63 */
	{   0,   0,},	/* row 64 */
	{   0,   0,},	/* row 65 */
	{   0,   0,},	/* row 66 */
	{   0,   0,},	/* row 67 */
	{   0,   0,},	/* row 68 */
	{   0,   0,},	/* row 69 */
	{   0,   0,},	/* row 70 */
	{   0,   0,},	/* row 71 */
	{   0,   0,},	/* row 72 */
	{   0,   0,},	/* row 73 */
	{   0,   0,},	/* row 74 */
	{   0,   0,},	/* row 75 */
	{   0,   0,},	/* row 76 */
	{   0,   0,},	/* row 77 */
	{   0,   0,},	/* row 78 */
	{   0,   0,},	/* row 79 */
	{   0,   0,},	/* row 80 */
	{   0,   0,},	/* row 81 */
	{   0,   0,},	/* row 82 */
	{   0,   0,},	/* row 83 */
	{   0,   0,},	/* row 84 */
	{   0,   0,},	/* row 85 */
	{   0,   0,},	/* row 86 */
	{   0,   0,},	/* row 87 */
	{   0,   0,},	/* row 88 */
	{   0,   0,},	/* row 89 */
	{   0,   0,},	/* row 90 */
	{   0,   0,},	/* row 91 */
	{   0,   0,},	/* row 92 */
	{   0,   0,},	/* row 93 */
	{   0,   0,},	/* row 94 */
	{   0,   0,},	/* row 95 */
	{   0,   0,},	/* row 96 */
	{   0,   0,},	/* row 97 */
	{   0,   0,},	/* row 98 */
	{   0,   0,},	/* row 99 */
	{   1,   1,},	/* row 100 */
	{   1,   1,},	/* row 101 */
	{   1,   1,},	/* row 102 */
	{   1,   1,},	/* row 103 */
	{   1,   1,},	/* row 104 */
	{   1,   1,},	/* row 105 */
	{   0,   0,},	/* row 106 */
	{   0,   0,},	/* row 107 */
	{   0,   0,},	/* row 108 */
	{   1,   1,},	/* row 109 */
	{   0,   0,},	/* row 110 */
	{   0,   0,},	/* row 111 */
	{   0,   0,},	/* row 112 */
	{   0,   0,},	/* row 113 */
	{   0,   0,},	/* row 114 */
	{   1,   1,},	/* row 115 */
	{   0,   0,},	/* row 116 */
	{   0,   0,},	/* row 117 */
	{   1,   1,},	/* row 118 */
	{   1,   1,},	/* row 119 */
	{   0,   0,},	/* row 120 */
	{   0,   0,},	/* row 121 */
	{   0,   0,},	/* row 122 */
	{   0,   0,},	/* row 123 */
	{   4,   1,},	/* row 124 */
	{   4,   1,},	/* row 125 */
	{   3,   1,},	/* row 126 */
	{   5,   1,},	/* row 127 */
	{   3,   1,},	/* row 128 */
	{   1,   1,},	/* row 129 */
	{   0,   0,},	/* row 130 */
	{   0,   0,},	/* row 131 */
	{   0,   0,},	/* row 132 */
	{   0,   0,},	/* row 133 */
	{   1,   1,},	/* row 134 */
	{   0,   0,},	/* row 135 */
	{   1,   1,},	/* row 136 */
	{   1,   1,},	/* row 137 */
	{   1,   1,},	/* row 138 */
	{   1,   1,},	/* row 139 */
	{   0,   0,},	/* row 140 */
	{   0,   0,},	/* row 141 */
	{   0,   0,},	/* row 142 */
	{   0,   0,},	/* row 143 */
	{   1,   1,},	/* row 144 */
};
static short PFsimplify_eruleMap[] = {
    0,   19,  102,  101,    0,   30,   31,   32,   33,   50,	/* 0-9 */
   54,   55,   11,   12,   13,   56,   15,   97,   96,   95,	/* 10-19 */
  123,  124,   83,   81,   80,   85,   84,   82,   90,   16,	/* 20-29 */
   60,    0,   18,   91,    0,  121,    0,   93,   94,   92,	/* 30-39 */
    0,  120,    0,   20,    0,  111,  110,    0,  107,  108,	/* 40-49 */
  109,  104,  105,  106,    0,   65,   64,   62,   61,   63,	/* 50-59 */
   74,   73,   72,   71,   70,   69,   68,   67,   66,    0,	/* 60-69 */
   75,   76,    0,    6,   41,   40,    7,    5,    4,   34,	/* 70-79 */
    3,    2,    0,   35,   36,    0,   44,    9,   45,    0,	/* 80-89 */
   47,   46,    0,  113,  114,    0,    1,    0,   51,   52,	/* 90-99 */
    0,   53,    0,   86,   87,    0,   43,    8,   42
};
#define PFsimplify_Query_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f52 +95]
#define PFsimplify_CoreExpr_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f51 +4]
#define PFsimplify_OptBindExpr_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f50 +72]
#define PFsimplify_OptVar_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_3[state].f13 +82]
#define PFsimplify_WhereExpr_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f49 +105]
#define PFsimplify_OrdWhereExpr_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f48 +85]
#define PFsimplify_OrderSpecs_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f47 +89]
#define PFsimplify_SequenceType_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f46 +97]
#define PFsimplify_SequenceTypeCast_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f45 +100]
#define PFsimplify_LocationStep_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f44 +54]
#define PFsimplify_LocationSteps_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f43 +69]
#define PFsimplify_TagName_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_0[state].f42 +102]
#define PFsimplify_FunExpr_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_1[state].f41 +31]
#define PFsimplify_FunctionArgs_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_1[state].f40 +36]
#define PFsimplify_Atom_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_1[state].f39 +0]
#define PFsimplify_LiteralValue_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_1[state].f38 +47]
#define PFsimplify_FunctionDecls_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_1[state].f37 +44]
#define PFsimplify_FunctionDecl_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_1[state].f31 +42]
#define PFsimplify_ParamList_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_1[state].f36 +92]
#define PFsimplify_FunctionBody_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_3[state].f2 +40]
#define PFsimplify_FunParam_rule(state)	PFsimplify_eruleMap[PFsimplify_plank_1[state].f33 +34]

#ifdef __STDC__
int PFsimplify_rule(int state, int goalnt) {
#else
int PFsimplify_rule(state, goalnt) int state; int goalnt; {
#endif
	PFsimplify_assert(state >= 0 && state < 145, PFsimplify_PANIC("Bad state %d passed to PFsimplify_rule\n", state));
	switch(goalnt) {
	case 1:
		return PFsimplify_Query_rule(state);
	case 2:
		return PFsimplify_CoreExpr_rule(state);
	case 3:
		return PFsimplify_OptBindExpr_rule(state);
	case 4:
		return PFsimplify_OptVar_rule(state);
	case 5:
		return PFsimplify_WhereExpr_rule(state);
	case 6:
		return PFsimplify_OrdWhereExpr_rule(state);
	case 7:
		return PFsimplify_OrderSpecs_rule(state);
	case 8:
		return PFsimplify_SequenceType_rule(state);
	case 9:
		return PFsimplify_SequenceTypeCast_rule(state);
	case 10:
		return PFsimplify_LocationStep_rule(state);
	case 11:
		return PFsimplify_LocationSteps_rule(state);
	case 12:
		return PFsimplify_TagName_rule(state);
	case 13:
		return PFsimplify_FunExpr_rule(state);
	case 14:
		return PFsimplify_FunctionArgs_rule(state);
	case 15:
		return PFsimplify_Atom_rule(state);
	case 16:
		return PFsimplify_LiteralValue_rule(state);
	case 17:
		return PFsimplify_FunctionDecls_rule(state);
	case 18:
		return PFsimplify_FunctionDecl_rule(state);
	case 19:
		return PFsimplify_ParamList_rule(state);
	case 20:
		return PFsimplify_FunctionBody_rule(state);
	case 21:
		return PFsimplify_FunParam_rule(state);
	default:
		PFsimplify_PANIC("Unknown nonterminal %d in PFsimplify_rule;\n", goalnt);
		abort();
		return 0;
	}
}

int PFsimplify_TEMP;
#define PFsimplify_var_state	139
#define PFsimplify_lit_str_state	103
#define PFsimplify_lit_int_state	102
#define PFsimplify_lit_dec_state	101
#define PFsimplify_lit_dbl_state	100
#define PFsimplify_nil_state	107
#define PFsimplify_seq_state(l,r)	( (PFsimplify_TEMP = PFsimplify_seq_transition[PFsimplify_plank_4[l].f0][PFsimplify_plank_4[r].f1]) ? PFsimplify_TEMP + 123 : 0 )
#define PFsimplify_ordered_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_3[l].f2) ? PFsimplify_TEMP + 108 : 0 )
#define PFsimplify_unordered_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_3[l].f2) ? PFsimplify_TEMP + 137 : 0 )
#define PFsimplify_flwr_state(l,r)	( (PFsimplify_TEMP = PFsimplify_flwr_transition[PFsimplify_plank_3[l].f3][PFsimplify_plank_3[r].f4]) ? PFsimplify_TEMP + 32 : 0 )
#define PFsimplify_let_state(l,r)	( (PFsimplify_TEMP = PFsimplify_let_transition[PFsimplify_plank_3[l].f5][PFsimplify_plank_3[r].f6]) ? PFsimplify_TEMP + 61 : 0 )
#define PFsimplify_letbind_state(l,r)	( (PFsimplify_TEMP = PFsimplify_letbind_transition[PFsimplify_plank_3[l].f7][PFsimplify_plank_3[r].f8]) ? PFsimplify_TEMP + 85 : 0 )
#define PFsimplify_for__state(l,r)	( (PFsimplify_TEMP = PFsimplify_for__transition[PFsimplify_plank_3[l].f9][PFsimplify_plank_3[r].f10]) ? PFsimplify_TEMP + 48 : 0 )
#define PFsimplify_forbind_state(l,r)	( (PFsimplify_TEMP = PFsimplify_forbind_transition[PFsimplify_plank_3[l].f11][PFsimplify_plank_3[r].f12]) ? PFsimplify_TEMP + 51 : 0 )
#define PFsimplify_forvars_state(l,r)	( (PFsimplify_TEMP = PFsimplify_forvars_transition[PFsimplify_plank_3[l].f7][PFsimplify_plank_3[r].f13]) ? PFsimplify_TEMP + 54 : 0 )
#define PFsimplify_where_state(l,r)	( (PFsimplify_TEMP = PFsimplify_where_transition[PFsimplify_plank_2[l].f14][PFsimplify_plank_3[r].f4]) ? PFsimplify_TEMP + 139 : 0 )
#define PFsimplify_orderby_state(l,r)	( (PFsimplify_TEMP = PFsimplify_orderby_transition[PFsimplify_plank_2[l].f15][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 107 : 0 )
#define PFsimplify_orderspecs_state(l,r)	( (PFsimplify_TEMP = PFsimplify_orderspecs_transition[PFsimplify_plank_3[l].f2][PFsimplify_plank_2[r].f16]) ? PFsimplify_TEMP + 109 : 0 )
#define PFsimplify_apply_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f17) ? PFsimplify_TEMP + 2 : 0 )
#define PFsimplify_arg_state(l,r)	( (PFsimplify_TEMP = PFsimplify_arg_transition[PFsimplify_plank_2[l].f18][PFsimplify_plank_2[r].f19]) ? PFsimplify_TEMP + 4 : 0 )
#define PFsimplify_typesw_state(l,r)	( (PFsimplify_TEMP = PFsimplify_typesw_transition[PFsimplify_plank_3[l].f2][PFsimplify_plank_2[r].f20]) ? PFsimplify_TEMP + 136 : 0 )
#define PFsimplify_cases_state(l,r)	( (PFsimplify_TEMP = PFsimplify_cases_transition[PFsimplify_plank_2[l].f21][PFsimplify_plank_2[r].f22]) ? PFsimplify_TEMP + 21 : 0 )
#define PFsimplify_case__state(l,r)	( (PFsimplify_TEMP = PFsimplify_case__transition[PFsimplify_plank_2[l].f23][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 20 : 0 )
#define PFsimplify_default__state(l)	( (PFsimplify_TEMP = PFsimplify_plank_3[l].f2) ? PFsimplify_TEMP + 25 : 0 )
#define PFsimplify_seqtype_state	130
#define PFsimplify_seqcast_state(l,r)	( (PFsimplify_TEMP = PFsimplify_seqcast_transition[PFsimplify_plank_2[l].f23][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 128 : 0 )
#define PFsimplify_proof_state(l,r)	( (PFsimplify_TEMP = PFsimplify_proof_transition[PFsimplify_plank_2[l].f24][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 117 : 0 )
#define PFsimplify_subty_state(l,r)	( (PFsimplify_TEMP = PFsimplify_subty_transition[PFsimplify_plank_3[l].f2][PFsimplify_plank_2[r].f23]) ? PFsimplify_TEMP + 131 : 0 )
#define PFsimplify_stattype_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_3[l].f2) ? PFsimplify_TEMP + 130 : 0 )
#define PFsimplify_if__state(l,r)	( (PFsimplify_TEMP = PFsimplify_if__transition[PFsimplify_plank_2[l].f25][PFsimplify_plank_2[r].f26]) ? PFsimplify_TEMP + 58 : 0 )
#define PFsimplify_then_else_state(l,r)	( (PFsimplify_TEMP = PFsimplify_then_else_transition[PFsimplify_plank_3[l].f2][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 134 : 0 )
#define PFsimplify_locsteps_state(l,r)	( (PFsimplify_TEMP = PFsimplify_locsteps_transition[PFsimplify_plank_2[l].f27][PFsimplify_plank_1[r].f28]) ? PFsimplify_TEMP + 103 : 0 )
#define PFsimplify_ancestor_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 0 : 0 )
#define PFsimplify_ancestor_or_self_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 1 : 0 )
#define PFsimplify_attribute_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 19 : 0 )
#define PFsimplify_child_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 23 : 0 )
#define PFsimplify_descendant_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 26 : 0 )
#define PFsimplify_descendant_or_self_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 27 : 0 )
#define PFsimplify_following_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 46 : 0 )
#define PFsimplify_following_sibling_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 47 : 0 )
#define PFsimplify_parent_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 113 : 0 )
#define PFsimplify_preceding_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 115 : 0 )
#define PFsimplify_preceding_sibling_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 116 : 0 )
#define PFsimplify_self_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 122 : 0 )
#define PFsimplify_select_narrow_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 120 : 0 )
#define PFsimplify_select_wide_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_2[l].f23) ? PFsimplify_TEMP + 121 : 0 )
#define PFsimplify_elem_state(l,r)	( (PFsimplify_TEMP = PFsimplify_elem_transition[PFsimplify_plank_1[l].f29][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 29 : 0 )
#define PFsimplify_attr_state(l,r)	( (PFsimplify_TEMP = PFsimplify_attr_transition[PFsimplify_plank_1[l].f29][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 18 : 0 )
#define PFsimplify_text_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_3[l].f2) ? PFsimplify_TEMP + 133 : 0 )
#define PFsimplify_doc_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_3[l].f2) ? PFsimplify_TEMP + 28 : 0 )
#define PFsimplify_comment_state(l)	( (PFsimplify_TEMP = PFsimplify_plank_3[l].f2) ? PFsimplify_TEMP + 24 : 0 )
#define PFsimplify_pi_state(l,r)	( (PFsimplify_TEMP = PFsimplify_pi_transition[PFsimplify_plank_3[l].f2][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 114 : 0 )
#define PFsimplify_tag_state	133
#define PFsimplify_true__state	136
#define PFsimplify_false__state	32
#define PFsimplify_empty_state	31
#define PFsimplify_main_state(l,r)	( (PFsimplify_TEMP = PFsimplify_main_transition[PFsimplify_plank_1[l].f30][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 105 : 0 )
#define PFsimplify_fun_decls_state(l,r)	( (PFsimplify_TEMP = PFsimplify_fun_decls_transition[PFsimplify_plank_1[l].f31][PFsimplify_plank_1[r].f30]) ? PFsimplify_TEMP + 57 : 0 )
#define PFsimplify_fun_decl_state(l,r)	( (PFsimplify_TEMP = PFsimplify_fun_decl_transition[PFsimplify_plank_1[l].f32][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 56 : 0 )
#define PFsimplify_params_state(l,r)	( (PFsimplify_TEMP = PFsimplify_params_transition[PFsimplify_plank_1[l].f33][PFsimplify_plank_1[r].f32]) ? PFsimplify_TEMP + 112 : 0 )
#define PFsimplify_param_state(l,r)	( (PFsimplify_TEMP = PFsimplify_param_transition[PFsimplify_plank_2[l].f23][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 111 : 0 )
#define PFsimplify_cast_state(l,r)	( (PFsimplify_TEMP = PFsimplify_cast_transition[PFsimplify_plank_2[l].f23][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 22 : 0 )
#define PFsimplify_recursion_state(l,r)	( (PFsimplify_TEMP = PFsimplify_recursion_transition[PFsimplify_plank_3[l].f7][PFsimplify_plank_1[r].f34]) ? PFsimplify_TEMP + 118 : 0 )
#define PFsimplify_seed_state(l,r)	( (PFsimplify_TEMP = PFsimplify_seed_transition[PFsimplify_plank_3[l].f2][PFsimplify_plank_3[r].f2]) ? PFsimplify_TEMP + 119 : 0 )
#define PFsimplify_xrpc_state(l,r)	( (PFsimplify_TEMP = PFsimplify_xrpc_transition[PFsimplify_plank_3[l].f2][PFsimplify_plank_1[r].f35]) ? PFsimplify_TEMP + 143 : 0 )

#ifdef __STDC__
int PFsimplify_state(int op, int l, int r) {
#else
int PFsimplify_state(op, l, r) int op; int l; int r; {
#endif
	register int PFsimplify_TEMP;
#ifndef NDEBUG
	switch (op) {
	case 7:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 24:
	case 25:
	case 26:
	case 27:
	case 30:
	case 31:
	case 32:
	case 34:
	case 35:
	case 40:
	case 55:
	case 56:
	case 60:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
		PFsimplify_assert(r >= 0 && r < 145, PFsimplify_PANIC("Bad state %d passed to PFsimplify_state\n", r));
		/*FALLTHROUGH*/
	case 9:
	case 10:
	case 23:
	case 28:
	case 33:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 57:
	case 58:
	case 59:
		PFsimplify_assert(l >= 0 && l < 145, PFsimplify_PANIC("Bad state %d passed to PFsimplify_state\n", l));
		/*FALLTHROUGH*/
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 29:
	case 61:
	case 65:
	case 66:
	case 67:
		break;
	}
#endif
	switch (op) {
	default: PFsimplify_PANIC("Unknown op %d in PFsimplify_state\n", op); abort(); return 0;
	case 1:
		return PFsimplify_var_state;
	case 2:
		return PFsimplify_lit_str_state;
	case 3:
		return PFsimplify_lit_int_state;
	case 4:
		return PFsimplify_lit_dec_state;
	case 5:
		return PFsimplify_lit_dbl_state;
	case 6:
		return PFsimplify_nil_state;
	case 7:
		return PFsimplify_seq_state(l,r);
	case 9:
		return PFsimplify_ordered_state(l);
	case 10:
		return PFsimplify_unordered_state(l);
	case 14:
		return PFsimplify_flwr_state(l,r);
	case 15:
		return PFsimplify_let_state(l,r);
	case 16:
		return PFsimplify_letbind_state(l,r);
	case 17:
		return PFsimplify_for__state(l,r);
	case 18:
		return PFsimplify_forbind_state(l,r);
	case 19:
		return PFsimplify_forvars_state(l,r);
	case 20:
		return PFsimplify_where_state(l,r);
	case 21:
		return PFsimplify_orderby_state(l,r);
	case 22:
		return PFsimplify_orderspecs_state(l,r);
	case 23:
		return PFsimplify_apply_state(l);
	case 24:
		return PFsimplify_arg_state(l,r);
	case 25:
		return PFsimplify_typesw_state(l,r);
	case 26:
		return PFsimplify_cases_state(l,r);
	case 27:
		return PFsimplify_case__state(l,r);
	case 28:
		return PFsimplify_default__state(l);
	case 29:
		return PFsimplify_seqtype_state;
	case 30:
		return PFsimplify_seqcast_state(l,r);
	case 31:
		return PFsimplify_proof_state(l,r);
	case 32:
		return PFsimplify_subty_state(l,r);
	case 33:
		return PFsimplify_stattype_state(l);
	case 34:
		return PFsimplify_if__state(l,r);
	case 35:
		return PFsimplify_then_else_state(l,r);
	case 40:
		return PFsimplify_locsteps_state(l,r);
	case 41:
		return PFsimplify_ancestor_state(l);
	case 42:
		return PFsimplify_ancestor_or_self_state(l);
	case 43:
		return PFsimplify_attribute_state(l);
	case 44:
		return PFsimplify_child_state(l);
	case 45:
		return PFsimplify_descendant_state(l);
	case 46:
		return PFsimplify_descendant_or_self_state(l);
	case 47:
		return PFsimplify_following_state(l);
	case 48:
		return PFsimplify_following_sibling_state(l);
	case 49:
		return PFsimplify_parent_state(l);
	case 50:
		return PFsimplify_preceding_state(l);
	case 51:
		return PFsimplify_preceding_sibling_state(l);
	case 52:
		return PFsimplify_self_state(l);
	case 53:
		return PFsimplify_select_narrow_state(l);
	case 54:
		return PFsimplify_select_wide_state(l);
	case 55:
		return PFsimplify_elem_state(l,r);
	case 56:
		return PFsimplify_attr_state(l,r);
	case 57:
		return PFsimplify_text_state(l);
	case 58:
		return PFsimplify_doc_state(l);
	case 59:
		return PFsimplify_comment_state(l);
	case 60:
		return PFsimplify_pi_state(l,r);
	case 61:
		return PFsimplify_tag_state;
	case 65:
		return PFsimplify_true__state;
	case 66:
		return PFsimplify_false__state;
	case 67:
		return PFsimplify_empty_state;
	case 68:
		return PFsimplify_main_state(l,r);
	case 69:
		return PFsimplify_fun_decls_state(l,r);
	case 70:
		return PFsimplify_fun_decl_state(l,r);
	case 71:
		return PFsimplify_params_state(l,r);
	case 72:
		return PFsimplify_param_state(l,r);
	case 73:
		return PFsimplify_cast_state(l,r);
	case 74:
		return PFsimplify_recursion_state(l,r);
	case 75:
		return PFsimplify_seed_state(l,r);
	case 76:
		return PFsimplify_xrpc_state(l,r);
	}
}
#ifdef PFsimplify_STATE_LABEL
#define PFsimplify_INCLUDE_EXTRA
#else
#ifdef STATE_LABEL
#define PFsimplify_INCLUDE_EXTRA
#define PFsimplify_STATE_LABEL 	STATE_LABEL
#define PFsimplify_NODEPTR_TYPE	NODEPTR_TYPE
#define PFsimplify_LEFT_CHILD  	LEFT_CHILD
#define PFsimplify_OP_LABEL    	OP_LABEL
#define PFsimplify_RIGHT_CHILD 	RIGHT_CHILD
#endif /* STATE_LABEL */
#endif /* PFsimplify_STATE_LABEL */

#ifdef PFsimplify_INCLUDE_EXTRA

#ifdef __STDC__
int PFsimplify_label(PFsimplify_NODEPTR_TYPE n) {
#else
int PFsimplify_label(n) PFsimplify_NODEPTR_TYPE n; {
#endif
	PFsimplify_assert(n, PFsimplify_PANIC("NULL pointer passed to PFsimplify_label\n"));
	switch (PFsimplify_OP_LABEL(n)) {
	default: PFsimplify_PANIC("Bad op %d in PFsimplify_label\n", PFsimplify_OP_LABEL(n)); abort(); return 0;
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 29:
	case 61:
	case 65:
	case 66:
	case 67:
		return PFsimplify_STATE_LABEL(n) = PFsimplify_state(PFsimplify_OP_LABEL(n), 0, 0);
	case 9:
	case 10:
	case 23:
	case 28:
	case 33:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 57:
	case 58:
	case 59:
		return PFsimplify_STATE_LABEL(n) = PFsimplify_state(PFsimplify_OP_LABEL(n), PFsimplify_label(PFsimplify_LEFT_CHILD(n)), 0);
	case 7:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 24:
	case 25:
	case 26:
	case 27:
	case 30:
	case 31:
	case 32:
	case 34:
	case 35:
	case 40:
	case 55:
	case 56:
	case 60:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
		return PFsimplify_STATE_LABEL(n) = PFsimplify_state(PFsimplify_OP_LABEL(n), PFsimplify_label(PFsimplify_LEFT_CHILD(n)), PFsimplify_label(PFsimplify_RIGHT_CHILD(n)));
	}
}
#ifdef __STDC__
PFsimplify_NODEPTR_TYPE * PFsimplify_kids(PFsimplify_NODEPTR_TYPE p, int rulenumber, PFsimplify_NODEPTR_TYPE *kids) {
#else
PFsimplify_NODEPTR_TYPE * PFsimplify_kids(p, rulenumber, kids) PFsimplify_NODEPTR_TYPE p; int rulenumber; PFsimplify_NODEPTR_TYPE *kids; {
#endif
	PFsimplify_assert(p, PFsimplify_PANIC("NULL node pointer passed to PFsimplify_kids\n"));
	PFsimplify_assert(kids, PFsimplify_PANIC("NULL kids pointer passed to PFsimplify_kids\n"));
	switch (rulenumber) {
	default:
		PFsimplify_PANIC("Unknown Rule %d in PFsimplify_kids;\n", rulenumber);
		abort();
		/* NOTREACHED */
	case 34:
		kids[0] = PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(PFsimplify_LEFT_CHILD(p)));
		kids[1] = PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p));
		kids[2] = PFsimplify_RIGHT_CHILD(p);
		break;
	case 5:
		kids[0] = PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(PFsimplify_LEFT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p)))));
		kids[1] = PFsimplify_RIGHT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p)));
		kids[2] = PFsimplify_RIGHT_CHILD(p);
		break;
	case 6:
	case 7:
		kids[0] = PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(PFsimplify_LEFT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p)))));
		kids[1] = PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p))));
		kids[2] = PFsimplify_RIGHT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p)));
		kids[3] = PFsimplify_RIGHT_CHILD(p);
		break;
	case 2:
	case 3:
	case 4:
	case 40:
		kids[0] = PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p));
		kids[1] = PFsimplify_RIGHT_CHILD(p);
		break;
	case 50:
		kids[0] = PFsimplify_LEFT_CHILD(p);
		kids[1] = PFsimplify_LEFT_CHILD(PFsimplify_LEFT_CHILD(PFsimplify_RIGHT_CHILD(p)));
		kids[2] = PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(PFsimplify_RIGHT_CHILD(p)));
		kids[3] = PFsimplify_LEFT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_RIGHT_CHILD(p)));
		break;
	case 55:
		kids[0] = PFsimplify_LEFT_CHILD(p);
		kids[1] = PFsimplify_LEFT_CHILD(PFsimplify_RIGHT_CHILD(p));
		kids[2] = PFsimplify_RIGHT_CHILD(PFsimplify_RIGHT_CHILD(p));
		break;
	case 54:
	case 13:
		kids[0] = PFsimplify_LEFT_CHILD(PFsimplify_LEFT_CHILD(p));
		kids[1] = PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p));
		kids[2] = PFsimplify_RIGHT_CHILD(p);
		break;
	case 8:
	case 9:
	case 15:
		kids[0] = PFsimplify_RIGHT_CHILD(p);
		break;
	case 18:
		kids[0] = PFsimplify_LEFT_CHILD(PFsimplify_LEFT_CHILD(p));
		kids[1] = PFsimplify_LEFT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p)));
		kids[2] = PFsimplify_LEFT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p))));
		kids[3] = PFsimplify_RIGHT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_RIGHT_CHILD(PFsimplify_LEFT_CHILD(p))));
		break;
	case 46:
	case 52:
	case 16:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 66:
	case 67:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 82:
	case 83:
	case 84:
	case 91:
	case 95:
	case 96:
		kids[0] = PFsimplify_LEFT_CHILD(p);
		break;
	case 35:
	case 36:
	case 41:
	case 51:
	case 86:
	case 94:
	case 19:
	case 101:
	case 104:
	case 105:
	case 106:
	case 107:
	case 108:
	case 109:
	case 110:
	case 113:
		break;
	case 30:
	case 31:
	case 43:
	case 60:
	case 87:
	case 90:
	case 102:
	case 120:
		kids[0] = p;
		break;
	case 11:
	case 12:
	case 123:
		kids[0] = PFsimplify_LEFT_CHILD(PFsimplify_RIGHT_CHILD(p));
		kids[1] = PFsimplify_RIGHT_CHILD(PFsimplify_RIGHT_CHILD(p));
		break;
	case 1:
	case 32:
	case 33:
	case 42:
	case 44:
	case 45:
	case 47:
	case 53:
	case 56:
	case 75:
	case 76:
	case 80:
	case 81:
	case 85:
	case 92:
	case 93:
	case 97:
	case 111:
	case 20:
	case 114:
	case 121:
	case 124:
		kids[0] = PFsimplify_LEFT_CHILD(p);
		kids[1] = PFsimplify_RIGHT_CHILD(p);
		break;
	}
	return kids;
}
#ifdef __STDC__
PFsimplify_NODEPTR_TYPE PFsimplify_child(PFsimplify_NODEPTR_TYPE p, int index) {
#else
PFsimplify_NODEPTR_TYPE PFsimplify_child(p, index) PFsimplify_NODEPTR_TYPE p; int index; {
#endif
	PFsimplify_assert(p, PFsimplify_PANIC("NULL pointer passed to PFsimplify_child\n"));
	switch (index) {
	case 0:
		return PFsimplify_LEFT_CHILD(p);
	case 1:
		return PFsimplify_RIGHT_CHILD(p);
	}
	PFsimplify_PANIC("Bad index %d in PFsimplify_child;\n", index);
	abort();
	return 0;
}
#ifdef __STDC__
int PFsimplify_op_label(PFsimplify_NODEPTR_TYPE p) {
#else
int PFsimplify_op_label(p) PFsimplify_NODEPTR_TYPE p; {
#endif
	PFsimplify_assert(p, PFsimplify_PANIC("NULL pointer passed to PFsimplify_op_label\n"));
	return PFsimplify_OP_LABEL(p);
}
#ifdef __STDC__
int PFsimplify_state_label(PFsimplify_NODEPTR_TYPE p) {
#else
int PFsimplify_state_label(p) PFsimplify_NODEPTR_TYPE p; {
#endif
	PFsimplify_assert(p, PFsimplify_PANIC("NULL pointer passed to PFsimplify_state_label\n"));
	return PFsimplify_STATE_LABEL(p);
}
#endif /* PFsimplify_INCLUDE_EXTRA */
#define PFsimplify_FunParam_NT 21
#define PFsimplify_FunctionBody_NT 20
#define PFsimplify_ParamList_NT 19
#define PFsimplify_FunctionDecl_NT 18
#define PFsimplify_FunctionDecls_NT 17
#define PFsimplify_LiteralValue_NT 16
#define PFsimplify_Atom_NT 15
#define PFsimplify_FunctionArgs_NT 14
#define PFsimplify_FunExpr_NT 13
#define PFsimplify_TagName_NT 12
#define PFsimplify_LocationSteps_NT 11
#define PFsimplify_LocationStep_NT 10
#define PFsimplify_SequenceTypeCast_NT 9
#define PFsimplify_SequenceType_NT 8
#define PFsimplify_OrderSpecs_NT 7
#define PFsimplify_OrdWhereExpr_NT 6
#define PFsimplify_WhereExpr_NT 5
#define PFsimplify_OptVar_NT 4
#define PFsimplify_OptBindExpr_NT 3
#define PFsimplify_CoreExpr_NT 2
#define PFsimplify_Query_NT 1
#define PFsimplify_NT 21
char * PFsimplify_opname[] = {
	0, /* 0 */
	"var", /* 1 */
	"lit_str", /* 2 */
	"lit_int", /* 3 */
	"lit_dec", /* 4 */
	"lit_dbl", /* 5 */
	"nil", /* 6 */
	"seq", /* 7 */
	0, /* 8 */
	"ordered", /* 9 */
	"unordered", /* 10 */
	0, /* 11 */
	0, /* 12 */
	0, /* 13 */
	"flwr", /* 14 */
	"let", /* 15 */
	"letbind", /* 16 */
	"for_", /* 17 */
	"forbind", /* 18 */
	"forvars", /* 19 */
	"where", /* 20 */
	"orderby", /* 21 */
	"orderspecs", /* 22 */
	"apply", /* 23 */
	"arg", /* 24 */
	"typesw", /* 25 */
	"cases", /* 26 */
	"case_", /* 27 */
	"default_", /* 28 */
	"seqtype", /* 29 */
	"seqcast", /* 30 */
	"proof", /* 31 */
	"subty", /* 32 */
	"stattype", /* 33 */
	"if_", /* 34 */
	"then_else", /* 35 */
	0, /* 36 */
	0, /* 37 */
	0, /* 38 */
	0, /* 39 */
	"locsteps", /* 40 */
	"ancestor", /* 41 */
	"ancestor_or_self", /* 42 */
	"attribute", /* 43 */
	"child", /* 44 */
	"descendant", /* 45 */
	"descendant_or_self", /* 46 */
	"following", /* 47 */
	"following_sibling", /* 48 */
	"parent", /* 49 */
	"preceding", /* 50 */
	"preceding_sibling", /* 51 */
	"self", /* 52 */
	"select_narrow", /* 53 */
	"select_wide", /* 54 */
	"elem", /* 55 */
	"attr", /* 56 */
	"text", /* 57 */
	"doc", /* 58 */
	"comment", /* 59 */
	"pi", /* 60 */
	"tag", /* 61 */
	0, /* 62 */
	0, /* 63 */
	0, /* 64 */
	"true_", /* 65 */
	"false_", /* 66 */
	"empty", /* 67 */
	"main", /* 68 */
	"fun_decls", /* 69 */
	"fun_decl", /* 70 */
	"params", /* 71 */
	"param", /* 72 */
	"cast", /* 73 */
	"recursion", /* 74 */
	"seed", /* 75 */
	"xrpc"
};
char PFsimplify_arity[] = {
	-1, /* 0 */
	0, /* 1 */
	0, /* 2 */
	0, /* 3 */
	0, /* 4 */
	0, /* 5 */
	0, /* 6 */
	2, /* 7 */
	-1, /* 8 */
	1, /* 9 */
	1, /* 10 */
	-1, /* 11 */
	-1, /* 12 */
	-1, /* 13 */
	2, /* 14 */
	2, /* 15 */
	2, /* 16 */
	2, /* 17 */
	2, /* 18 */
	2, /* 19 */
	2, /* 20 */
	2, /* 21 */
	2, /* 22 */
	1, /* 23 */
	2, /* 24 */
	2, /* 25 */
	2, /* 26 */
	2, /* 27 */
	1, /* 28 */
	0, /* 29 */
	2, /* 30 */
	2, /* 31 */
	2, /* 32 */
	1, /* 33 */
	2, /* 34 */
	2, /* 35 */
	-1, /* 36 */
	-1, /* 37 */
	-1, /* 38 */
	-1, /* 39 */
	2, /* 40 */
	1, /* 41 */
	1, /* 42 */
	1, /* 43 */
	1, /* 44 */
	1, /* 45 */
	1, /* 46 */
	1, /* 47 */
	1, /* 48 */
	1, /* 49 */
	1, /* 50 */
	1, /* 51 */
	1, /* 52 */
	1, /* 53 */
	1, /* 54 */
	2, /* 55 */
	2, /* 56 */
	1, /* 57 */
	1, /* 58 */
	1, /* 59 */
	2, /* 60 */
	0, /* 61 */
	-1, /* 62 */
	-1, /* 63 */
	-1, /* 64 */
	0, /* 65 */
	0, /* 66 */
	0, /* 67 */
	2, /* 68 */
	2, /* 69 */
	2, /* 70 */
	2, /* 71 */
	2, /* 72 */
	2, /* 73 */
	2, /* 74 */
	2, /* 75 */
	2
};
int PFsimplify_max_op = 76;
int PFsimplify_max_state = 144;
#define PFsimplify_Max_state 144
char *PFsimplify_string[] = {
	0,
	"Query: main(FunctionDecls, CoreExpr)",
	"OptBindExpr: for_(forbind(forvars(var, nil), LiteralValue), OptBindExpr)",
	"OptBindExpr: for_(forbind(forvars(var, var), LiteralValue), OptBindExpr)",
	"OptBindExpr: let(letbind(var, Atom), OptBindExpr)",
	"OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr)",
	"OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr)",
	"OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), OrdWhereExpr)), OptBindExpr)",
	"WhereExpr: where(true_, WhereExpr)",
	"OrdWhereExpr: where(true_, OrdWhereExpr)",
	0,
	"CoreExpr: if_(true_, then_else(CoreExpr, CoreExpr))",
	"CoreExpr: if_(false_, then_else(CoreExpr, CoreExpr))",
	"CoreExpr: seq(seq(CoreExpr, CoreExpr), CoreExpr)",
	0,
	"CoreExpr: seq(empty, CoreExpr)",
	"CoreExpr: seq(CoreExpr, empty)",
	0,
	"FunExpr: apply(arg(CoreExpr, arg(CoreExpr, arg(CoreExpr, FunctionArgs))))",
	"Atom: var",
	"FunctionDecl: fun_decl(ParamList, FunctionBody)",
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	"CoreExpr: Atom",
	"CoreExpr: SequenceTypeCast",
	"CoreExpr: flwr(OptBindExpr, WhereExpr)",
	"CoreExpr: flwr(OptBindExpr, OrdWhereExpr)",
	"OptBindExpr: for_(forbind(forvars(var, OptVar), CoreExpr), OptBindExpr)",
	"OptVar: nil",
	"OptVar: var",
	0,
	0,
	0,
	"OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr)",
	"OptBindExpr: nil",
	"WhereExpr: where(CoreExpr, WhereExpr)",
	"WhereExpr: CoreExpr",
	"OrdWhereExpr: where(CoreExpr, OrdWhereExpr)",
	"OrdWhereExpr: orderby(OrderSpecs, CoreExpr)",
	"OrderSpecs: orderspecs(CoreExpr, nil)",
	"OrderSpecs: orderspecs(CoreExpr, OrderSpecs)",
	0,
	0,
	"CoreExpr: typesw(CoreExpr, cases(case_(SequenceType, CoreExpr), default_(CoreExpr)))",
	"SequenceType: seqtype",
	"SequenceType: stattype(CoreExpr)",
	"SequenceTypeCast: seqcast(SequenceType, CoreExpr)",
	"CoreExpr: proof(subty(CoreExpr, SequenceType), CoreExpr)",
	"CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr))",
	"CoreExpr: seq(CoreExpr, CoreExpr)",
	0,
	0,
	0,
	"CoreExpr: LocationSteps",
	"LocationStep: ancestor(SequenceType)",
	"LocationStep: ancestor_or_self(SequenceType)",
	"LocationStep: attribute(SequenceType)",
	"LocationStep: child(SequenceType)",
	"LocationStep: descendant(SequenceType)",
	"LocationStep: descendant_or_self(SequenceType)",
	"LocationStep: following(SequenceType)",
	"LocationStep: following_sibling(SequenceType)",
	"LocationStep: parent(SequenceType)",
	"LocationStep: preceding(SequenceType)",
	"LocationStep: preceding_sibling(SequenceType)",
	"LocationStep: self(SequenceType)",
	"LocationStep: select_narrow(SequenceType)",
	"LocationStep: select_wide(SequenceType)",
	"LocationSteps: locsteps(LocationStep, LocationSteps)",
	"LocationSteps: locsteps(LocationStep, CoreExpr)",
	0,
	0,
	0,
	"CoreExpr: elem(TagName, CoreExpr)",
	"CoreExpr: attr(TagName, CoreExpr)",
	"CoreExpr: text(CoreExpr)",
	"CoreExpr: doc(CoreExpr)",
	"CoreExpr: comment(CoreExpr)",
	"CoreExpr: pi(CoreExpr, CoreExpr)",
	"TagName: tag",
	"TagName: CoreExpr",
	0,
	0,
	"CoreExpr: FunExpr",
	"FunExpr: apply(FunctionArgs)",
	"FunctionArgs: arg(CoreExpr, FunctionArgs)",
	"FunctionArgs: arg(SequenceTypeCast, FunctionArgs)",
	"FunctionArgs: nil",
	"CoreExpr: ordered(CoreExpr)",
	"CoreExpr: unordered(CoreExpr)",
	"CoreExpr: cast(SequenceType, CoreExpr)",
	0,
	0,
	0,
	"Atom: empty",
	"Atom: LiteralValue",
	0,
	"LiteralValue: lit_str",
	"LiteralValue: lit_int",
	"LiteralValue: lit_dec",
	"LiteralValue: lit_dbl",
	"LiteralValue: true_",
	"LiteralValue: false_",
	"FunctionDecls: nil",
	"FunctionDecls: fun_decls(FunctionDecl, FunctionDecls)",
	0,
	"ParamList: nil",
	"ParamList: params(FunParam, ParamList)",
	0,
	0,
	0,
	0,
	0,
	"FunctionBody: CoreExpr",
	"FunParam: param(SequenceType, CoreExpr)",
	0,
	"CoreExpr: recursion(var, seed(CoreExpr, CoreExpr))",
	"CoreExpr: xrpc(CoreExpr, FunExpr)",
};
int PFsimplify_max_rule = 124;
#define PFsimplify_Max_rule 124
short PFsimplify_rule_descriptor_0[] = { 0, 0 };
short PFsimplify_rule_descriptor_1[] = {   -1,   68,  -17,   -2, };
short PFsimplify_rule_descriptor_2[] = {   -3,   17,   18,   19,    1,    6,  -16,   -3, };
short PFsimplify_rule_descriptor_3[] = {   -3,   17,   18,   19,    1,    1,  -16,   -3, };
short PFsimplify_rule_descriptor_4[] = {   -3,   15,   16,    1,  -15,   -3, };
short PFsimplify_rule_descriptor_5[] = {   -3,   15,   16,    1,   14,   15,   16,    1,   -2,    6,   -5,   -3, };
short PFsimplify_rule_descriptor_6[] = {   -3,   15,   16,    1,   14,   15,   16,    1,   -2,   -3,   -5,   -3, };
short PFsimplify_rule_descriptor_7[] = {   -3,   15,   16,    1,   14,   15,   16,    1,   -2,   -3,   -6,   -3, };
short PFsimplify_rule_descriptor_8[] = {   -5,   20,   65,   -5, };
short PFsimplify_rule_descriptor_9[] = {   -6,   20,   65,   -6, };
short PFsimplify_rule_descriptor_11[] = {   -2,   34,   65,   35,   -2,   -2, };
short PFsimplify_rule_descriptor_12[] = {   -2,   34,   66,   35,   -2,   -2, };
short PFsimplify_rule_descriptor_13[] = {   -2,    7,    7,   -2,   -2,   -2, };
short PFsimplify_rule_descriptor_15[] = {   -2,    7,   67,   -2, };
short PFsimplify_rule_descriptor_16[] = {   -2,    7,   -2,   67, };
short PFsimplify_rule_descriptor_18[] = {  -13,   23,   24,   -2,   24,   -2,   24,   -2,  -14, };
short PFsimplify_rule_descriptor_19[] = {  -15,    1, };
short PFsimplify_rule_descriptor_20[] = {  -18,   70,  -19,  -20, };
short PFsimplify_rule_descriptor_30[] = {   -2,  -15, };
short PFsimplify_rule_descriptor_31[] = {   -2,   -9, };
short PFsimplify_rule_descriptor_32[] = {   -2,   14,   -3,   -5, };
short PFsimplify_rule_descriptor_33[] = {   -2,   14,   -3,   -6, };
short PFsimplify_rule_descriptor_34[] = {   -3,   17,   18,   19,    1,   -4,   -2,   -3, };
short PFsimplify_rule_descriptor_35[] = {   -4,    6, };
short PFsimplify_rule_descriptor_36[] = {   -4,    1, };
short PFsimplify_rule_descriptor_40[] = {   -3,   15,   16,    1,   -2,   -3, };
short PFsimplify_rule_descriptor_41[] = {   -3,    6, };
short PFsimplify_rule_descriptor_42[] = {   -5,   20,   -2,   -5, };
short PFsimplify_rule_descriptor_43[] = {   -5,   -2, };
short PFsimplify_rule_descriptor_44[] = {   -6,   20,   -2,   -6, };
short PFsimplify_rule_descriptor_45[] = {   -6,   21,   -7,   -2, };
short PFsimplify_rule_descriptor_46[] = {   -7,   22,   -2,    6, };
short PFsimplify_rule_descriptor_47[] = {   -7,   22,   -2,   -7, };
short PFsimplify_rule_descriptor_50[] = {   -2,   25,   -2,   26,   27,   -8,   -2,   28,   -2, };
short PFsimplify_rule_descriptor_51[] = {   -8,   29, };
short PFsimplify_rule_descriptor_52[] = {   -8,   33,   -2, };
short PFsimplify_rule_descriptor_53[] = {   -9,   30,   -8,   -2, };
short PFsimplify_rule_descriptor_54[] = {   -2,   31,   32,   -2,   -8,   -2, };
short PFsimplify_rule_descriptor_55[] = {   -2,   34,   -2,   35,   -2,   -2, };
short PFsimplify_rule_descriptor_56[] = {   -2,    7,   -2,   -2, };
short PFsimplify_rule_descriptor_60[] = {   -2,  -11, };
short PFsimplify_rule_descriptor_61[] = {  -10,   41,   -8, };
short PFsimplify_rule_descriptor_62[] = {  -10,   42,   -8, };
short PFsimplify_rule_descriptor_63[] = {  -10,   43,   -8, };
short PFsimplify_rule_descriptor_64[] = {  -10,   44,   -8, };
short PFsimplify_rule_descriptor_65[] = {  -10,   45,   -8, };
short PFsimplify_rule_descriptor_66[] = {  -10,   46,   -8, };
short PFsimplify_rule_descriptor_67[] = {  -10,   47,   -8, };
short PFsimplify_rule_descriptor_68[] = {  -10,   48,   -8, };
short PFsimplify_rule_descriptor_69[] = {  -10,   49,   -8, };
short PFsimplify_rule_descriptor_70[] = {  -10,   50,   -8, };
short PFsimplify_rule_descriptor_71[] = {  -10,   51,   -8, };
short PFsimplify_rule_descriptor_72[] = {  -10,   52,   -8, };
short PFsimplify_rule_descriptor_73[] = {  -10,   53,   -8, };
short PFsimplify_rule_descriptor_74[] = {  -10,   54,   -8, };
short PFsimplify_rule_descriptor_75[] = {  -11,   40,  -10,  -11, };
short PFsimplify_rule_descriptor_76[] = {  -11,   40,  -10,   -2, };
short PFsimplify_rule_descriptor_80[] = {   -2,   55,  -12,   -2, };
short PFsimplify_rule_descriptor_81[] = {   -2,   56,  -12,   -2, };
short PFsimplify_rule_descriptor_82[] = {   -2,   57,   -2, };
short PFsimplify_rule_descriptor_83[] = {   -2,   58,   -2, };
short PFsimplify_rule_descriptor_84[] = {   -2,   59,   -2, };
short PFsimplify_rule_descriptor_85[] = {   -2,   60,   -2,   -2, };
short PFsimplify_rule_descriptor_86[] = {  -12,   61, };
short PFsimplify_rule_descriptor_87[] = {  -12,   -2, };
short PFsimplify_rule_descriptor_90[] = {   -2,  -13, };
short PFsimplify_rule_descriptor_91[] = {  -13,   23,  -14, };
short PFsimplify_rule_descriptor_92[] = {  -14,   24,   -2,  -14, };
short PFsimplify_rule_descriptor_93[] = {  -14,   24,   -9,  -14, };
short PFsimplify_rule_descriptor_94[] = {  -14,    6, };
short PFsimplify_rule_descriptor_95[] = {   -2,    9,   -2, };
short PFsimplify_rule_descriptor_96[] = {   -2,   10,   -2, };
short PFsimplify_rule_descriptor_97[] = {   -2,   73,   -8,   -2, };
short PFsimplify_rule_descriptor_101[] = {  -15,   67, };
short PFsimplify_rule_descriptor_102[] = {  -15,  -16, };
short PFsimplify_rule_descriptor_104[] = {  -16,    2, };
short PFsimplify_rule_descriptor_105[] = {  -16,    3, };
short PFsimplify_rule_descriptor_106[] = {  -16,    4, };
short PFsimplify_rule_descriptor_107[] = {  -16,    5, };
short PFsimplify_rule_descriptor_108[] = {  -16,   65, };
short PFsimplify_rule_descriptor_109[] = {  -16,   66, };
short PFsimplify_rule_descriptor_110[] = {  -17,    6, };
short PFsimplify_rule_descriptor_111[] = {  -17,   69,  -18,  -17, };
short PFsimplify_rule_descriptor_113[] = {  -19,    6, };
short PFsimplify_rule_descriptor_114[] = {  -19,   71,  -21,  -19, };
short PFsimplify_rule_descriptor_120[] = {  -20,   -2, };
short PFsimplify_rule_descriptor_121[] = {  -21,   72,   -8,   -2, };
short PFsimplify_rule_descriptor_123[] = {   -2,   74,    1,   75,   -2,   -2, };
short PFsimplify_rule_descriptor_124[] = {   -2,   76,   -2,  -13, };
/* PFsimplify_rule_descriptors[0][1] = 1 iff grammar is normal form. */
short * PFsimplify_rule_descriptors[] = {
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_1,
	PFsimplify_rule_descriptor_2,
	PFsimplify_rule_descriptor_3,
	PFsimplify_rule_descriptor_4,
	PFsimplify_rule_descriptor_5,
	PFsimplify_rule_descriptor_6,
	PFsimplify_rule_descriptor_7,
	PFsimplify_rule_descriptor_8,
	PFsimplify_rule_descriptor_9,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_11,
	PFsimplify_rule_descriptor_12,
	PFsimplify_rule_descriptor_13,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_15,
	PFsimplify_rule_descriptor_16,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_18,
	PFsimplify_rule_descriptor_19,
	PFsimplify_rule_descriptor_20,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_30,
	PFsimplify_rule_descriptor_31,
	PFsimplify_rule_descriptor_32,
	PFsimplify_rule_descriptor_33,
	PFsimplify_rule_descriptor_34,
	PFsimplify_rule_descriptor_35,
	PFsimplify_rule_descriptor_36,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_40,
	PFsimplify_rule_descriptor_41,
	PFsimplify_rule_descriptor_42,
	PFsimplify_rule_descriptor_43,
	PFsimplify_rule_descriptor_44,
	PFsimplify_rule_descriptor_45,
	PFsimplify_rule_descriptor_46,
	PFsimplify_rule_descriptor_47,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_50,
	PFsimplify_rule_descriptor_51,
	PFsimplify_rule_descriptor_52,
	PFsimplify_rule_descriptor_53,
	PFsimplify_rule_descriptor_54,
	PFsimplify_rule_descriptor_55,
	PFsimplify_rule_descriptor_56,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_60,
	PFsimplify_rule_descriptor_61,
	PFsimplify_rule_descriptor_62,
	PFsimplify_rule_descriptor_63,
	PFsimplify_rule_descriptor_64,
	PFsimplify_rule_descriptor_65,
	PFsimplify_rule_descriptor_66,
	PFsimplify_rule_descriptor_67,
	PFsimplify_rule_descriptor_68,
	PFsimplify_rule_descriptor_69,
	PFsimplify_rule_descriptor_70,
	PFsimplify_rule_descriptor_71,
	PFsimplify_rule_descriptor_72,
	PFsimplify_rule_descriptor_73,
	PFsimplify_rule_descriptor_74,
	PFsimplify_rule_descriptor_75,
	PFsimplify_rule_descriptor_76,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_80,
	PFsimplify_rule_descriptor_81,
	PFsimplify_rule_descriptor_82,
	PFsimplify_rule_descriptor_83,
	PFsimplify_rule_descriptor_84,
	PFsimplify_rule_descriptor_85,
	PFsimplify_rule_descriptor_86,
	PFsimplify_rule_descriptor_87,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_90,
	PFsimplify_rule_descriptor_91,
	PFsimplify_rule_descriptor_92,
	PFsimplify_rule_descriptor_93,
	PFsimplify_rule_descriptor_94,
	PFsimplify_rule_descriptor_95,
	PFsimplify_rule_descriptor_96,
	PFsimplify_rule_descriptor_97,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_101,
	PFsimplify_rule_descriptor_102,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_104,
	PFsimplify_rule_descriptor_105,
	PFsimplify_rule_descriptor_106,
	PFsimplify_rule_descriptor_107,
	PFsimplify_rule_descriptor_108,
	PFsimplify_rule_descriptor_109,
	PFsimplify_rule_descriptor_110,
	PFsimplify_rule_descriptor_111,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_113,
	PFsimplify_rule_descriptor_114,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_120,
	PFsimplify_rule_descriptor_121,
	PFsimplify_rule_descriptor_0,
	PFsimplify_rule_descriptor_123,
	PFsimplify_rule_descriptor_124,
};
short PFsimplify_cost[][4] = {
	{    0,    0,    0,    0}, /* (none) = 0 */
	{   10,    0,    0,    0}, /* Query: main(FunctionDecls, CoreExpr) = 1 */
	{   10,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, nil), LiteralValue), OptBindExpr) = 2 */
	{   10,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, var), LiteralValue), OptBindExpr) = 3 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, Atom), OptBindExpr) = 4 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 5 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 6 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), OrdWhereExpr)), OptBindExpr) = 7 */
	{   10,    0,    0,    0}, /* WhereExpr: where(true_, WhereExpr) = 8 */
	{   10,    0,    0,    0}, /* OrdWhereExpr: where(true_, OrdWhereExpr) = 9 */
	{    0,    0,    0,    0}, /* (none) = 10 */
	{    1,    0,    0,    0}, /* CoreExpr: if_(true_, then_else(CoreExpr, CoreExpr)) = 11 */
	{    1,    0,    0,    0}, /* CoreExpr: if_(false_, then_else(CoreExpr, CoreExpr)) = 12 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(seq(CoreExpr, CoreExpr), CoreExpr) = 13 */
	{    0,    0,    0,    0}, /* (none) = 14 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(empty, CoreExpr) = 15 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, empty) = 16 */
	{    0,    0,    0,    0}, /* (none) = 17 */
	{   10,    0,    0,    0}, /* FunExpr: apply(arg(CoreExpr, arg(CoreExpr, arg(CoreExpr, FunctionArgs)))) = 18 */
	{   10,    0,    0,    0}, /* Atom: var = 19 */
	{   10,    0,    0,    0}, /* FunctionDecl: fun_decl(ParamList, FunctionBody) = 20 */
	{    0,    0,    0,    0}, /* (none) = 21 */
	{    0,    0,    0,    0}, /* (none) = 22 */
	{    0,    0,    0,    0}, /* (none) = 23 */
	{    0,    0,    0,    0}, /* (none) = 24 */
	{    0,    0,    0,    0}, /* (none) = 25 */
	{    0,    0,    0,    0}, /* (none) = 26 */
	{    0,    0,    0,    0}, /* (none) = 27 */
	{    0,    0,    0,    0}, /* (none) = 28 */
	{    0,    0,    0,    0}, /* (none) = 29 */
	{   10,    0,    0,    0}, /* CoreExpr: Atom = 30 */
	{   10,    0,    0,    0}, /* CoreExpr: SequenceTypeCast = 31 */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 32 */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, OrdWhereExpr) = 33 */
	{   10,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, OptVar), CoreExpr), OptBindExpr) = 34 */
	{   10,    0,    0,    0}, /* OptVar: nil = 35 */
	{   10,    0,    0,    0}, /* OptVar: var = 36 */
	{    0,    0,    0,    0}, /* (none) = 37 */
	{    0,    0,    0,    0}, /* (none) = 38 */
	{    0,    0,    0,    0}, /* (none) = 39 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr) = 40 */
	{   10,    0,    0,    0}, /* OptBindExpr: nil = 41 */
	{   10,    0,    0,    0}, /* WhereExpr: where(CoreExpr, WhereExpr) = 42 */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{   10,    0,    0,    0}, /* OrdWhereExpr: where(CoreExpr, OrdWhereExpr) = 44 */
	{   10,    0,    0,    0}, /* OrdWhereExpr: orderby(OrderSpecs, CoreExpr) = 45 */
	{   10,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, nil) = 46 */
	{   10,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, OrderSpecs) = 47 */
	{    0,    0,    0,    0}, /* (none) = 48 */
	{    0,    0,    0,    0}, /* (none) = 49 */
	{   10,    0,    0,    0}, /* CoreExpr: typesw(CoreExpr, cases(case_(SequenceType, CoreExpr), default_(CoreExpr))) = 50 */
	{   10,    0,    0,    0}, /* SequenceType: seqtype = 51 */
	{   10,    0,    0,    0}, /* SequenceType: stattype(CoreExpr) = 52 */
	{   10,    0,    0,    0}, /* SequenceTypeCast: seqcast(SequenceType, CoreExpr) = 53 */
	{   10,    0,    0,    0}, /* CoreExpr: proof(subty(CoreExpr, SequenceType), CoreExpr) = 54 */
	{   10,    0,    0,    0}, /* CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr)) = 55 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, CoreExpr) = 56 */
	{    0,    0,    0,    0}, /* (none) = 57 */
	{    0,    0,    0,    0}, /* (none) = 58 */
	{    0,    0,    0,    0}, /* (none) = 59 */
	{   10,    0,    0,    0}, /* CoreExpr: LocationSteps = 60 */
	{   10,    0,    0,    0}, /* LocationStep: ancestor(SequenceType) = 61 */
	{   10,    0,    0,    0}, /* LocationStep: ancestor_or_self(SequenceType) = 62 */
	{   10,    0,    0,    0}, /* LocationStep: attribute(SequenceType) = 63 */
	{   10,    0,    0,    0}, /* LocationStep: child(SequenceType) = 64 */
	{   10,    0,    0,    0}, /* LocationStep: descendant(SequenceType) = 65 */
	{   10,    0,    0,    0}, /* LocationStep: descendant_or_self(SequenceType) = 66 */
	{   10,    0,    0,    0}, /* LocationStep: following(SequenceType) = 67 */
	{   10,    0,    0,    0}, /* LocationStep: following_sibling(SequenceType) = 68 */
	{   10,    0,    0,    0}, /* LocationStep: parent(SequenceType) = 69 */
	{   10,    0,    0,    0}, /* LocationStep: preceding(SequenceType) = 70 */
	{   10,    0,    0,    0}, /* LocationStep: preceding_sibling(SequenceType) = 71 */
	{   10,    0,    0,    0}, /* LocationStep: self(SequenceType) = 72 */
	{   10,    0,    0,    0}, /* LocationStep: select_narrow(SequenceType) = 73 */
	{   10,    0,    0,    0}, /* LocationStep: select_wide(SequenceType) = 74 */
	{   10,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, LocationSteps) = 75 */
	{   10,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, CoreExpr) = 76 */
	{    0,    0,    0,    0}, /* (none) = 77 */
	{    0,    0,    0,    0}, /* (none) = 78 */
	{    0,    0,    0,    0}, /* (none) = 79 */
	{   10,    0,    0,    0}, /* CoreExpr: elem(TagName, CoreExpr) = 80 */
	{   10,    0,    0,    0}, /* CoreExpr: attr(TagName, CoreExpr) = 81 */
	{   10,    0,    0,    0}, /* CoreExpr: text(CoreExpr) = 82 */
	{   10,    0,    0,    0}, /* CoreExpr: doc(CoreExpr) = 83 */
	{   10,    0,    0,    0}, /* CoreExpr: comment(CoreExpr) = 84 */
	{   10,    0,    0,    0}, /* CoreExpr: pi(CoreExpr, CoreExpr) = 85 */
	{   10,    0,    0,    0}, /* TagName: tag = 86 */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) = 88 */
	{    0,    0,    0,    0}, /* (none) = 89 */
	{   10,    0,    0,    0}, /* CoreExpr: FunExpr = 90 */
	{   10,    0,    0,    0}, /* FunExpr: apply(FunctionArgs) = 91 */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 92 */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 93 */
	{   10,    0,    0,    0}, /* FunctionArgs: nil = 94 */
	{   10,    0,    0,    0}, /* CoreExpr: ordered(CoreExpr) = 95 */
	{   10,    0,    0,    0}, /* CoreExpr: unordered(CoreExpr) = 96 */
	{   10,    0,    0,    0}, /* CoreExpr: cast(SequenceType, CoreExpr) = 97 */
	{    0,    0,    0,    0}, /* (none) = 98 */
	{    0,    0,    0,    0}, /* (none) = 99 */
	{    0,    0,    0,    0}, /* (none) = 100 */
	{   10,    0,    0,    0}, /* Atom: empty = 101 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 102 */
	{    0,    0,    0,    0}, /* (none) = 103 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_str = 104 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_int = 105 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_dec = 106 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_dbl = 107 */
	{   10,    0,    0,    0}, /* LiteralValue: true_ = 108 */
	{   10,    0,    0,    0}, /* LiteralValue: false_ = 109 */
	{   10,    0,    0,    0}, /* FunctionDecls: nil = 110 */
	{   10,    0,    0,    0}, /* FunctionDecls: fun_decls(FunctionDecl, FunctionDecls) = 111 */
	{    0,    0,    0,    0}, /* (none) = 112 */
	{   10,    0,    0,    0}, /* ParamList: nil = 113 */
	{   10,    0,    0,    0}, /* ParamList: params(FunParam, ParamList) = 114 */
	{    0,    0,    0,    0}, /* (none) = 115 */
	{    0,    0,    0,    0}, /* (none) = 116 */
	{    0,    0,    0,    0}, /* (none) = 117 */
	{    0,    0,    0,    0}, /* (none) = 118 */
	{    0,    0,    0,    0}, /* (none) = 119 */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{   10,    0,    0,    0}, /* FunParam: param(SequenceType, CoreExpr) = 121 */
	{    0,    0,    0,    0}, /* (none) = 122 */
	{   10,    0,    0,    0}, /* CoreExpr: recursion(var, seed(CoreExpr, CoreExpr)) = 123 */
	{   10,    0,    0,    0}, /* CoreExpr: xrpc(CoreExpr, FunExpr) = 124 */
};

short PFsimplify_delta_cost[145][22][4] = {
{{0}}, /* state 0 */
{ /* state #1: ancestor(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: ancestor(SequenceType) = 61 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #2: ancestor_or_self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: ancestor_or_self(SequenceType) = 62 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #3: apply(arg(lit_dbl, arg(lit_dbl, arg(lit_dbl, nil)))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: FunExpr = 90 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* FunExpr: apply(arg(CoreExpr, arg(CoreExpr, arg(CoreExpr, FunctionArgs)))) = 18 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #4: apply(nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: FunExpr = 90 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* FunExpr: apply(FunctionArgs) = 91 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #5: arg(lit_dbl, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 92 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #6: arg(lit_dbl, arg(seqcast(seqtype, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 92 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #7: arg(seqcast(seqtype, lit_dbl), arg(seqcast(seqtype, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #8: arg(lit_dbl, arg(lit_dbl, arg(lit_dbl, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 92 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #9: arg(seqcast(seqtype, lit_dbl), arg(lit_dbl, arg(lit_dbl, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #10: arg(seqcast(seqtype, lit_dbl), arg(seqcast(seqtype, lit_dbl), arg(seqcast(seqtype, lit_dbl), nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #11: arg(lit_dbl, arg(seqcast(seqtype, lit_dbl), arg(seqcast(seqtype, lit_dbl), nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 92 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #12: arg(seqcast(seqtype, lit_dbl), arg(lit_dbl, arg(seqcast(seqtype, lit_dbl), nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #13: arg(lit_dbl, arg(seqcast(seqtype, lit_dbl), arg(lit_dbl, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 92 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #14: arg(lit_dbl, arg(lit_dbl, arg(seqcast(seqtype, lit_dbl), nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 92 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #15: arg(seqcast(seqtype, lit_dbl), arg(seqcast(seqtype, lit_dbl), arg(lit_dbl, nil))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #16: arg(seqcast(seqtype, lit_dbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #17: arg(lit_dbl, arg(lit_dbl, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArgs: arg(CoreExpr, FunctionArgs) = 92 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #18: arg(seqcast(seqtype, lit_dbl), arg(lit_dbl, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(SequenceTypeCast, FunctionArgs) = 93 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #19: attr(lit_dbl, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: attr(TagName, CoreExpr) = 81 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #20: attribute(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: attribute(SequenceType) = 63 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #21: case_(seqtype, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #22: cases(case_(seqtype, lit_dbl), default_(lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #23: cast(seqtype, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: cast(SequenceType, CoreExpr) = 97 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #24: child(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: child(SequenceType) = 64 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #25: comment(lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: comment(CoreExpr) = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #26: default_(lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #27: descendant(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: descendant(SequenceType) = 65 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #28: descendant_or_self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: descendant_or_self(SequenceType) = 66 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #29: doc(lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: doc(CoreExpr) = 83 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #30: elem(lit_dbl, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: elem(TagName, CoreExpr) = 80 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #31: empty */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: empty = 101 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #32: false_ */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* CoreExpr: Atom = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Atom: LiteralValue = 102 */
	{   10,    0,    0,    0}, /* LiteralValue: false_ = 109 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #33: flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #34: flwr(let(letbind(var, lit_dbl), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, OrdWhereExpr) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #35: flwr(let(letbind(var, lit_dbl), nil), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #36: flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #37: flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, OrdWhereExpr) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #38: flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #39: flwr(nil, orderby(orderspecs(lit_dbl, nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, OrdWhereExpr) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #40: flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #41: flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, OrdWhereExpr) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #42: flwr(nil, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #43: flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #44: flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #45: flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, OrdWhereExpr) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #46: flwr(let(letbind(var, lit_dbl), let(letbind(var, lit_dbl), nil)), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #47: following(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: following(SequenceType) = 67 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #48: following_sibling(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: following_sibling(SequenceType) = 68 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #49: for_(forbind(forvars(var, nil), empty), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, OptVar), CoreExpr), OptBindExpr) = 34 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #50: for_(forbind(forvars(var, var), lit_dbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, var), LiteralValue), OptBindExpr) = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #51: for_(forbind(forvars(var, nil), lit_dbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, nil), LiteralValue), OptBindExpr) = 2 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #52: forbind(forvars(var, nil), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #53: forbind(forvars(var, var), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #54: forbind(forvars(var, nil), empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #55: forvars(var, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #56: forvars(var, var) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #57: fun_decl(nil, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionDecl: fun_decl(ParamList, FunctionBody) = 20 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #58: fun_decls(fun_decl(nil, lit_dbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionDecls: fun_decls(FunctionDecl, FunctionDecls) = 111 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #59: if_(lit_dbl, then_else(lit_dbl, lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr)) = 55 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #60: if_(false_, then_else(lit_dbl, lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: if_(false_, then_else(CoreExpr, CoreExpr)) = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #61: if_(true_, then_else(lit_dbl, lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: if_(true_, then_else(CoreExpr, CoreExpr)) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #62: let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), OrdWhereExpr)), OptBindExpr) = 7 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #63: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #64: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), lit_dbl)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #65: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 6 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #66: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 6 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #67: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), OrdWhereExpr)), OptBindExpr) = 7 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #68: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), OrdWhereExpr)), OptBindExpr) = 7 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #69: let(letbind(var, lit_dbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, Atom), OptBindExpr) = 4 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #70: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #71: let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), lit_dbl)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #72: let(letbind(var, seq(lit_dbl, lit_dbl)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr) = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #73: let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 6 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #74: let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 6 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #75: let(letbind(var, flwr(let(letbind(var, lit_dbl), let(letbind(var, lit_dbl), nil)), lit_dbl)), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 6 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #76: let(letbind(var, flwr(let(letbind(var, lit_dbl), let(letbind(var, lit_dbl), nil)), lit_dbl)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), WhereExpr)), OptBindExpr) = 6 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #77: let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), OrdWhereExpr)), OptBindExpr) = 7 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #78: let(letbind(var, lit_dbl), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, Atom), OptBindExpr) = 4 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #79: let(letbind(var, seq(lit_dbl, lit_dbl)), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr) = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #80: let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #81: let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #82: let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), OrdWhereExpr)), OptBindExpr) = 7 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #83: let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), OptBindExpr), OrdWhereExpr)), OptBindExpr) = 7 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #84: let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #85: let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, flwr(let(letbind(var, CoreExpr), nil), WhereExpr)), OptBindExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #86: letbind(var, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #87: letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #88: letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #89: letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #90: letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #91: letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #92: letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #93: letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #94: letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #95: letbind(var, flwr(let(letbind(var, lit_dbl), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #96: letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #97: letbind(var, seq(lit_dbl, lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #98: letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #99: letbind(var, flwr(let(letbind(var, lit_dbl), let(letbind(var, lit_dbl), nil)), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #100: lit_dbl */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 102 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_dbl = 107 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #101: lit_dec */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 102 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_dec = 106 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #102: lit_int */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 102 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_int = 105 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #103: lit_str */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 102 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_str = 104 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #104: locsteps(ancestor(seqtype), locsteps(ancestor(seqtype), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationSteps = 60 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, LocationSteps) = 75 */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #105: locsteps(ancestor(seqtype), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: LocationSteps = 60 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, CoreExpr) = 76 */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #106: main(nil, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* Query: main(FunctionDecls, CoreExpr) = 1 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #107: nil */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: nil = 41 */
	{   10,    0,    0,    0}, /* OptVar: nil = 35 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: nil = 94 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionDecls: nil = 110 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* ParamList: nil = 113 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #108: orderby(orderspecs(lit_dbl, nil), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrdWhereExpr: orderby(OrderSpecs, CoreExpr) = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #109: ordered(lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: ordered(CoreExpr) = 95 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #110: orderspecs(lit_dbl, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, nil) = 46 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #111: orderspecs(lit_dbl, orderspecs(lit_dbl, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, OrderSpecs) = 47 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #112: param(seqtype, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunParam: param(SequenceType, CoreExpr) = 121 */
},
{ /* state #113: params(param(seqtype, lit_dbl), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* ParamList: params(FunParam, ParamList) = 114 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #114: parent(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: parent(SequenceType) = 69 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #115: pi(lit_dbl, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: pi(CoreExpr, CoreExpr) = 85 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #116: preceding(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: preceding(SequenceType) = 70 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #117: preceding_sibling(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: preceding_sibling(SequenceType) = 71 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #118: proof(subty(lit_dbl, seqtype), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: proof(subty(CoreExpr, SequenceType), CoreExpr) = 54 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #119: recursion(var, seed(lit_dbl, lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: recursion(var, seed(CoreExpr, CoreExpr)) = 123 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #120: seed(lit_dbl, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #121: select_narrow(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: select_narrow(SequenceType) = 73 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #122: select_wide(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: select_wide(SequenceType) = 74 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #123: self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: self(SequenceType) = 72 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #124: seq(lit_dbl, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, empty) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #125: seq(empty, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: seq(empty, CoreExpr) = 15 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #126: seq(seq(seq(lit_dbl, lit_dbl), lit_dbl), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: seq(seq(CoreExpr, CoreExpr), CoreExpr) = 13 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #127: seq(seq(lit_dbl, lit_dbl), lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: seq(seq(CoreExpr, CoreExpr), CoreExpr) = 13 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #128: seq(lit_dbl, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, CoreExpr) = 56 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #129: seqcast(seqtype, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* CoreExpr: SequenceTypeCast = 31 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SequenceTypeCast: seqcast(SequenceType, CoreExpr) = 53 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #130: seqtype */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SequenceType: seqtype = 51 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #131: stattype(lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SequenceType: stattype(CoreExpr) = 52 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #132: subty(lit_dbl, seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #133: tag */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* TagName: tag = 86 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #134: text(lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: text(CoreExpr) = 82 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #135: then_else(lit_dbl, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #136: true_ */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* CoreExpr: Atom = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* Atom: LiteralValue = 102 */
	{   10,    0,    0,    0}, /* LiteralValue: true_ = 108 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #137: typesw(lit_dbl, cases(case_(seqtype, lit_dbl), default_(lit_dbl))) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: typesw(CoreExpr, cases(case_(SequenceType, CoreExpr), default_(CoreExpr))) = 50 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #138: unordered(lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: unordered(CoreExpr) = 96 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #139: var */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptVar: var = 36 */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* Atom: var = 19 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #140: where(true_, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* WhereExpr: where(true_, WhereExpr) = 8 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #141: where(lit_dbl, orderby(orderspecs(lit_dbl, nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrdWhereExpr: where(CoreExpr, OrdWhereExpr) = 44 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #142: where(true_, orderby(orderspecs(lit_dbl, nil), lit_dbl)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrdWhereExpr: where(true_, OrdWhereExpr) = 9 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #143: where(lit_dbl, lit_dbl) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* WhereExpr: where(CoreExpr, WhereExpr) = 42 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #144: xrpc(lit_dbl, apply(nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* CoreExpr: xrpc(CoreExpr, FunExpr) = 124 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* TagName: CoreExpr = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 120 */
	{    0,    0,    0,    0}, /* (none) */
},
};

char * PFsimplify_state_string[] = {
" not a state", /* state 0 */
	"ancestor(seqtype)", /* state #1 */
	"ancestor_or_self(seqtype)", /* state #2 */
	"apply(arg(lit_dbl, arg(lit_dbl, arg(lit_dbl, nil))))", /* state #3 */
	"apply(nil)", /* state #4 */
	"arg(lit_dbl, nil)", /* state #5 */
	"arg(lit_dbl, arg(seqcast(seqtype, lit_dbl), nil))", /* state #6 */
	"arg(seqcast(seqtype, lit_dbl), arg(seqcast(seqtype, lit_dbl), nil))", /* state #7 */
	"arg(lit_dbl, arg(lit_dbl, arg(lit_dbl, nil)))", /* state #8 */
	"arg(seqcast(seqtype, lit_dbl), arg(lit_dbl, arg(lit_dbl, nil)))", /* state #9 */
	"arg(seqcast(seqtype, lit_dbl), arg(seqcast(seqtype, lit_dbl), arg(seqcast(seqtype, lit_dbl), nil)))", /* state #10 */
	"arg(lit_dbl, arg(seqcast(seqtype, lit_dbl), arg(seqcast(seqtype, lit_dbl), nil)))", /* state #11 */
	"arg(seqcast(seqtype, lit_dbl), arg(lit_dbl, arg(seqcast(seqtype, lit_dbl), nil)))", /* state #12 */
	"arg(lit_dbl, arg(seqcast(seqtype, lit_dbl), arg(lit_dbl, nil)))", /* state #13 */
	"arg(lit_dbl, arg(lit_dbl, arg(seqcast(seqtype, lit_dbl), nil)))", /* state #14 */
	"arg(seqcast(seqtype, lit_dbl), arg(seqcast(seqtype, lit_dbl), arg(lit_dbl, nil)))", /* state #15 */
	"arg(seqcast(seqtype, lit_dbl), nil)", /* state #16 */
	"arg(lit_dbl, arg(lit_dbl, nil))", /* state #17 */
	"arg(seqcast(seqtype, lit_dbl), arg(lit_dbl, nil))", /* state #18 */
	"attr(lit_dbl, lit_dbl)", /* state #19 */
	"attribute(seqtype)", /* state #20 */
	"case_(seqtype, lit_dbl)", /* state #21 */
	"cases(case_(seqtype, lit_dbl), default_(lit_dbl))", /* state #22 */
	"cast(seqtype, lit_dbl)", /* state #23 */
	"child(seqtype)", /* state #24 */
	"comment(lit_dbl)", /* state #25 */
	"default_(lit_dbl)", /* state #26 */
	"descendant(seqtype)", /* state #27 */
	"descendant_or_self(seqtype)", /* state #28 */
	"doc(lit_dbl)", /* state #29 */
	"elem(lit_dbl, lit_dbl)", /* state #30 */
	"empty", /* state #31 */
	"false_", /* state #32 */
	"flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)", /* state #33 */
	"flwr(let(letbind(var, lit_dbl), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))", /* state #34 */
	"flwr(let(letbind(var, lit_dbl), nil), lit_dbl)", /* state #35 */
	"flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)", /* state #36 */
	"flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))", /* state #37 */
	"flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)", /* state #38 */
	"flwr(nil, orderby(orderspecs(lit_dbl, nil), lit_dbl))", /* state #39 */
	"flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), lit_dbl)", /* state #40 */
	"flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))", /* state #41 */
	"flwr(nil, lit_dbl)", /* state #42 */
	"flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)", /* state #43 */
	"flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), lit_dbl)", /* state #44 */
	"flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))", /* state #45 */
	"flwr(let(letbind(var, lit_dbl), let(letbind(var, lit_dbl), nil)), lit_dbl)", /* state #46 */
	"following(seqtype)", /* state #47 */
	"following_sibling(seqtype)", /* state #48 */
	"for_(forbind(forvars(var, nil), empty), nil)", /* state #49 */
	"for_(forbind(forvars(var, var), lit_dbl), nil)", /* state #50 */
	"for_(forbind(forvars(var, nil), lit_dbl), nil)", /* state #51 */
	"forbind(forvars(var, nil), lit_dbl)", /* state #52 */
	"forbind(forvars(var, var), lit_dbl)", /* state #53 */
	"forbind(forvars(var, nil), empty)", /* state #54 */
	"forvars(var, nil)", /* state #55 */
	"forvars(var, var)", /* state #56 */
	"fun_decl(nil, lit_dbl)", /* state #57 */
	"fun_decls(fun_decl(nil, lit_dbl), nil)", /* state #58 */
	"if_(lit_dbl, then_else(lit_dbl, lit_dbl))", /* state #59 */
	"if_(false_, then_else(lit_dbl, lit_dbl))", /* state #60 */
	"if_(true_, then_else(lit_dbl, lit_dbl))", /* state #61 */
	"let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), nil)", /* state #62 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), lit_dbl)), let(letbind(var, lit_dbl), nil))", /* state #63 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), lit_dbl)), nil)", /* state #64 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)), let(letbind(var, lit_dbl), nil))", /* state #65 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)), nil)", /* state #66 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), let(letbind(var, lit_dbl), nil))", /* state #67 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), nil)", /* state #68 */
	"let(letbind(var, lit_dbl), nil)", /* state #69 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), lit_dbl)), let(letbind(var, lit_dbl), nil))", /* state #70 */
	"let(letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), lit_dbl)), nil)", /* state #71 */
	"let(letbind(var, seq(lit_dbl, lit_dbl)), nil)", /* state #72 */
	"let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)), let(letbind(var, lit_dbl), nil))", /* state #73 */
	"let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl)), nil)", /* state #74 */
	"let(letbind(var, flwr(let(letbind(var, lit_dbl), let(letbind(var, lit_dbl), nil)), lit_dbl)), let(letbind(var, lit_dbl), nil))", /* state #75 */
	"let(letbind(var, flwr(let(letbind(var, lit_dbl), let(letbind(var, lit_dbl), nil)), lit_dbl)), nil)", /* state #76 */
	"let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), let(letbind(var, lit_dbl), nil))", /* state #77 */
	"let(letbind(var, lit_dbl), let(letbind(var, lit_dbl), nil))", /* state #78 */
	"let(letbind(var, seq(lit_dbl, lit_dbl)), let(letbind(var, lit_dbl), nil))", /* state #79 */
	"let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), let(letbind(var, lit_dbl), nil))", /* state #80 */
	"let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil)", /* state #81 */
	"let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), let(letbind(var, lit_dbl), nil))", /* state #82 */
	"let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl))), nil)", /* state #83 */
	"let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), let(letbind(var, lit_dbl), nil))", /* state #84 */
	"let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil)", /* state #85 */
	"letbind(var, lit_dbl)", /* state #86 */
	"letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl)))", /* state #87 */
	"letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl))", /* state #88 */
	"letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl)))", /* state #89 */
	"letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl))", /* state #90 */
	"letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl)), nil), lit_dbl))", /* state #91 */
	"letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl))", /* state #92 */
	"letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl)))", /* state #93 */
	"letbind(var, flwr(let(letbind(var, flwr(let(letbind(var, lit_dbl), nil), lit_dbl)), nil), lit_dbl))", /* state #94 */
	"letbind(var, flwr(let(letbind(var, lit_dbl), nil), orderby(orderspecs(lit_dbl, nil), lit_dbl)))", /* state #95 */
	"letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), nil), lit_dbl))", /* state #96 */
	"letbind(var, seq(lit_dbl, lit_dbl))", /* state #97 */
	"letbind(var, flwr(let(letbind(var, seq(lit_dbl, lit_dbl)), let(letbind(var, lit_dbl), nil)), lit_dbl))", /* state #98 */
	"letbind(var, flwr(let(letbind(var, lit_dbl), let(letbind(var, lit_dbl), nil)), lit_dbl))", /* state #99 */
	"lit_dbl", /* state #100 */
	"lit_dec", /* state #101 */
	"lit_int", /* state #102 */
	"lit_str", /* state #103 */
	"locsteps(ancestor(seqtype), locsteps(ancestor(seqtype), lit_dbl))", /* state #104 */
	"locsteps(ancestor(seqtype), lit_dbl)", /* state #105 */
	"main(nil, lit_dbl)", /* state #106 */
	"nil", /* state #107 */
	"orderby(orderspecs(lit_dbl, nil), lit_dbl)", /* state #108 */
	"ordered(lit_dbl)", /* state #109 */
	"orderspecs(lit_dbl, nil)", /* state #110 */
	"orderspecs(lit_dbl, orderspecs(lit_dbl, nil))", /* state #111 */
	"param(seqtype, lit_dbl)", /* state #112 */
	"params(param(seqtype, lit_dbl), nil)", /* state #113 */
	"parent(seqtype)", /* state #114 */
	"pi(lit_dbl, lit_dbl)", /* state #115 */
	"preceding(seqtype)", /* state #116 */
	"preceding_sibling(seqtype)", /* state #117 */
	"proof(subty(lit_dbl, seqtype), lit_dbl)", /* state #118 */
	"recursion(var, seed(lit_dbl, lit_dbl))", /* state #119 */
	"seed(lit_dbl, lit_dbl)", /* state #120 */
	"select_narrow(seqtype)", /* state #121 */
	"select_wide(seqtype)", /* state #122 */
	"self(seqtype)", /* state #123 */
	"seq(lit_dbl, empty)", /* state #124 */
	"seq(empty, lit_dbl)", /* state #125 */
	"seq(seq(seq(lit_dbl, lit_dbl), lit_dbl), lit_dbl)", /* state #126 */
	"seq(seq(lit_dbl, lit_dbl), lit_dbl)", /* state #127 */
	"seq(lit_dbl, lit_dbl)", /* state #128 */
	"seqcast(seqtype, lit_dbl)", /* state #129 */
	"seqtype", /* state #130 */
	"stattype(lit_dbl)", /* state #131 */
	"subty(lit_dbl, seqtype)", /* state #132 */
	"tag", /* state #133 */
	"text(lit_dbl)", /* state #134 */
	"then_else(lit_dbl, lit_dbl)", /* state #135 */
	"true_", /* state #136 */
	"typesw(lit_dbl, cases(case_(seqtype, lit_dbl), default_(lit_dbl)))", /* state #137 */
	"unordered(lit_dbl)", /* state #138 */
	"var", /* state #139 */
	"where(true_, lit_dbl)", /* state #140 */
	"where(lit_dbl, orderby(orderspecs(lit_dbl, nil), lit_dbl))", /* state #141 */
	"where(true_, orderby(orderspecs(lit_dbl, nil), lit_dbl))", /* state #142 */
	"where(lit_dbl, lit_dbl)", /* state #143 */
	"xrpc(lit_dbl, apply(nil))", /* state #144 */
};
char *PFsimplify_ntname[] = {
	"Error: Nonterminals are > 0",
	"Query",
	"CoreExpr",
	"OptBindExpr",
	"OptVar",
	"WhereExpr",
	"OrdWhereExpr",
	"OrderSpecs",
	"SequenceType",
	"SequenceTypeCast",
	"LocationStep",
	"LocationSteps",
	"TagName",
	"FunExpr",
	"FunctionArgs",
	"Atom",
	"LiteralValue",
	"FunctionDecls",
	"FunctionDecl",
	"ParamList",
	"FunctionBody",
	"FunParam",
	0
};

short PFsimplify_closure[22][22] = {
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,   31,
	     0,   60,    0,   90,    0,   30,   30,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,   43,    0,    0,    0,    0,    0,    0,   43,
	     0,   43,    0,   43,    0,   43,   43,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,   87,    0,    0,    0,    0,    0,    0,   87,
	     0,   87,    0,   87,    0,   87,   87,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,  102,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
	{    0,    0,  120,    0,    0,    0,    0,    0,    0,  120,
	     0,  120,    0,  120,    0,  120,  120,    0,    0,    0,
	     0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,},
};
#line 378 "simplify.brg"


/** Maximum number of pattern leaves */
#define MAX_KIDS 10

static void relabel (PFcnode_t *p,  PFcnode_t **kids);

#include "core_mnemonic.h"

/* helper function that transforms where list into nested if-then-else(empty) */
static PFcnode_t *
transform_where (PFcnode_t *p)
{
    assert (p);
    switch (p->kind) {
        case c_where:
            /* replace where nodes by if-then-else constructs */
            return if_ (L(p), then_else (transform_where (R(p)), empty ()));
        default:
            return p;
    }
}

/**
 * Reducer function. This is the heart of this source file. It
 * contains all the action code for the above burg patterns.
 */
static bool
reduce (PFcnode_t *p, int goalnt)
{
    int           rule;           /* rule number that matches for this node */
    short        *nts;            /* target non-terminals for the leaf nodes of
                                     the current rule */
    PFcnode_t *   kids[MAX_KIDS]; /* leaf nodes of this rule */
    short         old_state_label, old_state_label2;
    bool          manual;
    bool          rewrite_again;

    old_state_label = STATE_LABEL(p);

    /* guard against too dep recursion */
    PFrecursion_fence();

    do {
        rewrite_again = false;
        manual = false;

        /* determine rule that matches for this non-terminal */
        rule = PFsimplify_rule (STATE_LABEL (p), goalnt);

        assert (rule);

        /*
        fprintf (stderr, "rule %i\n", rule);
        */

        /* initialize the kids[] vector */
        for (unsigned short i = 0; i < MAX_KIDS; i++)
            kids[i] = NULL;

        /*
         * prepare recursive traversal: get information on leaf nodes of
         * this rule
         */
        nts = PFsimplify_nts[rule];
        PFsimplify_kids (p, rule, kids);

        switch (rule) {

            /* Query:              main (FunctionDecls, CoreExpr) */
            case 1:
                manual = true;

                /*
                 * Look at query body first, then at function declarations.
                 * This way we make sure that the expansion of let statements
                 * also considers function declarations.
                 */
                reduce (kids[1], nts[1]);
                reduce (kids[0], nts[0]);
                break;

            /* OptBindExpr:        for_ (forbind (forvars (var, nil),
                                                  LiteralValue),
                                         OptBindExpr) */
            case 2:
                *p = *let (letbind (LLL(p), LR(p)), R(p));
                relabel (p, kids);
                rewrite_again = true;
                break;

            /* OptBindExpr:        for_ (forbind (forvars (var, var),
                                                  LiteralValue),
                                         OptBindExpr) */
            case 3:
                *p = *let (letbind (LLL(p), LR(p)),
                           let (letbind (LLR(p), num (1)), R(p)));
                relabel (p, kids);
                rewrite_again = true;
                break;

            /* OptBindExpr:        let (letbind (var, Atom), OptBindExpr) */
            case 4:
                manual = true;

                /*
                 * Unfold atoms (a is an atom)
                 *
                 *     let $v := a return e
                 *  -->
                 *     e[a/$v]
                 *
                 * See the comment in the declaration of var_env to
                 * understand what's going on here.
                 */

                /*
                 * Handle Atom first.  In case it is a variable, this
                 * will make sure that we do transitive cases of variable
                 * replacement correctly.
                 */
                reduce (kids[0], nts[0]);

                /* add mapping for this variable to the environment */
                *((bind_t *) PFarray_add (var_env[hash(LL(p)->sem.var)]))
                    = (bind_t) { .var = LL(p)->sem.var, .atom = LR(p) };

                if (LL(p)->sem.var->global && LR(p)->kind == c_var)
                    LR(p)->sem.var->global = true;

                /*
                 * Reduce the return part.
                 */
                reduce (kids[1], nts[1]);

                /*
                 * Do NOT remove the variable from the environment.
                 */

                /*
                 * We have now replaced every occurrence of the variable
                 * in the return part with its binding atom.  The return
                 * part now becomes the expression itself.
                 */
                *p = *R(p);

                rewrite_again = true;
                break;

            /* OptBindExpr:        let (letbind (var,
                                                 flwr (let (letbind (var,
                                                                     CoreExpr),
                                                            nil),
                                                       WhereExpr)),
                                        OptBindExpr) */
            case 5:
            {   /*
                 * Remove a nested let block:
                 *
                 *     let $v1 := let $v2 := e return e' return e''
                 *  -->
                 *     let $v2 := e return
                 *       let $v1 := e' return
                 *         e''
                 */
                bool label = false;
                /* make sure to transform (necessary) where lists into
                   if-then-else(empty) constructs */
                if (LRR(p)->kind == c_where) {
                    /* throw away unnecessary where list */
                    if (L(LRR(p))->kind == c_true) {
                        assert (kids[1] == LRR(p));
                        LRR(p) = R(LRR(p));
                        kids[1] = LRR(p);
                    }
                    else {
                        LRR(p) = transform_where (LRR(p));
                        label = true;
                    }
                }

                /* Don't remove flwr if there is an order by -- we could prune
                   an type error. After typechecking we know that the order by
                   has correct type and can rewrite the same pattern */
                *p = *let (letbind (LL(LRL(p)),
                                    LR(LRL(p))),   /* let $v2 := e return */
                           let (letbind (LL(p),
                                         LRR(p)),  /*   let $v1 := e' ret */
                                R(p)));            /*     e''             */

                /* in case we rewrote the WhereExpr as well
                   we need to label the complete Core tree */
                if (!label)
                    relabel (p, kids);
                else
                    PFsimplify_label (p);

                rewrite_again = true;
            }   break;

            /* OptBindExpr:        let (letbind (var,
                                                 flwr (let (letbind (var,
                                                                     CoreExpr),
                                                            OptBindExpr)),
                                                       WhereExpr),
                                        OptBindExpr) */
            case 6:
            /* OptBindExpr:        let (letbind (var,
                                                 flwr (let (letbind (var,
                                                                     CoreExpr),
                                                            OptBindExpr),
                                                       OrdWhereExpr)),
                                        OptBindExpr) */
            case 7:
                /*
                 * Remove a nested let block:
                 *
                 *     let $v1 := let $v2 := e return e' return e''
                 *  -->
                 *     let $v2 := e return
                 *       let $v1 := e' return
                 *         e''
                 */
                *p = *let (letbind (LL(LRL(p)),
                                    LR(LRL(p))),       /* let $v2 := e return */
                         let (letbind (LL(p),          /*   let $v1 := e' ret */
                                       flwr (R(LRL(p)),
                                             LRR(p))),
                              R(p)));                  /*     e''             */
                relabel (p, kids);
                rewrite_again = true;
                break;

            /* WhereExpr:          where (true_, WhereExpr) */
            case 8:
            /* OrdWhereExpr:       where (true_, OrdWhereExpr) */
            case 9:
                *p = *(R(p));
                /* don't need to re-label here,
                 * RL(p) should already be labeled */
                rewrite_again = true;
                break;

            /* CoreExpr:          if_ (true_, then_else (CoreExpr, CoreExpr)) */
            case 11:
                *p = *RL(p);
                /* don't need to re-label here,
                 * RL(p) should already be labeled */
                rewrite_again = true;
                break;

            /* CoreExpr:          if_ (false_, then_else (CoreExpr, CoreExpr))*/
            case 12:
                *p = *RR(p);
                /* don't need to re-label here,
                 * RR(p) should already be labeled */
                rewrite_again = true;
                break;

            /* CoreExpr:           seq (seq (CoreExpr, CoreExpr), CoreExpr) */
            case 13:
                *p = *seq (LL(p), seq (LR(p), R(p)));
                relabel (p, kids);
                rewrite_again = true;
                break;

            /* CoreExpr:           seq (empty, CoreExpr) */
            case 15:
                *p = *R(p);
                rewrite_again = true;
                break;

            /* CoreExpr:           seq (CoreExpr, empty) */
            case 16:
                *p = *L(p);
                rewrite_again = true;
                break;


            /* FunExpr:            apply (arg (CoreExpr,
                                               arg (CoreExpr,
                                                    arg (CoreExpr,
                                                         FunctionArgs)))) */
            case 18:
                /*
                 * There's exactly one function defined with an arbitrary
                 * number of arguments: fn:concat(). We normalize it here
                 * to subsequent calls with just two arguments.
                 */
                if (! PFqname_eq (p->sem.fun->qname,
                                  PFqname (PFns_fn, "concat"))) {

                    PFfun_t *fn_concat = function (PFqname (PFns_fn, "concat"));

                    /* The result must refer to the same parent non-terminal
                       FunExpr as otherwise the next reduce() call fails. */
                    *p = *apply (fn_concat,
                                 arg (apply (fn_concat,
                                             arg (LL(p),
                                                  arg (LRL(p),
                                                       nil ()))),
                                      LRR(p)));

                    relabel (p, kids);
                    rewrite_again = true;
                }
                break;



            /* Atom:                var */
            case 19:
                {
                    /*
                     * See the comment in the declaration of var_env and
                     * the rule that processes let-bindings to understand
                     * what's going on here.
                     */
                    unsigned short h = hash (p->sem.var);

                    /*
                     * Look up this variable in the variable replacement
                     * environment.  If we find it there, do the replacement.
                     */
                    for (unsigned int i = 0; i < PFarray_last (var_env[h]); i++)
                        if (((bind_t *) PFarray_at (var_env[h], i))->var
                                == p->sem.var) {
                            *p = *((bind_t *) PFarray_at (var_env[h], i))->atom;
                            rewrite_again = true;
                            break;
                        }
                }
                break;

            /* FunctionDecl:       fun_decl (ParamList, FunctionBody) */
            case 20:
                /* During simplification, the function body root may have
                 * changed. Fix it in the corresponding PFfun_t struct.
                 */
                p->sem.fun->core = R(p);
                break;

            default:
                break;
        }
    } while (rewrite_again);

    old_state_label2 = STATE_LABEL(p);

    if ( ! manual )
        for (unsigned int i = 0; nts[i]; i++) {
            while (reduce (kids[i], nts[i]))
                relabel (p, kids);
        }

    if (old_state_label != STATE_LABEL(p)
        || old_state_label2 != STATE_LABEL(p))
        return true;

    return false;
}


/*
 * Re-label a match pattern.
 *
 * Start with node @a p and relabel the subtree below. However, stop
 * if @a p is one of the pattern leaves, passed as the argument @a kids.
 */
static void
relabel (PFcnode_t *p,  PFcnode_t **kids)
{
    unsigned int i;

    for (i = 0; i < MAX_KIDS; i++) {
        if (kids[i] && p == kids[i])
            return;
    }

    /* Relabel p's children. */
    if (!L(p) && !R(p)) {
        STATE_LABEL(p) = PFsimplify_state (OP_LABEL(p), 0, 0);
    }
    else if (L(p) && !R(p)) {
        relabel (L(p), kids);
        STATE_LABEL(p) = PFsimplify_state (OP_LABEL(p),
                                           STATE_LABEL(L(p)),
                                           0);
    }
    else if (!L(p) && R(p)) {
        relabel (R(p), kids);
        STATE_LABEL(p) = PFsimplify_state (OP_LABEL(p),
                                           STATE_LABEL(R(p)),
                                           0);
    }
    else {
        relabel (L(p), kids);
        relabel (R(p), kids);
        STATE_LABEL(p) = PFsimplify_state (OP_LABEL(p),
                                           STATE_LABEL(L(p)),
                                           STATE_LABEL(R(p)));
    }

}

/* initialize global  variables */
static void
PFsimplify_init (void)
{
    /* set up variable replacement environment */
    for (unsigned short i = 0; i < HASH_BUCKETS; i++)
        var_env[i] = PFarray (sizeof (bind_t), 128);
}

/**
 * Simplify XQuery Core tree.
 *
 * @param r root of the XQuery Core tree.
 * @return the simplified Core tree
 */
PFcnode_t *
PFsimplify (PFcnode_t *r)
{
    assert (r);

    /* initialize global  variables */
    PFsimplify_init ();

    /* label the Core tree bottom up */
    PFsimplify_label (r);

    /* invoke rewriting */
    while (reduce (r, 1))
        /* rewrite as long as there is something to do. */;

    return r;
}


/* vim:set shiftwidth=4 expandtab filetype=c: */
