#line 1 "typecheck.brg"


/**
 * @file
 *
 * Type check XQuery Core tree.
 *
 * This phase attaches static type information to the XQuery Core
 * tree and checks for correct typedness.
 *
 * Copyright Notice:
 * -----------------
 *
 * The contents of this file are subject to the Pathfinder Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://monetdb.cwi.nl/Legal/PathfinderLicense-1.1.html
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is the Pathfinder system.
 *
 * The Original Code has initially been developed by the Database &
 * Information Systems Group at the University of Konstanz, Germany and
 * the Database Group at the Technische Universitaet Muenchen, Germany.
 * It is now maintained by the Database Systems Group at the Eberhard
 * Karls Universitaet Tuebingen, Germany.  Portions created by the
 * University of Konstanz, the Technische Universitaet Muenchen, and the
 * Universitaet Tuebingen are Copyright (C) 2000-2005 University of
 * Konstanz, (C) 2005-2008 Technische Universitaet Muenchen, and (C)
 * 2008-2010 Eberhard Karls Universitaet Tuebingen, respectively.  All
 * Rights Reserved.
 *
 *
 * $Id$
 */ 

/* always include pf_config.h first! */
#include "pf_config.h"
#include "pathfinder.h"
#include <assert.h>
#include <stdio.h>

#include "oops.h"
#include "core.h"
#include "qname.h"
/* #include "mem.h" */

/* PFvar_t */
#include "variable.h"

#include "subtyping.h"

/* Easily access subtree-parts */
#include "child_mnemonic.h"

/*
 * Accessors for the burg matcher
 */
typedef struct PFcnode_t *NODEPTR_TYPE;

/* accessor to the node kind */
#define OP_LABEL(p)    ((p)->kind) 

/* accessors to left and right child node */
#define LEFT_CHILD(p)  ((p)->child[0])
#define RIGHT_CHILD(p) ((p)->child[1])

/* the state determined during bottom-up labeling is stored here */
#define STATE_LABEL(p) ((p)->state_label)

/* If something goes wrong, call PFoops */
#define PANIC(...) PFoops (OOPS_BURG, __VA_ARGS__)

#ifndef PFtypecheck_PANIC
#define PFtypecheck_PANIC	PANIC
#endif /* PFtypecheck_PANIC */
#include <stdlib.h> /* for abort() */
#ifdef NDEBUG
#define PFtypecheck_assert(x,y)	;
#else
#define PFtypecheck_assert(x,y)	if(!(x)) {y; abort();}
#endif
static short PFtypecheck_r1_nts[] ={ 14, 2, 0 };
static short PFtypecheck_r2_nts[] ={ 2, 0 };
static short PFtypecheck_r3_nts[] ={ 12, 0 };
static short PFtypecheck_r4_nts[] ={ 6, 0 };
static short PFtypecheck_r5_nts[] ={ 3, 4, 0 };
static short PFtypecheck_r6_nts[] ={ 2, 3, 0 };
static short PFtypecheck_r9_nts[] ={ 0 };
static short PFtypecheck_r10_nts[] ={ 2, 4, 0 };
static short PFtypecheck_r11_nts[] ={ 5, 2, 0 };
static short PFtypecheck_r14_nts[] ={ 2, 2, 2, 0 };
static short PFtypecheck_r15_nts[] ={ 2, 2, 0 };
static short PFtypecheck_r17_nts[] ={ 2, 7, 2, 2, 0 };
static short PFtypecheck_r18_nts[] ={ 7, 2, 0 };
static short PFtypecheck_r19_nts[] ={ 2, 7, 2, 0 };
static short PFtypecheck_r25_nts[] ={ 9, 0 };
static short PFtypecheck_r26_nts[] ={ 7, 0 };
static short PFtypecheck_r40_nts[] ={ 8, 9, 0 };
static short PFtypecheck_r41_nts[] ={ 8, 2, 0 };
static short PFtypecheck_r42_nts[] ={ 10, 0 };
static short PFtypecheck_r44_nts[] ={ 11, 10, 0 };
static short PFtypecheck_r64_nts[] ={ 2, 5, 0 };
static short PFtypecheck_r67_nts[] ={ 13, 0 };
static short PFtypecheck_r81_nts[] ={ 15, 14, 0 };
static short PFtypecheck_r82_nts[] ={ 16, 17, 0 };
static short PFtypecheck_r84_nts[] ={ 18, 16, 0 };
short *PFtypecheck_nts[] = {
	0,
	PFtypecheck_r1_nts,
	PFtypecheck_r2_nts,
	PFtypecheck_r3_nts,
	PFtypecheck_r4_nts,
	PFtypecheck_r5_nts,
	PFtypecheck_r6_nts,
	PFtypecheck_r6_nts,
	PFtypecheck_r6_nts,
	PFtypecheck_r9_nts,
	PFtypecheck_r10_nts,
	PFtypecheck_r11_nts,
	PFtypecheck_r2_nts,
	0,
	PFtypecheck_r14_nts,
	PFtypecheck_r15_nts,
	PFtypecheck_r15_nts,
	PFtypecheck_r17_nts,
	PFtypecheck_r18_nts,
	PFtypecheck_r19_nts,
	0,
	PFtypecheck_r9_nts,
	PFtypecheck_r2_nts,
	0,
	0,
	PFtypecheck_r25_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r40_nts,
	PFtypecheck_r41_nts,
	PFtypecheck_r42_nts,
	PFtypecheck_r9_nts,
	PFtypecheck_r44_nts,
	PFtypecheck_r2_nts,
	PFtypecheck_r2_nts,
	PFtypecheck_r15_nts,
	PFtypecheck_r2_nts,
	PFtypecheck_r15_nts,
	PFtypecheck_r2_nts,
	PFtypecheck_r2_nts,
	PFtypecheck_r2_nts,
	PFtypecheck_r15_nts,
	PFtypecheck_r2_nts,
	0,
	0,
	0,
	0,
	0,
	PFtypecheck_r2_nts,
	PFtypecheck_r2_nts,
	0,
	PFtypecheck_r2_nts,
	PFtypecheck_r64_nts,
	PFtypecheck_r18_nts,
	PFtypecheck_r9_nts,
	PFtypecheck_r67_nts,
	PFtypecheck_r9_nts,
	PFtypecheck_r9_nts,
	PFtypecheck_r9_nts,
	PFtypecheck_r9_nts,
	PFtypecheck_r9_nts,
	PFtypecheck_r9_nts,
	PFtypecheck_r9_nts,
	0,
	0,
	0,
	0,
	0,
	PFtypecheck_r9_nts,
	PFtypecheck_r81_nts,
	PFtypecheck_r82_nts,
	PFtypecheck_r9_nts,
	PFtypecheck_r84_nts,
	PFtypecheck_r2_nts,
	PFtypecheck_r26_nts,
	PFtypecheck_r15_nts,
	PFtypecheck_r15_nts,
};
static unsigned char PFtypecheck_seq_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_twig_seq_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_flwr_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_let_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_letbind_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_for__transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */,
{    0,    2}	/* row 2 */
};
static unsigned char PFtypecheck_forbind_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    2}	/* row 1 */,
{    0,    1}	/* row 2 */
};
static unsigned char PFtypecheck_forvars_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    1,    2}	/* row 1 */
};
static unsigned char PFtypecheck_where_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_orderby_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_orderspecs_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFtypecheck_arg_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_typesw_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_cases_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_case__transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_seqcast_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_proof_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_subty_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_if__transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_then_else_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_locsteps_transition[2][3] = {
{    0,    0,    0}	/* row 0 */,
{    0,    2,    1}	/* row 1 */
};
static unsigned char PFtypecheck_elem_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    2}	/* row 1 */,
{    0,    1}	/* row 2 */
};
static unsigned char PFtypecheck_attr_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */,
{    0,    2}	/* row 2 */
};
static unsigned char PFtypecheck_pi_transition[3][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */,
{    0,    2}	/* row 2 */
};
static unsigned char PFtypecheck_main_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_fun_decls_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_fun_decl_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_params_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_param_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_cast_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_recursion_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_seed_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static unsigned char PFtypecheck_xrpc_transition[2][2] = {
{    0,    0}	/* row 0 */,
{    0,    1}	/* row 1 */
};
static struct {
	unsigned int f27:2;
	unsigned int f29:2;
	unsigned int f30:2;
	unsigned int f31:2;
	unsigned int f32:4;
	unsigned int f33:2;
	unsigned int f34:2;
	unsigned int f35:2;
	unsigned int f36:3;
	unsigned int f37:3;
	unsigned int f38:5;
	unsigned int f39:2;
} PFtypecheck_plank_0[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,  14,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   0,   0,  13,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  12,   2,},	/* row 3 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 4 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   8,   2,},	/* row 5 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   9,   2,},	/* row 6 */
	{   0,   0,   0,   0,  12,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  23,   2,},	/* row 10 */
	{   0,   0,   0,   0,  11,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   5,   2,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   0,   0,   0,  10,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   6,   2,},	/* row 16 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  11,   2,},	/* row 17 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  10,   2,},	/* row 18 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   2,   0,  16,   2,},	/* row 19 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   2,   0,  16,   2,},	/* row 20 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  13,   2,},	/* row 21 */
	{   0,   0,   0,   0,   9,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   0,   0,   0,   0,   8,   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 28 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 31 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  14,   2,},	/* row 32 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 33 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 34 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   2,   0,  16,   2,},	/* row 35 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   2,   0,  16,   2,},	/* row 36 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   2,   0,  16,   2,},	/* row 37 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   2,   0,  16,   2,},	/* row 38 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   2,   0,  18,   2,},	/* row 39 */
	{   0,   0,   0,   2,   0,   0,   0,   0,   2,   0,  18,   2,},	/* row 40 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 41 */
	{   2,   0,   2,   0,   0,   0,   0,   0,   0,   4,   0,   0,},	/* row 42 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 43 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   2,   2,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   0,   0,   0,   7,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   4,   2,},	/* row 50 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   3,   2,},	/* row 51 */
	{   0,   0,   0,   0,   6,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   5,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  21,   2,},	/* row 54 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  15,   2,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   4,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  19,   2,},	/* row 60 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   2,   0,   1,   2,},	/* row 61 */
	{   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   7,   2,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   2,   0,  16,   2,},	/* row 68 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  20,   2,},	/* row 69 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  22,   2,},	/* row 70 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  24,   2,},	/* row 71 */
	{   0,   2,   0,   0,   0,   0,   0,   0,   2,   0,  16,   2,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,  17,   2,},	/* row 74 */
};
static struct {
	unsigned int f13:2;
	unsigned int f14:2;
	unsigned int f15:2;
	unsigned int f16:2;
	unsigned int f17:2;
	unsigned int f18:2;
	unsigned int f19:2;
	unsigned int f20:2;
	unsigned int f21:2;
	unsigned int f22:2;
	unsigned int f23:2;
	unsigned int f24:2;
	unsigned int f25:2;
	unsigned int f26:2;
	unsigned int f28:4;
} PFtypecheck_plank_1[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 3 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 4 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 5 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 9 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 18 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   6,},	/* row 19 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   3,},	/* row 20 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 28 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,},	/* row 30 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 31 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 32 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 33 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 34 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   4,},	/* row 35 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   7,},	/* row 36 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   1,},	/* row 37 */
	{   0,   0,   0,   0,   0,   1,   1,   2,   0,   0,   0,   0,   0,   0,   5,},	/* row 38 */
	{   0,   0,   0,   0,   0,   2,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 39 */
	{   0,   0,   0,   0,   0,   2,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 40 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 41 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   1,   0,   0,   2,   0,},	/* row 42 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 43 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   1,   0,},	/* row 48 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 61 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 66 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   2,},	/* row 68 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   0,   0,   0,   0,   0,   1,   1,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
};
static struct {
	unsigned int f0:2;
	unsigned int f1:2;
	unsigned int f2:2;
	unsigned int f3:2;
	unsigned int f4:2;
	unsigned int f5:2;
	unsigned int f6:2;
	unsigned int f7:2;
	unsigned int f8:2;
	unsigned int f9:2;
	unsigned int f10:2;
	unsigned int f11:2;
	unsigned int f12:2;
} PFtypecheck_plank_2[] = {
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 0 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 1 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 2 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 3 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,},	/* row 4 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 5 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 6 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 7 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,},	/* row 8 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,},	/* row 9 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 10 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 11 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 12 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 13 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 14 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 15 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 16 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 17 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 18 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 19 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 20 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 21 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 22 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 23 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 24 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 25 */
	{   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,   0,},	/* row 26 */
	{   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,},	/* row 27 */
	{   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,},	/* row 28 */
	{   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   0,   0,   0,},	/* row 29 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 30 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 31 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 32 */
	{   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 33 */
	{   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 34 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 35 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 36 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 37 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 38 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 39 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 40 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 41 */
	{   0,   1,   0,   0,   0,   0,   0,   1,   0,   1,   1,   0,   0,},	/* row 42 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 43 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 44 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   2,   0,   0,   0,},	/* row 45 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   1,   2,   0,   0,   0,},	/* row 46 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 47 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 48 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 49 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 50 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 51 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 52 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 53 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 54 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 55 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 56 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 57 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 58 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 59 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 60 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 61 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 62 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 63 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 64 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 65 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 66 */
	{   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 67 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 68 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 69 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 70 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 71 */
	{   1,   0,   1,   0,   1,   0,   0,   2,   0,   0,   0,   0,   0,},	/* row 72 */
	{   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 73 */
	{   1,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,},	/* row 74 */
};
static short PFtypecheck_eruleMap[] = {
    0,   67,   66,    0,    4,   60,   54,   53,   52,   51,	/* 0-9 */
   50,   49,   48,   47,   46,   42,    5,   14,   87,    3,	/* 10-19 */
   88,   25,   15,   16,   19,   17,   65,   61,    0,   86,	/* 20-29 */
    0,   45,    0,   44,   43,    0,   85,    0,   82,    0,	/* 30-39 */
   81,   80,    0,   69,   72,   73,   71,   68,   74,   70,	/* 40-49 */
    0,   30,   39,   38,   37,   36,   35,   34,   33,   32,	/* 50-59 */
   31,   29,   28,   27,   26,    0,   40,   41,    0,    8,	/* 60-69 */
    6,    7,    9,    0,   64,   63,    0,   84,   83,    0,	/* 70-79 */
    1,    2,    0,   22,   21,    0,   18,    0,   11,   12,	/* 80-89 */
   10
};
#define PFtypecheck_Query_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f39 +79]
#define PFtypecheck_CoreExpr_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f38 +3]
#define PFtypecheck_OptBindExpr_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f37 +68]
#define PFtypecheck_WhereExpr_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f36 +87]
#define PFtypecheck_OrderSpecs_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f35 +73]
#define PFtypecheck_SequenceTypeCast_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f34 +85]
#define PFtypecheck_SequenceType_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f33 +82]
#define PFtypecheck_LocationStep_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f32 +50]
#define PFtypecheck_LocationSteps_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f31 +65]
#define PFtypecheck_FunctionArgs_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f30 +32]
#define PFtypecheck_FunctionArg_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_2[state].f0 +30]
#define PFtypecheck_Atom_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f29 +0]
#define PFtypecheck_LiteralValue_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_1[state].f28 +42]
#define PFtypecheck_FunctionDecls_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_0[state].f27 +39]
#define PFtypecheck_FunctionDecl_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_1[state].f22 +37]
#define PFtypecheck_ParamList_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_1[state].f26 +76]
#define PFtypecheck_FunctionBody_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_2[state].f0 +35]
#define PFtypecheck_FunParam_rule(state)	PFtypecheck_eruleMap[PFtypecheck_plank_1[state].f24 +28]

#ifdef __STDC__
int PFtypecheck_rule(int state, int goalnt) {
#else
int PFtypecheck_rule(state, goalnt) int state; int goalnt; {
#endif
	PFtypecheck_assert(state >= 0 && state < 75, PFtypecheck_PANIC("Bad state %d passed to PFtypecheck_rule\n", state));
	switch(goalnt) {
	case 1:
		return PFtypecheck_Query_rule(state);
	case 2:
		return PFtypecheck_CoreExpr_rule(state);
	case 3:
		return PFtypecheck_OptBindExpr_rule(state);
	case 4:
		return PFtypecheck_WhereExpr_rule(state);
	case 5:
		return PFtypecheck_OrderSpecs_rule(state);
	case 6:
		return PFtypecheck_SequenceTypeCast_rule(state);
	case 7:
		return PFtypecheck_SequenceType_rule(state);
	case 8:
		return PFtypecheck_LocationStep_rule(state);
	case 9:
		return PFtypecheck_LocationSteps_rule(state);
	case 10:
		return PFtypecheck_FunctionArgs_rule(state);
	case 11:
		return PFtypecheck_FunctionArg_rule(state);
	case 12:
		return PFtypecheck_Atom_rule(state);
	case 13:
		return PFtypecheck_LiteralValue_rule(state);
	case 14:
		return PFtypecheck_FunctionDecls_rule(state);
	case 15:
		return PFtypecheck_FunctionDecl_rule(state);
	case 16:
		return PFtypecheck_ParamList_rule(state);
	case 17:
		return PFtypecheck_FunctionBody_rule(state);
	case 18:
		return PFtypecheck_FunParam_rule(state);
	default:
		PFtypecheck_PANIC("Unknown nonterminal %d in PFtypecheck_rule;\n", goalnt);
		abort();
		return 0;
	}
}

int PFtypecheck_TEMP;
#define PFtypecheck_var_state	72
#define PFtypecheck_lit_str_state	38
#define PFtypecheck_lit_int_state	37
#define PFtypecheck_lit_dec_state	36
#define PFtypecheck_lit_dbl_state	35
#define PFtypecheck_nil_state	42
#define PFtypecheck_seq_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_seq_transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 59 : 0 )
#define PFtypecheck_twig_seq_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_twig_seq_transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 68 : 0 )
#define PFtypecheck_ordered_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_2[l].f0) ? PFtypecheck_TEMP + 43 : 0 )
#define PFtypecheck_unordered_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_2[l].f0) ? PFtypecheck_TEMP + 70 : 0 )
#define PFtypecheck_flwr_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_flwr_transition[PFtypecheck_plank_2[l].f1][PFtypecheck_plank_2[r].f2]) ? PFtypecheck_TEMP + 20 : 0 )
#define PFtypecheck_let_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_let_transition[PFtypecheck_plank_2[l].f3][PFtypecheck_plank_2[r].f1]) ? PFtypecheck_TEMP + 32 : 0 )
#define PFtypecheck_letbind_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_letbind_transition[PFtypecheck_plank_2[l].f4][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 33 : 0 )
#define PFtypecheck_for__state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_for__transition[PFtypecheck_plank_2[l].f5][PFtypecheck_plank_2[r].f1]) ? PFtypecheck_TEMP + 23 : 0 )
#define PFtypecheck_forbind_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_forbind_transition[PFtypecheck_plank_2[l].f6][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 25 : 0 )
#define PFtypecheck_forvars_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_forvars_transition[PFtypecheck_plank_2[l].f4][PFtypecheck_plank_2[r].f7]) ? PFtypecheck_TEMP + 27 : 0 )
#define PFtypecheck_where_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_where_transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_2[r].f2]) ? PFtypecheck_TEMP + 72 : 0 )
#define PFtypecheck_orderby_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_orderby_transition[PFtypecheck_plank_2[l].f8][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 42 : 0 )
#define PFtypecheck_orderspecs_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_orderspecs_transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_2[r].f9]) ? PFtypecheck_TEMP + 44 : 0 )
#define PFtypecheck_apply_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_2[l].f10) ? PFtypecheck_TEMP + 2 : 0 )
#define PFtypecheck_arg_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_arg_transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_2[r].f10]) ? PFtypecheck_TEMP + 3 : 0 )
#define PFtypecheck_typesw_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_typesw_transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_2[r].f11]) ? PFtypecheck_TEMP + 69 : 0 )
#define PFtypecheck_cases_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_cases_transition[PFtypecheck_plank_2[l].f12][PFtypecheck_plank_1[r].f13]) ? PFtypecheck_TEMP + 8 : 0 )
#define PFtypecheck_case__state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_case__transition[PFtypecheck_plank_1[l].f14][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 7 : 0 )
#define PFtypecheck_default__state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_2[l].f0) ? PFtypecheck_TEMP + 12 : 0 )
#define PFtypecheck_seqtype_state	62
#define PFtypecheck_seqcast_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_seqcast_transition[PFtypecheck_plank_1[l].f14][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 60 : 0 )
#define PFtypecheck_proof_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_proof_transition[PFtypecheck_plank_1[l].f15][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 53 : 0 )
#define PFtypecheck_subty_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_subty_transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_1[r].f14]) ? PFtypecheck_TEMP + 63 : 0 )
#define PFtypecheck_stattype_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_2[l].f0) ? PFtypecheck_TEMP + 62 : 0 )
#define PFtypecheck_if__state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_if__transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_1[r].f16]) ? PFtypecheck_TEMP + 31 : 0 )
#define PFtypecheck_then_else_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_then_else_transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 66 : 0 )
#define PFtypecheck_locsteps_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_locsteps_transition[PFtypecheck_plank_1[l].f17][PFtypecheck_plank_1[r].f18]) ? PFtypecheck_TEMP + 38 : 0 )
#define PFtypecheck_ancestor_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 0 : 0 )
#define PFtypecheck_ancestor_or_self_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 1 : 0 )
#define PFtypecheck_attribute_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 6 : 0 )
#define PFtypecheck_child_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 10 : 0 )
#define PFtypecheck_descendant_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 13 : 0 )
#define PFtypecheck_descendant_or_self_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 14 : 0 )
#define PFtypecheck_following_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 21 : 0 )
#define PFtypecheck_following_sibling_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 22 : 0 )
#define PFtypecheck_parent_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 48 : 0 )
#define PFtypecheck_preceding_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 51 : 0 )
#define PFtypecheck_preceding_sibling_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 52 : 0 )
#define PFtypecheck_self_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 58 : 0 )
#define PFtypecheck_select_narrow_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 56 : 0 )
#define PFtypecheck_select_wide_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_1[l].f14) ? PFtypecheck_TEMP + 57 : 0 )
#define PFtypecheck_elem_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_elem_transition[PFtypecheck_plank_1[l].f19][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 16 : 0 )
#define PFtypecheck_attr_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_attr_transition[PFtypecheck_plank_1[l].f19][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 4 : 0 )
#define PFtypecheck_text_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_2[l].f0) ? PFtypecheck_TEMP + 65 : 0 )
#define PFtypecheck_doc_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_2[l].f0) ? PFtypecheck_TEMP + 15 : 0 )
#define PFtypecheck_comment_state(l)	( (PFtypecheck_TEMP = PFtypecheck_plank_2[l].f0) ? PFtypecheck_TEMP + 11 : 0 )
#define PFtypecheck_pi_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_pi_transition[PFtypecheck_plank_1[l].f20][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 49 : 0 )
#define PFtypecheck_tag_state	65
#define PFtypecheck_true__state	68
#define PFtypecheck_false__state	20
#define PFtypecheck_empty_state	19
#define PFtypecheck_main_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_main_transition[PFtypecheck_plank_1[l].f21][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 40 : 0 )
#define PFtypecheck_fun_decls_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_fun_decls_transition[PFtypecheck_plank_1[l].f22][PFtypecheck_plank_1[r].f21]) ? PFtypecheck_TEMP + 30 : 0 )
#define PFtypecheck_fun_decl_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_fun_decl_transition[PFtypecheck_plank_1[l].f23][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 29 : 0 )
#define PFtypecheck_params_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_params_transition[PFtypecheck_plank_1[l].f24][PFtypecheck_plank_1[r].f23]) ? PFtypecheck_TEMP + 47 : 0 )
#define PFtypecheck_param_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_param_transition[PFtypecheck_plank_1[l].f14][PFtypecheck_plank_2[r].f4]) ? PFtypecheck_TEMP + 46 : 0 )
#define PFtypecheck_cast_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_cast_transition[PFtypecheck_plank_1[l].f14][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 9 : 0 )
#define PFtypecheck_recursion_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_recursion_transition[PFtypecheck_plank_2[l].f4][PFtypecheck_plank_1[r].f25]) ? PFtypecheck_TEMP + 54 : 0 )
#define PFtypecheck_seed_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_seed_transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 55 : 0 )
#define PFtypecheck_xrpc_state(l,r)	( (PFtypecheck_TEMP = PFtypecheck_xrpc_transition[PFtypecheck_plank_2[l].f0][PFtypecheck_plank_2[r].f0]) ? PFtypecheck_TEMP + 73 : 0 )

#ifdef __STDC__
int PFtypecheck_state(int op, int l, int r) {
#else
int PFtypecheck_state(op, l, r) int op; int l; int r; {
#endif
	register int PFtypecheck_TEMP;
#ifndef NDEBUG
	switch (op) {
	case 7:
	case 8:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 24:
	case 25:
	case 26:
	case 27:
	case 30:
	case 31:
	case 32:
	case 34:
	case 35:
	case 40:
	case 55:
	case 56:
	case 60:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
		PFtypecheck_assert(r >= 0 && r < 75, PFtypecheck_PANIC("Bad state %d passed to PFtypecheck_state\n", r));
		/*FALLTHROUGH*/
	case 9:
	case 10:
	case 23:
	case 28:
	case 33:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 57:
	case 58:
	case 59:
		PFtypecheck_assert(l >= 0 && l < 75, PFtypecheck_PANIC("Bad state %d passed to PFtypecheck_state\n", l));
		/*FALLTHROUGH*/
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 29:
	case 61:
	case 65:
	case 66:
	case 67:
		break;
	}
#endif
	switch (op) {
	default: PFtypecheck_PANIC("Unknown op %d in PFtypecheck_state\n", op); abort(); return 0;
	case 1:
		return PFtypecheck_var_state;
	case 2:
		return PFtypecheck_lit_str_state;
	case 3:
		return PFtypecheck_lit_int_state;
	case 4:
		return PFtypecheck_lit_dec_state;
	case 5:
		return PFtypecheck_lit_dbl_state;
	case 6:
		return PFtypecheck_nil_state;
	case 7:
		return PFtypecheck_seq_state(l,r);
	case 8:
		return PFtypecheck_twig_seq_state(l,r);
	case 9:
		return PFtypecheck_ordered_state(l);
	case 10:
		return PFtypecheck_unordered_state(l);
	case 14:
		return PFtypecheck_flwr_state(l,r);
	case 15:
		return PFtypecheck_let_state(l,r);
	case 16:
		return PFtypecheck_letbind_state(l,r);
	case 17:
		return PFtypecheck_for__state(l,r);
	case 18:
		return PFtypecheck_forbind_state(l,r);
	case 19:
		return PFtypecheck_forvars_state(l,r);
	case 20:
		return PFtypecheck_where_state(l,r);
	case 21:
		return PFtypecheck_orderby_state(l,r);
	case 22:
		return PFtypecheck_orderspecs_state(l,r);
	case 23:
		return PFtypecheck_apply_state(l);
	case 24:
		return PFtypecheck_arg_state(l,r);
	case 25:
		return PFtypecheck_typesw_state(l,r);
	case 26:
		return PFtypecheck_cases_state(l,r);
	case 27:
		return PFtypecheck_case__state(l,r);
	case 28:
		return PFtypecheck_default__state(l);
	case 29:
		return PFtypecheck_seqtype_state;
	case 30:
		return PFtypecheck_seqcast_state(l,r);
	case 31:
		return PFtypecheck_proof_state(l,r);
	case 32:
		return PFtypecheck_subty_state(l,r);
	case 33:
		return PFtypecheck_stattype_state(l);
	case 34:
		return PFtypecheck_if__state(l,r);
	case 35:
		return PFtypecheck_then_else_state(l,r);
	case 40:
		return PFtypecheck_locsteps_state(l,r);
	case 41:
		return PFtypecheck_ancestor_state(l);
	case 42:
		return PFtypecheck_ancestor_or_self_state(l);
	case 43:
		return PFtypecheck_attribute_state(l);
	case 44:
		return PFtypecheck_child_state(l);
	case 45:
		return PFtypecheck_descendant_state(l);
	case 46:
		return PFtypecheck_descendant_or_self_state(l);
	case 47:
		return PFtypecheck_following_state(l);
	case 48:
		return PFtypecheck_following_sibling_state(l);
	case 49:
		return PFtypecheck_parent_state(l);
	case 50:
		return PFtypecheck_preceding_state(l);
	case 51:
		return PFtypecheck_preceding_sibling_state(l);
	case 52:
		return PFtypecheck_self_state(l);
	case 53:
		return PFtypecheck_select_narrow_state(l);
	case 54:
		return PFtypecheck_select_wide_state(l);
	case 55:
		return PFtypecheck_elem_state(l,r);
	case 56:
		return PFtypecheck_attr_state(l,r);
	case 57:
		return PFtypecheck_text_state(l);
	case 58:
		return PFtypecheck_doc_state(l);
	case 59:
		return PFtypecheck_comment_state(l);
	case 60:
		return PFtypecheck_pi_state(l,r);
	case 61:
		return PFtypecheck_tag_state;
	case 65:
		return PFtypecheck_true__state;
	case 66:
		return PFtypecheck_false__state;
	case 67:
		return PFtypecheck_empty_state;
	case 68:
		return PFtypecheck_main_state(l,r);
	case 69:
		return PFtypecheck_fun_decls_state(l,r);
	case 70:
		return PFtypecheck_fun_decl_state(l,r);
	case 71:
		return PFtypecheck_params_state(l,r);
	case 72:
		return PFtypecheck_param_state(l,r);
	case 73:
		return PFtypecheck_cast_state(l,r);
	case 74:
		return PFtypecheck_recursion_state(l,r);
	case 75:
		return PFtypecheck_seed_state(l,r);
	case 76:
		return PFtypecheck_xrpc_state(l,r);
	}
}
#ifdef PFtypecheck_STATE_LABEL
#define PFtypecheck_INCLUDE_EXTRA
#else
#ifdef STATE_LABEL
#define PFtypecheck_INCLUDE_EXTRA
#define PFtypecheck_STATE_LABEL 	STATE_LABEL
#define PFtypecheck_NODEPTR_TYPE	NODEPTR_TYPE
#define PFtypecheck_LEFT_CHILD  	LEFT_CHILD
#define PFtypecheck_OP_LABEL    	OP_LABEL
#define PFtypecheck_RIGHT_CHILD 	RIGHT_CHILD
#endif /* STATE_LABEL */
#endif /* PFtypecheck_STATE_LABEL */

#ifdef PFtypecheck_INCLUDE_EXTRA

#ifdef __STDC__
int PFtypecheck_label(PFtypecheck_NODEPTR_TYPE n) {
#else
int PFtypecheck_label(n) PFtypecheck_NODEPTR_TYPE n; {
#endif
	PFtypecheck_assert(n, PFtypecheck_PANIC("NULL pointer passed to PFtypecheck_label\n"));
	switch (PFtypecheck_OP_LABEL(n)) {
	default: PFtypecheck_PANIC("Bad op %d in PFtypecheck_label\n", PFtypecheck_OP_LABEL(n)); abort(); return 0;
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 29:
	case 61:
	case 65:
	case 66:
	case 67:
		return PFtypecheck_STATE_LABEL(n) = PFtypecheck_state(PFtypecheck_OP_LABEL(n), 0, 0);
	case 9:
	case 10:
	case 23:
	case 28:
	case 33:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 57:
	case 58:
	case 59:
		return PFtypecheck_STATE_LABEL(n) = PFtypecheck_state(PFtypecheck_OP_LABEL(n), PFtypecheck_label(PFtypecheck_LEFT_CHILD(n)), 0);
	case 7:
	case 8:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 24:
	case 25:
	case 26:
	case 27:
	case 30:
	case 31:
	case 32:
	case 34:
	case 35:
	case 40:
	case 55:
	case 56:
	case 60:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
		return PFtypecheck_STATE_LABEL(n) = PFtypecheck_state(PFtypecheck_OP_LABEL(n), PFtypecheck_label(PFtypecheck_LEFT_CHILD(n)), PFtypecheck_label(PFtypecheck_RIGHT_CHILD(n)));
	}
}
#ifdef __STDC__
PFtypecheck_NODEPTR_TYPE * PFtypecheck_kids(PFtypecheck_NODEPTR_TYPE p, int rulenumber, PFtypecheck_NODEPTR_TYPE *kids) {
#else
PFtypecheck_NODEPTR_TYPE * PFtypecheck_kids(p, rulenumber, kids) PFtypecheck_NODEPTR_TYPE p; int rulenumber; PFtypecheck_NODEPTR_TYPE *kids; {
#endif
	PFtypecheck_assert(p, PFtypecheck_PANIC("NULL node pointer passed to PFtypecheck_kids\n"));
	PFtypecheck_assert(kids, PFtypecheck_PANIC("NULL kids pointer passed to PFtypecheck_kids\n"));
	switch (rulenumber) {
	default:
		PFtypecheck_PANIC("Unknown Rule %d in PFtypecheck_kids;\n", rulenumber);
		abort();
		/* NOTREACHED */
	case 6:
	case 7:
	case 8:
		kids[0] = PFtypecheck_RIGHT_CHILD(PFtypecheck_LEFT_CHILD(p));
		kids[1] = PFtypecheck_RIGHT_CHILD(p);
		break;
	case 14:
		kids[0] = PFtypecheck_LEFT_CHILD(p);
		kids[1] = PFtypecheck_LEFT_CHILD(PFtypecheck_RIGHT_CHILD(p));
		kids[2] = PFtypecheck_RIGHT_CHILD(PFtypecheck_RIGHT_CHILD(p));
		break;
	case 17:
		kids[0] = PFtypecheck_LEFT_CHILD(p);
		kids[1] = PFtypecheck_LEFT_CHILD(PFtypecheck_LEFT_CHILD(PFtypecheck_RIGHT_CHILD(p)));
		kids[2] = PFtypecheck_RIGHT_CHILD(PFtypecheck_LEFT_CHILD(PFtypecheck_RIGHT_CHILD(p)));
		kids[3] = PFtypecheck_LEFT_CHILD(PFtypecheck_RIGHT_CHILD(PFtypecheck_RIGHT_CHILD(p)));
		break;
	case 19:
		kids[0] = PFtypecheck_LEFT_CHILD(PFtypecheck_LEFT_CHILD(p));
		kids[1] = PFtypecheck_RIGHT_CHILD(PFtypecheck_LEFT_CHILD(p));
		kids[2] = PFtypecheck_RIGHT_CHILD(p);
		break;
	case 46:
	case 48:
	case 54:
		kids[0] = PFtypecheck_RIGHT_CHILD(p);
		break;
	case 9:
	case 21:
	case 43:
	case 66:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 80:
	case 83:
		break;
	case 2:
	case 3:
	case 4:
	case 12:
	case 25:
	case 45:
	case 67:
	case 85:
		kids[0] = p;
		break;
	case 63:
	case 22:
	case 26:
	case 27:
	case 28:
	case 29:
	case 30:
	case 31:
	case 32:
	case 33:
	case 34:
	case 35:
	case 36:
	case 37:
	case 38:
	case 39:
	case 42:
	case 50:
	case 51:
	case 52:
	case 60:
	case 61:
	case 86:
		kids[0] = PFtypecheck_LEFT_CHILD(p);
		break;
	case 87:
		kids[0] = PFtypecheck_LEFT_CHILD(PFtypecheck_RIGHT_CHILD(p));
		kids[1] = PFtypecheck_RIGHT_CHILD(PFtypecheck_RIGHT_CHILD(p));
		break;
	case 1:
	case 5:
	case 10:
	case 11:
	case 64:
	case 15:
	case 16:
	case 18:
	case 40:
	case 41:
	case 44:
	case 47:
	case 49:
	case 53:
	case 65:
	case 81:
	case 82:
	case 84:
	case 88:
		kids[0] = PFtypecheck_LEFT_CHILD(p);
		kids[1] = PFtypecheck_RIGHT_CHILD(p);
		break;
	}
	return kids;
}
#ifdef __STDC__
PFtypecheck_NODEPTR_TYPE PFtypecheck_child(PFtypecheck_NODEPTR_TYPE p, int index) {
#else
PFtypecheck_NODEPTR_TYPE PFtypecheck_child(p, index) PFtypecheck_NODEPTR_TYPE p; int index; {
#endif
	PFtypecheck_assert(p, PFtypecheck_PANIC("NULL pointer passed to PFtypecheck_child\n"));
	switch (index) {
	case 0:
		return PFtypecheck_LEFT_CHILD(p);
	case 1:
		return PFtypecheck_RIGHT_CHILD(p);
	}
	PFtypecheck_PANIC("Bad index %d in PFtypecheck_child;\n", index);
	abort();
	return 0;
}
#ifdef __STDC__
int PFtypecheck_op_label(PFtypecheck_NODEPTR_TYPE p) {
#else
int PFtypecheck_op_label(p) PFtypecheck_NODEPTR_TYPE p; {
#endif
	PFtypecheck_assert(p, PFtypecheck_PANIC("NULL pointer passed to PFtypecheck_op_label\n"));
	return PFtypecheck_OP_LABEL(p);
}
#ifdef __STDC__
int PFtypecheck_state_label(PFtypecheck_NODEPTR_TYPE p) {
#else
int PFtypecheck_state_label(p) PFtypecheck_NODEPTR_TYPE p; {
#endif
	PFtypecheck_assert(p, PFtypecheck_PANIC("NULL pointer passed to PFtypecheck_state_label\n"));
	return PFtypecheck_STATE_LABEL(p);
}
#endif /* PFtypecheck_INCLUDE_EXTRA */
#define PFtypecheck_FunParam_NT 18
#define PFtypecheck_FunctionBody_NT 17
#define PFtypecheck_ParamList_NT 16
#define PFtypecheck_FunctionDecl_NT 15
#define PFtypecheck_FunctionDecls_NT 14
#define PFtypecheck_LiteralValue_NT 13
#define PFtypecheck_Atom_NT 12
#define PFtypecheck_FunctionArg_NT 11
#define PFtypecheck_FunctionArgs_NT 10
#define PFtypecheck_LocationSteps_NT 9
#define PFtypecheck_LocationStep_NT 8
#define PFtypecheck_SequenceType_NT 7
#define PFtypecheck_SequenceTypeCast_NT 6
#define PFtypecheck_OrderSpecs_NT 5
#define PFtypecheck_WhereExpr_NT 4
#define PFtypecheck_OptBindExpr_NT 3
#define PFtypecheck_CoreExpr_NT 2
#define PFtypecheck_Query_NT 1
#define PFtypecheck_NT 18
char * PFtypecheck_opname[] = {
	0, /* 0 */
	"var", /* 1 */
	"lit_str", /* 2 */
	"lit_int", /* 3 */
	"lit_dec", /* 4 */
	"lit_dbl", /* 5 */
	"nil", /* 6 */
	"seq", /* 7 */
	"twig_seq", /* 8 */
	"ordered", /* 9 */
	"unordered", /* 10 */
	0, /* 11 */
	0, /* 12 */
	0, /* 13 */
	"flwr", /* 14 */
	"let", /* 15 */
	"letbind", /* 16 */
	"for_", /* 17 */
	"forbind", /* 18 */
	"forvars", /* 19 */
	"where", /* 20 */
	"orderby", /* 21 */
	"orderspecs", /* 22 */
	"apply", /* 23 */
	"arg", /* 24 */
	"typesw", /* 25 */
	"cases", /* 26 */
	"case_", /* 27 */
	"default_", /* 28 */
	"seqtype", /* 29 */
	"seqcast", /* 30 */
	"proof", /* 31 */
	"subty", /* 32 */
	"stattype", /* 33 */
	"if_", /* 34 */
	"then_else", /* 35 */
	0, /* 36 */
	0, /* 37 */
	0, /* 38 */
	0, /* 39 */
	"locsteps", /* 40 */
	"ancestor", /* 41 */
	"ancestor_or_self", /* 42 */
	"attribute", /* 43 */
	"child", /* 44 */
	"descendant", /* 45 */
	"descendant_or_self", /* 46 */
	"following", /* 47 */
	"following_sibling", /* 48 */
	"parent", /* 49 */
	"preceding", /* 50 */
	"preceding_sibling", /* 51 */
	"self", /* 52 */
	"select_narrow", /* 53 */
	"select_wide", /* 54 */
	"elem", /* 55 */
	"attr", /* 56 */
	"text", /* 57 */
	"doc", /* 58 */
	"comment", /* 59 */
	"pi", /* 60 */
	"tag", /* 61 */
	0, /* 62 */
	0, /* 63 */
	0, /* 64 */
	"true_", /* 65 */
	"false_", /* 66 */
	"empty", /* 67 */
	"main", /* 68 */
	"fun_decls", /* 69 */
	"fun_decl", /* 70 */
	"params", /* 71 */
	"param", /* 72 */
	"cast", /* 73 */
	"recursion", /* 74 */
	"seed", /* 75 */
	"xrpc"
};
char PFtypecheck_arity[] = {
	-1, /* 0 */
	0, /* 1 */
	0, /* 2 */
	0, /* 3 */
	0, /* 4 */
	0, /* 5 */
	0, /* 6 */
	2, /* 7 */
	2, /* 8 */
	1, /* 9 */
	1, /* 10 */
	-1, /* 11 */
	-1, /* 12 */
	-1, /* 13 */
	2, /* 14 */
	2, /* 15 */
	2, /* 16 */
	2, /* 17 */
	2, /* 18 */
	2, /* 19 */
	2, /* 20 */
	2, /* 21 */
	2, /* 22 */
	1, /* 23 */
	2, /* 24 */
	2, /* 25 */
	2, /* 26 */
	2, /* 27 */
	1, /* 28 */
	0, /* 29 */
	2, /* 30 */
	2, /* 31 */
	2, /* 32 */
	1, /* 33 */
	2, /* 34 */
	2, /* 35 */
	-1, /* 36 */
	-1, /* 37 */
	-1, /* 38 */
	-1, /* 39 */
	2, /* 40 */
	1, /* 41 */
	1, /* 42 */
	1, /* 43 */
	1, /* 44 */
	1, /* 45 */
	1, /* 46 */
	1, /* 47 */
	1, /* 48 */
	1, /* 49 */
	1, /* 50 */
	1, /* 51 */
	1, /* 52 */
	1, /* 53 */
	1, /* 54 */
	2, /* 55 */
	2, /* 56 */
	1, /* 57 */
	1, /* 58 */
	1, /* 59 */
	2, /* 60 */
	0, /* 61 */
	-1, /* 62 */
	-1, /* 63 */
	-1, /* 64 */
	0, /* 65 */
	0, /* 66 */
	0, /* 67 */
	2, /* 68 */
	2, /* 69 */
	2, /* 70 */
	2, /* 71 */
	2, /* 72 */
	2, /* 73 */
	2, /* 74 */
	2, /* 75 */
	2
};
int PFtypecheck_max_op = 76;
int PFtypecheck_max_state = 74;
#define PFtypecheck_Max_state 74
char *PFtypecheck_string[] = {
	0,
	"Query: main(FunctionDecls, CoreExpr)",
	"Query: CoreExpr",
	"CoreExpr: Atom",
	"CoreExpr: SequenceTypeCast",
	"CoreExpr: flwr(OptBindExpr, WhereExpr)",
	"OptBindExpr: for_(forbind(forvars(var, nil), CoreExpr), OptBindExpr)",
	"OptBindExpr: for_(forbind(forvars(var, var), CoreExpr), OptBindExpr)",
	"OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr)",
	"OptBindExpr: nil",
	"WhereExpr: where(CoreExpr, WhereExpr)",
	"WhereExpr: orderby(OrderSpecs, CoreExpr)",
	"WhereExpr: CoreExpr",
	0,
	"CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr))",
	"CoreExpr: seq(CoreExpr, CoreExpr)",
	"CoreExpr: twig_seq(CoreExpr, CoreExpr)",
	"CoreExpr: typesw(CoreExpr, cases(case_(SequenceType, CoreExpr), default_(CoreExpr)))",
	"SequenceTypeCast: seqcast(SequenceType, CoreExpr)",
	"CoreExpr: proof(subty(CoreExpr, SequenceType), CoreExpr)",
	0,
	"SequenceType: seqtype",
	"SequenceType: stattype(CoreExpr)",
	0,
	0,
	"CoreExpr: LocationSteps",
	"LocationStep: ancestor(SequenceType)",
	"LocationStep: ancestor_or_self(SequenceType)",
	"LocationStep: attribute(SequenceType)",
	"LocationStep: child(SequenceType)",
	"LocationStep: descendant(SequenceType)",
	"LocationStep: descendant_or_self(SequenceType)",
	"LocationStep: following(SequenceType)",
	"LocationStep: following_sibling(SequenceType)",
	"LocationStep: parent(SequenceType)",
	"LocationStep: preceding(SequenceType)",
	"LocationStep: preceding_sibling(SequenceType)",
	"LocationStep: self(SequenceType)",
	"LocationStep: select_narrow(SequenceType)",
	"LocationStep: select_wide(SequenceType)",
	"LocationSteps: locsteps(LocationStep, LocationSteps)",
	"LocationSteps: locsteps(LocationStep, CoreExpr)",
	"CoreExpr: apply(FunctionArgs)",
	"FunctionArgs: nil",
	"FunctionArgs: arg(FunctionArg, FunctionArgs)",
	"FunctionArg: CoreExpr",
	"CoreExpr: elem(tag, CoreExpr)",
	"CoreExpr: elem(CoreExpr, CoreExpr)",
	"CoreExpr: attr(tag, CoreExpr)",
	"CoreExpr: attr(CoreExpr, CoreExpr)",
	"CoreExpr: text(CoreExpr)",
	"CoreExpr: doc(CoreExpr)",
	"CoreExpr: comment(CoreExpr)",
	"CoreExpr: pi(CoreExpr, CoreExpr)",
	"CoreExpr: pi(lit_str, CoreExpr)",
	0,
	0,
	0,
	0,
	0,
	"CoreExpr: ordered(CoreExpr)",
	"CoreExpr: unordered(CoreExpr)",
	0,
	"OrderSpecs: orderspecs(CoreExpr, nil)",
	"OrderSpecs: orderspecs(CoreExpr, OrderSpecs)",
	"CoreExpr: cast(SequenceType, CoreExpr)",
	"Atom: var",
	"Atom: LiteralValue",
	"LiteralValue: lit_str",
	"LiteralValue: lit_int",
	"LiteralValue: lit_dec",
	"LiteralValue: lit_dbl",
	"LiteralValue: true_",
	"LiteralValue: false_",
	"LiteralValue: empty",
	0,
	0,
	0,
	0,
	0,
	"FunctionDecls: nil",
	"FunctionDecls: fun_decls(FunctionDecl, FunctionDecls)",
	"FunctionDecl: fun_decl(ParamList, FunctionBody)",
	"ParamList: nil",
	"ParamList: params(FunParam, ParamList)",
	"FunctionBody: CoreExpr",
	"FunParam: param(SequenceType, var)",
	"CoreExpr: recursion(var, seed(CoreExpr, CoreExpr))",
	"CoreExpr: xrpc(CoreExpr, CoreExpr)",
};
int PFtypecheck_max_rule = 88;
#define PFtypecheck_Max_rule 88
short PFtypecheck_rule_descriptor_0[] = { 0, 0 };
short PFtypecheck_rule_descriptor_1[] = {   -1,   68,  -14,   -2, };
short PFtypecheck_rule_descriptor_2[] = {   -1,   -2, };
short PFtypecheck_rule_descriptor_3[] = {   -2,  -12, };
short PFtypecheck_rule_descriptor_4[] = {   -2,   -6, };
short PFtypecheck_rule_descriptor_5[] = {   -2,   14,   -3,   -4, };
short PFtypecheck_rule_descriptor_6[] = {   -3,   17,   18,   19,    1,    6,   -2,   -3, };
short PFtypecheck_rule_descriptor_7[] = {   -3,   17,   18,   19,    1,    1,   -2,   -3, };
short PFtypecheck_rule_descriptor_8[] = {   -3,   15,   16,    1,   -2,   -3, };
short PFtypecheck_rule_descriptor_9[] = {   -3,    6, };
short PFtypecheck_rule_descriptor_10[] = {   -4,   20,   -2,   -4, };
short PFtypecheck_rule_descriptor_11[] = {   -4,   21,   -5,   -2, };
short PFtypecheck_rule_descriptor_12[] = {   -4,   -2, };
short PFtypecheck_rule_descriptor_14[] = {   -2,   34,   -2,   35,   -2,   -2, };
short PFtypecheck_rule_descriptor_15[] = {   -2,    7,   -2,   -2, };
short PFtypecheck_rule_descriptor_16[] = {   -2,    8,   -2,   -2, };
short PFtypecheck_rule_descriptor_17[] = {   -2,   25,   -2,   26,   27,   -7,   -2,   28,   -2, };
short PFtypecheck_rule_descriptor_18[] = {   -6,   30,   -7,   -2, };
short PFtypecheck_rule_descriptor_19[] = {   -2,   31,   32,   -2,   -7,   -2, };
short PFtypecheck_rule_descriptor_21[] = {   -7,   29, };
short PFtypecheck_rule_descriptor_22[] = {   -7,   33,   -2, };
short PFtypecheck_rule_descriptor_25[] = {   -2,   -9, };
short PFtypecheck_rule_descriptor_26[] = {   -8,   41,   -7, };
short PFtypecheck_rule_descriptor_27[] = {   -8,   42,   -7, };
short PFtypecheck_rule_descriptor_28[] = {   -8,   43,   -7, };
short PFtypecheck_rule_descriptor_29[] = {   -8,   44,   -7, };
short PFtypecheck_rule_descriptor_30[] = {   -8,   45,   -7, };
short PFtypecheck_rule_descriptor_31[] = {   -8,   46,   -7, };
short PFtypecheck_rule_descriptor_32[] = {   -8,   47,   -7, };
short PFtypecheck_rule_descriptor_33[] = {   -8,   48,   -7, };
short PFtypecheck_rule_descriptor_34[] = {   -8,   49,   -7, };
short PFtypecheck_rule_descriptor_35[] = {   -8,   50,   -7, };
short PFtypecheck_rule_descriptor_36[] = {   -8,   51,   -7, };
short PFtypecheck_rule_descriptor_37[] = {   -8,   52,   -7, };
short PFtypecheck_rule_descriptor_38[] = {   -8,   53,   -7, };
short PFtypecheck_rule_descriptor_39[] = {   -8,   54,   -7, };
short PFtypecheck_rule_descriptor_40[] = {   -9,   40,   -8,   -9, };
short PFtypecheck_rule_descriptor_41[] = {   -9,   40,   -8,   -2, };
short PFtypecheck_rule_descriptor_42[] = {   -2,   23,  -10, };
short PFtypecheck_rule_descriptor_43[] = {  -10,    6, };
short PFtypecheck_rule_descriptor_44[] = {  -10,   24,  -11,  -10, };
short PFtypecheck_rule_descriptor_45[] = {  -11,   -2, };
short PFtypecheck_rule_descriptor_46[] = {   -2,   55,   61,   -2, };
short PFtypecheck_rule_descriptor_47[] = {   -2,   55,   -2,   -2, };
short PFtypecheck_rule_descriptor_48[] = {   -2,   56,   61,   -2, };
short PFtypecheck_rule_descriptor_49[] = {   -2,   56,   -2,   -2, };
short PFtypecheck_rule_descriptor_50[] = {   -2,   57,   -2, };
short PFtypecheck_rule_descriptor_51[] = {   -2,   58,   -2, };
short PFtypecheck_rule_descriptor_52[] = {   -2,   59,   -2, };
short PFtypecheck_rule_descriptor_53[] = {   -2,   60,   -2,   -2, };
short PFtypecheck_rule_descriptor_54[] = {   -2,   60,    2,   -2, };
short PFtypecheck_rule_descriptor_60[] = {   -2,    9,   -2, };
short PFtypecheck_rule_descriptor_61[] = {   -2,   10,   -2, };
short PFtypecheck_rule_descriptor_63[] = {   -5,   22,   -2,    6, };
short PFtypecheck_rule_descriptor_64[] = {   -5,   22,   -2,   -5, };
short PFtypecheck_rule_descriptor_65[] = {   -2,   73,   -7,   -2, };
short PFtypecheck_rule_descriptor_66[] = {  -12,    1, };
short PFtypecheck_rule_descriptor_67[] = {  -12,  -13, };
short PFtypecheck_rule_descriptor_68[] = {  -13,    2, };
short PFtypecheck_rule_descriptor_69[] = {  -13,    3, };
short PFtypecheck_rule_descriptor_70[] = {  -13,    4, };
short PFtypecheck_rule_descriptor_71[] = {  -13,    5, };
short PFtypecheck_rule_descriptor_72[] = {  -13,   65, };
short PFtypecheck_rule_descriptor_73[] = {  -13,   66, };
short PFtypecheck_rule_descriptor_74[] = {  -13,   67, };
short PFtypecheck_rule_descriptor_80[] = {  -14,    6, };
short PFtypecheck_rule_descriptor_81[] = {  -14,   69,  -15,  -14, };
short PFtypecheck_rule_descriptor_82[] = {  -15,   70,  -16,  -17, };
short PFtypecheck_rule_descriptor_83[] = {  -16,    6, };
short PFtypecheck_rule_descriptor_84[] = {  -16,   71,  -18,  -16, };
short PFtypecheck_rule_descriptor_85[] = {  -17,   -2, };
short PFtypecheck_rule_descriptor_86[] = {  -18,   72,   -7,    1, };
short PFtypecheck_rule_descriptor_87[] = {   -2,   74,    1,   75,   -2,   -2, };
short PFtypecheck_rule_descriptor_88[] = {   -2,   76,   -2,   -2, };
/* PFtypecheck_rule_descriptors[0][1] = 1 iff grammar is normal form. */
short * PFtypecheck_rule_descriptors[] = {
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_1,
	PFtypecheck_rule_descriptor_2,
	PFtypecheck_rule_descriptor_3,
	PFtypecheck_rule_descriptor_4,
	PFtypecheck_rule_descriptor_5,
	PFtypecheck_rule_descriptor_6,
	PFtypecheck_rule_descriptor_7,
	PFtypecheck_rule_descriptor_8,
	PFtypecheck_rule_descriptor_9,
	PFtypecheck_rule_descriptor_10,
	PFtypecheck_rule_descriptor_11,
	PFtypecheck_rule_descriptor_12,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_14,
	PFtypecheck_rule_descriptor_15,
	PFtypecheck_rule_descriptor_16,
	PFtypecheck_rule_descriptor_17,
	PFtypecheck_rule_descriptor_18,
	PFtypecheck_rule_descriptor_19,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_21,
	PFtypecheck_rule_descriptor_22,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_25,
	PFtypecheck_rule_descriptor_26,
	PFtypecheck_rule_descriptor_27,
	PFtypecheck_rule_descriptor_28,
	PFtypecheck_rule_descriptor_29,
	PFtypecheck_rule_descriptor_30,
	PFtypecheck_rule_descriptor_31,
	PFtypecheck_rule_descriptor_32,
	PFtypecheck_rule_descriptor_33,
	PFtypecheck_rule_descriptor_34,
	PFtypecheck_rule_descriptor_35,
	PFtypecheck_rule_descriptor_36,
	PFtypecheck_rule_descriptor_37,
	PFtypecheck_rule_descriptor_38,
	PFtypecheck_rule_descriptor_39,
	PFtypecheck_rule_descriptor_40,
	PFtypecheck_rule_descriptor_41,
	PFtypecheck_rule_descriptor_42,
	PFtypecheck_rule_descriptor_43,
	PFtypecheck_rule_descriptor_44,
	PFtypecheck_rule_descriptor_45,
	PFtypecheck_rule_descriptor_46,
	PFtypecheck_rule_descriptor_47,
	PFtypecheck_rule_descriptor_48,
	PFtypecheck_rule_descriptor_49,
	PFtypecheck_rule_descriptor_50,
	PFtypecheck_rule_descriptor_51,
	PFtypecheck_rule_descriptor_52,
	PFtypecheck_rule_descriptor_53,
	PFtypecheck_rule_descriptor_54,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_60,
	PFtypecheck_rule_descriptor_61,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_63,
	PFtypecheck_rule_descriptor_64,
	PFtypecheck_rule_descriptor_65,
	PFtypecheck_rule_descriptor_66,
	PFtypecheck_rule_descriptor_67,
	PFtypecheck_rule_descriptor_68,
	PFtypecheck_rule_descriptor_69,
	PFtypecheck_rule_descriptor_70,
	PFtypecheck_rule_descriptor_71,
	PFtypecheck_rule_descriptor_72,
	PFtypecheck_rule_descriptor_73,
	PFtypecheck_rule_descriptor_74,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_0,
	PFtypecheck_rule_descriptor_80,
	PFtypecheck_rule_descriptor_81,
	PFtypecheck_rule_descriptor_82,
	PFtypecheck_rule_descriptor_83,
	PFtypecheck_rule_descriptor_84,
	PFtypecheck_rule_descriptor_85,
	PFtypecheck_rule_descriptor_86,
	PFtypecheck_rule_descriptor_87,
	PFtypecheck_rule_descriptor_88,
};
short PFtypecheck_cost[][4] = {
	{    0,    0,    0,    0}, /* (none) = 0 */
	{   10,    0,    0,    0}, /* Query: main(FunctionDecls, CoreExpr) = 1 */
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   10,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{   10,    0,    0,    0}, /* CoreExpr: SequenceTypeCast = 4 */
	{   10,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 5 */
	{   10,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, nil), CoreExpr), OptBindExpr) = 6 */
	{   10,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, var), CoreExpr), OptBindExpr) = 7 */
	{   10,    0,    0,    0}, /* OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr) = 8 */
	{   10,    0,    0,    0}, /* OptBindExpr: nil = 9 */
	{   10,    0,    0,    0}, /* WhereExpr: where(CoreExpr, WhereExpr) = 10 */
	{   10,    0,    0,    0}, /* WhereExpr: orderby(OrderSpecs, CoreExpr) = 11 */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) = 13 */
	{   10,    0,    0,    0}, /* CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr)) = 14 */
	{   10,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, CoreExpr) = 15 */
	{   10,    0,    0,    0}, /* CoreExpr: twig_seq(CoreExpr, CoreExpr) = 16 */
	{   10,    0,    0,    0}, /* CoreExpr: typesw(CoreExpr, cases(case_(SequenceType, CoreExpr), default_(CoreExpr))) = 17 */
	{   10,    0,    0,    0}, /* SequenceTypeCast: seqcast(SequenceType, CoreExpr) = 18 */
	{   10,    0,    0,    0}, /* CoreExpr: proof(subty(CoreExpr, SequenceType), CoreExpr) = 19 */
	{    0,    0,    0,    0}, /* (none) = 20 */
	{   10,    0,    0,    0}, /* SequenceType: seqtype = 21 */
	{   10,    0,    0,    0}, /* SequenceType: stattype(CoreExpr) = 22 */
	{    0,    0,    0,    0}, /* (none) = 23 */
	{    0,    0,    0,    0}, /* (none) = 24 */
	{   10,    0,    0,    0}, /* CoreExpr: LocationSteps = 25 */
	{   10,    0,    0,    0}, /* LocationStep: ancestor(SequenceType) = 26 */
	{   10,    0,    0,    0}, /* LocationStep: ancestor_or_self(SequenceType) = 27 */
	{   10,    0,    0,    0}, /* LocationStep: attribute(SequenceType) = 28 */
	{   10,    0,    0,    0}, /* LocationStep: child(SequenceType) = 29 */
	{   10,    0,    0,    0}, /* LocationStep: descendant(SequenceType) = 30 */
	{   10,    0,    0,    0}, /* LocationStep: descendant_or_self(SequenceType) = 31 */
	{   10,    0,    0,    0}, /* LocationStep: following(SequenceType) = 32 */
	{   10,    0,    0,    0}, /* LocationStep: following_sibling(SequenceType) = 33 */
	{   10,    0,    0,    0}, /* LocationStep: parent(SequenceType) = 34 */
	{   10,    0,    0,    0}, /* LocationStep: preceding(SequenceType) = 35 */
	{   10,    0,    0,    0}, /* LocationStep: preceding_sibling(SequenceType) = 36 */
	{   10,    0,    0,    0}, /* LocationStep: self(SequenceType) = 37 */
	{   10,    0,    0,    0}, /* LocationStep: select_narrow(SequenceType) = 38 */
	{   10,    0,    0,    0}, /* LocationStep: select_wide(SequenceType) = 39 */
	{   10,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, LocationSteps) = 40 */
	{   10,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, CoreExpr) = 41 */
	{   10,    0,    0,    0}, /* CoreExpr: apply(FunctionArgs) = 42 */
	{   10,    0,    0,    0}, /* FunctionArgs: nil = 43 */
	{   10,    0,    0,    0}, /* FunctionArgs: arg(FunctionArg, FunctionArgs) = 44 */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{   10,    0,    0,    0}, /* CoreExpr: elem(tag, CoreExpr) = 46 */
	{   10,    0,    0,    0}, /* CoreExpr: elem(CoreExpr, CoreExpr) = 47 */
	{   10,    0,    0,    0}, /* CoreExpr: attr(tag, CoreExpr) = 48 */
	{   10,    0,    0,    0}, /* CoreExpr: attr(CoreExpr, CoreExpr) = 49 */
	{   10,    0,    0,    0}, /* CoreExpr: text(CoreExpr) = 50 */
	{   10,    0,    0,    0}, /* CoreExpr: doc(CoreExpr) = 51 */
	{   10,    0,    0,    0}, /* CoreExpr: comment(CoreExpr) = 52 */
	{   10,    0,    0,    0}, /* CoreExpr: pi(CoreExpr, CoreExpr) = 53 */
	{   10,    0,    0,    0}, /* CoreExpr: pi(lit_str, CoreExpr) = 54 */
	{    0,    0,    0,    0}, /* (none) = 55 */
	{    0,    0,    0,    0}, /* (none) = 56 */
	{    0,    0,    0,    0}, /* (none) = 57 */
	{    0,    0,    0,    0}, /* (none) = 58 */
	{    0,    0,    0,    0}, /* (none) = 59 */
	{   10,    0,    0,    0}, /* CoreExpr: ordered(CoreExpr) = 60 */
	{   10,    0,    0,    0}, /* CoreExpr: unordered(CoreExpr) = 61 */
	{    0,    0,    0,    0}, /* (none) = 62 */
	{   10,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, nil) = 63 */
	{   10,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, OrderSpecs) = 64 */
	{   10,    0,    0,    0}, /* CoreExpr: cast(SequenceType, CoreExpr) = 65 */
	{   10,    0,    0,    0}, /* Atom: var = 66 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 67 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_str = 68 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_int = 69 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_dec = 70 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_dbl = 71 */
	{   10,    0,    0,    0}, /* LiteralValue: true_ = 72 */
	{   10,    0,    0,    0}, /* LiteralValue: false_ = 73 */
	{   10,    0,    0,    0}, /* LiteralValue: empty = 74 */
	{    0,    0,    0,    0}, /* (none) = 75 */
	{    0,    0,    0,    0}, /* (none) = 76 */
	{    0,    0,    0,    0}, /* (none) = 77 */
	{    0,    0,    0,    0}, /* (none) = 78 */
	{    0,    0,    0,    0}, /* (none) = 79 */
	{   10,    0,    0,    0}, /* FunctionDecls: nil = 80 */
	{   10,    0,    0,    0}, /* FunctionDecls: fun_decls(FunctionDecl, FunctionDecls) = 81 */
	{   10,    0,    0,    0}, /* FunctionDecl: fun_decl(ParamList, FunctionBody) = 82 */
	{   10,    0,    0,    0}, /* ParamList: nil = 83 */
	{   10,    0,    0,    0}, /* ParamList: params(FunParam, ParamList) = 84 */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{   10,    0,    0,    0}, /* FunParam: param(SequenceType, var) = 86 */
	{   10,    0,    0,    0}, /* CoreExpr: recursion(var, seed(CoreExpr, CoreExpr)) = 87 */
	{   10,    0,    0,    0}, /* CoreExpr: xrpc(CoreExpr, CoreExpr) = 88 */
};

short PFtypecheck_delta_cost[75][19][4] = {
{{0}}, /* state 0 */
{ /* state #1: ancestor(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: ancestor(SequenceType) = 26 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #2: ancestor_or_self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: ancestor_or_self(SequenceType) = 27 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #3: apply(nil) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: apply(FunctionArgs) = 42 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #4: arg(empty, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionArgs: arg(FunctionArg, FunctionArgs) = 44 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #5: attr(empty, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: attr(CoreExpr, CoreExpr) = 49 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #6: attr(tag, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: attr(tag, CoreExpr) = 48 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #7: attribute(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: attribute(SequenceType) = 28 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #8: case_(seqtype, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #9: cases(case_(seqtype, empty), default_(empty)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #10: cast(seqtype, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: cast(SequenceType, CoreExpr) = 65 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #11: child(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: child(SequenceType) = 29 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #12: comment(empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: comment(CoreExpr) = 52 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #13: default_(empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #14: descendant(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: descendant(SequenceType) = 30 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #15: descendant_or_self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: descendant_or_self(SequenceType) = 31 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #16: doc(empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: doc(CoreExpr) = 51 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #17: elem(tag, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: elem(tag, CoreExpr) = 46 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #18: elem(empty, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: elem(CoreExpr, CoreExpr) = 47 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #19: empty */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 67 */
	{    0,    0,    0,    0}, /* LiteralValue: empty = 74 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #20: false_ */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 67 */
	{    0,    0,    0,    0}, /* LiteralValue: false_ = 73 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #21: flwr(nil, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: flwr(OptBindExpr, WhereExpr) = 5 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #22: following(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: following(SequenceType) = 32 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #23: following_sibling(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: following_sibling(SequenceType) = 33 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #24: for_(forbind(forvars(var, nil), empty), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, nil), CoreExpr), OptBindExpr) = 6 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #25: for_(forbind(forvars(var, var), empty), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: for_(forbind(forvars(var, var), CoreExpr), OptBindExpr) = 7 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #26: forbind(forvars(var, var), empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #27: forbind(forvars(var, nil), empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #28: forvars(var, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #29: forvars(var, var) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #30: fun_decl(nil, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionDecl: fun_decl(ParamList, FunctionBody) = 82 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #31: fun_decls(fun_decl(nil, empty), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunctionDecls: fun_decls(FunctionDecl, FunctionDecls) = 81 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #32: if_(empty, then_else(empty, empty)) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: if_(CoreExpr, then_else(CoreExpr, CoreExpr)) = 14 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #33: let(letbind(var, empty), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OptBindExpr: let(letbind(var, CoreExpr), OptBindExpr) = 8 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #34: letbind(var, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #35: lit_dbl */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 67 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_dbl = 71 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #36: lit_dec */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 67 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_dec = 70 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #37: lit_int */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 67 */
	{    0,    0,    0,    0}, /* LiteralValue: lit_int = 69 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #38: lit_str */
	{0},
	{   40,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   30,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{   20,    0,    0,    0}, /* Atom: LiteralValue = 67 */
	{   10,    0,    0,    0}, /* LiteralValue: lit_str = 68 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   40,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #39: locsteps(ancestor(seqtype), locsteps(ancestor(seqtype), empty)) */
	{0},
	{   20,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   10,    0,    0,    0}, /* CoreExpr: LocationSteps = 25 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, LocationSteps) = 40 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #40: locsteps(ancestor(seqtype), empty) */
	{0},
	{   20,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   10,    0,    0,    0}, /* CoreExpr: LocationSteps = 25 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationSteps: locsteps(LocationStep, CoreExpr) = 41 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #41: main(nil, empty) */
	{0},
	{    0,    0,    0,    0}, /* Query: main(FunctionDecls, CoreExpr) = 1 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #42: nil */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* OptBindExpr: nil = 9 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArgs: nil = 43 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionDecls: nil = 80 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* ParamList: nil = 83 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #43: orderby(orderspecs(empty, nil), empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* WhereExpr: orderby(OrderSpecs, CoreExpr) = 11 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #44: ordered(empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: ordered(CoreExpr) = 60 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #45: orderspecs(empty, orderspecs(empty, nil)) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, OrderSpecs) = 64 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #46: orderspecs(empty, nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* OrderSpecs: orderspecs(CoreExpr, nil) = 63 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #47: param(seqtype, var) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* FunParam: param(SequenceType, var) = 86 */
},
{ /* state #48: params(param(seqtype, var), nil) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* ParamList: params(FunParam, ParamList) = 84 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #49: parent(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: parent(SequenceType) = 34 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #50: pi(empty, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: pi(CoreExpr, CoreExpr) = 53 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #51: pi(lit_str, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: pi(lit_str, CoreExpr) = 54 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #52: preceding(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: preceding(SequenceType) = 35 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #53: preceding_sibling(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: preceding_sibling(SequenceType) = 36 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #54: proof(subty(empty, seqtype), empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: proof(subty(CoreExpr, SequenceType), CoreExpr) = 19 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #55: recursion(var, seed(empty, empty)) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: recursion(var, seed(CoreExpr, CoreExpr)) = 87 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #56: seed(empty, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #57: select_narrow(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: select_narrow(SequenceType) = 38 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #58: select_wide(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: select_wide(SequenceType) = 39 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #59: self(seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* LocationStep: self(SequenceType) = 37 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #60: seq(empty, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: seq(CoreExpr, CoreExpr) = 15 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #61: seqcast(seqtype, empty) */
	{0},
	{   20,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   10,    0,    0,    0}, /* CoreExpr: SequenceTypeCast = 4 */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SequenceTypeCast: seqcast(SequenceType, CoreExpr) = 18 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   20,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #62: seqtype */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SequenceType: seqtype = 21 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #63: stattype(empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* SequenceType: stattype(CoreExpr) = 22 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #64: subty(empty, seqtype) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #65: tag */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #66: text(empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: text(CoreExpr) = 50 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #67: then_else(empty, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #68: true_ */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{   10,    0,    0,    0}, /* Atom: LiteralValue = 67 */
	{    0,    0,    0,    0}, /* LiteralValue: true_ = 72 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #69: twig_seq(empty, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: twig_seq(CoreExpr, CoreExpr) = 16 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #70: typesw(empty, cases(case_(seqtype, empty), default_(empty))) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: typesw(CoreExpr, cases(case_(SequenceType, CoreExpr), default_(CoreExpr))) = 17 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #71: unordered(empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: unordered(CoreExpr) = 61 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #72: var */
	{0},
	{   30,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{   20,    0,    0,    0}, /* CoreExpr: Atom = 3 */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{   10,    0,    0,    0}, /* Atom: var = 66 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   30,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #73: where(empty, empty) */
	{0},
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* WhereExpr: where(CoreExpr, WhereExpr) = 10 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
},
{ /* state #74: xrpc(empty, empty) */
	{0},
	{   10,    0,    0,    0}, /* Query: CoreExpr = 2 */
	{    0,    0,    0,    0}, /* CoreExpr: xrpc(CoreExpr, CoreExpr) = 88 */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* WhereExpr: CoreExpr = 12 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionArg: CoreExpr = 45 */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{    0,    0,    0,    0}, /* (none) */
	{   10,    0,    0,    0}, /* FunctionBody: CoreExpr = 85 */
	{    0,    0,    0,    0}, /* (none) */
},
};

char * PFtypecheck_state_string[] = {
" not a state", /* state 0 */
	"ancestor(seqtype)", /* state #1 */
	"ancestor_or_self(seqtype)", /* state #2 */
	"apply(nil)", /* state #3 */
	"arg(empty, nil)", /* state #4 */
	"attr(empty, empty)", /* state #5 */
	"attr(tag, empty)", /* state #6 */
	"attribute(seqtype)", /* state #7 */
	"case_(seqtype, empty)", /* state #8 */
	"cases(case_(seqtype, empty), default_(empty))", /* state #9 */
	"cast(seqtype, empty)", /* state #10 */
	"child(seqtype)", /* state #11 */
	"comment(empty)", /* state #12 */
	"default_(empty)", /* state #13 */
	"descendant(seqtype)", /* state #14 */
	"descendant_or_self(seqtype)", /* state #15 */
	"doc(empty)", /* state #16 */
	"elem(tag, empty)", /* state #17 */
	"elem(empty, empty)", /* state #18 */
	"empty", /* state #19 */
	"false_", /* state #20 */
	"flwr(nil, empty)", /* state #21 */
	"following(seqtype)", /* state #22 */
	"following_sibling(seqtype)", /* state #23 */
	"for_(forbind(forvars(var, nil), empty), nil)", /* state #24 */
	"for_(forbind(forvars(var, var), empty), nil)", /* state #25 */
	"forbind(forvars(var, var), empty)", /* state #26 */
	"forbind(forvars(var, nil), empty)", /* state #27 */
	"forvars(var, nil)", /* state #28 */
	"forvars(var, var)", /* state #29 */
	"fun_decl(nil, empty)", /* state #30 */
	"fun_decls(fun_decl(nil, empty), nil)", /* state #31 */
	"if_(empty, then_else(empty, empty))", /* state #32 */
	"let(letbind(var, empty), nil)", /* state #33 */
	"letbind(var, empty)", /* state #34 */
	"lit_dbl", /* state #35 */
	"lit_dec", /* state #36 */
	"lit_int", /* state #37 */
	"lit_str", /* state #38 */
	"locsteps(ancestor(seqtype), locsteps(ancestor(seqtype), empty))", /* state #39 */
	"locsteps(ancestor(seqtype), empty)", /* state #40 */
	"main(nil, empty)", /* state #41 */
	"nil", /* state #42 */
	"orderby(orderspecs(empty, nil), empty)", /* state #43 */
	"ordered(empty)", /* state #44 */
	"orderspecs(empty, orderspecs(empty, nil))", /* state #45 */
	"orderspecs(empty, nil)", /* state #46 */
	"param(seqtype, var)", /* state #47 */
	"params(param(seqtype, var), nil)", /* state #48 */
	"parent(seqtype)", /* state #49 */
	"pi(empty, empty)", /* state #50 */
	"pi(lit_str, empty)", /* state #51 */
	"preceding(seqtype)", /* state #52 */
	"preceding_sibling(seqtype)", /* state #53 */
	"proof(subty(empty, seqtype), empty)", /* state #54 */
	"recursion(var, seed(empty, empty))", /* state #55 */
	"seed(empty, empty)", /* state #56 */
	"select_narrow(seqtype)", /* state #57 */
	"select_wide(seqtype)", /* state #58 */
	"self(seqtype)", /* state #59 */
	"seq(empty, empty)", /* state #60 */
	"seqcast(seqtype, empty)", /* state #61 */
	"seqtype", /* state #62 */
	"stattype(empty)", /* state #63 */
	"subty(empty, seqtype)", /* state #64 */
	"tag", /* state #65 */
	"text(empty)", /* state #66 */
	"then_else(empty, empty)", /* state #67 */
	"true_", /* state #68 */
	"twig_seq(empty, empty)", /* state #69 */
	"typesw(empty, cases(case_(seqtype, empty), default_(empty)))", /* state #70 */
	"unordered(empty)", /* state #71 */
	"var", /* state #72 */
	"where(empty, empty)", /* state #73 */
	"xrpc(empty, empty)", /* state #74 */
};
char *PFtypecheck_ntname[] = {
	"Error: Nonterminals are > 0",
	"Query",
	"CoreExpr",
	"OptBindExpr",
	"WhereExpr",
	"OrderSpecs",
	"SequenceTypeCast",
	"SequenceType",
	"LocationStep",
	"LocationSteps",
	"FunctionArgs",
	"FunctionArg",
	"Atom",
	"LiteralValue",
	"FunctionDecls",
	"FunctionDecl",
	"ParamList",
	"FunctionBody",
	"FunParam",
	0
};

short PFtypecheck_closure[19][19] = {
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    2,    0,    0,    0,    2,    0,    0,    2,
	     0,    0,    2,    2,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    4,    0,    0,   25,
	     0,    0,    3,    3,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,   12,    0,    0,    0,   12,    0,    0,   12,
	     0,    0,   12,   12,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,   45,    0,    0,    0,   45,    0,    0,   45,
	     0,    0,   45,   45,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,   67,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
	{    0,    0,   85,    0,    0,    0,   85,    0,    0,   85,
	     0,    0,   85,   85,    0,    0,    0,    0,    0,},
	{    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
	     0,    0,    0,    0,    0,    0,    0,    0,    0,},
};
#line 305 "typecheck.brg"


/** Type of a core tree node */
#define TY(p) ((p)->type)

/** Maximum number of pattern leaves */
#define MAX_KIDS 10

/** mnemonic XQuery Core constructors */
#include "core_mnemonic.h"

static PFfun_t * overload (PFqname_t qn, PFcnode_t *args);
static PFty_t specific (PFfun_t *fn, PFcnode_t *args);

/**
 * Reducer function. This is the heart of this source file. It
 * contains all the action code for the above burg patterns.
 */
static void
do_reduce (PFcnode_t * p, int rule, short *nts, PFcnode_t *kids[]);

static void
reduce (PFcnode_t * p, int goalnt)
{
    int           rule;           /* rule number that matches for this node */
    short        *nts;            /* target non-terminals for the leaf nodes of
                                     the current rule */
    PFcnode_t    *kids[MAX_KIDS]; /* leaf nodes of this rule */

    /* guard against too dep recursion */
    PFrecursion_fence();

    /* determine rule that matches for this non-terminal */
    rule = PFtypecheck_rule (STATE_LABEL (p), goalnt);
    assert (rule);

    /* PFinfo (OOPS_NOTICE, "match for rule %i", rule); */

    /* initialize the kids[] vector */
    for (unsigned short i = 0; i < MAX_KIDS; i++)
        kids[i] = NULL;

    /*
     * prepare recursive traversal: get information on leaf nodes of
     * this rule
     */
    nts = PFtypecheck_nts[rule];
    PFtypecheck_kids (p, rule, kids);

    /* PFinfo (OOPS_NOTICE, "in rule %u", rule); */

    /* evaluate top-down in a number of cases */
    switch (rule) {
        /* Query:              main (FunctionDecls, CoreExpr) */
        case 1:
        /* OptBindExpr:        for_ (forbind (forvars (var, nil),
                                              CoreExpr),
                                     OptBindExpr) */
        case 6:

        /* OptBindExpr:        for_ (forbind (forvars (var, var),
                                              CoreExpr),
                                     OptBindExpr) */
        case 7:

        /* OptBindExpr:        let (letbind (var, CoreExpr), OptBindExpr) */
        case 8:

        /* CoreExpr:           recursion (var, seed (CoreExpr, CoreExpr)) */
        case 87:

            break;

        default:
            /*
             * Recursively invoke compilation.
             * This means bottom-up compilation.
             */
            for (unsigned short i = 0; nts[i]; i++)
                reduce (kids[i], nts[i]);
    }

    do_reduce (p, rule, nts, kids);
}

static void
do_reduce (PFcnode_t * p, int rule, short *nts, PFcnode_t *kids[])
{
    /* guard against too dep recursion */
    PFrecursion_fence();

    switch (rule) {

        /* Query:              main (FunctionDecls, CoreExpr) */
        case 1:
            /* TOPDOWN */

            /*
             * Type-check query body before any user-defined function.
             * This way we type all global variables (they have been
             * replaced by `let ...' clauses around the query body),
             * before we type any function body. (Note that function
             * bodies may refer global variables.)
             */
            reduce (kids[1], nts[1]);
            reduce (kids[0], nts[0]);

            if (PFty_subtype (TY(R(p)), PFty_plus (PFty_none ())))
                /*
                 * Not really okay, but we let it go through with
                 * a warning: the query *statically* evaluated to
                 * the error type (none).
                 *
                 * NOTE: `none' is a subtype of all other types (but
                 *       nothing is a subtype of `none').  Hence,
                 *       do this check before any other check.
                 */
                PFinfo (OOPS_WARNING, "query will always return an error");
            else if (PFty_subtype (TY(R(p)), PFty_star (PFty_item ())))
                /* okay, this is a normal query */
                ;
            else if (PFty_subtype (TY(R(p)), PFty_star (PFty_stmt ())))
                /* okay, this is an update query */
                ;
            else if (PFty_subtype (TY(R(p)), PFty_star (PFty_docmgmt ())))
                /* okay, this is a document management query */
                ;
            else
                PFoops (OOPS_TYPECHECK,
                        "illegal combination of query and update features "
                        "(result type is `%s')", PFty_str (TY(R(p))));

            break;

        /* Query:              CoreExpr */
        case 2:
            break;

        /* CoreExpr:           Atom */
        case 3:
            break;

        /* CoreExpr:           SequenceTypeCast */
        case 4:
            break;

        /* CoreExpr:           flwr (OptBindExpr, WhereExpr) */
        case 5:
            TY(p) = *PFty_simplify (L(p)->sem.flwr.quantifier (TY(R(p))));
            break;

        /* OptBindExpr:        for_ (forbind (forvars (var, nil),
                                              CoreExpr),
                                     OptBindExpr) */
        case 6:
        {   /* TOPDOWN */

            /* W3C XQuery, 5.8.2
             *
             *   E |- CoreExpr : t1   E[Var : prime (t1)] |- CoreExpr : t2
             * -------------------------------------------------------------
             * for_ (Var, nil, CoreExpr, OptBindExpr) : t2 . quantifier (t1)
             */
            PFty_t t1;

            /* nil : none */
            TY(LLR(p)) = PFty_none ();

            /* E |- CoreExpr : t1 */
            reduce (kids[0], nts[0]);
            t1 = TY(LR(p));

            /*
             * The specs prohibit the (statically typed) empty sequence
             * in many places.  (see XQuery FS, beginning of Section 4)
             */
            if (PFty_subtype (t1, PFty_empty ()))
                PFoops (OOPS_TYPECHECK,
                        "binding sequence in a for clause has static "
                        "type `empty'");

            /*
             * XQuery Update Facility disallows updates in the `for'
             * part.
             */
            if (!PFty_disjoint (PFty_stmt (),
                                PFty_prime (PFty_defn (t1))))
                PFoops (OOPS_TYPECHECK,
                        "err:XUST0101: binding sequence may not contain "
                        "an updating expression (has type `%s')",
                        PFty_str (t1));

            /* sanity check */
            if (!PFty_subtype (t1, PFty_star (PFty_item ())))
                PFoops (OOPS_TYPECHECK,
                        "illegal binding in for clause, cannot iterate over "
                        "type `%s'",
                        PFty_str (t1));

            /* Var : prime (t1) */
            TY(LLL(p)) = *PFty_simplify (PFty_prime (PFty_defn (t1)));

            /* Var1 should now have a sensible type (not `none') */
            assert (PFty_subtype (TY(LLL(p)), PFty_star (PFty_item ())));

            /* E[Var : prime (t1)] |- CoreExpr : t2 */
            assert (LLL(p)->sem.var);
            TY( LLL(p)->sem.var ) = TY(LLL(p));
            reduce (kids[1], nts[1]);

            p->sem.flwr.quantifier = PFty_quantifier 
                                     (R(p)->sem.flwr.quantifier (
                                          PFty_defn (t1)));

        } break;

        /* OptBindExpr:        for_ (forbind (forvars (var, var),
                                              CoreExpr),
                                     OptBindExpr) */
        case 7:
        {   /* TOPDOWN */

            /* W3C XQuery, 5.8.2
             *
             *                    E |- CoreExpr : t1
             *  E[Var1:prime (t1), Var2:xs:integer] |- OptBindExpr : t2
             * --------------------------------------------------------------
             *  for_ (Var1, Var2, CoreExpr, CoreExpr) : t2 . quantifier (t1)
             */
            PFty_t t1;

            /* E |- CoreExpr : t1 */
            reduce (kids[0], nts[0]);
            t1 = TY(LR(p));

            /*
             * The specs prohibit the (statically typed) empty sequence
             * in many places.  (see XQuery FS, beginning of Section 4)
             */
            if (PFty_subtype (t1, PFty_empty ()))
                PFoops (OOPS_TYPECHECK,
                        "binding sequence in a for clause has static "
                        "type `empty'");

            /*
             * XQuery Update Facility disallows updates in the `for'
             * part.
             */
            if (!PFty_disjoint (PFty_stmt (),
                                PFty_prime (PFty_defn (t1))))
                PFoops (OOPS_TYPECHECK,
                        "err:XUST0101: binding sequence may not contain "
                        "an updating expression (has type `%s')",
                        PFty_str (t1));

            /* sanity check */
            if (!PFty_subtype (t1, PFty_star (PFty_item ())))
                PFoops (OOPS_TYPECHECK,
                        "illegal binding in for clause, cannot iterate over "
                        "type `%s'",
                        PFty_str (t1));

            /* Var2 : xs:integer */
            TY(LLR(p)) = PFty_xs_integer ();
            assert (LLR(p)->sem.var);
            TY( LLR(p)->sem.var ) = TY(LLR(p));

            /* Var1 : prime (t1) */
            TY(LLL(p)) = *PFty_simplify (PFty_prime (PFty_defn (t1)));

            /* Var1 should now have a sensible type (not `none') */
            assert (PFty_subtype (TY(LLL(p)), PFty_star (PFty_item ())));

            /* E[Var1 : prime (t1), Var2 : xs:integer] |- CoreExpr : t2 */
            assert (LLL(p)->sem.var);
            TY( LLL(p)->sem.var ) = TY(LLL(p));
            reduce (kids[1], nts[1]);

            p->sem.flwr.quantifier = PFty_quantifier 
                               (R(p)->sem.flwr.quantifier (PFty_defn (t1)));

        } break;

        /* OptBindExpr:        let (letbind (var, CoreExpr), OptBindExpr) */
        case 8:
        {   /* TOPDOWN */

            /* W3C XQuery, 5.8.3
             *
             * E |- CoreExpr1 : t1   E[Var : t1] |- CoreExpr2 : t2
             * ----------------------------------------------------
             *      E |- let (Var, CoreExpr1, CoreExpr2) : t2
             */
            PFty_t t1;

            /* E |- CoreExpr1 : t1 */
            reduce (kids[0], nts[0]);
            t1 = TY(LR(p));
            TY(LL(p)) = t1;

            /*
             * NOTE:
             *   The XQuery Update Facility disallows updating
             *   expressions in the `let' part of a FLWOR clause.
             *   However, our compilation into XQuery Core has
             *   introduced lots of `let' clauses, such that any
             *   update expression would fail if we really enforce
             *   this semantics.
             */

            /* E[Var : t1] |- CoreExpr : t2 */
            assert (LL(p)->sem.var);
            TY( LL(p)->sem.var ) = t1;
            reduce (kids[1], nts[1]);

            p->sem.flwr.quantifier = R(p)->sem.flwr.quantifier;
        } break;

        /* OptBindExpr:        nil */
        case 9:
            p->sem.flwr.quantifier = PFty_one;
            break;

        /* WhereExpr:          where (CoreExpr, WhereExpr) */
        case 10:
        /* WhereExpr:          orderby (OrderSpecs, CoreExpr) */
        case 11:
            TY(p) = TY(R(p));
            break;

        /* WhereExpr:          CoreExpr */
        case 12:
            break;

        /* OrderSpecs:         orderspecs (CoreExpr, nil) */
        case 63:
        /* OrderSpecs:         orderspecs (CoreExpr, OrderSpecs) */
        case 64:
            /*
             * XQuery Update Facility disallows updates in `order by'
             * clauses.
             */
            if (!PFty_disjoint (PFty_stmt (),
                                PFty_prime (PFty_defn (TY(L(p))))))
                PFoops (OOPS_TYPECHECK,
                        "err:XUST0101: `order by' may not contain "
                        "an updating expression (has type `%s')",
                        PFty_str (TY(L(p))));

            if (!PFty_subtype (TY(L(p)), PFty_opt (PFty_atomic ())))
                PFoops (OOPS_TYPECHECK,
                        "[err:XPTY0004]"
                        " Orderspec requires at most one atomic item "
                        "(given: %s).", PFty_str (TY(L(p))));

            if (!PFty_subtype (TY(L(p)), PFty_opt (PFty_xs_string ())) &&
                !PFty_subtype (TY(L(p)), PFty_opt (PFty_xs_decimal ())) &&
                !PFty_subtype (TY(L(p)), PFty_opt (PFty_xs_double ())) &&
                !PFty_subtype (TY(L(p)), PFty_opt (PFty_xs_datetime ())) &&
                !PFty_subtype (TY(L(p)), PFty_opt (PFty_xs_date ())) &&
                !PFty_subtype (TY(L(p)), PFty_opt (PFty_xs_time ())) &&
                !PFty_subtype (TY(L(p)),
                            PFty_opt (PFty_xs_yearmonthduration ())) &&
                !PFty_subtype (TY(L(p)),
                            PFty_opt (PFty_xs_daytimeduration ()))
               )
                PFoops (OOPS_TYPECHECK,
                        "[err:XPTY0004]"
                        " Orderspec requires an type whose order can be "
                        "decided using 'gt' (given: %s).", PFty_str (TY(L(p))));
            break;

        /* CoreExpr:           if_ (CoreExpr, then_else (CoreExpr, CoreExpr)) */
        case 14:
            /* W3C XQuery, 5.10
             *
             * E |- CoreExpr1:boolean  E |- CoreExpr2:t1  E |- CoreExpr3:t2
             * ------------------------------------------------------------
             *  E |- ifthenelse (CoreExpr1, CoreExp2, CoreExpr3) : t1 | t2
             */
            if (PFty_eq (PFty_defn (TY(L(p))), PFty_xs_boolean ()))
                TY(p) = *PFty_simplify (PFty_choice (TY(RL(p)), TY(RR(p))));
            else
                PFoops (OOPS_TYPECHECK,
                        "if-then-else condition of type %s (expected %s)",
                        PFty_str (TY(L(p))), PFty_str (PFty_xs_boolean ()));

            /*
             * no mixture of updates and expressions
             */
            if (!PFty_disjoint (PFty_stmt (),
                                PFty_prime (PFty_defn (TY(p))))
                && !PFty_disjoint (PFty_item (),
                                   PFty_prime (PFty_defn (TY(p)))))
                PFoops (OOPS_TYPECHECK,
                        "err:XUST0101: illegal mix of updating and "
                        "non-updating expressions (got type `%s')",
                        PFty_str (TY(p)));

            break;

        /* CoreExpr:           seq (CoreExpr, CoreExpr) */
        case 15:
        /* CoreExpr:           twig_seq (CoreExpr, CoreExpr) */
        case 16:
            /* W3C XQuery, 5.3.1
             * 
             * E |- CoreExpr1 : t1    E |- CoreExpr2 : t2
             * ------------------------------------------
             *  E |- seq (CoreExpr1, CoreExpr2) : t1, t2
             */
            TY(p) = *PFty_simplify (PFty_seq (TY(L(p)), TY(R(p))));

            /*
             * no mixture of updates and expressions
             */
            if (!PFty_disjoint (PFty_stmt (),
                                PFty_prime (PFty_defn (TY(p))))
                && !PFty_disjoint (PFty_item (),
                                   PFty_prime (PFty_defn (TY(p)))))
                PFoops (OOPS_TYPECHECK,
                        "err:XUST0101: illegal mix of updating and "
                        "non-updating expressions (got type `%s')",
                        PFty_str (TY(p)));

            break;

        /* CoreExpr:           typesw (CoreExpr,
                                       cases (case_ (SequenceType,
                                                     CoreExpr),
                                              default_ (CoreExpr))) */
        case 17:
        {   /* W3C XQuery, 5.12.2
             *
             *                   E |- CoreExpr:t1  E |- SequenceType:t2  
             *           E |- CoreExpr1:t3    E |- CoreExpr2:t4    t1 <: t2
             * ---------------------------------------------------------------
             *  E |- typeswitch (CoreExpr, cases (
             *                                 case_ (SequenceType, CoreExpr1),
             *                                 default (CoreExpr2))) : t3
             *
             *                   E |- CoreExpr:t1  E |- SequenceType:t2  
             *           E |- CoreExpr1:t3    E |- CoreExpr2:t4    t1 || t2
             * ---------------------------------------------------------------
             *  E |- typeswitch (CoreExpr, cases (
             *                                 case_ (SequenceType, CoreExpr1),
             *                                 default (CoreExpr2))) : t4
             *
             *                   E |- CoreExpr:t1  E |- SequenceType:t2  
             *                 E |- CoreExpr1:t3    E |- CoreExpr2:t4  
             * ---------------------------------------------------------------
             *  E |- typeswitch (CoreExpr, cases (
             *                                 case_ (SequenceType, CoreExpr1),
             *                                 default (CoreExpr2))) : t3 | t4
             */
            PFty_t t1, t2;

            t1 = TY(L(p));
            t2 = TY(RLL(p));

            /*
             * XQuery Update Facility disallows updates in the
             * operand expression of a typeswitch.
             */
            if (!PFty_disjoint (PFty_stmt (),
                                PFty_prime (PFty_defn (t1))))
                PFoops (OOPS_TYPECHECK,
                        "err:XUST0101: operand in `typeswitch' may not contain "
                        "an updating expression (has type `%s')",
                        PFty_str (t1));

            if (PFty_subtype (t1, t2))
                TY(p) = TY(RLR(p));
            else if (PFty_disjoint (t1, t2))
                TY(p) = TY(RRL(p));
            else
                TY(p) = *PFty_simplify (PFty_choice (TY(RLR(p)), TY(RRL(p))));

            /*
             * no mixture of updates and expressions
             */
            if (!PFty_disjoint (PFty_stmt (),
                                PFty_prime (PFty_defn (TY(p))))
                && !PFty_disjoint (PFty_item (),
                                   PFty_prime (PFty_defn (TY(p)))))
                PFoops (OOPS_TYPECHECK,
                        "err:XUST0101: illegal mix of updating and "
                        "non-updating expressions (got type `%s')",
                        PFty_str (t1));

        } break;

        /* SequenceTypeCast:   seqcast (SequenceType, CoreExpr) */
        case 18:
            TY(p) = TY(L(p));
            break;

        /* CoreExpr:           proof (subty (CoreExpr, SequenceType),
                                      CoreExpr) */
        case 19:
            /*
             *    E |- CoreExpr1 : t1   E |- SequenceType : t2
             *                      t1 <: t2
             *                 E |- CoreExpr2 : t3
             * ----------------------------------------------------
             * E |- proof (CoreExpr1, SequenceType, CoreExpr2) : t3
             */

            /* perform the <: proof */
            if (! (PFty_subtype (TY(LL(p)), TY(LR(p)))))
                PFoops (OOPS_TYPECHECK,
                        "%s is not a subtype of %s",
                        PFty_str (TY(LL(p))),
                        PFty_str (TY(LR(p))));

            /* remove the successful proof and simply return the guarded
             * expression 
             */
            *p = *R(p);
            break;

        /* SequenceType:       seqtype */
        case 21:
            TY(p) = p->sem.type;
            break;

        /* SequenceType:       stattype (CoreExpr) */
        case 22:
        {   /*
             * We now know the static type of the argument expression.
             * We can thus replace the stattype node by a seqtype node
             * carrying the respective type.
             * After typechecking there should be no more stattype nodes
             * left.
             */
            PFcnode_t *ret = PFcore_seqtype ( TY(L(p)) );
            ret->type = ret->sem.type;

            /* Set state label correctly before we return. */
            STATE_LABEL(ret) = PFtypecheck_state (OP_LABEL(ret), 0, 0);

            *p = *ret;
        }

        /* CoreExpr:           LocationSteps */
        case 25:
            break;

        /* LocationStep:       ancestor (SequenceType) */
        case 26:
            TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       ancestor_or_self (SequenceType) */
        case 27:
            TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       attribute (SequenceType) */
        case 28:
            /* attribute::node() maps to attribute::attribute() */
            if (PFty_subtype (PFty_xs_anyNode(), TY(L(p))))
                TY(p) = PFty_xs_anyAttribute();

            /* all other kind tests (elem|text|doc|pi|comment)
               provide empty results */
            else if (!PFty_subtype (TY(L(p)), PFty_xs_anyAttribute()))
                TY(p) = PFty_empty ();

            /* the following cases handle only attribute kind tests */

            /*
             * For attribute steps that do not contain any wildcards,
             * we know that there can be at most one match for each
             * context node.
             */
            else if (! (PFQNAME_NS_WILDCARD (TY(L(p)).name)
                        || PFQNAME_LOC_WILDCARD (TY(L(p)).name)))
                TY(p) = PFty_opt (TY(L(p)));
            else
                TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       child (SequenceType) */
        case 29:
            TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       descendant (SequenceType) */
        case 30:
            TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       descendant_or_self (SequenceType) */
        case 31:
            TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       following (SequenceType) */
        case 32:
            TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       following_sibling (SequenceType) */
        case 33:
            TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       parent (SequenceType) */
        case 34:
        {
            PFty_t possible_parent_types
                = PFty_choice (PFty_xs_anyElement (),
                               PFty_doc (PFty_xs_anyNode ()));

            if (PFty_subtype (possible_parent_types,
                              TY(L(p))))
                TY(p) = PFty_opt (possible_parent_types);
            else
                TY(p) = PFty_opt (TY(L(p)));
        } break;

        /* LocationStep:       preceding (SequenceType) */
        case 35:
            TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       preceding_sibling (SequenceType) */
        case 36:
            TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       self (SequenceType) */
        case 37:
            TY(p) = TY(L(p));
            break;
/* [STANDOFF] */
        case 38:
        /* LocationStep:       select_narrow (SequenceType) */
            TY(p) = PFty_star (TY(L(p)));
            break;

        /* LocationStep:       select_wide (SequenceType) */
        case 39:
            TY(p) = PFty_star (TY(L(p)));
            break;
/* [/STANDOFF] */

        /* LocationSteps:      locsteps (LocationStep, LocationSteps) */
        case 40:
            TY(p) = *PFty_simplify (PFty_quantifier (TY(R(p))) (TY(L(p))));
            break;

        /* LocationSteps:      locsteps (LocationStep, CoreExpr) */
        case 41:
            TY(p) = *PFty_simplify (PFty_quantifier (TY(R(p))) (TY(L(p))));
            break;

        /* CoreExpr:           apply (FunctionArgs) */
        case 42:
            /* resolve overloading,
             * any type errors will be detected during resolution
             */
            p->sem.fun = overload (p->sem.fun->qname, L(p));

            /* invoke specific typing rules for standard F&O functions 
             * (W3C XQuery Formal Semantics 6.2)
             */
            TY(p) = specific (p->sem.fun, L(p));

            break;

        /* FunctionArgs:       nil */
        case 43:
            break;

        /* FunctionArgs:       arg (FunctionArg, FunctionArgs) */
        case 44:
            TY(p) = TY(L(p));
            break;

        /* FunctionArg:        CoreExpr */
        case 45:
            break;


        /* CoreExpr:           elem (tag, CoreExpr) */
        case 46:
            TY(p) = *PFty_simplify (PFty_elem (L(p)->sem.qname, TY(R(p))));
            break;

        /* CoreExpr:           elem (CoreExpr, CoreExpr) */
        case 47:
        {   
            PFty_t t1 = TY(R(p));
            PFqname_t wild = PFqname (PFns_wild, NULL);

            if (!PFty_promotable (TY(L(p)), PFty_xs_QName ()))
                PFoops (OOPS_TYPECHECK,
                        "tag name in computed element constructor"
                        " has illegal type `%s'",
                        PFty_str (TY(L(p))));

            TY(p) = *PFty_simplify (PFty_elem (wild, t1));
        } break;

        /* CoreExpr:           attr (tag, CoreExpr) */
        case 48:
            TY(p) = *PFty_simplify (PFty_attr (L(p)->sem.qname,
                                               PFty_untypedAtomic ()));
            break;

        /* CoreExpr:           attr (CoreExpr, CoreExpr) */
        case 49:
        {
            PFqname_t wild = PFqname (PFns_wild, NULL);

            if (!PFty_promotable (TY(L(p)), PFty_xs_QName ()))
                PFoops (OOPS_TYPECHECK,
                        "tag name in computed attribute constructor"
                        " has illegal type '%s'",
                        PFty_str (TY(L(p))));

            TY(p)= *PFty_simplify (PFty_attr (wild, PFty_untypedAtomic ()));
        } break;

        /* CoreExpr:           text (CoreExpr) */
        case 50:
            /*
             * XQuery Draft, 3.7.3.4 (Sep 15, 2005 version):
             *
             * "If the result of atomization is an empty sequence,
             *  no text node is constructed."
             */
            if (PFty_subtype (PFty_empty (), TY(L(p))))
                TY(p) = PFty_opt (PFty_text ());
            else
                TY(p) = PFty_text ();
            break;

        /* CoreExpr:           doc (CoreExpr) */
        case 51:
            TY(p) = *PFty_simplify (PFty_doc (TY(L(p))));
            break;

        /* CoreExpr:           comment (CoreExpr) */
        case 52:
            TY(p) = PFty_comm ();
            break;

        /* CoreExpr:           pi (CoreExpr, CoreExpr) */
        case 53:
            if (!PFty_promotable (TY(L(p)), PFty_xs_string ()))
                PFoops (OOPS_TYPECHECK,
                        "target name in processing-instruction constructor"
                        " has illegal type '%s'",
                        PFty_str (TY(L(p))));
            TY(p) = PFty_pi (NULL);
            break;

        /* CoreExpr:           pi (lit_str, CoreExpr) */
        case 54:
            TY(L(p)) = PFty_xs_string ();
            TY(p) = PFty_pi (L(p)->sem.str);
            break;

        /* CoreExpr:           ordered (CoreExpr) */
        case 60:
            TY(p) = TY(L(p));
            break;

        /* CoreExpr:           unordered (CoreExpr) */
        case 61:
            TY(p) = TY(L(p));
            break;

        /* CoreExpr:           cast (SequenceType, CoreExpr) */
        case 65:
            if (!PFty_subtype (TY(L(p)), PFty_opt (PFty_atomic ())))
                PFoops (OOPS_TYPECHECK,
                        "err:XPTY0004: "
                        "casting is only allowed to an atomic type");

            /* check for occurrence indicator + */
            if (PFty_subtype (TY(R(p)), PFty_plus (PFty_item ())) &&
                !PFty_subtype (TY(R(p)), PFty_item ()))
                PFoops (OOPS_TYPECHECK, "err:XPTY0004");

            /* check for occurrence indicator ? */
            if (PFty_subtype (TY(L(p)), PFty_item ()) &&
                !PFty_subtype (TY(R(p)), PFty_item ()))
                PFoops (OOPS_TYPECHECK, "err:XPTY0004");

            TY(p) = TY(L(p));
            break;

        /* Atom:               var */
        case 66:
            /* W3C XQuery, 5.1.2
             *
             * E.varType(Var) = t
             * -------------------
             *    E |- Var : t
             */
            assert (p->sem.var);
            TY(p) = TY( p->sem.var );
            break;

        /* Atom:               LiteralValue */
        case 67:
            break;

        /* LiteralValue:       lit_str */
        case 68:
            /* W3C XQuery, 5.1.1
             *
             * --------------------------
             * Env |- lit_str : xs:string
             */
            TY(p) = PFty_xs_string ();
            break;

        /* LiteralValue:       lit_int */
        case 69:
            /* W3C XQuery, 5.1.1
             *
             * ---------------------------
             * Env |- lit_int : xs:integer
             */
            TY(p) = PFty_xs_integer ();
            break;

        /* LiteralValue:       lit_dec */
        case 70:
            /* W3C XQuery, 5.1.1
             *
             * ---------------------------
             * Env |- lit_dec : xs:decimal
             */
            TY(p) = PFty_xs_decimal ();
            break;

        /* LiteralValue:       lit_dbl */
        case 71:
            /* W3C XQuery, 5.1.1
             *
             * --------------------------
             * Env |- lit_dec : xs:double
             */
            TY(p) = PFty_xs_double ();
            break;

        /* LiteralValue:       true_ */
        case 72:
            /*
             * -------------------------
             * Env |- true_ : xs:boolean
             */
            TY(p) = PFty_xs_boolean ();
            break;

        /* LiteralValue:       false_ */
        case 73:
            /*
             * --------------------------
             * Env |- false_ : xs:boolean
             */
            TY(p) = PFty_xs_boolean ();
            break;

        /* LiteralValue:       empty */
        case 74:
            /*
             * ------------------
             * Env |- empty_ : ()
             */
            TY(p) = PFty_empty ();
            break;

        /* FunctionDecls:      nil */
        case 80:
            break;

        /* FunctionDecls:      fun_decls (FunctionDecl, FunctionDecls) */
        case 81:
            break;

        /* FunctionDecl:       fun_decl (ParamList, FunctionBody) */
        case 82:
            /*
             * See if function body matches function return type.
             */
            assert (p->sem.fun->sig_count == 1);
            if (!PFty_subtype (TY(R(p)), p->sem.fun->sigs[0].ret_ty))
                PFoops (OOPS_TYPECHECK,
                        "body of %s() evaluates to `%s' which is not "
                        "a subtype of `%s'",
                        PFqname_str (p->sem.fun->qname),
                        PFty_str (TY(R(p))),
                        PFty_str (p->sem.fun->sigs[0].ret_ty));
            break;

        /* ParamList:          nil */
        case 83:
            break;

        /* ParamList:          param (FunParam, ParamList) */
        case 84:
            break;

        /* FunctionBody:       CoreExpr */
        case 85:
            break;

        /* FunParam:           param (SequenceType, var) */
        case 86:
            /*
             * Bind parameter variable to the given type. We need this
             * to type-check the function body.
             */
            TY(R(p)) = TY(L(p));
            TY(R(p)->sem.var) = TY(L(p));
            break;

        /* CoreExpr:           recursion (var, seed (CoreExpr, CoreExpr)) */
        case 87:
            /* TOPDOWN */

            /*
             * Reduce the seed expression first.  We made sure that
             * the static type of the seed expression will be the type
             * given in the `with $var as ...' part of the input query
             * (or the default type `node*') in the translation to
             * Core.
             */
            reduce (kids[0], nts[0]);

            /*
             * Now attach this type to the recursion variable
             */
            TY(L(p)) = TY(RL(p));
            TY(L(p)->sem.var) = TY(RL(p));

            /*
             * Of course, that same type must also be a node type
             */
            if (! PFty_subtype (TY(RL(p)), PFty_star (PFty_node ())))
                PFoops (OOPS_TYPECHECK,
                        "recursion is only possible on node types "
                        "(got %s)", PFty_str (TY(RL(p))));

            /*
             * The type must also allow more than one node
             */
            if (! PFty_subtype (PFty_plus (TY(RL(p))), TY(RL(p))))
                PFoops (OOPS_TYPECHECK,
                        "the type given in a recursive expression "
                        "must allow sequences of length greater than one "
                        "(got %s)", PFty_str (TY(RL(p))));

            /*
             * Now we are ready to type-check the recursion body
             * (which may use the variable)
             */
            reduce (kids[1], nts[1]);

            /*
             * The same type is also the type of the overall expression.
             */
            TY(p) = TY(RL(p));

            break;

        /* CoreExpr:           xrpc (CoreExpr, CoreExpr) */
        case 88:
            if (! PFty_subtype (TY(L(p)), PFty_xs_string ()))
                PFoops (OOPS_TYPECHECK,
                        "the location specified in an `execute at' statement "
                        "must be a subtype of xs:string (got %s)",
                        PFty_str (TY(L(p))));
            TY(p) = TY(R(p));
            break;

        default:
            PFoops (OOPS_FATAL, "untranslated expression '%s'",
                    PFtypecheck_string[rule]);
            break;
    }
}

static void fun_not_found (PFqname_t qn, PFcnode_t *args) 
{
    PFarray_t *fns = PFenv_lookup (PFfun_env, qn);
    assert (fns);

    /* construct (error) message listing the actual argument types:
     * ": t1; t2; ...; tn" (NB: n >= 1 is guaranteed here)
     */
    PFarray_t *args_str = PFarray (sizeof (char), 128);
    char semi = ':';

    do {
        PFarray_printf (args_str, "%c %s", 
                        semi,
                        PFty_str (args->child[0]->type));
        semi = ';';
        args = args->child[1];
    } while (args->kind != c_nil);

    PFinfo (OOPS_TYPECHECK, 
            "no variant of function %s accepts the given argument type(s)%s",
            PFqname_str (qn),
            (char *) PFarray_at (args_str, 0));

    PFinfo (OOPS_TYPECHECK, "maybe you meant:");

    for (unsigned int i = 0; i < PFarray_last (fns); i++) {

        PFfun_t *fn       = *(PFfun_t **) PFarray_at (fns, i);

        for (unsigned j = 0; j < fn->sig_count; j++) {
            args_str = PFarray (sizeof (char), 512);

            PFfun_sig_t *sig = fn->sigs + j;

            PFarray_printf (args_str, "%s (", PFqname_str (fn->qname));

            for (unsigned int k = 0; k < fn->arity; k++) {
                PFarray_printf (args_str, "%s%s",
                    k ? ", " : "",
                    PFty_str (sig->par_ty[k]));
            }

            PFarray_printf (args_str, ") as %s", PFty_str (sig->ret_ty));

            PFinfo (OOPS_TYPECHECK, "  %s", (char *) PFarray_at (args_str, 0));
        }
    }

    PFoops (OOPS_TYPECHECK,
            "illegal arguments for function %s", PFqname_str (qn));
}


/**
 * Resolve function overloading.  In the list of functions of the same
 * name @a qn, find the first (most specific) to match the actual
 * argument types @a args (matching is based on `can be promoted to'
 * relationship).
 *
 * @attention NB. This relies on the list of functions for name @a qn
 * to be sorted: the most specific instance comes first (see
 * semantics/xquery_fo.c)
 *
 * @param qn name of (overloaded) function
 * @param args right-deep core tree of function arguments 
 *             arg (e1, arg (e2, ..., arg (en, nil)...))
 */
static PFfun_t *
overload (PFqname_t qn, PFcnode_t *args)
{
    PFty_t     zoo_ty;
    PFarray_t *fns;
    PFcnode_t *arg;
    PFfun_t *fn;
    unsigned int i, a;
    bool ari_match, zoo_match, arg_match;
    PFfun_t *candidate_fn = NULL;

    assert (args && (args->kind == c_nil || args->kind == c_arg));

    fns = PFenv_lookup (PFfun_env, qn);
    assert (fns);

    for (i = 0; i < PFarray_last (fns); i++) {
        fn    = *(PFfun_t **) PFarray_at (fns, i);
        arg   = args;

        /* can all actual argument types be promoted to
         * expected formal parameter types?
         */
        if (fn->sig_count == 1) {
            arg_match = true;
            ari_match = true;
            a         = 0;
            while (a < fn->arity) {
                /* test if function has at least the same
                   number of arguments as the tested function */
                if (arg->kind == c_nil)
                {
                    ari_match = false;
                    break;
                }

                arg_match = PFty_promotable (arg->child[0]->type,
                                             (fn->sigs[0].par_ty)[a]);

                /* apply function zero-or-one on the type of the argument */
                zoo_ty = *PFty_simplify (
                              PFty_opt (
                                  PFty_prime (
                                      PFty_defn (
                                          arg->child[0]->type))));

                /* and check if this type would be ok */
                zoo_match = PFty_promotable (zoo_ty, (fn->sigs[0].par_ty)[a]);

                /* if neither the original type
                   nor the zero-or-one type match
                   we give up */
                if (!arg_match && !zoo_match)
                    break;

                /* if the original type does not match
                   but the zero-or-one type matches 
                   we apply function zero-or-one on the input
                   and check the argument again */
                if (!arg_match && zoo_match) {
                    /* create the function fn:zero-or-one */
                    PFfun_t *zoo = function (PFqname (PFns_fn, "zero-or-one"));
                    PFcnode_t *ret = PFcore_apply (
                                         zoo,
                                         PFcore_arg (
                                             L(arg),
                                             PFcore_nil ()));

                    /* Set state label correctly before we return. */
                    STATE_LABEL(LR(ret)) = PFtypecheck_state (
                                               OP_LABEL(LR(ret)), 0, 0);
                    STATE_LABEL(L(ret))  = PFtypecheck_state (
                                               OP_LABEL(L(ret)),
                                               STATE_LABEL(LL(ret)),
                                               STATE_LABEL(LR(ret)));
                    STATE_LABEL(ret)     = PFtypecheck_state (
                                               OP_LABEL(ret),
                                               STATE_LABEL(L(ret)),
                                               0);

                    /* fix the types correctly */
                    TY(L(ret)) = TY(L(arg));
                    TY(ret)    = zoo_ty;
                    TY(arg)    = zoo_ty;

                    /* replace the argument by the function
                       zero-or-one applied to the argument */
                    L(arg) = ret;

                    /* re-check */
                }
                else {
                    /* continue */
                    a++;
                    arg = arg->child[1];
                }

                assert (arg);
            }

            /* yes, return this function (its the most specific match) */
            /* and it has the same number of arguments */
            if (ari_match && arg_match && arg->kind == c_nil)
                return fn;
        }
        else
            /* function with multiple signatures (dynamic overloading).
             * Type checking is a little bit tricky and is done in
             * specific. We assume that this is always the right function.
             * However, there might be a function later on the list that
             * matches exactly. Keep this candidate function and return
             * it if nothing better is found. We thus assume that there
             * is only one function with multiple signatures and several
             * functions with one signature.
             */
            candidate_fn = fn;
    }

    if (candidate_fn != NULL)
        return candidate_fn;

    fun_not_found (qn, args);

    /* just to pacify picky compilers; never reached due to "exit" in PFoops */
    return 0;
}

static PFty_t next_choice (PFty_t t) {
    if (t.type == ty_choice)
        return *(t.child[0]);
    return PFty_none ();
}

static PFty_t next_type (PFty_t t) {
    if (t.type == ty_choice)
        return *(t.child[1]);
    return t;
}

/**
 * Apply specific typing rules for standard XQuery F&O functions
 * (see W3C XQuery, 7.2)
 *
 * @bug
 *   This function has two arguments, both of which are even
 *   documented. But only one of them is actually used.
 *
 * @param fn function reference
 * @param args right-deep core tree of function arguments 
 * @return return type of @a fn when applied to arguments @a args
 */
static PFty_t
specific (PFfun_t *fn, PFcnode_t *args)
{
    assert (fn);
    assert (args && (args->kind == c_nil || args->kind == c_arg));

    /* Typing rules for fn:data() are described by the special
     * judgement `data on' (W3C FS 6.2.3), implemented in PFty_data_on()
     */
    if ((! PFqname_eq (fn->qname, PFqname (PFns_fn, "data")))
        || (! PFqname_eq (fn->qname, PFqname (PFns_pf, "typed-value")))) {
        /* fn:data() gets exactly one argument */
        assert (args->kind == c_arg && R(args)->kind == c_nil);
        return *PFty_simplify (
                (PFty_quantifier (TY(L(args)))
                    (PFty_data_on (TY(L(args))))));
    }

    /* specific typing rules for fn:insert-before() */
    if (! PFqname_eq (fn->qname, PFqname (PFns_fn, "insert-before"))) {
        assert (args->kind == c_arg && R(args)->kind == c_arg &&
                R(R(args))->kind == c_arg && R(R(R(args)))->kind == c_nil);

        PFty_t seq_type = PFty_seq (PFty_defn (TY(L(args))),
                                    PFty_defn (TY(L(R(R(args))))));

        return *PFty_simplify (PFty_quantifier (seq_type)
                                   (PFty_prime (seq_type)));
    }

    /* specific typing rules for fn:remove() */
    if (! PFqname_eq (fn->qname, PFqname (PFns_fn, "remove"))) {
        assert (args->kind == c_arg && R(args)->kind == c_arg &&
                R(R(args))->kind == c_nil);
        return *PFty_simplify (
                    PFty_opt (PFty_quantifier (TY(L(args)))
                                  (PFty_prime (PFty_defn(TY(L(args)))))));
    }

    /* specific typing rules for fn:subsequence() */
    if (! PFqname_eq (fn->qname, PFqname (PFns_fn, "subsequence"))) {

        assert (args->kind == c_arg);

        /*
         * The W3C Formal Semantics demands a special treatment of the
         * case
         *    fn:subsequence (Expr, Num, 1)
         * (Use quantifier `?' if last argument is literal 1.)
         *
         * However, we won't see any literal constants here, as they
         * have been wrapped into fn:data() and others.  We just ignore
         * that W3C rule.  (Current draft is buggy with that respect
         * anyway.  No one knows, how those rules will look like in
         * upcoming drafts...)
         */

        /* use occurrence indicator `?' if expr contains at most one item */
        if (PFty_subtype (TY(L(args)), PFty_opt (PFty_item ())))
            return *PFty_simplify (PFty_opt (
                        PFty_prime (PFty_defn(TY(L(args))))));
        /* otherwise we cannot do more than `*' */
        else
            return *PFty_simplify (PFty_star (
                        PFty_prime (PFty_defn (TY(L(args))))));
    }

    if (! PFqname_eq (fn->qname, PFqname (PFns_fn, "distinct-values")) ||
        ! PFqname_eq (fn->qname, PFqname (PFns_fn, "reverse")) ||
        ! PFqname_eq (fn->qname, PFqname (PFns_fn, "trace")) ||
        ! PFqname_eq (fn->qname, PFqname (PFns_fn, "unordered"))) {
        return *PFty_simplify (
                    (PFty_quantifier (PFty_defn (TY(L(args))))
                         (PFty_prime (PFty_defn (TY(L(args)))))));
    }

    if (! PFqname_eq (fn->qname, PFqname (PFns_pf, "query-cache"))) {
        return TY(R(args));
    }

    if (! PFqname_eq (fn->qname, PFqname (PFns_fn, "zero-or-one"))) {
        return *PFty_simplify (PFty_opt (PFty_prime (PFty_defn (TY(L(args))))));
    }

    if (! PFqname_eq (fn->qname, PFqname (PFns_fn, "exactly-one"))) {
        return *PFty_simplify (PFty_prime (PFty_defn (TY(L(args)))));
    }

    if (! PFqname_eq (fn->qname, PFqname (PFns_op, "union"))) {
        PFty_t seq_type = PFty_seq (PFty_defn (TY(L(args))),
                                    PFty_defn (TY(RL(args))));
        return *PFty_simplify (
                    (PFty_quantifier (seq_type))
                        (PFty_prime (seq_type)));
    }

    if (! PFqname_eq (fn->qname, PFqname (PFns_op, "intersect"))) {
        PFty_t seq_type = PFty_seq (PFty_defn (TY(L(args))),
                                    PFty_defn (TY(RL(args))));
        return *PFty_simplify (
                    PFty_opt (
                        (PFty_quantifier (seq_type))
                            (PFty_prime (seq_type))));
    }

    if (! PFqname_eq (fn->qname, PFqname (PFns_op, "except"))) {
        PFty_t left_type = PFty_defn (TY(L(args)));
        return *PFty_simplify (
                    PFty_opt (
                        (PFty_quantifier (left_type))
                            (PFty_prime (left_type))));
    }

    /* #pf:distinct-doc-order-or-atomic-sequence() splits up the typing
       into a case for atomic values and one for node values */
    if (! PFqname_eq (fn->qname, 
                      PFqname (
                          PFns_pf, 
                          "distinct-doc-order-or-atomic-sequence"))) {
        /* #pf:distinct-doc-order-or-atomic-sequence 
           gets exactly one argument */
        assert (args->kind == c_arg && R(args)->kind == c_nil);

        if (PFty_subtype (TY(L(args)), PFty_star (PFty_node ())))
            return *PFty_simplify (
                    (PFty_quantifier (TY(L(args))))
                        (PFty_prime (PFty_defn (TY(L(args))))));
        else if (PFty_subtype (TY(L(args)), PFty_star (PFty_atomic ())))
            return TY(L(args));
        else
            PFoops (OOPS_TYPECHECK,
                    "err:XPTY0018: the result of the last step "
                    "in a path expression contains both nodes "
                    "and atomic values");
    }

    /* #pf:distinct-doc-order() more or less returns its input */
    if (! PFqname_eq (fn->qname, PFqname (PFns_pf, "distinct-doc-order"))) {
        /* #pf:distinct-doc-order gets exactly one argument */
        assert (args->kind == c_arg && R(args)->kind == c_nil);

        return *PFty_simplify (
                (PFty_quantifier (TY(L(args))))
                    (PFty_prime (PFty_defn (TY(L(args))))));
    }

    /* Typing rules for #pf:item-sequence-to-node-sequence() are described
     * by the special judgment `is2ns', implemented in PFty_is2ns(),
     * which reduces atomic types to text().
     */
    if ((! PFqname_eq (fn->qname,
                       PFqname (PFns_pf, "item-sequence-to-node-sequence")))) {
        assert (args->kind == c_arg && R(args)->kind == c_nil);
        return *PFty_simplify ((PFty_is2ns (PFty_defn (TY(L(args))))));
    }

    /* If #pf:merge-adjacent-text-nodes does not consume textnodes
     * the output has the same type as the input.
     */
    if ((! PFqname_eq (fn->qname,
                       PFqname (PFns_pf, "merge-adjacent-text-nodes"))) &&
        !PFty_subtype (PFty_text(), PFty_prime (PFty_defn (TY(L(args)))))) {
        /* #pf:merge-adjacent-text-nodes gets exactly one argument */
        assert (args->kind == c_arg && R(args)->kind == c_nil);

        return TY(L(args));
    }


    if (fn->sig_count > 1) {
        /* special handing for functions with multiple signatures,
         * but one implementation ("dynamic overloading")
         */
        /* currently, only functions with 2 parameters are supported.
         * So we can use simple for loops and we do not need complex
         * permutation stuff.
         */
        assert (fn->arity == 2);
        PFty_t ret_type = PFty_none ();
        PFty_t arg1_type = PFty_defn (TY(L(args)));
        PFty_t arg2_type = PFty_defn (TY(L(R(args))));

        /* iterate through the possible types of argument 1 */
        for (PFty_t c1 = PFty_normalize_choice (arg1_type); 
             c1.type != ty_none;
             c1 = next_choice (c1)) 
        {
            PFty_t t1 = next_type (c1);

            /* iterate through the possible types of argument 2 */
            for (PFty_t c2 = PFty_normalize_choice (arg2_type); 
                        c2.type != ty_none;
                        c2 = next_choice (c2))
            {
                PFty_t t2 = next_type (c2);

                bool found = false;
                /* for every combination, check if we have a matching
                 * signature.
                 */
                for (unsigned int i = 0; i < fn->sig_count && !found; i++) {
                    PFfun_sig_t *sig = fn->sigs + i;

                    if (PFty_promotable (t1, sig->par_ty[0])
                        && PFty_promotable (t2, sig->par_ty[1]))
                    {
                        found = true;
                        /* the return type is the combination of
                         * the return types of every matching signature
                         */
                        if (ret_type.type != ty_none)
                            ret_type = PFty_choice (ret_type, sig->ret_ty);
                        else
                            ret_type = sig->ret_ty;
                    }
                }
                if (!found)
                    fun_not_found (fn->qname, args);
            }
        }

        return ret_type;
    }

    return fn->sigs[0].ret_ty;
}



/**
 * Type check XQuery Core tree.
 *
 * @param r root of the XQuery Core tree
 * @return @a r
 */
PFcnode_t *
PFty_check (PFcnode_t *r)
{
    assert (r);

    /* label the core tree bottom up */
    PFtypecheck_label (r);

    /* invoke compilation */
    reduce (r, 1);

    return r;
}


/* vim:set shiftwidth=4 expandtab filetype=c: */
